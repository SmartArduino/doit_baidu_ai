exports.config = {
  env: "prod-mp",
  apiUrl: "https://toystory.guoguozhiwan.com",
};
