var e = require("../common/vendor.js"),
  n = require("./config.dev.h5.js"),
  i = require("./config.dev.mp-weixin.js"),
  o = require("./config.prod.mp-weixin.js");
exports.getConfig = function () {
  console.log("mp-weixin");
  var r = e.index.getAccountInfoSync().miniProgram.envVersion;
  return (
    console.log("envVersion", r),
    "develop" == r || "trial" == r
      ? i.config
      : "release" == r
      ? o.config
      : n.config
  );
};
