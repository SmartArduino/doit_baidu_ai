exports.config = {
  env: "test-mp",
  apiUrl: "http://toystory-test.guoguozhiwan.com",
};
