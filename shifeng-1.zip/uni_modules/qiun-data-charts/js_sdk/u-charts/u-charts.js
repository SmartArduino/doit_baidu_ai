var t = require("../../../../@babel/runtime/helpers/slicedToArray"),
  e = require("../../../../@babel/runtime/helpers/typeof"),
  a = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper"),
  i = {
    version: "v2.5.0-20230101",
    yAxisWidth: 15,
    xAxisHeight: 22,
    padding: [10, 10, 10, 10],
    rotate: !1,
    fontSize: 13,
    fontColor: "#666666",
    dataPointShape: ["circle", "circle", "circle", "circle"],
    color: [
      "#1890FF",
      "#91CB74",
      "#FAC858",
      "#EE6666",
      "#73C0DE",
      "#3CA272",
      "#FC8452",
      "#9A60B4",
      "#ea7ccc",
    ],
    linearColor: [
      "#0EE2F8",
      "#2BDCA8",
      "#FA7D8D",
      "#EB88E2",
      "#2AE3A0",
      "#0EE2F8",
      "#EB88E2",
      "#6773E3",
      "#F78A85",
    ],
    pieChartLinePadding: 15,
    pieChartTextPadding: 5,
    titleFontSize: 20,
    subtitleFontSize: 15,
    radarLabelTextMargin: 13,
  },
  o = function (t) {
    for (
      var e = arguments.length, a = new Array(e > 1 ? e - 1 : 0), i = 1;
      i < e;
      i++
    )
      a[i - 1] = arguments[i];
    if (null == t)
      throw new TypeError(
        "[uCharts] Cannot convert undefined or null to object"
      );
    if (!a || a.length <= 0) return t;
    function o(t, e) {
      for (var a in e)
        t[a] =
          t[a] && "[object Object]" === t[a].toString()
            ? o(t[a], e[a])
            : (t[a] = e[a]);
      return t;
    }
    return (
      a.forEach(function (e) {
        t = o(t, e);
      }),
      t
    );
  },
  r = {
    toFixed: function (t, e) {
      return (e = e || 2), this.isFloat(t) && (t = t.toFixed(e)), t;
    },
    isFloat: function (t) {
      return t % 1 != 0;
    },
    approximatelyEqual: function (t, e) {
      return Math.abs(t - e) < 1e-10;
    },
    isSameSign: function (t, e) {
      return (
        (Math.abs(t) === t && Math.abs(e) === e) ||
        (Math.abs(t) !== t && Math.abs(e) !== e)
      );
    },
    isSameXCoordinateArea: function (t, e) {
      return this.isSameSign(t.x, e.x);
    },
    isCollision: function (t, e) {
      return (
        (t.end = {}),
        (t.end.x = t.start.x + t.width),
        (t.end.y = t.start.y - t.height),
        (e.end = {}),
        (e.end.x = e.start.x + e.width),
        (e.end.y = e.start.y - e.height),
        !(
          e.start.x > t.end.x ||
          e.end.x < t.start.x ||
          e.end.y > t.start.y ||
          e.start.y < t.end.y
        )
      );
    },
  };
function n(t, e) {
  var a = t.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i, function (t, e, a, i) {
      return e + e + a + a + i + i;
    }),
    i = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(a);
  return (
    "rgba(" +
    parseInt(i[1], 16) +
    "," +
    parseInt(i[2], 16) +
    "," +
    parseInt(i[3], 16) +
    "," +
    e +
    ")"
  );
}
function l(t, e, a) {
  if (isNaN(t)) throw new Error("[uCharts] series数据需为Number格式");
  (a = a || 10), (e = e || "upper");
  for (var i = 1; a < 1; ) (a *= 10), (i *= 10);
  for (t = "upper" === e ? Math.ceil(t * i) : Math.floor(t * i); t % a != 0; )
    if ("upper" === e) {
      if (t == t + 1) break;
      t++;
    } else t--;
  return t / i;
}
function s(t, e, a, i, o) {
  var r = o.width - o.area[1] - o.area[3],
    n = a.eachSpacing * (o.chartData.xAxisData.xAxisPoints.length - 1);
  "mount" == o.type &&
    o.extra &&
    o.extra.mount &&
    o.extra.mount.widthRatio &&
    o.extra.mount.widthRatio > 1 &&
    (o.extra.mount.widthRatio > 2 && (o.extra.mount.widthRatio = 2),
    (n += (o.extra.mount.widthRatio - 1) * a.eachSpacing));
  var l = e;
  return (
    e >= 0
      ? ((l = 0),
        t.uevent.trigger("scrollLeft"),
        (t.scrollOption.position = "left"),
        (o.xAxis.scrollPosition = "left"))
      : Math.abs(e) >= n - r
      ? ((l = r - n),
        t.uevent.trigger("scrollRight"),
        (t.scrollOption.position = "right"),
        (o.xAxis.scrollPosition = "right"))
      : ((t.scrollOption.position = e), (o.xAxis.scrollPosition = e)),
    l
  );
}
function h(t, e, a) {
  function i(t) {
    for (; t < 0; ) t += 2 * Math.PI;
    for (; t > 2 * Math.PI; ) t -= 2 * Math.PI;
    return t;
  }
  return (
    (t = i(t)),
    (e = i(e)) > (a = i(a)) &&
      ((a += 2 * Math.PI), t < e && (t += 2 * Math.PI)),
    t >= e && t <= a
  );
}
function c(t, e) {
  function a(t, e) {
    return (
      !(!t[e - 1] || !t[e + 1]) &&
      (t[e].y >= Math.max(t[e - 1].y, t[e + 1].y) ||
        t[e].y <= Math.min(t[e - 1].y, t[e + 1].y))
    );
  }
  function i(t, e) {
    return (
      !(!t[e - 1] || !t[e + 1]) &&
      (t[e].x >= Math.max(t[e - 1].x, t[e + 1].x) ||
        t[e].x <= Math.min(t[e - 1].x, t[e + 1].x))
    );
  }
  var o = 0.2,
    r = 0.2,
    n = null,
    l = null,
    s = null,
    h = null;
  if (
    (e < 1
      ? ((n = t[0].x + (t[1].x - t[0].x) * o),
        (l = t[0].y + (t[1].y - t[0].y) * o))
      : ((n = t[e].x + (t[e + 1].x - t[e - 1].x) * o),
        (l = t[e].y + (t[e + 1].y - t[e - 1].y) * o)),
    e > t.length - 3)
  ) {
    var c = t.length - 1;
    (s = t[c].x - (t[c].x - t[c - 1].x) * r),
      (h = t[c].y - (t[c].y - t[c - 1].y) * r);
  } else
    (s = t[e + 1].x - (t[e + 2].x - t[e].x) * r),
      (h = t[e + 1].y - (t[e + 2].y - t[e].y) * r);
  return (
    a(t, e + 1) && (h = t[e + 1].y),
    a(t, e) && (l = t[e].y),
    i(t, e + 1) && (s = t[e + 1].x),
    i(t, e) && (n = t[e].x),
    (l >= Math.max(t[e].y, t[e + 1].y) || l <= Math.min(t[e].y, t[e + 1].y)) &&
      (l = t[e].y),
    (h >= Math.max(t[e].y, t[e + 1].y) || h <= Math.min(t[e].y, t[e + 1].y)) &&
      (h = t[e + 1].y),
    (n >= Math.max(t[e].x, t[e + 1].x) || n <= Math.min(t[e].x, t[e + 1].x)) &&
      (n = t[e].x),
    (s >= Math.max(t[e].x, t[e + 1].x) || s <= Math.min(t[e].x, t[e + 1].x)) &&
      (s = t[e + 1].x),
    { ctrA: { x: n, y: l }, ctrB: { x: s, y: h } }
  );
}
function x(t, e, a) {
  return { x: a.x + t, y: a.y - e };
}
function d(t, e) {
  if (e)
    for (; r.isCollision(t, e); )
      t.start.x > 0
        ? t.start.y--
        : t.start.x < 0 || t.start.y > 0
        ? t.start.y++
        : t.start.y--;
  return t;
}
function p(t, e, a) {
  for (var i = 0, o = 0; o < t.length; o++) {
    var r = t[o];
    if (
      (r.color || ((r.color = a.color[i]), (i = (i + 1) % a.color.length)),
      r.linearIndex || (r.linearIndex = o),
      r.index || (r.index = 0),
      r.type || (r.type = e.type),
      void 0 === r.show && (r.show = !0),
      r.type || (r.type = e.type),
      r.pointShape || (r.pointShape = "circle"),
      !r.legendShape)
    )
      switch (r.type) {
        case "line":
          r.legendShape = "line";
          break;
        case "column":
        case "bar":
          r.legendShape = "rect";
          break;
        case "area":
        case "mount":
          r.legendShape = "triangle";
          break;
        default:
          r.legendShape = "circle";
      }
  }
  return t;
}
function f(t, e, a, i) {
  var o = e || [];
  if (
    ("custom" == t && 0 == o.length && (o = i.linearColor),
    "custom" == t && o.length < a.length)
  )
    for (var r = a.length - o.length, n = 0; n < r; n++)
      o.push(i.linearColor[(n + 1) % i.linearColor.length]);
  return o;
}
function u(t, e, a) {
  var i = 0;
  if (
    ((t = String(t)),
    !1 !== a && void 0 !== a && a.setFontSize && a.measureText)
  )
    return a.setFontSize(e), a.measureText(t).width;
  t = t.split("");
  for (var o = 0; o < t.length; o++) {
    var r = t[o];
    /[a-zA-Z]/.test(r)
      ? (i += 7)
      : /[0-9]/.test(r)
      ? (i += 5.5)
      : /\./.test(r)
      ? (i += 2.7)
      : /-/.test(r)
      ? (i += 3.25)
      : /:/.test(r)
      ? (i += 2.5)
      : /[\u4e00-\u9fa5]/.test(r)
      ? (i += 10)
      : /\(|\)/.test(r)
      ? (i += 3.73)
      : /\s/.test(r)
      ? (i += 2.5)
      : /%/.test(r)
      ? (i += 8)
      : (i += 10);
  }
  return (i * e) / 10;
}
function g(t) {
  return t.reduce(function (t, e) {
    return (t.data ? t.data : t).concat(e.data);
  }, []);
}
function y(t, e) {
  for (var a = new Array(e), i = 0; i < a.length; i++) a[i] = 0;
  for (var o = 0; o < t.length; o++)
    for (i = 0; i < a.length; i++) a[i] += t[o].data[i];
  return t.reduce(function (t, e) {
    return (t.data ? t.data : t).concat(e.data).concat(a);
  }, []);
}
function v(t, e, a) {
  var i, o;
  return (
    t.clientX
      ? e.rotate
        ? ((o = e.height - t.clientX * e.pix),
          (i =
            (t.pageY -
              a.currentTarget.offsetTop -
              (e.height / e.pix / 2) * (e.pix - 1)) *
            e.pix))
        : ((i = t.clientX * e.pix),
          (o =
            (t.pageY -
              a.currentTarget.offsetTop -
              (e.height / e.pix / 2) * (e.pix - 1)) *
            e.pix))
      : e.rotate
      ? ((o = e.height - t.x * e.pix), (i = t.y * e.pix))
      : ((i = t.x * e.pix), (o = t.y * e.pix)),
    { x: i, y: o }
  );
}
function m(t, e, a) {
  var i = [],
    o = [],
    r = e.constructor.toString().indexOf("Array") > -1;
  if (r) for (var n = w(t), l = 0; l < a.length; l++) o.push(n[a[l]]);
  else o = t;
  for (var s = 0; s < o.length; s++) {
    var h = o[s],
      c = -1;
    if (
      ((c = r ? e[s] : e), null !== h.data[c] && void 0 !== h.data[c] && h.show)
    ) {
      var x = {};
      (x.color = h.color),
        (x.type = h.type),
        (x.style = h.style),
        (x.pointShape = h.pointShape),
        (x.disableLegend = h.disableLegend),
        (x.legendShape = h.legendShape),
        (x.name = h.name),
        (x.show = h.show),
        (x.data = h.formatter ? h.formatter(h.data[c]) : h.data[c]),
        i.push(x);
    }
  }
  return i;
}
function S(t, e, a) {
  var i = t.map(function (t) {
    return u(t, e, a);
  });
  return Math.max.apply(null, i);
}
function b(t) {
  for (var e = (2 * Math.PI) / t, a = [], i = 0; i < t; i++) a.push(e * i);
  return a.map(function (t) {
    return -1 * t + Math.PI / 2;
  });
}
function A(t, e, a, i, o) {
  var r = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : {},
    n = e.chartData.calPoints ? e.chartData.calPoints : [],
    l = {};
  if (i.length > 0) {
    for (var s = [], h = 0; h < i.length; h++) s.push(n[i[h]]);
    l = s[0][a[0]];
  } else
    for (var c = 0; c < n.length; c++)
      if (n[c][a]) {
        l = n[c][a];
        break;
      }
  var x = t.map(function (t) {
      var i = null;
      return (
        e.categories && e.categories.length > 0 && (i = o[a]),
        {
          text: r.formatter ? r.formatter(t, i, a, e) : t.name + ": " + t.data,
          color: t.color,
          legendShape:
            "auto" == e.extra.tooltip.legendShape
              ? t.legendShape
              : e.extra.tooltip.legendShape,
        }
      );
    }),
    d = { x: Math.round(l.x), y: Math.round(l.y) };
  return { textList: x, offset: d };
}
function T(t, e, a, i) {
  var o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {},
    r = e.chartData.xAxisPoints[a] + e.chartData.eachSpacing / 2,
    n = t.map(function (t) {
      return {
        text: o.formatter ? o.formatter(t, i[a], a, e) : t.name + ": " + t.data,
        color: t.color,
        disableLegend: !!t.disableLegend,
        legendShape:
          "auto" == e.extra.tooltip.legendShape
            ? t.legendShape
            : e.extra.tooltip.legendShape,
      };
    });
  n = n.filter(function (t) {
    if (!0 !== t.disableLegend) return t;
  });
  var l = { x: Math.round(r), y: 0 };
  return { textList: n, offset: l };
}
function P(t, e, a, i, o, r) {
  var n = a.chartData.calPoints,
    l = r.color.upFill,
    s = r.color.downFill,
    h = [l, l, s, l],
    c = [];
  e.map(function (e) {
    0 == i
      ? e.data[1] - e.data[0] < 0
        ? (h[1] = s)
        : (h[1] = l)
      : (e.data[0] < t[i - 1][1] && (h[0] = s),
        e.data[1] < e.data[0] && (h[1] = s),
        e.data[2] > t[i - 1][1] && (h[2] = l),
        e.data[3] < t[i - 1][1] && (h[3] = s));
    var o = {
        text: "开盘：" + e.data[0],
        color: h[0],
        legendShape:
          "auto" == a.extra.tooltip.legendShape
            ? e.legendShape
            : a.extra.tooltip.legendShape,
      },
      r = {
        text: "收盘：" + e.data[1],
        color: h[1],
        legendShape:
          "auto" == a.extra.tooltip.legendShape
            ? e.legendShape
            : a.extra.tooltip.legendShape,
      },
      n = {
        text: "最低：" + e.data[2],
        color: h[2],
        legendShape:
          "auto" == a.extra.tooltip.legendShape
            ? e.legendShape
            : a.extra.tooltip.legendShape,
      },
      x = {
        text: "最高：" + e.data[3],
        color: h[3],
        legendShape:
          "auto" == a.extra.tooltip.legendShape
            ? e.legendShape
            : a.extra.tooltip.legendShape,
      };
    c.push(o, r, n, x);
  });
  for (var x = [], d = { x: 0, y: 0 }, p = 0; p < n.length; p++) {
    var f = n[p];
    void 0 !== f[i] && null !== f[i] && x.push(f[i]);
  }
  return (d.x = Math.round(x[0][0].x)), { textList: c, offset: d };
}
function w(t) {
  for (var e = [], a = 0; a < t.length; a++) 1 == t[a].show && e.push(t[a]);
  return e;
}
function C(t, e, a) {
  return (
    t.x <= e.width - e.area[1] + 10 &&
    t.x >= e.area[3] - 10 &&
    t.y >= e.area[0] &&
    t.y <= e.height - e.area[2]
  );
}
function M(t, e, a) {
  return Math.pow(t.x - e.x, 2) + Math.pow(t.y - e.y, 2) <= Math.pow(a, 2);
}
function _(t, e) {
  var a = [],
    i = [];
  return (
    t.forEach(function (t, o) {
      e.connectNulls
        ? null !== t && i.push(t)
        : null !== t
        ? i.push(t)
        : (i.length && a.push(i), (i = []));
    }),
    i.length && a.push(i),
    a
  );
}
function F(t, e, a, i, o) {
  var r = {
      angle: 0,
      xAxisHeight: e.xAxis.lineHeight * e.pix + e.xAxis.marginTop * e.pix,
    },
    n = e.xAxis.fontSize * e.pix,
    l = t.map(function (t, a) {
      var i = e.xAxis.formatter ? e.xAxis.formatter(t, a, e) : t;
      return u(String(i), n, o);
    }),
    s = Math.max.apply(this, l);
  if (1 == e.xAxis.rotateLabel) {
    r.angle = (e.xAxis.rotateAngle * Math.PI) / 180;
    var h = e.xAxis.marginTop * e.pix * 2 + Math.abs(s * Math.sin(r.angle));
    (h =
      h < n + e.xAxis.marginTop * e.pix * 2
        ? h + e.xAxis.marginTop * e.pix * 2
        : h),
      (r.xAxisHeight = h);
  }
  return (
    e.enableScroll && e.xAxis.scrollShow && (r.xAxisHeight += 6 * e.pix),
    e.xAxis.disabled && (r.xAxisHeight = 0),
    r
  );
}
function D(t, a, i, n) {
  var l = o({}, { type: "" }, a.extra.bar),
    s = {
      angle: 0,
      xAxisHeight: a.xAxis.lineHeight * a.pix + a.xAxis.marginTop * a.pix,
    };
  (s.ranges = (function (t, a, i, o) {
    var r,
      n = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : -1;
    r = "stack" == o ? y(t, a.categories.length) : g(t);
    var l = [];
    (r = r.filter(function (t) {
      return "object" === e(t) && null !== t
        ? t.constructor.toString().indexOf("Array") > -1
          ? null !== t
          : null !== t.value
        : null !== t;
    })).map(function (t) {
      "object" === e(t)
        ? t.constructor.toString().indexOf("Array") > -1
          ? "candle" == a.type
            ? t.map(function (t) {
                l.push(t);
              })
            : l.push(t[0])
          : l.push(t.value)
        : l.push(t);
    });
    var s = 0,
      h = 0;
    if (
      (l.length > 0 &&
        ((s = Math.min.apply(this, l)), (h = Math.max.apply(this, l))),
      n > -1
        ? ("number" == typeof a.xAxis.data[n].min &&
            (s = Math.min(a.xAxis.data[n].min, s)),
          "number" == typeof a.xAxis.data[n].max &&
            (h = Math.max(a.xAxis.data[n].max, h)))
        : ("number" == typeof a.xAxis.min && (s = Math.min(a.xAxis.min, s)),
          "number" == typeof a.xAxis.max && (h = Math.max(a.xAxis.max, h))),
      s === h)
    ) {
      var c = h || 10;
      h += c;
    }
    for (
      var x = s, d = h, p = [], f = (d - x) / a.xAxis.splitNumber, u = 0;
      u <= a.xAxis.splitNumber;
      u++
    )
      p.push(x + f * u);
    return p;
  })(t, a, i, l.type)),
    (s.rangesFormat = s.ranges.map(function (t) {
      return (t = r.toFixed(t, 2));
    }));
  var h = s.ranges.map(function (t) {
    return (t = r.toFixed(t, 2));
  });
  return (
    (s = Object.assign(s, j(h, a))).eachSpacing,
    h.map(function (t) {
      return u(t, a.xAxis.fontSize * a.pix, n);
    }),
    !0 === a.xAxis.disabled && (s.xAxisHeight = 0),
    s
  );
}
function L(t, e, a, i, o) {
  var r = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 1,
    n = o.extra.radar || {};
  n.max = n.max || 0;
  for (
    var l = Math.max(n.max, Math.max.apply(null, g(i))),
      s = [],
      h = function () {
        var o = i[c],
          n = {};
        (n.color = o.color),
          (n.legendShape = o.legendShape),
          (n.pointShape = o.pointShape),
          (n.data = []),
          o.data.forEach(function (i, o) {
            var s = {};
            (s.angle = t[o]),
              (s.proportion = i / l),
              (s.value = i),
              (s.position = x(
                a * s.proportion * r * Math.cos(s.angle),
                a * s.proportion * r * Math.sin(s.angle),
                e
              )),
              n.data.push(s);
          }),
          s.push(n);
      },
      c = 0;
    c < i.length;
    c++
  )
    h();
  return s;
}
function k(t, e) {
  for (
    var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
      i = 0,
      o = 0,
      r = 0;
    r < t.length;
    r++
  ) {
    var n = t[r];
    (n.data = null === n.data ? 0 : n.data), (i += n.data);
  }
  for (var l = 0; l < t.length; l++) {
    var s = t[l];
    (s.data = null === s.data ? 0 : s.data),
      (s._proportion_ = 0 === i ? (1 / t.length) * a : (s.data / i) * a),
      (s._radius_ = e);
  }
  for (var h = 0; h < t.length; h++) {
    var c = t[h];
    (c._start_ = o), (o += 2 * c._proportion_ * Math.PI);
  }
  return t;
}
function I(t, e, a, i) {
  for (
    var o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1,
      r = 0;
    r < t.length;
    r++
  )
    "funnel" == a.type
      ? (t[r].radius = (t[r].data / t[0].data) * e * o)
      : (t[r].radius = ((i * (t.length - r)) / (i * t.length)) * e * o),
      (t[r]._proportion_ = t[r].data / t[0].data);
  return t;
}
function O(t, e, a, i) {
  for (
    var o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1,
      r = 0,
      n = 0,
      l = [],
      s = 0;
    s < t.length;
    s++
  ) {
    var h = t[s];
    (h.data = null === h.data ? 0 : h.data), (r += h.data), l.push(h.data);
  }
  for (
    var c = Math.min.apply(null, l),
      x = Math.max.apply(null, l),
      d = i - a,
      p = 0;
    p < t.length;
    p++
  ) {
    var f = t[p];
    (f.data = null === f.data ? 0 : f.data),
      0 === r
        ? ((f._proportion_ = (1 / t.length) * o),
          (f._rose_proportion_ = (1 / t.length) * o))
        : ((f._proportion_ = (f.data / r) * o),
          (f._rose_proportion_ =
            "area" == e ? (1 / t.length) * o : (f.data / r) * o)),
      (f._radius_ = a + d * ((f.data - c) / (x - c)) || i);
  }
  for (var u = 0; u < t.length; u++) {
    var g = t[u];
    (g._start_ = n), (n += 2 * g._rose_proportion_ * Math.PI);
  }
  return t;
}
function z(t, e) {
  var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
  1 == a && (a = 0.999999);
  for (var i = 0; i < t.length; i++) {
    var o = t[i];
    o.data = null === o.data ? 0 : o.data;
    var r = void 0;
    (r =
      "circle" == e.type
        ? 2
        : "ccw" == e.direction
        ? e.startAngle < e.endAngle
          ? 2 + e.startAngle - e.endAngle
          : e.startAngle - e.endAngle
        : e.endAngle < e.startAngle
        ? 2 + e.endAngle - e.startAngle
        : e.startAngle - e.endAngle),
      (o._proportion_ = r * o.data * a + e.startAngle),
      "ccw" == e.direction && (o._proportion_ = e.startAngle - r * o.data * a),
      o._proportion_ >= 2 && (o._proportion_ = o._proportion_ % 2);
  }
  return t;
}
function W(t, e) {
  var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
  1 == a && (a = 0.999999);
  for (var i = 0; i < t.length; i++) {
    var o = t[i];
    o.data = null === o.data ? 0 : o.data;
    var r = void 0;
    (r =
      "circle" == e.type
        ? 2
        : e.endAngle < e.startAngle
        ? 2 + e.endAngle - e.startAngle
        : e.startAngle - e.endAngle),
      (o._proportion_ = r * o.data * a + e.startAngle),
      o._proportion_ >= 2 && (o._proportion_ = o._proportion_ % 2);
  }
  return t;
}
function R(t, e, a) {
  var i;
  i = a < e ? 2 + a - e : e - a;
  for (var o = e, r = 0; r < t.length; r++)
    (t[r].value = null === t[r].value ? 0 : t[r].value),
      (t[r]._startAngle_ = o),
      (t[r]._endAngle_ = i * t[r].value + e),
      t[r]._endAngle_ >= 2 && (t[r]._endAngle_ = t[r]._endAngle_ % 2),
      (o = t[r]._endAngle_);
  return t;
}
function E(t, e, a) {
  for (
    var i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1,
      o = 0;
    o < t.length;
    o++
  ) {
    var r = t[o];
    if (((r.data = null === r.data ? 0 : r.data), "auto" == a.pointer.color)) {
      for (var n = 0; n < e.length; n++)
        if (r.data <= e[n].value) {
          r.color = e[n].color;
          break;
        }
    } else r.color = a.pointer.color;
    var l = void 0;
    (l =
      a.endAngle < a.startAngle
        ? 2 + a.endAngle - a.startAngle
        : a.startAngle - a.endAngle),
      (r._endAngle_ = l * r.data + a.startAngle),
      (r._oldAngle_ = a.oldAngle),
      a.oldAngle < a.endAngle && (r._oldAngle_ += 2),
      r.data >= a.oldData
        ? (r._proportion_ = (r._endAngle_ - r._oldAngle_) * i + a.oldAngle)
        : (r._proportion_ = r._oldAngle_ - (r._oldAngle_ - r._endAngle_) * i),
      r._proportion_ >= 2 && (r._proportion_ = r._proportion_ % 2);
  }
  return t;
}
function B(t, e, a, i, o, r) {
  return t.map(function (t) {
    if (null === t) return null;
    var o = 0,
      n = 0;
    return (
      "mix" == r.type
        ? ((o = r.extra.mix.column.seriesGap * r.pix || 0),
          (n = r.extra.mix.column.categoryGap * r.pix || 0))
        : ((o = r.extra.column.seriesGap * r.pix || 0),
          (n = r.extra.column.categoryGap * r.pix || 0)),
      (o = Math.min(o, e / a)),
      (n = Math.min(n, e / a)),
      (t.width = Math.ceil((e - 2 * n - o * (a - 1)) / a)),
      r.extra.mix &&
        r.extra.mix.column.width &&
        +r.extra.mix.column.width > 0 &&
        (t.width = Math.min(t.width, +r.extra.mix.column.width * r.pix)),
      r.extra.column &&
        r.extra.column.width &&
        +r.extra.column.width > 0 &&
        (t.width = Math.min(t.width, +r.extra.column.width * r.pix)),
      t.width <= 0 && (t.width = 1),
      (t.x += (i + 0.5 - a / 2) * (t.width + o)),
      t
    );
  });
}
function G(t, e, a, i, o, r) {
  return t.map(function (t) {
    if (null === t) return null;
    var o = 0,
      n = 0;
    return (
      (o = r.extra.bar.seriesGap * r.pix || 0),
      (n = r.extra.bar.categoryGap * r.pix || 0),
      (o = Math.min(o, e / a)),
      (n = Math.min(n, e / a)),
      (t.width = Math.ceil((e - 2 * n - o * (a - 1)) / a)),
      r.extra.bar &&
        r.extra.bar.width &&
        +r.extra.bar.width > 0 &&
        (t.width = Math.min(t.width, +r.extra.bar.width * r.pix)),
      t.width <= 0 && (t.width = 1),
      (t.y += (i + 0.5 - a / 2) * (t.width + o)),
      t
    );
  });
}
function X(t, e, a, i, o, r, n) {
  var l = r.extra.column.categoryGap * r.pix || 0;
  return t.map(function (t) {
    return null === t
      ? null
      : ((t.width = e - 2 * l),
        r.extra.column &&
          r.extra.column.width &&
          +r.extra.column.width > 0 &&
          (t.width = Math.min(t.width, +r.extra.column.width * r.pix)),
        i > 0 && (t.width -= n),
        t);
  });
}
function N(t, e, a, i, o, r, n) {
  var l = r.extra.column.categoryGap * r.pix || 0;
  return t.map(function (t, a) {
    return null === t
      ? null
      : ((t.width = Math.ceil(e - 2 * l)),
        r.extra.column &&
          r.extra.column.width &&
          +r.extra.column.width > 0 &&
          (t.width = Math.min(t.width, +r.extra.column.width * r.pix)),
        t.width <= 0 && (t.width = 1),
        t);
  });
}
function H(t, e, a, i, o, r, n) {
  var l = r.extra.bar.categoryGap * r.pix || 0;
  return t.map(function (t, a) {
    return null === t
      ? null
      : ((t.width = Math.ceil(e - 2 * l)),
        r.extra.bar &&
          r.extra.bar.width &&
          +r.extra.bar.width > 0 &&
          (t.width = Math.min(t.width, +r.extra.bar.width * r.pix)),
        t.width <= 0 && (t.width = 1),
        t);
  });
}
function j(t, e, a) {
  var i = e.width - e.area[1] - e.area[3],
    o = e.enableScroll ? Math.min(e.xAxis.itemCount, t.length) : t.length;
  ("line" == e.type ||
    "area" == e.type ||
    "scatter" == e.type ||
    "bubble" == e.type ||
    "bar" == e.type) &&
    o > 1 &&
    "justify" == e.xAxis.boundaryGap &&
    (o -= 1);
  var r = 0;
  "mount" == e.type &&
    e.extra &&
    e.extra.mount &&
    e.extra.mount.widthRatio &&
    e.extra.mount.widthRatio > 1 &&
    (e.extra.mount.widthRatio > 2 && (e.extra.mount.widthRatio = 2),
    (o += r = e.extra.mount.widthRatio - 1));
  var n = i / o,
    l = [],
    s = e.area[3],
    h = e.width - e.area[1];
  return (
    t.forEach(function (t, e) {
      l.push(s + (r / 2) * n + e * n);
    }),
    "justify" !== e.xAxis.boundaryGap &&
      (!0 === e.enableScroll ? l.push(s + r * n + t.length * n) : l.push(h)),
    { xAxisPoints: l, startX: s, endX: h, eachSpacing: n }
  );
}
function Y(t, e, a, i, o, r, n) {
  var l = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 1,
    s = [],
    h = r.height - r.area[0] - r.area[2];
  return (
    t.forEach(function (t, n) {
      if (null === t) s.push(null);
      else {
        var c = [];
        t.forEach(function (t, s) {
          var x = {};
          x.x = i[n] + Math.round(o / 2);
          var d = t.value || t,
            p = (h * (d - e)) / (a - e);
          (p *= l), (x.y = r.height - Math.round(p) - r.area[2]), c.push(x);
        }),
          s.push(c);
      }
    }),
    s
  );
}
function q(t, a, i, o, r, n, l) {
  var s = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 1,
    h = "center";
  ("line" != n.type &&
    "area" != n.type &&
    "scatter" != n.type &&
    "bubble" != n.type) ||
    (h = n.xAxis.boundaryGap);
  var c = [],
    x = n.height - n.area[0] - n.area[2],
    d = n.width - n.area[1] - n.area[3];
  return (
    t.forEach(function (t, l) {
      if (null === t) c.push(null);
      else {
        var p = {};
        (p.color = t.color), (p.x = o[l]);
        var f,
          u,
          g,
          y = t;
        if ("object" === e(t) && null !== t)
          if (t.constructor.toString().indexOf("Array") > -1)
            (u = (f = [].concat(n.chartData.xAxisData.ranges)).shift()),
              (g = f.pop()),
              (y = t[1]),
              (p.x = n.area[3] + (d * (t[0] - u)) / (g - u)),
              "bubble" == n.type && ((p.r = t[2]), (p.t = t[3]));
          else y = t.value;
        "center" == h && (p.x += r / 2);
        var v = (x * (y - a)) / (i - a);
        (v *= s), (p.y = n.height - v - n.area[2]), c.push(p);
      }
    }),
    c
  );
}
function J(t, a, i, o, r, n, l, s, h) {
  h = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : 1;
  var c = n.xAxis.boundaryGap,
    x = [],
    d = n.height - n.area[0] - n.area[2],
    p = n.width - n.area[1] - n.area[3];
  return (
    t.forEach(function (t, l) {
      if (null === t) x.push(null);
      else {
        var f = {};
        if (((f.color = t.color), "vertical" == s.animation)) {
          f.x = o[l];
          var u,
            g,
            y,
            v = t;
          if ("object" === e(t) && null !== t)
            if (t.constructor.toString().indexOf("Array") > -1)
              (g = (u = [].concat(n.chartData.xAxisData.ranges)).shift()),
                (y = u.pop()),
                (v = t[1]),
                (f.x = n.area[3] + (p * (t[0] - g)) / (y - g));
            else v = t.value;
          "center" == c && (f.x += r / 2);
          var m = (d * (v - a)) / (i - a);
          (m *= h), (f.y = n.height - m - n.area[2]), x.push(f);
        } else {
          f.x = o[0] + r * l * h;
          v = t;
          "center" == c && (f.x += r / 2);
          m = (d * (v - a)) / (i - a);
          (f.y = n.height - m - n.area[2]), x.push(f);
        }
      }
    }),
    x
  );
}
function Z(t, a, i, o, r, n, l, s, h) {
  h = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : 1;
  var c = [],
    x = n.height - n.area[0] - n.area[2],
    d = n.width - n.area[1] - n.area[3];
  return (
    t.forEach(function (t, l) {
      if (null === t) c.push(null);
      else {
        var s = {};
        (s.color = t.color), (s.x = o[l]);
        var p,
          f,
          u,
          g = t;
        if ("object" === e(t) && null !== t)
          if (t.constructor.toString().indexOf("Array") > -1)
            (f = (p = [].concat(n.chartData.xAxisData.ranges)).shift()),
              (u = p.pop()),
              (g = t[1]),
              (s.x = n.area[3] + (d * (t[0] - f)) / (u - f));
          else g = t.value;
        s.x += r / 2;
        var y = (x * (g * h - a)) / (i - a);
        (s.y = n.height - y - n.area[2]), c.push(s);
      }
    }),
    c
  );
}
function $(t, e, a, i, o, r, n, l) {
  var s = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : 1,
    h = [],
    c = r.height - r.area[0] - r.area[2];
  r.width, r.area[1], r.area[3];
  var x = o * n.widthRatio;
  return (
    t.forEach(function (t, n) {
      if (null === t) h.push(null);
      else {
        var l = {};
        (l.color = t.color), (l.x = i[n]), (l.x += o / 2);
        var d = t.data,
          p = (c * (d * s - e)) / (a - e);
        (l.y = r.height - p - r.area[2]),
          (l.value = d),
          (l.width = x),
          h.push(l);
      }
    }),
    h
  );
}
function K(t, a, i, o, r, n, l) {
  var s = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 1,
    h = [];
  n.height, n.area[0], n.area[2];
  var c = n.width - n.area[1] - n.area[3];
  return (
    t.forEach(function (t, r) {
      if (null === t) h.push(null);
      else {
        var l = {};
        (l.color = t.color), (l.y = o[r]);
        var x = t;
        "object" === e(t) && null !== t && (x = t.value);
        var d = (c * (x - a)) / (i - a);
        (d *= s),
          (l.height = d),
          (l.value = x),
          (l.x = d + n.area[3]),
          h.push(l);
      }
    }),
    h
  );
}
function Q(t, a, i, o, r, n, l, s, h) {
  var c = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : 1,
    x = [],
    d = n.height - n.area[0] - n.area[2];
  return (
    t.forEach(function (t, l) {
      if (null === t) x.push(null);
      else {
        var p = {};
        if (((p.color = t.color), (p.x = o[l] + Math.round(r / 2)), s > 0)) {
          for (var f = 0, u = 0; u <= s; u++) f += h[u].data[l];
          var g = (d * (f - a)) / (i - a),
            y = (d * (f - t - a)) / (i - a);
        } else {
          f = t;
          "object" === e(t) && null !== t && (f = t.value);
          (g = (d * (f - a)) / (i - a)), (y = 0);
        }
        var v = y;
        (g *= c),
          (v *= c),
          (p.y = n.height - Math.round(g) - n.area[2]),
          (p.y0 = n.height - Math.round(v) - n.area[2]),
          x.push(p);
      }
    }),
    x
  );
}
function U(t, a, i, o, r, n, l, s, h) {
  var c = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : 1,
    x = [],
    d = n.width - n.area[1] - n.area[3];
  return (
    t.forEach(function (t, r) {
      if (null === t) x.push(null);
      else {
        var l = {};
        if (((l.color = t.color), (l.y = o[r]), s > 0)) {
          for (var p = 0, f = 0; f <= s; f++) p += h[f].data[r];
          var u = (d * (p - a)) / (i - a),
            g = (d * (p - t - a)) / (i - a);
        } else {
          p = t;
          "object" === e(t) && null !== t && (p = t.value);
          (u = (d * (p - a)) / (i - a)), (g = 0);
        }
        var y = g;
        (u *= c),
          (y *= c),
          (l.height = u - y),
          (l.x = n.area[3] + u),
          (l.x0 = n.area[3] + y),
          x.push(l);
      }
    }),
    x
  );
}
function V(t, a, i, o, r) {
  var n;
  n = "stack" == o ? y(t, a.categories.length) : g(t);
  var s = [];
  (n = n.filter(function (t) {
    return "object" === e(t) && null !== t
      ? t.constructor.toString().indexOf("Array") > -1
        ? null !== t
        : null !== t.value
      : null !== t;
  })).map(function (t) {
    "object" === e(t)
      ? t.constructor.toString().indexOf("Array") > -1
        ? "candle" == a.type
          ? t.map(function (t) {
              s.push(t);
            })
          : s.push(t[1])
        : s.push(t.value)
      : s.push(t);
  });
  var h = r.min || 0,
    c = r.max || 0;
  s.length > 0 &&
    ((h = Math.min.apply(this, s)), (c = Math.max.apply(this, s))),
    h === c && (0 == c ? (c = 10) : (h = 0));
  for (
    var x = (function (t, e) {
        var a = 0,
          i = e - t;
        return {
          minRange: l(
            t,
            "lower",
            (a =
              i >= 1e4
                ? 1e3
                : i >= 1e3
                ? 100
                : i >= 100
                ? 10
                : i >= 10
                ? 5
                : i >= 1
                ? 1
                : i >= 0.1
                ? 0.1
                : i >= 0.01
                ? 0.01
                : i >= 0.001
                ? 0.001
                : i >= 1e-4
                ? 1e-4
                : i >= 1e-5
                ? 1e-5
                : 1e-6)
          ),
          maxRange: l(e, "upper", a),
        };
      })(h, c),
      d = void 0 === r.min || null === r.min ? x.minRange : r.min,
      p =
        ((void 0 === r.max || null === r.max ? x.maxRange : r.max) - d) /
        a.yAxis.splitNumber,
      f = [],
      u = 0;
    u <= a.yAxis.splitNumber;
    u++
  )
    f.push(d + p * u);
  return f.reverse();
}
function tt(t, e, a, i) {
  var n = o({}, { type: "" }, e.extra.column),
    l = e.yAxis.data.length,
    s = new Array(l);
  if (l > 0) {
    for (var h = 0; h < l; h++) {
      s[h] = [];
      for (var c = 0; c < t.length; c++) t[c].index == h && s[h].push(t[c]);
    }
    for (
      var x = new Array(l),
        d = new Array(l),
        p = new Array(l),
        f = function (t) {
          var o = e.yAxis.data[t];
          1 == e.yAxis.disabled && (o.disabled = !0),
            "categories" === o.type
              ? (o.formatter ||
                  (o.formatter = function (t, e, a) {
                    return t + (o.unit || "");
                  }),
                (o.categories = o.categories || e.categories),
                (x[t] = o.categories))
              : (o.formatter ||
                  (o.formatter = function (t, e, a) {
                    return r.toFixed(t, o.tofix || 0) + (o.unit || "");
                  }),
                (x[t] = V(s[t], e, 0, n.type, o)));
          var l = o.fontSize * e.pix || a.fontSize;
          (p[t] = { position: o.position ? o.position : "left", width: 0 }),
            (d[t] = x[t].map(function (a, r) {
              return (
                (a = o.formatter(a, r, e)),
                (p[t].width = Math.max(p[t].width, u(a, l, i) + 5)),
                a
              );
            }));
          var h = o.calibration ? 4 * e.pix : 0;
          (p[t].width += h + 3 * e.pix), !0 === o.disabled && (p[t].width = 0);
        },
        g = 0;
      g < l;
      g++
    )
      f(g);
  } else {
    (x = new Array(1)), (d = new Array(1)), (p = new Array(1));
    "bar" === e.type
      ? ((x[0] = e.categories),
        e.yAxis.formatter ||
          (e.yAxis.formatter = function (t, e, a) {
            return t + (a.yAxis.unit || "");
          }))
      : (e.yAxis.formatter ||
          (e.yAxis.formatter = function (t, e, a) {
            return t.toFixed(a.yAxis.tofix) + (a.yAxis.unit || "");
          }),
        (x[0] = V(t, e, 0, n.type, {}))),
      (p[0] = { position: "left", width: 0 });
    var y = e.yAxis.fontSize * e.pix || a.fontSize;
    (d[0] = x[0].map(function (t, a) {
      return (
        (t = e.yAxis.formatter(t, a, e)),
        (p[0].width = Math.max(p[0].width, u(t, y, i) + 5)),
        t
      );
    })),
      (p[0].width += 3 * e.pix),
      !0 === e.yAxis.disabled
        ? ((p[0] = { position: "left", width: 0 }),
          (e.yAxis.data[0] = { disabled: !0 }))
        : ((e.yAxis.data[0] = {
            disabled: !1,
            position: "left",
            max: e.yAxis.max,
            min: e.yAxis.min,
            formatter: e.yAxis.formatter,
          }),
          "bar" === e.type &&
            ((e.yAxis.data[0].categories = e.categories),
            (e.yAxis.data[0].type = "categories")));
  }
  return { rangesFormat: d, ranges: x, yAxisWidth: p };
}
function et(t, e) {
  !0 !== e.rotateLock
    ? (t.translate(e.height, 0), t.rotate((90 * Math.PI) / 180))
    : !0 !== e._rotate_ &&
      (t.translate(e.height, 0),
      t.rotate((90 * Math.PI) / 180),
      (e._rotate_ = !0));
}
function at(t, e, a, i, o) {
  if (
    (i.beginPath(),
    "hollow" == o.dataPointShapeType
      ? (i.setStrokeStyle(e),
        i.setFillStyle(o.background),
        i.setLineWidth(2 * o.pix))
      : (i.setStrokeStyle("#ffffff"),
        i.setFillStyle(e),
        i.setLineWidth(1 * o.pix)),
    "diamond" === a)
  )
    t.forEach(function (t, e) {
      null !== t &&
        (i.moveTo(t.x, t.y - 4.5),
        i.lineTo(t.x - 4.5, t.y),
        i.lineTo(t.x, t.y + 4.5),
        i.lineTo(t.x + 4.5, t.y),
        i.lineTo(t.x, t.y - 4.5));
    });
  else if ("circle" === a)
    t.forEach(function (t, e) {
      null !== t &&
        (i.moveTo(t.x + 2.5 * o.pix, t.y),
        i.arc(t.x, t.y, 3 * o.pix, 0, 2 * Math.PI, !1));
    });
  else if ("square" === a)
    t.forEach(function (t, e) {
      null !== t &&
        (i.moveTo(t.x - 3.5, t.y - 3.5), i.rect(t.x - 3.5, t.y - 3.5, 7, 7));
    });
  else if ("triangle" === a)
    t.forEach(function (t, e) {
      null !== t &&
        (i.moveTo(t.x, t.y - 4.5),
        i.lineTo(t.x - 4.5, t.y + 4.5),
        i.lineTo(t.x + 4.5, t.y + 4.5),
        i.lineTo(t.x, t.y - 4.5));
    });
  else if ("none" === a) return;
  i.closePath(), i.fill(), i.stroke();
}
function it(t, e, a, i, o, r, n) {
  if (
    o.tooltip &&
    !(o.tooltip.group.length > 0 && 0 == o.tooltip.group.includes(n))
  ) {
    var l =
      "number" == typeof o.tooltip.index
        ? o.tooltip.index
        : o.tooltip.index[o.tooltip.group.indexOf(n)];
    if (
      (i.beginPath(),
      "hollow" == r.activeType
        ? (i.setStrokeStyle(e),
          i.setFillStyle(o.background),
          i.setLineWidth(2 * o.pix))
        : (i.setStrokeStyle("#ffffff"),
          i.setFillStyle(e),
          i.setLineWidth(1 * o.pix)),
      "diamond" === a)
    )
      t.forEach(function (t, e) {
        null !== t &&
          l == e &&
          (i.moveTo(t.x, t.y - 4.5),
          i.lineTo(t.x - 4.5, t.y),
          i.lineTo(t.x, t.y + 4.5),
          i.lineTo(t.x + 4.5, t.y),
          i.lineTo(t.x, t.y - 4.5));
      });
    else if ("circle" === a)
      t.forEach(function (t, e) {
        null !== t &&
          l == e &&
          (i.moveTo(t.x + 2.5 * o.pix, t.y),
          i.arc(t.x, t.y, 3 * o.pix, 0, 2 * Math.PI, !1));
      });
    else if ("square" === a)
      t.forEach(function (t, e) {
        null !== t &&
          l == e &&
          (i.moveTo(t.x - 3.5, t.y - 3.5), i.rect(t.x - 3.5, t.y - 3.5, 7, 7));
      });
    else if ("triangle" === a)
      t.forEach(function (t, e) {
        null !== t &&
          l == e &&
          (i.moveTo(t.x, t.y - 4.5),
          i.lineTo(t.x - 4.5, t.y + 4.5),
          i.lineTo(t.x + 4.5, t.y + 4.5),
          i.lineTo(t.x, t.y - 4.5));
      });
    else if ("none" === a) return;
    i.closePath(), i.fill(), i.stroke();
  }
}
function ot(t, e, a, i) {
  var o = t.title.fontSize || e.titleFontSize,
    r = t.subtitle.fontSize || e.subtitleFontSize,
    n = t.title.name || "",
    l = t.subtitle.name || "",
    s = t.title.color || t.fontColor,
    h = t.subtitle.color || t.fontColor,
    c = n ? o : 0,
    x = l ? r : 0;
  if (l) {
    var d = u(l, r * t.pix, a),
      p = i.x - d / 2 + (t.subtitle.offsetX || 0) * t.pix,
      f = i.y + (r * t.pix) / 2 + (t.subtitle.offsetY || 0) * t.pix;
    n && (f += (c * t.pix + 5) / 2),
      a.beginPath(),
      a.setFontSize(r * t.pix),
      a.setFillStyle(h),
      a.fillText(l, p, f),
      a.closePath(),
      a.stroke();
  }
  if (n) {
    var g = u(n, o * t.pix, a),
      y = i.x - g / 2 + (t.title.offsetX || 0),
      v = i.y + (o * t.pix) / 2 + (t.title.offsetY || 0) * t.pix;
    l && (v -= (x * t.pix + 5) / 2),
      a.beginPath(),
      a.setFontSize(o * t.pix),
      a.setFillStyle(s),
      a.fillText(n, y, v),
      a.closePath(),
      a.stroke();
  }
}
function rt(t, a, i, o, r) {
  var n = a.data,
    l = a.textOffset ? a.textOffset : 0;
  t.forEach(function (t, s) {
    if (null !== t) {
      o.beginPath();
      var h = a.textSize ? a.textSize * r.pix : i.fontSize;
      o.setFontSize(h), o.setFillStyle(a.textColor || r.fontColor);
      var c = n[s];
      "object" === e(n[s]) &&
        null !== n[s] &&
        (c =
          n[s].constructor.toString().indexOf("Array") > -1
            ? n[s][1]
            : n[s].value);
      var x = a.formatter ? a.formatter(c, s, a, r) : c;
      o.setTextAlign("center"),
        o.fillText(String(x), t.x, t.y - 4 + l * r.pix),
        o.closePath(),
        o.stroke(),
        o.setTextAlign("left");
    }
  });
}
function nt(t, a, i, o, r) {
  var n = a.data,
    l = a.textOffset ? a.textOffset : 0,
    s = r.extra.column.labelPosition;
  t.forEach(function (t, h) {
    if (null !== t) {
      o.beginPath();
      var c = a.textSize ? a.textSize * r.pix : i.fontSize;
      o.setFontSize(c), o.setFillStyle(a.textColor || r.fontColor);
      var x = n[h];
      "object" === e(n[h]) &&
        null !== n[h] &&
        (x =
          n[h].constructor.toString().indexOf("Array") > -1
            ? n[h][1]
            : n[h].value);
      var d = a.formatter ? a.formatter(x, h, a, r) : x;
      o.setTextAlign("center");
      var p = t.y - 4 * r.pix + l * r.pix;
      t.y > a.zeroPoints && (p = t.y + l * r.pix + c),
        "insideTop" == s &&
          ((p = t.y + c + l * r.pix),
          t.y > a.zeroPoints && (p = t.y - l * r.pix - 4 * r.pix)),
        "center" == s &&
          ((p = t.y + l * r.pix + (r.height - r.area[2] - t.y + c) / 2),
          a.zeroPoints < r.height - r.area[2] &&
            (p = t.y + l * r.pix + (a.zeroPoints - t.y + c) / 2),
          t.y > a.zeroPoints &&
            (p = t.y - l * r.pix - (t.y - a.zeroPoints - c) / 2),
          "stack" == r.extra.column.type &&
            (p = t.y + l * r.pix + (t.y0 - t.y + c) / 2)),
        "bottom" == s &&
          ((p = r.height - r.area[2] + l * r.pix - 4 * r.pix),
          a.zeroPoints < r.height - r.area[2] &&
            (p = a.zeroPoints + l * r.pix - 4 * r.pix),
          t.y > a.zeroPoints && (p = a.zeroPoints - l * r.pix + c + 2 * r.pix),
          "stack" == r.extra.column.type && (p = t.y0 + l * r.pix - 4 * r.pix)),
        o.fillText(String(d), t.x, p),
        o.closePath(),
        o.stroke(),
        o.setTextAlign("left");
    }
  });
}
function lt(t, e, a, i, o, r) {
  e.data;
  var n = e.textOffset ? e.textOffset : 0;
  o.extra.mount.labelPosition,
    t.forEach(function (t, l) {
      if (null !== t) {
        i.beginPath();
        var s = e[l].textSize ? e[l].textSize * o.pix : a.fontSize;
        i.setFontSize(s), i.setFillStyle(e[l].textColor || o.fontColor);
        var h = t.value,
          c = e[l].formatter ? e[l].formatter(h, l, e, o) : h;
        i.setTextAlign("center");
        var x = t.y - 4 * o.pix + n * o.pix;
        t.y > r && (x = t.y + n * o.pix + s),
          i.fillText(String(c), t.x, x),
          i.closePath(),
          i.stroke(),
          i.setTextAlign("left");
      }
    });
}
function st(t, a, i, o, r) {
  var n = a.data;
  a.textOffset && a.textOffset,
    t.forEach(function (t, l) {
      if (null !== t) {
        o.beginPath();
        var s = a.textSize ? a.textSize * r.pix : i.fontSize;
        o.setFontSize(s), o.setFillStyle(a.textColor || r.fontColor);
        var h = n[l];
        "object" === e(n[l]) && null !== n[l] && (h = n[l].value);
        var c = a.formatter ? a.formatter(h, l, a, r) : h;
        o.setTextAlign("left"),
          o.fillText(String(c), t.x + 4 * r.pix, t.y + s / 2 - 3),
          o.closePath(),
          o.stroke();
      }
    });
}
function ht(t, e, a, i, o, r) {
  e = (e -= t.width / 2 + t.labelOffset * i.pix) < 10 ? 10 : e;
  for (
    var n =
        (t.endAngle < t.startAngle
          ? 2 + t.endAngle - t.startAngle
          : t.startAngle - t.endAngle) / t.splitLine.splitNumber,
      l = (t.endNumber - t.startNumber) / t.splitLine.splitNumber,
      s = t.startAngle,
      h = t.startNumber,
      c = 0;
    c < t.splitLine.splitNumber + 1;
    c++
  ) {
    var x = { x: e * Math.cos(s * Math.PI), y: e * Math.sin(s * Math.PI) },
      d = t.formatter ? t.formatter(h, c, i) : h;
    (x.x += a.x - u(d, o.fontSize, r) / 2), (x.y += a.y);
    var p = x.x,
      f = x.y;
    r.beginPath(),
      r.setFontSize(o.fontSize),
      r.setFillStyle(t.labelColor || i.fontColor),
      r.fillText(d, p, f + o.fontSize / 2),
      r.closePath(),
      r.stroke(),
      (s += n) >= 2 && (s %= 2),
      (h += l);
  }
}
function ct(t, e, a, i, o, n) {
  var l = i.extra.radar || {};
  t.forEach(function (t, s) {
    if (!0 === l.labelPointShow && "" !== i.categories[s]) {
      var h = { x: e * Math.cos(t), y: e * Math.sin(t) },
        c = x(h.x, h.y, a);
      n.setFillStyle(l.labelPointColor),
        n.beginPath(),
        n.arc(c.x, c.y, l.labelPointRadius * i.pix, 0, 2 * Math.PI, !1),
        n.closePath(),
        n.fill();
    }
    if (!0 === l.labelShow) {
      var d = {
          x: (e + o.radarLabelTextMargin * i.pix) * Math.cos(t),
          y: (e + o.radarLabelTextMargin * i.pix) * Math.sin(t),
        },
        p = x(d.x, d.y, a),
        f = p.x,
        g = p.y;
      r.approximatelyEqual(d.x, 0)
        ? (f -= u(i.categories[s] || "", o.fontSize, n) / 2)
        : d.x < 0 && (f -= u(i.categories[s] || "", o.fontSize, n)),
        n.beginPath(),
        n.setFontSize(o.fontSize),
        n.setFillStyle(l.labelColor || i.fontColor),
        n.fillText(i.categories[s] || "", f, g + o.fontSize / 2),
        n.closePath(),
        n.stroke();
    }
  });
}
function xt(t, e, a, i, o, n) {
  for (
    var l = a.pieChartLinePadding,
      s = [],
      h = null,
      c = t.map(function (a, i) {
        var o = a.formatter
          ? a.formatter(a, i, t, e)
          : r.toFixed(100 * a._proportion_.toFixed(4)) + "%";
        o = a.labelText ? a.labelText : o;
        var n = 2 * Math.PI - (a._start_ + (2 * Math.PI * a._proportion_) / 2);
        return (
          a._rose_proportion_ &&
            (n =
              2 * Math.PI -
              (a._start_ + (2 * Math.PI * a._rose_proportion_) / 2)),
          {
            arc: n,
            text: o,
            color: a.color,
            radius: a._radius_,
            textColor: a.textColor,
            textSize: a.textSize,
            labelShow: a.labelShow,
          }
        );
      }),
      p = 0;
    p < c.length;
    p++
  ) {
    var f = c[p],
      g = Math.cos(f.arc) * (f.radius + l),
      y = Math.sin(f.arc) * (f.radius + l),
      v = Math.cos(f.arc) * f.radius,
      m = Math.sin(f.arc) * f.radius,
      S = g >= 0 ? g + a.pieChartTextPadding : g - a.pieChartTextPadding,
      b = y,
      A = u(f.text, f.textSize * e.pix || a.fontSize, i),
      T = b;
    h &&
      r.isSameXCoordinateArea(h.start, { x: S }) &&
      (T =
        S > 0
          ? Math.min(b, h.start.y)
          : g < 0 || b > 0
          ? Math.max(b, h.start.y)
          : Math.min(b, h.start.y)),
      S < 0 && (S -= A),
      (h = d(
        {
          lineStart: { x: v, y: m },
          lineEnd: { x: g, y: y },
          start: { x: S, y: T },
          width: A,
          height: a.fontSize,
          text: f.text,
          color: f.color,
          textColor: f.textColor,
          textSize: f.textSize,
        },
        h
      )),
      s.push(h);
  }
  for (var P = 0; P < s.length; P++)
    if (!1 !== c[P].labelShow) {
      var w = s[P],
        C = x(w.lineStart.x, w.lineStart.y, n),
        M = x(w.lineEnd.x, w.lineEnd.y, n),
        _ = x(w.start.x, w.start.y, n);
      i.setLineWidth(1 * e.pix),
        i.setFontSize(w.textSize * e.pix || a.fontSize),
        i.beginPath(),
        i.setStrokeStyle(w.color),
        i.setFillStyle(w.color),
        i.moveTo(C.x, C.y);
      var F = w.start.x < 0 ? _.x + w.width : _.x,
        D = w.start.x < 0 ? _.x - 5 : _.x + 5;
      i.quadraticCurveTo(M.x, M.y, F, _.y),
        i.moveTo(C.x, C.y),
        i.stroke(),
        i.closePath(),
        i.beginPath(),
        i.moveTo(_.x + w.width, _.y),
        i.arc(F, _.y, 2 * e.pix, 0, 2 * Math.PI),
        i.closePath(),
        i.fill(),
        i.beginPath(),
        i.setFontSize(w.textSize * e.pix || a.fontSize),
        i.setFillStyle(w.textColor || e.fontColor),
        i.fillText(w.text, D, _.y + 3),
        i.closePath(),
        i.stroke(),
        i.closePath();
    }
}
function dt(t, e, a) {
  for (
    var i = o({}, { type: "solid", dashLength: 4, data: [] }, t.extra.markLine),
      r = t.area[3],
      l = t.width - t.area[1],
      s = (function (t, e) {
        for (
          var a, i, o = e.height - e.area[0] - e.area[2], r = 0;
          r < t.length;
          r++
        ) {
          t[r].yAxisIndex = t[r].yAxisIndex ? t[r].yAxisIndex : 0;
          var n = [].concat(e.chartData.yAxisData.ranges[t[r].yAxisIndex]);
          (a = n.pop()), (i = n.shift());
          var l = (o * (t[r].value - a)) / (i - a);
          t[r].y = e.height - Math.round(l) - e.area[2];
        }
        return t;
      })(i.data, t),
      h = 0;
    h < s.length;
    h++
  ) {
    var c = o(
      {},
      {
        lineColor: "#DE4A42",
        showLabel: !1,
        labelFontSize: 13,
        labelPadding: 6,
        labelFontColor: "#666666",
        labelBgColor: "#DFE8FF",
        labelBgOpacity: 0.8,
        labelAlign: "left",
        labelOffsetX: 0,
        labelOffsetY: 0,
      },
      s[h]
    );
    if (
      ("dash" == i.type && a.setLineDash([i.dashLength, i.dashLength]),
      a.setStrokeStyle(c.lineColor),
      a.setLineWidth(1 * t.pix),
      a.beginPath(),
      a.moveTo(r, c.y),
      a.lineTo(l, c.y),
      a.stroke(),
      a.setLineDash([]),
      c.showLabel)
    ) {
      var x = c.labelFontSize * t.pix,
        d = c.labelText ? c.labelText : c.value;
      a.setFontSize(x);
      var p = u(d, x, a) + c.labelPadding * t.pix * 2,
        f = "left" == c.labelAlign ? t.area[3] - p : t.width - t.area[1];
      f += c.labelOffsetX;
      var g = c.y - 0.5 * x - c.labelPadding * t.pix;
      g += c.labelOffsetY;
      var y = f + c.labelPadding * t.pix;
      c.y,
        a.setFillStyle(n(c.labelBgColor, c.labelBgOpacity)),
        a.setStrokeStyle(c.labelBgColor),
        a.setLineWidth(1 * t.pix),
        a.beginPath(),
        a.rect(f, g, p, x + 2 * c.labelPadding * t.pix),
        a.closePath(),
        a.stroke(),
        a.fill(),
        a.setFontSize(x),
        a.setTextAlign("left"),
        a.setFillStyle(c.labelFontColor),
        a.fillText(String(d), y, g + x + (c.labelPadding * t.pix) / 2),
        a.stroke(),
        a.setTextAlign("left");
    }
  }
}
function pt(t, e, a, i, r) {
  var l = o({}, { gridType: "solid", dashLength: 4 }, t.extra.tooltip),
    s = t.area[3],
    h = t.width - t.area[1];
  if (
    ("dash" == l.gridType && a.setLineDash([l.dashLength, l.dashLength]),
    a.setStrokeStyle(l.gridColor || "#cccccc"),
    a.setLineWidth(1 * t.pix),
    a.beginPath(),
    a.moveTo(s, t.tooltip.offset.y),
    a.lineTo(h, t.tooltip.offset.y),
    a.stroke(),
    a.setLineDash([]),
    l.yAxisLabel)
  )
    for (
      var c = l.boxPadding * t.pix,
        x = (function (t, e, a, i, o) {
          for (
            var r = [].concat(a.chartData.yAxisData.ranges),
              n = a.height - a.area[0] - a.area[2],
              l = a.area[0],
              s = [],
              h = 0;
            h < r.length;
            h++
          ) {
            var c = Math.max.apply(this, r[h]),
              x = c - ((c - Math.min.apply(this, r[h])) * (t - l)) / n;
            (x =
              a.yAxis.data && a.yAxis.data[h].formatter
                ? a.yAxis.data[h].formatter(x, h, a)
                : x.toFixed(0)),
              s.push(String(x));
          }
          return s;
        })(t.tooltip.offset.y, t.series, t),
        d = t.chartData.yAxisData.yAxisWidth,
        p = t.area[3],
        f = t.width - t.area[1],
        g = 0;
      g < x.length;
      g++
    ) {
      a.setFontSize(l.fontSize * t.pix);
      var y,
        v = u(x[g], l.fontSize * t.pix, a),
        m = void 0,
        S = void 0;
      "left" == d[g].position
        ? ((m = p - (v + 2 * c) - 2 * t.pix), (S = Math.max(m, m + v + 2 * c)))
        : ((m = f + 2 * t.pix), (S = Math.max(m + d[g].width, m + v + 2 * c)));
      var b = m + ((y = S - m) - v) / 2,
        A = t.tooltip.offset.y;
      a.beginPath(),
        a.setFillStyle(
          n(
            l.labelBgColor || e.toolTipBackground,
            l.labelBgOpacity || e.toolTipOpacity
          )
        ),
        a.setStrokeStyle(l.labelBgColor || e.toolTipBackground),
        a.setLineWidth(1 * t.pix),
        a.rect(m, A - 0.5 * e.fontSize - c, y, e.fontSize + 2 * c),
        a.closePath(),
        a.stroke(),
        a.fill(),
        a.beginPath(),
        a.setFontSize(e.fontSize),
        a.setFillStyle(l.labelFontColor || t.fontColor),
        a.fillText(x[g], b, A + 0.5 * e.fontSize),
        a.closePath(),
        a.stroke(),
        "left" == d[g].position
          ? (p -= d[g].width + t.yAxis.padding * t.pix)
          : (f += d[g].width + t.yAxis.padding * t.pix);
    }
}
function ft(t, e, a, i, r) {
  var l = o(
    {},
    { activeBgColor: "#000000", activeBgOpacity: 0.08, activeWidth: r },
    e.extra.column
  );
  l.activeWidth = l.activeWidth > r ? r : l.activeWidth;
  var s = e.area[0],
    h = e.height - e.area[2];
  i.beginPath(),
    i.setFillStyle(n(l.activeBgColor, l.activeBgOpacity)),
    i.rect(t - l.activeWidth / 2, s, l.activeWidth, h - s),
    i.closePath(),
    i.fill(),
    i.setFillStyle("#FFFFFF");
}
function ut(t, e, a, i, r) {
  var l = o(
      {},
      { activeBgColor: "#000000", activeBgOpacity: 0.08 },
      e.extra.bar
    ),
    s = e.area[3],
    h = e.width - e.area[1];
  i.beginPath(),
    i.setFillStyle(n(l.activeBgColor, l.activeBgOpacity)),
    i.rect(s, t - r / 2, h - s, r),
    i.closePath(),
    i.fill(),
    i.setFillStyle("#FFFFFF");
}
function gt(t, e, a, i, r, l, s) {
  var h = o(
    {},
    {
      showBox: !0,
      showArrow: !0,
      showCategory: !1,
      bgColor: "#000000",
      bgOpacity: 0.7,
      borderColor: "#000000",
      borderWidth: 0,
      borderRadius: 0,
      borderOpacity: 0.7,
      boxPadding: 3,
      fontColor: "#FFFFFF",
      fontSize: 13,
      lineHeight: 20,
      legendShow: !0,
      legendShape: "auto",
      splitLine: !0,
    },
    a.extra.tooltip
  );
  1 == h.showCategory &&
    a.categories &&
    t.unshift({ text: a.categories[a.tooltip.index], color: null });
  var c = h.fontSize * a.pix,
    x = h.lineHeight * a.pix,
    d = h.boxPadding * a.pix,
    p = c,
    f = 5 * a.pix;
  0 == h.legendShow && ((p = 0), (f = 0));
  var g = h.showArrow ? 8 * a.pix : 0,
    y = !1;
  ("line" != a.type &&
    "mount" != a.type &&
    "area" != a.type &&
    "candle" != a.type &&
    "mix" != a.type) ||
    (1 == h.splitLine &&
      (function (t, e, a, i) {
        var o = e.extra.tooltip || {};
        (o.gridType = null == o.gridType ? "solid" : o.gridType),
          (o.dashLength = null == o.dashLength ? 4 : o.dashLength);
        var r = e.area[0],
          l = e.height - e.area[2];
        if (
          ("dash" == o.gridType && i.setLineDash([o.dashLength, o.dashLength]),
          i.setStrokeStyle(o.gridColor || "#cccccc"),
          i.setLineWidth(1 * e.pix),
          i.beginPath(),
          i.moveTo(t, r),
          i.lineTo(t, l),
          i.stroke(),
          i.setLineDash([]),
          o.xAxisLabel)
        ) {
          var s = e.categories[e.tooltip.index];
          i.setFontSize(a.fontSize);
          var h = u(s, a.fontSize, i),
            c = t - 0.5 * h,
            x = l + 2 * e.pix;
          i.beginPath(),
            i.setFillStyle(
              n(
                o.labelBgColor || a.toolTipBackground,
                o.labelBgOpacity || a.toolTipOpacity
              )
            ),
            i.setStrokeStyle(o.labelBgColor || a.toolTipBackground),
            i.setLineWidth(1 * e.pix),
            i.rect(
              c - o.boxPadding * e.pix,
              x,
              h + 2 * o.boxPadding * e.pix,
              a.fontSize + 2 * o.boxPadding * e.pix
            ),
            i.closePath(),
            i.stroke(),
            i.fill(),
            i.beginPath(),
            i.setFontSize(a.fontSize),
            i.setFillStyle(o.labelFontColor || e.fontColor),
            i.fillText(String(s), c, x + o.boxPadding * e.pix + a.fontSize),
            i.closePath(),
            i.stroke();
        }
      })(a.tooltip.offset.x, a, i, r)),
    ((e = o({ x: 0, y: 0 }, e)).y -= 8 * a.pix);
  var v = t.map(function (t) {
      return u(t.text, c, r);
    }),
    m = p + f + 4 * d + Math.max.apply(null, v),
    S = 2 * d + t.length * x;
  if (0 != h.showBox) {
    e.x - Math.abs(a._scrollDistance_ || 0) + g + m > a.width && (y = !0),
      S + e.y > a.height && (e.y = a.height - S),
      r.beginPath(),
      r.setFillStyle(n(h.bgColor, h.bgOpacity)),
      r.setLineWidth(h.borderWidth * a.pix),
      r.setStrokeStyle(n(h.borderColor, h.borderOpacity));
    var b = h.borderRadius;
    y
      ? (m + g > a.width &&
          (e.x =
            a.width + Math.abs(a._scrollDistance_ || 0) + g + (m - a.width)),
        m > e.x &&
          (e.x =
            a.width + Math.abs(a._scrollDistance_ || 0) + g + (m - a.width)),
        h.showArrow &&
          (r.moveTo(e.x, e.y + 10 * a.pix),
          r.lineTo(e.x - g, e.y + 10 * a.pix + 5 * a.pix)),
        r.arc(e.x - g - b, e.y + S - b, b, 0, Math.PI / 2, !1),
        r.arc(
          e.x - g - Math.round(m) + b,
          e.y + S - b,
          b,
          Math.PI / 2,
          Math.PI,
          !1
        ),
        r.arc(
          e.x - g - Math.round(m) + b,
          e.y + b,
          b,
          -Math.PI,
          -Math.PI / 2,
          !1
        ),
        r.arc(e.x - g - b, e.y + b, b, -Math.PI / 2, 0, !1),
        h.showArrow &&
          (r.lineTo(e.x - g, e.y + 10 * a.pix - 5 * a.pix),
          r.lineTo(e.x, e.y + 10 * a.pix)))
      : (h.showArrow &&
          (r.moveTo(e.x, e.y + 10 * a.pix),
          r.lineTo(e.x + g, e.y + 10 * a.pix - 5 * a.pix)),
        r.arc(e.x + g + b, e.y + b, b, -Math.PI, -Math.PI / 2, !1),
        r.arc(e.x + g + Math.round(m) - b, e.y + b, b, -Math.PI / 2, 0, !1),
        r.arc(e.x + g + Math.round(m) - b, e.y + S - b, b, 0, Math.PI / 2, !1),
        r.arc(e.x + g + b, e.y + S - b, b, Math.PI / 2, Math.PI, !1),
        h.showArrow &&
          (r.lineTo(e.x + g, e.y + 10 * a.pix + 5 * a.pix),
          r.lineTo(e.x, e.y + 10 * a.pix))),
      r.closePath(),
      r.fill(),
      h.borderWidth > 0 && r.stroke(),
      h.legendShow &&
        t.forEach(function (t, i) {
          if (null !== t.color) {
            r.beginPath(), r.setFillStyle(t.color);
            var o = e.x + g + 2 * d,
              n = e.y + (x - c) / 2 + x * i + d + 1;
            switch ((y && (o = e.x - m - g + 2 * d), t.legendShape)) {
              case "line":
                r.moveTo(o, n + 0.5 * p - 2 * a.pix),
                  r.fillRect(o, n + 0.5 * p - 2 * a.pix, p, 4 * a.pix);
                break;
              case "triangle":
                r.moveTo(o + 7.5 * a.pix, n + 0.5 * p - 5 * a.pix),
                  r.lineTo(o + 2.5 * a.pix, n + 0.5 * p + 5 * a.pix),
                  r.lineTo(o + 12.5 * a.pix, n + 0.5 * p + 5 * a.pix),
                  r.lineTo(o + 7.5 * a.pix, n + 0.5 * p - 5 * a.pix);
                break;
              case "diamond":
                r.moveTo(o + 7.5 * a.pix, n + 0.5 * p - 5 * a.pix),
                  r.lineTo(o + 2.5 * a.pix, n + 0.5 * p),
                  r.lineTo(o + 7.5 * a.pix, n + 0.5 * p + 5 * a.pix),
                  r.lineTo(o + 12.5 * a.pix, n + 0.5 * p),
                  r.lineTo(o + 7.5 * a.pix, n + 0.5 * p - 5 * a.pix);
                break;
              case "circle":
                r.moveTo(o + 7.5 * a.pix, n + 0.5 * p),
                  r.arc(
                    o + 7.5 * a.pix,
                    n + 0.5 * p,
                    5 * a.pix,
                    0,
                    2 * Math.PI
                  );
                break;
              case "rect":
                r.moveTo(o, n + 0.5 * p - 5 * a.pix),
                  r.fillRect(
                    o,
                    n + 0.5 * p - 5 * a.pix,
                    15 * a.pix,
                    10 * a.pix
                  );
                break;
              case "square":
                r.moveTo(o + 2 * a.pix, n + 0.5 * p - 5 * a.pix),
                  r.fillRect(
                    o + 2 * a.pix,
                    n + 0.5 * p - 5 * a.pix,
                    10 * a.pix,
                    10 * a.pix
                  );
                break;
              default:
                r.moveTo(o, n + 0.5 * p - 5 * a.pix),
                  r.fillRect(
                    o,
                    n + 0.5 * p - 5 * a.pix,
                    15 * a.pix,
                    10 * a.pix
                  );
            }
            r.closePath(), r.fill();
          }
        }),
      t.forEach(function (t, a) {
        var i = e.x + g + 2 * d + p + f;
        y && (i = e.x - m - g + 2 * d + p + f);
        var o = e.y + x * a + (x - c) / 2 - 1 + d + c;
        r.beginPath(),
          r.setFontSize(c),
          r.setTextBaseline("normal"),
          r.setFillStyle(h.fontColor),
          r.fillText(t.text, i, o),
          r.closePath(),
          r.stroke();
      });
  }
}
function yt(t, e, a, i, o, r) {
  (t.extra.tooltip || {}).horizentalLine &&
    t.tooltip &&
    1 === i &&
    ("line" == t.type ||
      "area" == t.type ||
      "column" == t.type ||
      "mount" == t.type ||
      "candle" == t.type ||
      "mix" == t.type) &&
    pt(t, e, a),
    a.save(),
    t._scrollDistance_ &&
      0 !== t._scrollDistance_ &&
      !0 === t.enableScroll &&
      a.translate(t._scrollDistance_, 0),
    t.tooltip &&
      t.tooltip.textList &&
      t.tooltip.textList.length &&
      1 === i &&
      gt(t.tooltip.textList, t.tooltip.offset, t, e, a),
    a.restore();
}
function vt(t, e, a, i) {
  var o = e.chartData.xAxisData,
    r = o.xAxisPoints,
    n = o.startX,
    l = o.endX,
    s = o.eachSpacing,
    h = "center";
  ("bar" != e.type &&
    "line" != e.type &&
    "area" != e.type &&
    "scatter" != e.type &&
    "bubble" != e.type) ||
    (h = e.xAxis.boundaryGap);
  var c = e.height - e.area[2],
    x = e.area[0];
  if (e.enableScroll && e.xAxis.scrollShow) {
    var d = e.height - e.area[2] + a.xAxisHeight,
      p = l - n,
      f = s * (r.length - 1);
    "mount" == e.type &&
      e.extra &&
      e.extra.mount &&
      e.extra.mount.widthRatio &&
      e.extra.mount.widthRatio > 1 &&
      (e.extra.mount.widthRatio > 2 && (e.extra.mount.widthRatio = 2),
      (f += (e.extra.mount.widthRatio - 1) * s));
    var g = (p * p) / f,
      y = 0;
    e._scrollDistance_ && (y = (-e._scrollDistance_ * p) / f),
      i.beginPath(),
      i.setLineCap("round"),
      i.setLineWidth(6 * e.pix),
      i.setStrokeStyle(e.xAxis.scrollBackgroundColor || "#EFEBEF"),
      i.moveTo(n, d),
      i.lineTo(l, d),
      i.stroke(),
      i.closePath(),
      i.beginPath(),
      i.setLineCap("round"),
      i.setLineWidth(6 * e.pix),
      i.setStrokeStyle(e.xAxis.scrollColor || "#A6A6A6"),
      i.moveTo(n + y, d),
      i.lineTo(n + y + g, d),
      i.stroke(),
      i.closePath(),
      i.setLineCap("butt");
  }
  if (
    (i.save(),
    e._scrollDistance_ &&
      0 !== e._scrollDistance_ &&
      i.translate(e._scrollDistance_, 0),
    !0 === e.xAxis.calibration &&
      (i.setStrokeStyle(e.xAxis.gridColor || "#cccccc"),
      i.setLineCap("butt"),
      i.setLineWidth(1 * e.pix),
      r.forEach(function (t, a) {
        a > 0 &&
          (i.beginPath(),
          i.moveTo(t - s / 2, c),
          i.lineTo(t - s / 2, c + 3 * e.pix),
          i.closePath(),
          i.stroke());
      })),
    !0 !== e.xAxis.disableGrid &&
      (i.setStrokeStyle(e.xAxis.gridColor || "#cccccc"),
      i.setLineCap("butt"),
      i.setLineWidth(1 * e.pix),
      "dash" == e.xAxis.gridType &&
        i.setLineDash([e.xAxis.dashLength * e.pix, e.xAxis.dashLength * e.pix]),
      (e.xAxis.gridEval = e.xAxis.gridEval || 1),
      r.forEach(function (t, a) {
        a % e.xAxis.gridEval == 0 &&
          (i.beginPath(), i.moveTo(t, c), i.lineTo(t, x), i.stroke());
      }),
      i.setLineDash([])),
    !0 !== e.xAxis.disabled)
  ) {
    var v = t.length;
    e.xAxis.labelCount &&
      ((v = e.xAxis.itemCount
        ? Math.ceil((t.length / e.xAxis.itemCount) * e.xAxis.labelCount)
        : e.xAxis.labelCount),
      (v -= 1));
    for (
      var m = Math.ceil(t.length / v), S = [], b = t.length, A = 0;
      A < b;
      A++
    )
      A % m != 0 ? S.push("") : S.push(t[A]);
    S[b - 1] = t[b - 1];
    var T = e.xAxis.fontSize * e.pix || a.fontSize;
    0 === a._xAxisTextAngle_
      ? S.forEach(function (t, a) {
          var o = e.xAxis.formatter ? e.xAxis.formatter(t, a, e) : t,
            n = -u(String(o), T, i) / 2;
          "center" == h && (n += s / 2), e.xAxis.scrollShow && e.pix;
          var l = e._scrollDistance_ || 0,
            x = "center" == h ? r[a] + s / 2 : r[a];
          x - Math.abs(l) >= e.area[3] - 1 &&
            x - Math.abs(l) <= e.width - e.area[1] + 1 &&
            (i.beginPath(),
            i.setFontSize(T),
            i.setFillStyle(e.xAxis.fontColor || e.fontColor),
            i.fillText(
              String(o),
              r[a] + n,
              c +
                e.xAxis.marginTop * e.pix +
                ((e.xAxis.lineHeight - e.xAxis.fontSize) * e.pix) / 2 +
                e.xAxis.fontSize * e.pix
            ),
            i.closePath(),
            i.stroke());
        })
      : S.forEach(function (t, o) {
          var n = e.xAxis.formatter ? e.xAxis.formatter(t) : t,
            l = e._scrollDistance_ || 0,
            x = "center" == h ? r[o] + s / 2 : r[o];
          if (
            x - Math.abs(l) >= e.area[3] - 1 &&
            x - Math.abs(l) <= e.width - e.area[1] + 1
          ) {
            i.save(),
              i.beginPath(),
              i.setFontSize(T),
              i.setFillStyle(e.xAxis.fontColor || e.fontColor);
            var d = u(String(n), T, i),
              p = r[o];
            "center" == h && (p = r[o] + s / 2), e.xAxis.scrollShow && e.pix;
            var f =
              c +
              e.xAxis.marginTop * e.pix +
              T -
              T * Math.abs(Math.sin(a._xAxisTextAngle_));
            e.xAxis.rotateAngle < 0
              ? ((p -= T / 2), (d = 0))
              : ((p += T / 2), (d = -d)),
              i.translate(p, f),
              i.rotate(-1 * a._xAxisTextAngle_),
              i.fillText(String(n), d, 0),
              i.closePath(),
              i.stroke(),
              i.restore();
          }
        });
  }
  i.restore(),
    e.xAxis.title &&
      (i.beginPath(),
      i.setFontSize(e.xAxis.titleFontSize * e.pix),
      i.setFillStyle(e.xAxis.titleFontColor),
      i.fillText(
        String(e.xAxis.title),
        e.width - e.area[1] + e.xAxis.titleOffsetX * e.pix,
        e.height -
          e.area[2] +
          e.xAxis.marginTop * e.pix +
          ((e.xAxis.lineHeight - e.xAxis.titleFontSize) * e.pix) / 2 +
          (e.xAxis.titleFontSize + e.xAxis.titleOffsetY) * e.pix
      ),
      i.closePath(),
      i.stroke()),
    e.xAxis.axisLine &&
      (i.beginPath(),
      i.setStrokeStyle(e.xAxis.axisLineColor),
      i.setLineWidth(1 * e.pix),
      i.moveTo(n, e.height - e.area[2]),
      i.lineTo(l, e.height - e.area[2]),
      i.stroke());
}
function mt(t, e, a, i) {
  if (!0 !== e.yAxis.disableGrid) {
    var o = (e.height - e.area[0] - e.area[2]) / e.yAxis.splitNumber,
      r = e.area[3],
      n = e.chartData.xAxisData.xAxisPoints,
      l = e.chartData.xAxisData.eachSpacing,
      s = l * (n.length - 1);
    "mount" == e.type &&
      e.extra &&
      e.extra.mount &&
      e.extra.mount.widthRatio &&
      e.extra.mount.widthRatio > 1 &&
      (e.extra.mount.widthRatio > 2 && (e.extra.mount.widthRatio = 2),
      (s += (e.extra.mount.widthRatio - 1) * l));
    var h = r + s,
      c = [],
      x = 1;
    !1 === e.xAxis.axisLine && (x = 0);
    for (var d = x; d < e.yAxis.splitNumber + 1; d++)
      c.push(e.height - e.area[2] - o * d);
    i.save(),
      e._scrollDistance_ &&
        0 !== e._scrollDistance_ &&
        i.translate(e._scrollDistance_, 0),
      "dash" == e.yAxis.gridType &&
        i.setLineDash([e.yAxis.dashLength * e.pix, e.yAxis.dashLength * e.pix]),
      i.setStrokeStyle(e.yAxis.gridColor),
      i.setLineWidth(1 * e.pix),
      c.forEach(function (t, e) {
        i.beginPath(), i.moveTo(r, t), i.lineTo(h, t), i.stroke();
      }),
      i.setLineDash([]),
      i.restore();
  }
}
function St(t, e, a, i) {
  if (!0 !== e.yAxis.disabled) {
    var o = e.height - e.area[0] - e.area[2],
      r = o / e.yAxis.splitNumber,
      n = e.area[3],
      l = e.width - e.area[1],
      s = e.height - e.area[2];
    i.beginPath(),
      i.setFillStyle(e.background),
      1 == e.enableScroll &&
        e.xAxis.scrollPosition &&
        "left" !== e.xAxis.scrollPosition &&
        i.fillRect(0, 0, n, s + 2 * e.pix),
      1 == e.enableScroll &&
        e.xAxis.scrollPosition &&
        "right" !== e.xAxis.scrollPosition &&
        i.fillRect(l, 0, e.width, s + 2 * e.pix),
      i.closePath(),
      i.stroke();
    var h = e.area[3],
      c = e.width - e.area[1],
      x = e.area[3] + (e.width - e.area[1] - e.area[3]) / 2;
    if (e.yAxis.data)
      for (
        var d,
          p = function () {
            var t = e.yAxis.data[f];
            if (((d = []), "categories" === t.type))
              for (var n = 0; n <= t.categories.length; n++)
                d.push(
                  e.area[0] +
                    o / t.categories.length / 2 +
                    (o / t.categories.length) * n
                );
            else
              for (var l = 0; l <= e.yAxis.splitNumber; l++)
                d.push(e.area[0] + r * l);
            if (!0 !== t.disabled) {
              var s = e.chartData.yAxisData.rangesFormat[f],
                p = t.fontSize ? t.fontSize * e.pix : a.fontSize,
                g = e.chartData.yAxisData.yAxisWidth[f],
                y = t.textAlign || "right";
              if (
                (s.forEach(function (a, o) {
                  var r = d[o];
                  i.beginPath(),
                    i.setFontSize(p),
                    i.setLineWidth(1 * e.pix),
                    i.setStrokeStyle(t.axisLineColor || "#cccccc"),
                    i.setFillStyle(t.fontColor || e.fontColor);
                  var n = 0,
                    l = 4 * e.pix;
                  if ("left" == g.position) {
                    switch (
                      (1 == t.calibration &&
                        (i.moveTo(h, r),
                        i.lineTo(h - 3 * e.pix, r),
                        (l += 3 * e.pix)),
                      y)
                    ) {
                      case "left":
                        i.setTextAlign("left"), (n = h - g.width);
                        break;
                      case "right":
                        i.setTextAlign("right"), (n = h - l);
                        break;
                      default:
                        i.setTextAlign("center"), (n = h - g.width / 2);
                    }
                    i.fillText(String(a), n, r + p / 2 - 3 * e.pix);
                  } else if ("right" == g.position) {
                    switch (
                      (1 == t.calibration &&
                        (i.moveTo(c, r),
                        i.lineTo(c + 3 * e.pix, r),
                        (l += 3 * e.pix)),
                      y)
                    ) {
                      case "left":
                        i.setTextAlign("left"), (n = c + l);
                        break;
                      case "right":
                        i.setTextAlign("right"), (n = c + g.width);
                        break;
                      default:
                        i.setTextAlign("center"), (n = c + g.width / 2);
                    }
                    i.fillText(String(a), n, r + p / 2 - 3 * e.pix);
                  } else if ("center" == g.position) {
                    switch (
                      (1 == t.calibration &&
                        (i.moveTo(x, r),
                        i.lineTo(x - 3 * e.pix, r),
                        (l += 3 * e.pix)),
                      y)
                    ) {
                      case "left":
                        i.setTextAlign("left"), (n = x - g.width);
                        break;
                      case "right":
                        i.setTextAlign("right"), (n = x - l);
                        break;
                      default:
                        i.setTextAlign("center"), (n = x - g.width / 2);
                    }
                    i.fillText(String(a), n, r + p / 2 - 3 * e.pix);
                  }
                  i.closePath(), i.stroke(), i.setTextAlign("left");
                }),
                !1 !== t.axisLine &&
                  (i.beginPath(),
                  i.setStrokeStyle(t.axisLineColor || "#cccccc"),
                  i.setLineWidth(1 * e.pix),
                  "left" == g.position
                    ? (i.moveTo(h, e.height - e.area[2]),
                      i.lineTo(h, e.area[0]))
                    : "right" == g.position
                    ? (i.moveTo(c, e.height - e.area[2]),
                      i.lineTo(c, e.area[0]))
                    : "center" == g.position &&
                      (i.moveTo(x, e.height - e.area[2]),
                      i.lineTo(x, e.area[0])),
                  i.stroke()),
                e.yAxis.showTitle)
              ) {
                var v = t.titleFontSize * e.pix || a.fontSize,
                  m = t.title;
                i.beginPath(),
                  i.setFontSize(v),
                  i.setFillStyle(t.titleFontColor || e.fontColor),
                  "left" == g.position
                    ? i.fillText(
                        m,
                        h - u(m, v, i) / 2 + (t.titleOffsetX || 0),
                        e.area[0] - (10 - (t.titleOffsetY || 0)) * e.pix
                      )
                    : "right" == g.position
                    ? i.fillText(
                        m,
                        c - u(m, v, i) / 2 + (t.titleOffsetX || 0),
                        e.area[0] - (10 - (t.titleOffsetY || 0)) * e.pix
                      )
                    : "center" == g.position &&
                      i.fillText(
                        m,
                        x - u(m, v, i) / 2 + (t.titleOffsetX || 0),
                        e.area[0] - (10 - (t.titleOffsetY || 0)) * e.pix
                      ),
                  i.closePath(),
                  i.stroke();
              }
              "left" == g.position
                ? (h -= g.width + e.yAxis.padding * e.pix)
                : (c += g.width + e.yAxis.padding * e.pix);
            }
          },
          f = 0;
        f < e.yAxis.data.length;
        f++
      )
        p();
  }
}
function bt(t, e, a, i, o) {
  if (!1 !== e.legend.show) {
    var r = o.legendData,
      n = r.points,
      l = r.area,
      s = e.legend.padding * e.pix,
      h = e.legend.fontSize * e.pix,
      c = 15 * e.pix,
      x = 5 * e.pix,
      d = e.legend.itemGap * e.pix,
      p = Math.max(e.legend.lineHeight * e.pix, h);
    i.beginPath(),
      i.setLineWidth(e.legend.borderWidth * e.pix),
      i.setStrokeStyle(e.legend.borderColor),
      i.setFillStyle(e.legend.backgroundColor),
      i.moveTo(l.start.x, l.start.y),
      i.rect(l.start.x, l.start.y, l.width, l.height),
      i.closePath(),
      i.fill(),
      i.stroke(),
      n.forEach(function (t, o) {
        var n,
          f = 0;
        (f = r.widthArr[o]), (n = r.heightArr[o]);
        var g = 0,
          y = 0;
        if ("top" == e.legend.position || "bottom" == e.legend.position) {
          switch (e.legend.float) {
            case "left":
              g = l.start.x + s;
              break;
            case "right":
              g = l.start.x + l.width - f;
              break;
            default:
              g = l.start.x + (l.width - f) / 2;
          }
          y = l.start.y + s + o * p;
        } else (f = 0 == o ? 0 : r.widthArr[o - 1]), (g = l.start.x + s + f), (y = l.start.y + s + (l.height - n) / 2);
        i.setFontSize(a.fontSize);
        for (var v = 0; v < t.length; v++) {
          var m = t[v];
          switch (
            ((m.area = [0, 0, 0, 0]),
            (m.area[0] = g),
            (m.area[1] = y),
            (m.area[3] = y + p),
            i.beginPath(),
            i.setLineWidth(1 * e.pix),
            i.setStrokeStyle(m.show ? m.color : e.legend.hiddenColor),
            i.setFillStyle(m.show ? m.color : e.legend.hiddenColor),
            m.legendShape)
          ) {
            case "line":
              i.moveTo(g, y + 0.5 * p - 2 * e.pix),
                i.fillRect(g, y + 0.5 * p - 2 * e.pix, 15 * e.pix, 4 * e.pix);
              break;
            case "triangle":
              i.moveTo(g + 7.5 * e.pix, y + 0.5 * p - 5 * e.pix),
                i.lineTo(g + 2.5 * e.pix, y + 0.5 * p + 5 * e.pix),
                i.lineTo(g + 12.5 * e.pix, y + 0.5 * p + 5 * e.pix),
                i.lineTo(g + 7.5 * e.pix, y + 0.5 * p - 5 * e.pix);
              break;
            case "diamond":
              i.moveTo(g + 7.5 * e.pix, y + 0.5 * p - 5 * e.pix),
                i.lineTo(g + 2.5 * e.pix, y + 0.5 * p),
                i.lineTo(g + 7.5 * e.pix, y + 0.5 * p + 5 * e.pix),
                i.lineTo(g + 12.5 * e.pix, y + 0.5 * p),
                i.lineTo(g + 7.5 * e.pix, y + 0.5 * p - 5 * e.pix);
              break;
            case "circle":
              i.moveTo(g + 7.5 * e.pix, y + 0.5 * p),
                i.arc(g + 7.5 * e.pix, y + 0.5 * p, 5 * e.pix, 0, 2 * Math.PI);
              break;
            case "rect":
              i.moveTo(g, y + 0.5 * p - 5 * e.pix),
                i.fillRect(g, y + 0.5 * p - 5 * e.pix, 15 * e.pix, 10 * e.pix);
              break;
            case "square":
              i.moveTo(g + 5 * e.pix, y + 0.5 * p - 5 * e.pix),
                i.fillRect(
                  g + 5 * e.pix,
                  y + 0.5 * p - 5 * e.pix,
                  10 * e.pix,
                  10 * e.pix
                );
              break;
            case "none":
              break;
            default:
              i.moveTo(g, y + 0.5 * p - 5 * e.pix),
                i.fillRect(g, y + 0.5 * p - 5 * e.pix, 15 * e.pix, 10 * e.pix);
          }
          i.closePath(), i.fill(), i.stroke(), (g += c + x);
          var S = 0.5 * p + 0.5 * h - 2,
            b = m.legendText ? m.legendText : m.name;
          i.beginPath(),
            i.setFontSize(h),
            i.setFillStyle(m.show ? e.legend.fontColor : e.legend.hiddenColor),
            i.fillText(b, g, y + S),
            i.closePath(),
            i.stroke(),
            "top" == e.legend.position || "bottom" == e.legend.position
              ? ((g += u(b, h, i) + d), (m.area[2] = g))
              : ((m.area[2] = g + u(b, h, i) + d), (g -= c + x), (y += p));
        }
      });
  }
}
function At(t, e, a, i) {
  var r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1,
    l = o(
      {},
      {
        activeOpacity: 0.5,
        activeRadius: 10,
        offsetAngle: 0,
        labelWidth: 15,
        ringWidth: 30,
        customRadius: 0,
        border: !1,
        borderWidth: 2,
        borderColor: "#FFFFFF",
        centerColor: "#FFFFFF",
        linearType: "none",
        customColor: [],
      },
      "pie" == e.type ? e.extra.pie : e.extra.ring
    ),
    s = {
      x: e.area[3] + (e.width - e.area[1] - e.area[3]) / 2,
      y: e.area[0] + (e.height - e.area[0] - e.area[2]) / 2,
    };
  0 == a.pieChartLinePadding &&
    (a.pieChartLinePadding = l.activeRadius * e.pix);
  var h = Math.min(
    (e.width - e.area[1] - e.area[3]) / 2 -
      a.pieChartLinePadding -
      a.pieChartTextPadding -
      a._pieTextMaxLength_,
    (e.height - e.area[0] - e.area[2]) / 2 -
      a.pieChartLinePadding -
      a.pieChartTextPadding
  );
  (h = h < 10 ? 10 : h),
    l.customRadius > 0 && (h = l.customRadius * e.pix),
    (t = k(t, h, r));
  var c = l.activeRadius * e.pix;
  if (
    ((l.customColor = f(l.linearType, l.customColor, t, a)),
    (t = t.map(function (t) {
      return (t._start_ += (l.offsetAngle * Math.PI) / 180), t;
    })).forEach(function (t, a) {
      e.tooltip &&
        e.tooltip.index == a &&
        (i.beginPath(),
        i.setFillStyle(n(t.color, l.activeOpacity || 0.5)),
        i.moveTo(s.x, s.y),
        i.arc(
          s.x,
          s.y,
          t._radius_ + c,
          t._start_,
          t._start_ + 2 * t._proportion_ * Math.PI
        ),
        i.closePath(),
        i.fill()),
        i.beginPath(),
        i.setLineWidth(l.borderWidth * e.pix),
        (i.lineJoin = "round"),
        i.setStrokeStyle(l.borderColor);
      var o,
        r = t.color;
      "custom" == l.linearType &&
        ((o = i.createCircularGradient
          ? i.createCircularGradient(s.x, s.y, t._radius_)
          : i.createRadialGradient(
              s.x,
              s.y,
              0,
              s.x,
              s.y,
              t._radius_
            )).addColorStop(0, n(l.customColor[t.linearIndex], 1)),
        o.addColorStop(1, n(t.color, 1)),
        (r = o));
      i.setFillStyle(r),
        i.moveTo(s.x, s.y),
        i.arc(
          s.x,
          s.y,
          t._radius_,
          t._start_,
          t._start_ + 2 * t._proportion_ * Math.PI
        ),
        i.closePath(),
        i.fill(),
        1 == l.border && i.stroke();
    }),
    "ring" === e.type)
  ) {
    var x = 0.6 * h;
    "number" == typeof l.ringWidth &&
      l.ringWidth > 0 &&
      (x = Math.max(0, h - l.ringWidth * e.pix)),
      i.beginPath(),
      i.setFillStyle(l.centerColor),
      i.moveTo(s.x, s.y),
      i.arc(s.x, s.y, x, 0, 2 * Math.PI),
      i.closePath(),
      i.fill();
  }
  return (
    !1 !== e.dataLabel && 1 === r && xt(t, e, a, i, 0, s),
    1 === r && "ring" === e.type && ot(e, a, i, s),
    { center: s, radius: h, series: t }
  );
}
function Tt(t, e) {
  var a = Array(2),
    i = (20037508.34 * t) / 180,
    o = Math.log(Math.tan(((90 + e) * Math.PI) / 360)) / (Math.PI / 180);
  return (o = (20037508.34 * o) / 180), (a[0] = i), (a[1] = o), a;
}
function Pt(t, e, a, i, o, r) {
  return { x: (e - a.xMin) * i + o, y: (a.yMax - t) * i + r };
}
function wt(t, e, a) {
  return (
    e[1] != a[1] &&
    !(e[1] > t[1] && a[1] > t[1]) &&
    !(e[1] < t[1] && a[1] < t[1]) &&
    !(e[1] == t[1] && a[1] > t[1]) &&
    !(a[1] == t[1] && e[1] > t[1]) &&
    !(e[0] < t[0] && a[1] < t[1]) &&
    !(a[0] - ((a[0] - e[0]) * (a[1] - t[1])) / (a[1] - e[1]) < t[0])
  );
}
function Ct(t, e, a) {
  for (var i = 0, o = 0; o < e.length; o++) {
    var r = e[o][0];
    1 == e.length && (r = e[o][0]);
    for (var n = 0; n < r.length - 1; n++) {
      var l = r[n],
        s = r[n + 1];
      a && ((l = Tt(r[n][0], r[n][1])), (s = Tt(r[n + 1][0], r[n + 1][1]))),
        wt(t, l, s) && (i += 1);
    }
  }
  return i % 2 == 1;
}
function Mt(t, e, a) {
  a = 0 == a ? 1 : a;
  for (var i = [], o = 0; o < a; o++) i[o] = Math.random();
  return (
    Math.floor(
      (i.reduce(function (t, e) {
        return t + e;
      }) /
        a) *
        (e - t)
    ) + t
  );
}
function _t(t, e, a, i) {
  for (var o = !1, r = 0; r < e.length; r++)
    if (e[r].area) {
      if (
        !(
          t[3] < e[r].area[1] ||
          t[0] > e[r].area[2] ||
          t[1] > e[r].area[3] ||
          t[2] < e[r].area[0]
        )
      ) {
        o = !0;
        break;
      }
      if (t[0] < 0 || t[1] < 0 || t[2] > a || t[3] > i) {
        o = !0;
        break;
      }
      o = !1;
    }
  return o;
}
function Ft(t, e, a) {
  var i = t.series;
  switch (e) {
    case "normal":
      for (var o = 0; o < i.length; o++) {
        for (
          var r = i[o].name,
            n = i[o].textSize * t.pix,
            l = u(r, n, a),
            s = void 0,
            h = void 0,
            c = void 0,
            x = 0;
          ;

        ) {
          if (
            (x++,
            (s = Mt(-t.width / 2, t.width / 2, 5) - l / 2),
            (h = Mt(-t.height / 2, t.height / 2, 5) + n / 2),
            !_t(
              (c = [
                s - 5 + t.width / 2,
                h - 5 - n + t.height / 2,
                s + l + 5 + t.width / 2,
                h + 5 + t.height / 2,
              ]),
              i,
              t.width,
              t.height
            ))
          )
            break;
          if (1e3 == x) {
            c = [-100, -100, -100, -100];
            break;
          }
        }
        i[o].area = c;
      }
      break;
    case "vertical":
      for (var d = 0; d < i.length; d++) {
        for (
          var p = i[d].name,
            f = i[d].textSize * t.pix,
            g = u(p, f, a),
            y = Math.random() > 0.7,
            v = void 0,
            m = void 0,
            S = void 0,
            b = void 0,
            A = 0;
          ;

        ) {
          A++;
          var T = void 0;
          if (
            (y
              ? ((v = Mt(-t.width / 2, t.width / 2, 5) - g / 2),
                (S = [
                  (m = Mt(-t.height / 2, t.height / 2, 5) + f / 2) -
                    5 -
                    g +
                    t.width / 2,
                  -v - 5 + t.height / 2,
                  m + 5 + t.width / 2,
                  -v + f + 5 + t.height / 2,
                ]),
                (T = _t(
                  (b = [
                    t.width -
                      (t.width / 2 - t.height / 2) -
                      (-v + f + 5 + t.height / 2) -
                      5,
                    t.height / 2 - t.width / 2 + (m - 5 - g + t.width / 2) - 5,
                    t.width -
                      (t.width / 2 - t.height / 2) -
                      (-v + f + 5 + t.height / 2) +
                      f,
                    t.height / 2 -
                      t.width / 2 +
                      (m - 5 - g + t.width / 2) +
                      g +
                      5,
                  ]),
                  i,
                  t.height,
                  t.width
                )))
              : ((v = Mt(-t.width / 2, t.width / 2, 5) - g / 2),
                (m = Mt(-t.height / 2, t.height / 2, 5) + f / 2),
                (T = _t(
                  (S = [
                    v - 5 + t.width / 2,
                    m - 5 - f + t.height / 2,
                    v + g + 5 + t.width / 2,
                    m + 5 + t.height / 2,
                  ]),
                  i,
                  t.width,
                  t.height
                ))),
            !T)
          )
            break;
          if (1e3 == A) {
            S = [-1e3, -1e3, -1e3, -1e3];
            break;
          }
        }
        y ? ((i[d].area = b), (i[d].areav = S)) : (i[d].area = S),
          (i[d].rotate = y);
      }
  }
  return i;
}
function Dt(t, e, a, i, o, n, l) {
  for (var s = 0; s < t.length; s++) {
    var h = t[s];
    if (!1 !== h.labelShow) {
      var c = void 0,
        x = void 0,
        d = void 0,
        p = void 0,
        f = h.formatter
          ? h.formatter(h, s, t, e)
          : r.toFixed(100 * h._proportion_) + "%";
      (f = h.labelText ? h.labelText : f),
        "right" == o &&
          ((x =
            (c =
              s == t.length - 1
                ? (h.funnelArea[2] + l.x) / 2
                : (h.funnelArea[2] + t[s + 1].funnelArea[2]) / 2) +
            2 * n),
          (d = h.funnelArea[1] + i / 2),
          (p = h.textSize * e.pix || e.fontSize * e.pix),
          a.setLineWidth(1 * e.pix),
          a.setStrokeStyle(h.color),
          a.setFillStyle(h.color),
          a.beginPath(),
          a.moveTo(c, d),
          a.lineTo(x, d),
          a.stroke(),
          a.closePath(),
          a.beginPath(),
          a.moveTo(x, d),
          a.arc(x, d, 2 * e.pix, 0, 2 * Math.PI),
          a.closePath(),
          a.fill(),
          a.beginPath(),
          a.setFontSize(p),
          a.setFillStyle(h.textColor || e.fontColor),
          a.fillText(f, x + 5, d + p / 2 - 2),
          a.closePath(),
          a.stroke(),
          a.closePath()),
        "left" == o &&
          ((x =
            (c =
              s == t.length - 1
                ? (h.funnelArea[0] + l.x) / 2
                : (h.funnelArea[0] + t[s + 1].funnelArea[0]) / 2) -
            2 * n),
          (d = h.funnelArea[1] + i / 2),
          (p = h.textSize * e.pix || e.fontSize * e.pix),
          a.setLineWidth(1 * e.pix),
          a.setStrokeStyle(h.color),
          a.setFillStyle(h.color),
          a.beginPath(),
          a.moveTo(c, d),
          a.lineTo(x, d),
          a.stroke(),
          a.closePath(),
          a.beginPath(),
          a.moveTo(x, d),
          a.arc(x, d, 2, 0, 2 * Math.PI),
          a.closePath(),
          a.fill(),
          a.beginPath(),
          a.setFontSize(p),
          a.setFillStyle(h.textColor || e.fontColor),
          a.fillText(f, x - 5 - u(f, p, a), d + p / 2 - 2),
          a.closePath(),
          a.stroke(),
          a.closePath());
    }
  }
}
function Lt(t, e, a, i, o, r, n) {
  for (var l = 0; l < t.length; l++) {
    var s = t[l],
      h = void 0,
      c = void 0;
    s.centerText &&
      ((h = s.funnelArea[1] + i / 2),
      (c = s.centerTextSize * e.pix || e.fontSize * e.pix),
      a.beginPath(),
      a.setFontSize(c),
      a.setFillStyle(s.centerTextColor || "#FFFFFF"),
      a.fillText(s.centerText, n.x - u(s.centerText, c, a) / 2, h + c / 2 - 2),
      a.closePath(),
      a.stroke(),
      a.closePath());
  }
}
function kt(t, e) {
  e.save(), e.translate(0, 0.5), e.restore(), e.draw();
}
var It = {
  easeIn: function (t) {
    return Math.pow(t, 3);
  },
  easeOut: function (t) {
    return Math.pow(t - 1, 3) + 1;
  },
  easeInOut: function (t) {
    return (t /= 0.5) < 1
      ? 0.5 * Math.pow(t, 3)
      : 0.5 * (Math.pow(t - 2, 3) + 2);
  },
  linear: function (t) {
    return t;
  },
};
function Ot(t) {
  (this.isStop = !1),
    (t.duration = void 0 === t.duration ? 1e3 : t.duration),
    (t.timing = t.timing || "easeInOut");
  var e =
      "undefined" != typeof setTimeout
        ? function (t, e) {
            setTimeout(function () {
              t(+new Date());
            }, e);
          }
        : "undefined" != typeof requestAnimationFrame
        ? requestAnimationFrame
        : function (t) {
            t(null);
          },
    a = null,
    i = function (o) {
      if (null === o || !0 === this.isStop)
        return (
          t.onProcess && t.onProcess(1),
          void (t.onAnimationFinish && t.onAnimationFinish())
        );
      if ((null === a && (a = o), o - a < t.duration)) {
        var r = (o - a) / t.duration;
        (r = (0, It[t.timing])(r)), t.onProcess && t.onProcess(r), e(i, 17);
      } else
        t.onProcess && t.onProcess(1),
          t.onAnimationFinish && t.onAnimationFinish();
    };
  (i = i.bind(this)), e(i, 17);
}
function zt(i, l, s, h) {
  var d = this,
    y = this,
    v = l.series;
  "line" === i &&
    (v = (function (t, i, o) {
      var r = [];
      if (
        t.length > 0 &&
        t[0].data.constructor.toString().indexOf("Array") > -1
      ) {
        var n,
          l = [],
          s = [],
          h = a(t[0].data);
        try {
          for (h.s(); !(n = h.n()).done; ) {
            var c = n.value;
            "object" === e(c) && null !== c
              ? (l.push(c.value), s.push(c.labelText))
              : (l.push(c), s.push(c));
          }
        } catch (t) {
          h.e(t);
        } finally {
          h.f();
        }
        (t[0].data = l), t[0].labelText || (t[0].labelText = s), r.push(t[0]);
      } else r = t;
      return r;
    })(v)),
    ("pie" !== i &&
      "ring" !== i &&
      "mount" !== i &&
      "rose" !== i &&
      "funnel" !== i) ||
      (v = (function (t, e, a) {
        var i = [];
        if (
          t.length > 0 &&
          t[0].data.constructor.toString().indexOf("Array") > -1
        ) {
          e._pieSeries_ = t;
          for (var o = t[0].data, r = 0; r < o.length; r++)
            (o[r].formatter = t[0].formatter),
              (o[r].data = o[r].value),
              i.push(o[r]);
          e.series = i;
        } else i = t;
        return i;
      })(v, l));
  var m = l.categories;
  if ("mount" === i) {
    m = [];
    for (var A = 0; A < v.length; A++) !1 !== v[A].show && m.push(v[A].name);
    l.categories = m;
  }
  v = p(v, l, s);
  var T = l.animation ? l.duration : 0;
  y.animationInstance && y.animationInstance.stop();
  var P = null;
  if ("candle" == i) {
    var C = o({}, l.extra.candle.average);
    C.show
      ? ((P = p(
          (P = (function (t, e, a, i) {
            for (var o = [], r = 0; r < t.length; r++) {
              for (
                var n = { data: [], name: e[r], color: a[r] },
                  l = 0,
                  s = i.length;
                l < s;
                l++
              )
                if (l < t[r]) n.data.push(null);
                else {
                  for (var h = 0, c = 0; c < t[r]; c++) h += i[l - c][1];
                  n.data.push(+(h / t[r]).toFixed(3));
                }
              o.push(n);
            }
            return o;
          })(C.day, C.name, C.color, v[0].data)),
          l,
          s
        )),
        (l.seriesMA = P))
      : (P = l.seriesMA ? (l.seriesMA = p(l.seriesMA, l, s)) : v);
  } else P = v;
  (l._series_ = v = w(v)), (l.area = new Array(4));
  for (var M = 0; M < 4; M++) l.area[M] = l.padding[M] * l.pix;
  var V = (function (t, e, a, i, o) {
      var r = {
        area: {
          start: { x: 0, y: 0 },
          end: { x: 0, y: 0 },
          width: 0,
          height: 0,
          wholeWidth: 0,
          wholeHeight: 0,
        },
        points: [],
        widthArr: [],
        heightArr: [],
      };
      if (!1 === e.legend.show) return (i.legendData = r), r;
      var n = e.legend.padding * e.pix,
        l = e.legend.margin * e.pix,
        s = e.legend.fontSize ? e.legend.fontSize * e.pix : a.fontSize,
        h = 15 * e.pix,
        c = 5 * e.pix,
        x = Math.max(e.legend.lineHeight * e.pix, s);
      if ("top" == e.legend.position || "bottom" == e.legend.position) {
        for (var d = [], p = 0, f = [], g = [], y = 0; y < t.length; y++) {
          var v = t[y],
            m =
              h +
              c +
              u((v.legendText ? v.legendText : v.name) || "undefined", s, o) +
              e.legend.itemGap * e.pix;
          p + m > e.width - e.area[1] - e.area[3]
            ? (d.push(g),
              f.push(p - e.legend.itemGap * e.pix),
              (p = m),
              (g = [v]))
            : ((p += m), g.push(v));
        }
        if (g.length) {
          d.push(g), f.push(p - e.legend.itemGap * e.pix), (r.widthArr = f);
          var S = Math.max.apply(null, f);
          switch (e.legend.float) {
            case "left":
              (r.area.start.x = e.area[3]),
                (r.area.end.x = e.area[3] + S + 2 * n);
              break;
            case "right":
              (r.area.start.x = e.width - e.area[1] - S - 2 * n),
                (r.area.end.x = e.width - e.area[1]);
              break;
            default:
              (r.area.start.x = (e.width - S) / 2 - n),
                (r.area.end.x = (e.width + S) / 2 + n);
          }
          (r.area.width = S + 2 * n),
            (r.area.wholeWidth = S + 2 * n),
            (r.area.height = d.length * x + 2 * n),
            (r.area.wholeHeight = d.length * x + 2 * n + 2 * l),
            (r.points = d);
        }
      } else {
        var b = t.length,
          A = e.height - e.area[0] - e.area[2] - 2 * l - 2 * n,
          T = Math.min(Math.floor(A / x), b);
        switch (
          ((r.area.height = T * x + 2 * n),
          (r.area.wholeHeight = T * x + 2 * n),
          e.legend.float)
        ) {
          case "top":
            (r.area.start.y = e.area[0] + l),
              (r.area.end.y = e.area[0] + l + r.area.height);
            break;
          case "bottom":
            (r.area.start.y = e.height - e.area[2] - l - r.area.height),
              (r.area.end.y = e.height - e.area[2] - l);
            break;
          default:
            (r.area.start.y = (e.height - r.area.height) / 2),
              (r.area.end.y = (e.height + r.area.height) / 2);
        }
        for (
          var P = b % T == 0 ? b / T : Math.floor(b / T + 1), w = [], C = 0;
          C < P;
          C++
        ) {
          var M = t.slice(C * T, C * T + T);
          w.push(M);
        }
        if (((r.points = w), w.length)) {
          for (var _ = 0; _ < w.length; _++) {
            for (var F = w[_], D = 0, L = 0; L < F.length; L++) {
              var k =
                h +
                c +
                u(F[L].name || "undefined", s, o) +
                e.legend.itemGap * e.pix;
              k > D && (D = k);
            }
            r.widthArr.push(D), r.heightArr.push(F.length * x + 2 * n);
          }
          for (var I = 0, O = 0; O < r.widthArr.length; O++) I += r.widthArr[O];
          (r.area.width = I - e.legend.itemGap * e.pix + 2 * n),
            (r.area.wholeWidth = r.area.width + n);
        }
      }
      switch (e.legend.position) {
        case "top":
          (r.area.start.y = e.area[0] + l),
            (r.area.end.y = e.area[0] + l + r.area.height);
          break;
        case "bottom":
          (r.area.start.y = e.height - e.area[2] - r.area.height - l),
            (r.area.end.y = e.height - e.area[2] - l);
          break;
        case "left":
          (r.area.start.x = e.area[3]),
            (r.area.end.x = e.area[3] + r.area.width);
          break;
        case "right":
          (r.area.start.x = e.width - e.area[1] - r.area.width),
            (r.area.end.x = e.width - e.area[1]);
      }
      return (i.legendData = r), r;
    })(P, l, s, l.chartData, h),
    pt = V.area.wholeHeight,
    gt = V.area.wholeWidth;
  switch (l.legend.position) {
    case "top":
      l.area[0] += pt;
      break;
    case "bottom":
      l.area[2] += pt;
      break;
    case "left":
      l.area[3] += gt;
      break;
    case "right":
      l.area[1] += gt;
  }
  var wt = {},
    Ct = 0;
  if (
    "line" === l.type ||
    "column" === l.type ||
    "mount" === l.type ||
    "area" === l.type ||
    "mix" === l.type ||
    "candle" === l.type ||
    "scatter" === l.type ||
    "bubble" === l.type ||
    "bar" === l.type
  ) {
    if (((Ct = (wt = tt(v, l, s, h)).yAxisWidth), l.yAxis.showTitle)) {
      for (var Mt = 0, _t = 0; _t < l.yAxis.data.length; _t++)
        Mt = Math.max(
          Mt,
          l.yAxis.data[_t].titleFontSize
            ? l.yAxis.data[_t].titleFontSize * l.pix
            : s.fontSize
        );
      l.area[0] += Mt;
    }
    for (var It = 0, zt = 0, Wt = 0; Wt < Ct.length; Wt++)
      "left" == Ct[Wt].position
        ? ((l.area[3] +=
            zt > 0 ? Ct[Wt].width + l.yAxis.padding * l.pix : Ct[Wt].width),
          (zt += 1))
        : "right" == Ct[Wt].position &&
          ((l.area[1] +=
            It > 0 ? Ct[Wt].width + l.yAxis.padding * l.pix : Ct[Wt].width),
          (It += 1));
  } else s.yAxisWidth = Ct;
  if (
    ((l.chartData.yAxisData = wt),
    l.categories &&
      l.categories.length &&
      "radar" !== l.type &&
      "gauge" !== l.type &&
      "bar" !== l.type)
  ) {
    l.chartData.xAxisData = j(l.categories, l);
    var Rt = F(l.categories, l, 0, l.chartData.xAxisData.eachSpacing, h),
      Et = Rt.xAxisHeight,
      Bt = Rt.angle;
    (s.xAxisHeight = Et),
      (s._xAxisTextAngle_ = Bt),
      (l.area[2] += Et),
      (l.chartData.categoriesData = Rt);
  } else if (
    "line" === l.type ||
    "area" === l.type ||
    "scatter" === l.type ||
    "bubble" === l.type ||
    "bar" === l.type
  ) {
    l.chartData.xAxisData = D(v, l, s, h);
    var Gt = F(
        (m = l.chartData.xAxisData.rangesFormat),
        l,
        0,
        l.chartData.xAxisData.eachSpacing,
        h
      ),
      Xt = Gt.xAxisHeight,
      Nt = Gt.angle;
    (s.xAxisHeight = Xt),
      (s._xAxisTextAngle_ = Nt),
      (l.area[2] += Xt),
      (l.chartData.categoriesData = Gt);
  } else l.chartData.xAxisData = { xAxisPoints: [] };
  if (
    l.enableScroll &&
    "right" == l.xAxis.scrollAlign &&
    void 0 === l._scrollDistance_
  ) {
    var Ht,
      jt = l.chartData.xAxisData.xAxisPoints,
      Yt = l.chartData.xAxisData.startX;
    (Ht =
      l.chartData.xAxisData.endX -
      Yt -
      l.chartData.xAxisData.eachSpacing * (jt.length - 1)),
      (y.scrollOption.currentOffset = Ht),
      (y.scrollOption.startTouchX = Ht),
      (y.scrollOption.distance = 0),
      (y.scrollOption.lastMoveTime = 0),
      (l._scrollDistance_ = Ht);
  }
  switch (
    (("pie" !== i && "ring" !== i && "rose" !== i) ||
      (s._pieTextMaxLength_ =
        !1 === l.dataLabel
          ? 0
          : (function (t, e, a, i) {
              t = k(t);
              for (var o = 0, n = 0; n < t.length; n++) {
                var l = t[n],
                  s = l.formatter
                    ? l.formatter(+l._proportion_.toFixed(2))
                    : r.toFixed(100 * l._proportion_) + "%";
                o = Math.max(o, u(s, l.textSize * i.pix || e.fontSize, a));
              }
              return o;
            })(P, s, h, l)),
    i)
  ) {
    case "word":
      this.animationInstance = new Ot({
        timing: l.timing,
        duration: T,
        onProcess: function (t) {
          h.clearRect(0, 0, l.width, l.height),
            l.rotate && et(h, l),
            (function (t, e, a, i) {
              var r =
                  arguments.length > 4 && void 0 !== arguments[4]
                    ? arguments[4]
                    : 1,
                n = o({}, { type: "normal", autoColors: !0 }, e.extra.word);
              e.chartData.wordCloudData ||
                (e.chartData.wordCloudData = Ft(e, n.type, i)),
                i.beginPath(),
                i.setFillStyle(e.background),
                i.rect(0, 0, e.width, e.height),
                i.fill(),
                i.save();
              var l = e.chartData.wordCloudData;
              i.translate(e.width / 2, e.height / 2);
              for (var s = 0; s < l.length; s++) {
                i.save(), l[s].rotate && i.rotate((90 * Math.PI) / 180);
                var h = l[s].name,
                  c = l[s].textSize * e.pix,
                  x = u(h, c, i);
                i.beginPath(),
                  i.setStrokeStyle(l[s].color),
                  i.setFillStyle(l[s].color),
                  i.setFontSize(c),
                  l[s].rotate
                    ? l[s].areav[0] > 0 &&
                      (e.tooltip && e.tooltip.index == s
                        ? i.strokeText(
                            h,
                            (l[s].areav[0] + 5 - e.width / 2) * r -
                              (x * (1 - r)) / 2,
                            (l[s].areav[1] + 5 + c - e.height / 2) * r
                          )
                        : i.fillText(
                            h,
                            (l[s].areav[0] + 5 - e.width / 2) * r -
                              (x * (1 - r)) / 2,
                            (l[s].areav[1] + 5 + c - e.height / 2) * r
                          ))
                    : l[s].area[0] > 0 &&
                      (e.tooltip && e.tooltip.index == s
                        ? i.strokeText(
                            h,
                            (l[s].area[0] + 5 - e.width / 2) * r -
                              (x * (1 - r)) / 2,
                            (l[s].area[1] + 5 + c - e.height / 2) * r
                          )
                        : i.fillText(
                            h,
                            (l[s].area[0] + 5 - e.width / 2) * r -
                              (x * (1 - r)) / 2,
                            (l[s].area[1] + 5 + c - e.height / 2) * r
                          )),
                  i.stroke(),
                  i.restore();
              }
              i.restore();
            })(v, l, s, h, t),
            kt(0, h);
        },
        onAnimationFinish: function () {
          y.uevent.trigger("renderComplete");
        },
      });
      break;
    case "map":
      h.clearRect(0, 0, l.width, l.height),
        (function (t, e, a, i) {
          var r,
            l,
            s = o(
              {},
              {
                border: !0,
                mercator: !1,
                borderWidth: 1,
                active: !0,
                borderColor: "#666666",
                fillOpacity: 0.6,
                activeBorderColor: "#f04864",
                activeFillColor: "#facc14",
                activeFillOpacity: 1,
              },
              e.extra.map
            ),
            h = t,
            c = (function (t) {
              for (
                var e, a = { xMin: 180, xMax: 0, yMin: 90, yMax: 0 }, i = 0;
                i < t.length;
                i++
              )
                for (
                  var o = t[i].geometry.coordinates, r = 0;
                  r < o.length;
                  r++
                ) {
                  1 == (e = o[r]).length && (e = e[0]);
                  for (var n = 0; n < e.length; n++) {
                    var l = { x: e[n][0], y: e[n][1] };
                    (a.xMin = a.xMin < l.x ? a.xMin : l.x),
                      (a.xMax = a.xMax > l.x ? a.xMax : l.x),
                      (a.yMin = a.yMin < l.y ? a.yMin : l.y),
                      (a.yMax = a.yMax > l.y ? a.yMax : l.y);
                  }
                }
              return a;
            })(h);
          if (s.mercator) {
            var x = Tt(c.xMax, c.yMax),
              d = Tt(c.xMin, c.yMin);
            (c.xMax = x[0]), (c.yMax = x[1]), (c.xMin = d[0]), (c.yMin = d[1]);
          }
          for (
            var p = e.width / Math.abs(c.xMax - c.xMin),
              f = e.height / Math.abs(c.yMax - c.yMin),
              g = p < f ? p : f,
              y = e.width / 2 - (Math.abs(c.xMax - c.xMin) / 2) * g,
              v = e.height / 2 - (Math.abs(c.yMax - c.yMin) / 2) * g,
              m = 0;
            m < h.length;
            m++
          ) {
            i.beginPath(),
              i.setLineWidth(s.borderWidth * e.pix),
              i.setStrokeStyle(s.borderColor),
              i.setFillStyle(n(t[m].color, t[m].fillOpacity || s.fillOpacity)),
              1 == s.active &&
                e.tooltip &&
                e.tooltip.index == m &&
                (i.setStrokeStyle(s.activeBorderColor),
                i.setFillStyle(n(s.activeFillColor, s.activeFillOpacity)));
            for (var S = h[m].geometry.coordinates, b = 0; b < S.length; b++) {
              1 == (r = S[b]).length && (r = r[0]);
              for (var A = 0; A < r.length; A++) {
                var T = Array(2);
                (l = Pt(
                  (T = s.mercator ? Tt(r[A][0], r[A][1]) : r[A])[1],
                  T[0],
                  c,
                  g,
                  y,
                  v
                )),
                  0 === A
                    ? (i.beginPath(), i.moveTo(l.x, l.y))
                    : i.lineTo(l.x, l.y);
              }
              i.fill(), 1 == s.border && i.stroke();
            }
          }
          if (1 == e.dataLabel)
            for (m = 0; m < h.length; m++) {
              var P = h[m].properties.centroid;
              if (P) {
                s.mercator &&
                  (P = Tt(
                    h[m].properties.centroid[0],
                    h[m].properties.centroid[1]
                  )),
                  (l = Pt(P[1], P[0], c, g, y, v));
                var w = h[m].textSize * e.pix || a.fontSize,
                  C = h[m].textColor || e.fontColor;
                s.active &&
                  s.activeTextColor &&
                  e.tooltip &&
                  e.tooltip.index == m &&
                  (C = s.activeTextColor);
                var M = h[m].properties.name;
                i.beginPath(),
                  i.setFontSize(w),
                  i.setFillStyle(C),
                  i.fillText(M, l.x - u(M, w, i) / 2, l.y + w / 2),
                  i.closePath(),
                  i.stroke();
              }
            }
          (e.chartData.mapData = {
            bounds: c,
            scale: g,
            xoffset: y,
            yoffset: v,
            mercator: s.mercator,
          }),
            yt(e, a, i, 1),
            i.draw();
        })(v, l, s, h),
        setTimeout(function () {
          d.uevent.trigger("renderComplete");
        }, 50);
      break;
    case "funnel":
      this.animationInstance = new Ot({
        timing: l.timing,
        duration: T,
        onProcess: function (t) {
          h.clearRect(0, 0, l.width, l.height),
            l.rotate && et(h, l),
            (l.chartData.funnelData = (function (t, e, a, i) {
              var r =
                  arguments.length > 4 && void 0 !== arguments[4]
                    ? arguments[4]
                    : 1,
                l = o(
                  {},
                  {
                    type: "funnel",
                    activeWidth: 10,
                    activeOpacity: 0.3,
                    border: !1,
                    borderWidth: 2,
                    borderColor: "#FFFFFF",
                    fillOpacity: 1,
                    minSize: 0,
                    labelAlign: "right",
                    linearType: "none",
                    customColor: [],
                  },
                  e.extra.funnel
                ),
                s = (e.height - e.area[0] - e.area[2]) / t.length,
                h = {
                  x: e.area[3] + (e.width - e.area[1] - e.area[3]) / 2,
                  y: e.height - e.area[2],
                },
                c = l.activeWidth * e.pix,
                x = Math.min(
                  (e.width - e.area[1] - e.area[3]) / 2 - c,
                  (e.height - e.area[0] - e.area[2]) / 2 - c
                ),
                d = I(t, x, l, s, r);
              if (
                (i.save(),
                i.translate(h.x, h.y),
                (l.customColor = f(l.linearType, l.customColor, t, a)),
                "pyramid" == l.type)
              )
                for (var p = 0; p < d.length; p++) {
                  if (p == d.length - 1) {
                    e.tooltip &&
                      e.tooltip.index == p &&
                      (i.beginPath(),
                      i.setFillStyle(n(d[p].color, l.activeOpacity)),
                      i.moveTo(-c, -s),
                      i.lineTo(-d[p].radius - c, 0),
                      i.lineTo(d[p].radius + c, 0),
                      i.lineTo(c, -s),
                      i.lineTo(-c, -s),
                      i.closePath(),
                      i.fill()),
                      (d[p].funnelArea = [
                        h.x - d[p].radius,
                        h.y - s * (p + 1),
                        h.x + d[p].radius,
                        h.y - s * p,
                      ]),
                      i.beginPath(),
                      i.setLineWidth(l.borderWidth * e.pix),
                      i.setStrokeStyle(l.borderColor);
                    var u = n(d[p].color, l.fillOpacity);
                    if ("custom" == l.linearType)
                      (y = i.createLinearGradient(
                        d[p].radius,
                        -s,
                        -d[p].radius,
                        -s
                      )).addColorStop(0, n(d[p].color, l.fillOpacity)),
                        y.addColorStop(
                          0.5,
                          n(l.customColor[d[p].linearIndex], l.fillOpacity)
                        ),
                        y.addColorStop(1, n(d[p].color, l.fillOpacity)),
                        (u = y);
                    i.setFillStyle(u),
                      i.moveTo(0, -s),
                      i.lineTo(-d[p].radius, 0),
                      i.lineTo(d[p].radius, 0),
                      i.lineTo(0, -s),
                      i.closePath(),
                      i.fill(),
                      1 == l.border && i.stroke();
                  } else {
                    e.tooltip &&
                      e.tooltip.index == p &&
                      (i.beginPath(),
                      i.setFillStyle(n(d[p].color, l.activeOpacity)),
                      i.moveTo(0, 0),
                      i.lineTo(-d[p].radius - c, 0),
                      i.lineTo(-d[p + 1].radius - c, -s),
                      i.lineTo(d[p + 1].radius + c, -s),
                      i.lineTo(d[p].radius + c, 0),
                      i.lineTo(0, 0),
                      i.closePath(),
                      i.fill()),
                      (d[p].funnelArea = [
                        h.x - d[p].radius,
                        h.y - s * (p + 1),
                        h.x + d[p].radius,
                        h.y - s * p,
                      ]),
                      i.beginPath(),
                      i.setLineWidth(l.borderWidth * e.pix),
                      i.setStrokeStyle(l.borderColor);
                    u = n(d[p].color, l.fillOpacity);
                    if ("custom" == l.linearType)
                      (y = i.createLinearGradient(
                        d[p].radius,
                        -s,
                        -d[p].radius,
                        -s
                      )).addColorStop(0, n(d[p].color, l.fillOpacity)),
                        y.addColorStop(
                          0.5,
                          n(l.customColor[d[p].linearIndex], l.fillOpacity)
                        ),
                        y.addColorStop(1, n(d[p].color, l.fillOpacity)),
                        (u = y);
                    i.setFillStyle(u),
                      i.moveTo(0, 0),
                      i.lineTo(-d[p].radius, 0),
                      i.lineTo(-d[p + 1].radius, -s),
                      i.lineTo(d[p + 1].radius, -s),
                      i.lineTo(d[p].radius, 0),
                      i.lineTo(0, 0),
                      i.closePath(),
                      i.fill(),
                      1 == l.border && i.stroke();
                  }
                  i.translate(0, -s);
                }
              else {
                i.translate(0, -(d.length - 1) * s);
                for (var g = 0; g < d.length; g++) {
                  if (g == d.length - 1) {
                    e.tooltip &&
                      e.tooltip.index == g &&
                      (i.beginPath(),
                      i.setFillStyle(n(d[g].color, l.activeOpacity)),
                      i.moveTo(-c - l.minSize / 2, 0),
                      i.lineTo(-d[g].radius - c, -s),
                      i.lineTo(d[g].radius + c, -s),
                      i.lineTo(c + l.minSize / 2, 0),
                      i.lineTo(-c - l.minSize / 2, 0),
                      i.closePath(),
                      i.fill()),
                      (d[g].funnelArea = [
                        h.x - d[g].radius,
                        h.y - s,
                        h.x + d[g].radius,
                        h.y,
                      ]),
                      i.beginPath(),
                      i.setLineWidth(l.borderWidth * e.pix),
                      i.setStrokeStyle(l.borderColor);
                    u = n(d[g].color, l.fillOpacity);
                    if ("custom" == l.linearType)
                      (y = i.createLinearGradient(
                        d[g].radius,
                        -s,
                        -d[g].radius,
                        -s
                      )).addColorStop(0, n(d[g].color, l.fillOpacity)),
                        y.addColorStop(
                          0.5,
                          n(l.customColor[d[g].linearIndex], l.fillOpacity)
                        ),
                        y.addColorStop(1, n(d[g].color, l.fillOpacity)),
                        (u = y);
                    i.setFillStyle(u),
                      i.moveTo(0, 0),
                      i.lineTo(-l.minSize / 2, 0),
                      i.lineTo(-d[g].radius, -s),
                      i.lineTo(d[g].radius, -s),
                      i.lineTo(l.minSize / 2, 0),
                      i.lineTo(0, 0),
                      i.closePath(),
                      i.fill(),
                      1 == l.border && i.stroke();
                  } else {
                    e.tooltip &&
                      e.tooltip.index == g &&
                      (i.beginPath(),
                      i.setFillStyle(n(d[g].color, l.activeOpacity)),
                      i.moveTo(0, 0),
                      i.lineTo(-d[g + 1].radius - c, 0),
                      i.lineTo(-d[g].radius - c, -s),
                      i.lineTo(d[g].radius + c, -s),
                      i.lineTo(d[g + 1].radius + c, 0),
                      i.lineTo(0, 0),
                      i.closePath(),
                      i.fill()),
                      (d[g].funnelArea = [
                        h.x - d[g].radius,
                        h.y - s * (d.length - g),
                        h.x + d[g].radius,
                        h.y - s * (d.length - g - 1),
                      ]),
                      i.beginPath(),
                      i.setLineWidth(l.borderWidth * e.pix),
                      i.setStrokeStyle(l.borderColor);
                    var y;
                    u = n(d[g].color, l.fillOpacity);
                    if ("custom" == l.linearType)
                      (y = i.createLinearGradient(
                        d[g].radius,
                        -s,
                        -d[g].radius,
                        -s
                      )).addColorStop(0, n(d[g].color, l.fillOpacity)),
                        y.addColorStop(
                          0.5,
                          n(l.customColor[d[g].linearIndex], l.fillOpacity)
                        ),
                        y.addColorStop(1, n(d[g].color, l.fillOpacity)),
                        (u = y);
                    i.setFillStyle(u),
                      i.moveTo(0, 0),
                      i.lineTo(-d[g + 1].radius, 0),
                      i.lineTo(-d[g].radius, -s),
                      i.lineTo(d[g].radius, -s),
                      i.lineTo(d[g + 1].radius, 0),
                      i.lineTo(0, 0),
                      i.closePath(),
                      i.fill(),
                      1 == l.border && i.stroke();
                  }
                  i.translate(0, s);
                }
              }
              return (
                i.restore(),
                !1 !== e.dataLabel &&
                  1 === r &&
                  Dt(d, e, i, s, l.labelAlign, c, h),
                1 === r && Lt(d, e, i, s, l.labelAlign, c, h),
                { center: h, radius: x, series: d }
              );
            })(v, l, s, h, t)),
            bt(l.series, l, s, h, l.chartData),
            yt(l, s, h, t),
            kt(0, h);
        },
        onAnimationFinish: function () {
          y.uevent.trigger("renderComplete");
        },
      });
      break;
    case "line":
      this.animationInstance = new Ot({
        timing: l.timing,
        duration: T,
        onProcess: function (t) {
          h.clearRect(0, 0, l.width, l.height),
            l.rotate && et(h, l),
            mt(0, l, 0, h),
            vt(m, l, s, h);
          var e = (function (t, e, a, i) {
              var r =
                  arguments.length > 4 && void 0 !== arguments[4]
                    ? arguments[4]
                    : 1,
                l = o(
                  {},
                  {
                    type: "straight",
                    width: 2,
                    activeType: "none",
                    linearType: "none",
                    onShadow: !1,
                    animation: "vertical",
                  },
                  e.extra.line
                );
              l.width *= e.pix;
              var s = e.chartData.xAxisData,
                h = s.xAxisPoints,
                x = s.eachSpacing,
                d = [];
              i.save();
              var p = 0,
                f = e.width + x;
              return (
                e._scrollDistance_ &&
                  0 !== e._scrollDistance_ &&
                  !0 === e.enableScroll &&
                  (i.translate(e._scrollDistance_, 0),
                  (p = -e._scrollDistance_ - 2 * x + e.area[3]),
                  (f = p + (e.xAxis.itemCount + 4) * x)),
                t.forEach(function (t, o) {
                  var s, u, g;
                  i.beginPath(),
                    i.setStrokeStyle(t.color),
                    i.moveTo(-1e4, -1e4),
                    i.lineTo(-10001, -10001),
                    i.stroke(),
                    (u = (s = [].concat(
                      e.chartData.yAxisData.ranges[t.index]
                    )).pop()),
                    (g = s.shift());
                  var y = J(t.data, u, g, h, x, e, a, l, r);
                  d.push(y);
                  var v = _(y, t);
                  if ("dash" == t.lineType) {
                    var m = t.dashLength ? t.dashLength : 8;
                    (m *= e.pix), i.setLineDash([m, m]);
                  }
                  i.beginPath();
                  var S = t.color;
                  if (
                    "none" !== l.linearType &&
                    t.linearColor &&
                    t.linearColor.length > 0
                  ) {
                    for (
                      var b = i.createLinearGradient(
                          e.chartData.xAxisData.startX,
                          e.height / 2,
                          e.chartData.xAxisData.endX,
                          e.height / 2
                        ),
                        A = 0;
                      A < t.linearColor.length;
                      A++
                    )
                      b.addColorStop(
                        t.linearColor[A][0],
                        n(t.linearColor[A][1], 1)
                      );
                    S = b;
                  }
                  i.setStrokeStyle(S),
                    1 == l.onShadow && t.setShadow && t.setShadow.length > 0
                      ? i.setShadow(
                          t.setShadow[0],
                          t.setShadow[1],
                          t.setShadow[2],
                          t.setShadow[3]
                        )
                      : i.setShadow(0, 0, 0, "rgba(0,0,0,0)"),
                    i.setLineWidth(l.width),
                    v.forEach(function (t, e) {
                      if (1 === t.length) i.moveTo(t[0].x, t[0].y);
                      else {
                        i.moveTo(t[0].x, t[0].y);
                        var a = 0;
                        if ("curve" === l.type)
                          for (var o = 0; o < t.length; o++) {
                            var r = t[o];
                            if (
                              (0 == a &&
                                r.x > p &&
                                (i.moveTo(r.x, r.y), (a = 1)),
                              o > 0 && r.x > p && r.x < f)
                            ) {
                              var n = c(t, o - 1);
                              i.bezierCurveTo(
                                n.ctrA.x,
                                n.ctrA.y,
                                n.ctrB.x,
                                n.ctrB.y,
                                r.x,
                                r.y
                              );
                            }
                          }
                        if ("straight" === l.type)
                          for (var s = 0; s < t.length; s++) {
                            var h = t[s];
                            0 == a && h.x > p && (i.moveTo(h.x, h.y), (a = 1)),
                              s > 0 && h.x > p && h.x < f && i.lineTo(h.x, h.y);
                          }
                        if ("step" === l.type)
                          for (var x = 0; x < t.length; x++) {
                            var d = t[x];
                            0 == a && d.x > p && (i.moveTo(d.x, d.y), (a = 1)),
                              x > 0 &&
                                d.x > p &&
                                d.x < f &&
                                (i.lineTo(d.x, t[x - 1].y), i.lineTo(d.x, d.y));
                          }
                        i.moveTo(t[0].x, t[0].y);
                      }
                    }),
                    i.stroke(),
                    i.setLineDash([]),
                    !1 !== e.dataPointShape &&
                      at(y, t.color, t.pointShape, i, e),
                    it(y, t.color, t.pointShape, i, e, l);
                }),
                !1 !== e.dataLabel &&
                  1 === r &&
                  t.forEach(function (t, o) {
                    var n, l, s;
                    (l = (n = [].concat(
                      e.chartData.yAxisData.ranges[t.index]
                    )).pop()),
                      (s = n.shift()),
                      rt(q(t.data, l, s, h, x, e, a, r), t, a, i, e);
                  }),
                i.restore(),
                { xAxisPoints: h, calPoints: d, eachSpacing: x }
              );
            })(v, l, s, h, t),
            a = e.xAxisPoints,
            i = e.calPoints,
            r = e.eachSpacing;
          (l.chartData.xAxisPoints = a),
            (l.chartData.calPoints = i),
            (l.chartData.eachSpacing = r),
            St(0, l, s, h),
            !1 !== l.enableMarkLine && 1 === t && dt(l, 0, h),
            bt(l.series, l, s, h, l.chartData),
            yt(l, s, h, t),
            kt(0, h);
        },
        onAnimationFinish: function () {
          y.uevent.trigger("renderComplete");
        },
      });
      break;
    case "scatter":
      this.animationInstance = new Ot({
        timing: l.timing,
        duration: T,
        onProcess: function (t) {
          h.clearRect(0, 0, l.width, l.height),
            l.rotate && et(h, l),
            mt(0, l, 0, h),
            vt(m, l, s, h);
          var e = (function (t, e, a, i) {
              var r =
                arguments.length > 4 && void 0 !== arguments[4]
                  ? arguments[4]
                  : 1;
              o({}, { type: "circle" }, e.extra.scatter);
              var n = e.chartData.xAxisData,
                l = n.xAxisPoints,
                s = n.eachSpacing,
                h = [];
              return (
                i.save(),
                e.width,
                e._scrollDistance_ &&
                  0 !== e._scrollDistance_ &&
                  !0 === e.enableScroll &&
                  (i.translate(e._scrollDistance_, 0),
                  -e._scrollDistance_ - 2 * s + e.area[3],
                  e.xAxis.itemCount),
                t.forEach(function (t, o) {
                  var n, h, c;
                  (h = (n = [].concat(
                    e.chartData.yAxisData.ranges[t.index]
                  )).pop()),
                    (c = n.shift());
                  var x = q(t.data, h, c, l, s, e, a, r);
                  i.beginPath(),
                    i.setStrokeStyle(t.color),
                    i.setFillStyle(t.color),
                    i.setLineWidth(1 * e.pix);
                  var d = t.pointShape;
                  if ("diamond" === d)
                    x.forEach(function (t, e) {
                      null !== t &&
                        (i.moveTo(t.x, t.y - 4.5),
                        i.lineTo(t.x - 4.5, t.y),
                        i.lineTo(t.x, t.y + 4.5),
                        i.lineTo(t.x + 4.5, t.y),
                        i.lineTo(t.x, t.y - 4.5));
                    });
                  else if ("circle" === d)
                    x.forEach(function (t, a) {
                      null !== t &&
                        (i.moveTo(t.x + 2.5 * e.pix, t.y),
                        i.arc(t.x, t.y, 3 * e.pix, 0, 2 * Math.PI, !1));
                    });
                  else if ("square" === d)
                    x.forEach(function (t, e) {
                      null !== t &&
                        (i.moveTo(t.x - 3.5, t.y - 3.5),
                        i.rect(t.x - 3.5, t.y - 3.5, 7, 7));
                    });
                  else if ("triangle" === d)
                    x.forEach(function (t, e) {
                      null !== t &&
                        (i.moveTo(t.x, t.y - 4.5),
                        i.lineTo(t.x - 4.5, t.y + 4.5),
                        i.lineTo(t.x + 4.5, t.y + 4.5),
                        i.lineTo(t.x, t.y - 4.5));
                    });
                  else if ("triangle" === d) return;
                  i.closePath(), i.fill(), i.stroke();
                }),
                !1 !== e.dataLabel &&
                  1 === r &&
                  t.forEach(function (t, o) {
                    var n, h, c;
                    (h = (n = [].concat(
                      e.chartData.yAxisData.ranges[t.index]
                    )).pop()),
                      (c = n.shift()),
                      rt(q(t.data, h, c, l, s, e, a, r), t, a, i, e);
                  }),
                i.restore(),
                { xAxisPoints: l, calPoints: h, eachSpacing: s }
              );
            })(v, l, s, h, t),
            a = e.xAxisPoints,
            i = e.calPoints,
            r = e.eachSpacing;
          (l.chartData.xAxisPoints = a),
            (l.chartData.calPoints = i),
            (l.chartData.eachSpacing = r),
            St(0, l, s, h),
            !1 !== l.enableMarkLine && 1 === t && dt(l, 0, h),
            bt(l.series, l, s, h, l.chartData),
            yt(l, s, h, t),
            kt(0, h);
        },
        onAnimationFinish: function () {
          y.uevent.trigger("renderComplete");
        },
      });
      break;
    case "bubble":
      this.animationInstance = new Ot({
        timing: l.timing,
        duration: T,
        onProcess: function (t) {
          h.clearRect(0, 0, l.width, l.height),
            l.rotate && et(h, l),
            mt(0, l, 0, h),
            vt(m, l, s, h);
          var e = (function (t, e, a, i) {
              var r =
                  arguments.length > 4 && void 0 !== arguments[4]
                    ? arguments[4]
                    : 1,
                l = o({}, { opacity: 1, border: 2 }, e.extra.bubble),
                s = e.chartData.xAxisData,
                h = s.xAxisPoints,
                c = s.eachSpacing,
                x = [];
              return (
                i.save(),
                e.width,
                e._scrollDistance_ &&
                  0 !== e._scrollDistance_ &&
                  !0 === e.enableScroll &&
                  (i.translate(e._scrollDistance_, 0),
                  -e._scrollDistance_ - 2 * c + e.area[3],
                  e.xAxis.itemCount),
                t.forEach(function (t, o) {
                  var s, x, d;
                  (x = (s = [].concat(
                    e.chartData.yAxisData.ranges[t.index]
                  )).pop()),
                    (d = s.shift());
                  var p = q(t.data, x, d, h, c, e, a, r);
                  i.beginPath(),
                    i.setStrokeStyle(t.color),
                    i.setLineWidth(l.border * e.pix),
                    i.setFillStyle(n(t.color, l.opacity)),
                    p.forEach(function (t, a) {
                      i.moveTo(t.x + t.r, t.y),
                        i.arc(t.x, t.y, t.r * e.pix, 0, 2 * Math.PI, !1);
                    }),
                    i.closePath(),
                    i.fill(),
                    i.stroke(),
                    !1 !== e.dataLabel &&
                      1 === r &&
                      p.forEach(function (o, r) {
                        i.beginPath();
                        var n = t.textSize * e.pix || a.fontSize;
                        i.setFontSize(n),
                          i.setFillStyle(t.textColor || "#FFFFFF"),
                          i.setTextAlign("center"),
                          i.fillText(String(o.t), o.x, o.y + n / 2),
                          i.closePath(),
                          i.stroke(),
                          i.setTextAlign("left");
                      });
                }),
                i.restore(),
                { xAxisPoints: h, calPoints: x, eachSpacing: c }
              );
            })(v, l, s, h, t),
            a = e.xAxisPoints,
            i = e.calPoints,
            r = e.eachSpacing;
          (l.chartData.xAxisPoints = a),
            (l.chartData.calPoints = i),
            (l.chartData.eachSpacing = r),
            St(0, l, s, h),
            !1 !== l.enableMarkLine && 1 === t && dt(l, 0, h),
            bt(l.series, l, s, h, l.chartData),
            yt(l, s, h, t),
            kt(0, h);
        },
        onAnimationFinish: function () {
          y.uevent.trigger("renderComplete");
        },
      });
      break;
    case "mix":
      this.animationInstance = new Ot({
        timing: l.timing,
        duration: T,
        onProcess: function (e) {
          h.clearRect(0, 0, l.width, l.height),
            l.rotate && et(h, l),
            mt(0, l, 0, h),
            vt(m, l, s, h);
          var a = (function (e, a, i, r) {
              var l =
                  arguments.length > 4 && void 0 !== arguments[4]
                    ? arguments[4]
                    : 1,
                s = a.chartData.xAxisData,
                h = s.xAxisPoints,
                x = s.eachSpacing,
                d = o(
                  {},
                  {
                    width: x / 2,
                    barBorderCircle: !1,
                    barBorderRadius: [],
                    seriesGap: 2,
                    linearType: "none",
                    linearOpacity: 1,
                    customColor: [],
                    colorStop: 0,
                  },
                  a.extra.mix.column
                ),
                p = o({}, { opacity: 0.2, gradient: !1 }, a.extra.mix.area),
                u = o({}, { width: 2 }, a.extra.mix.line),
                g = a.height - a.area[2],
                y = [],
                v = 0,
                m = 0;
              e.forEach(function (t, e) {
                "column" == t.type && (m += 1);
              }),
                r.save();
              var S = -2,
                b = h.length + 2,
                A = 0,
                T = a.width + x;
              if (
                (a._scrollDistance_ &&
                  0 !== a._scrollDistance_ &&
                  !0 === a.enableScroll &&
                  (r.translate(a._scrollDistance_, 0),
                  (S = Math.floor(-a._scrollDistance_ / x) - 2),
                  (b = S + a.xAxis.itemCount + 4),
                  (A = -a._scrollDistance_ - 2 * x + a.area[3]),
                  (T = A + (a.xAxis.itemCount + 4) * x)),
                (d.customColor = f(d.linearType, d.customColor, e, i)),
                e.forEach(function (e, o) {
                  var s, f, P;
                  (f = (s = [].concat(
                    a.chartData.yAxisData.ranges[e.index]
                  )).pop()),
                    (P = s.shift());
                  var w = q(e.data, f, P, h, x, a, i, l);
                  if ((y.push(w), "column" == e.type)) {
                    w = B(w, x, m, v, 0, a);
                    for (var C = 0; C < w.length; C++) {
                      var M = w[C];
                      if (null !== M && C > S && C < b) {
                        var F = M.x - M.width / 2;
                        a.height, M.y, a.area[2], r.beginPath();
                        var D = M.color || e.color,
                          L = M.color || e.color;
                        if ("none" !== d.linearType) {
                          var k = r.createLinearGradient(
                            F,
                            M.y,
                            F,
                            a.height - a.area[2]
                          );
                          "opacity" == d.linearType
                            ? (k.addColorStop(0, n(D, d.linearOpacity)),
                              k.addColorStop(1, n(D, 1)))
                            : (k.addColorStop(
                                0,
                                n(d.customColor[e.linearIndex], d.linearOpacity)
                              ),
                              k.addColorStop(
                                d.colorStop,
                                n(d.customColor[e.linearIndex], d.linearOpacity)
                              ),
                              k.addColorStop(1, n(D, 1))),
                            (D = k);
                        }
                        if (
                          (d.barBorderRadius &&
                            4 === d.barBorderRadius.length) ||
                          d.barBorderCircle
                        ) {
                          var I = F,
                            O = M.y,
                            z = M.width,
                            W = a.height - a.area[2] - M.y;
                          d.barBorderCircle &&
                            (d.barBorderRadius = [z / 2, z / 2, 0, 0]);
                          var R = t(d.barBorderRadius, 4),
                            E = R[0],
                            G = R[1],
                            X = R[2],
                            N = R[3],
                            H = Math.min(z / 2, W / 2);
                          (E = (E = E > H ? H : E) < 0 ? 0 : E),
                            (G = (G = G > H ? H : G) < 0 ? 0 : G),
                            (X = (X = X > H ? H : X) < 0 ? 0 : X),
                            (N = (N = N > H ? H : N) < 0 ? 0 : N),
                            r.arc(I + E, O + E, E, -Math.PI, -Math.PI / 2),
                            r.arc(I + z - G, O + G, G, -Math.PI / 2, 0),
                            r.arc(I + z - X, O + W - X, X, 0, Math.PI / 2),
                            r.arc(I + N, O + W - N, N, Math.PI / 2, Math.PI);
                        } else
                          r.moveTo(F, M.y),
                            r.lineTo(F + M.width, M.y),
                            r.lineTo(F + M.width, a.height - a.area[2]),
                            r.lineTo(F, a.height - a.area[2]),
                            r.lineTo(F, M.y),
                            r.setLineWidth(1),
                            r.setStrokeStyle(L);
                        r.setFillStyle(D), r.closePath(), r.fill();
                      }
                    }
                    v += 1;
                  }
                  if ("area" == e.type)
                    for (var j = _(w, e), Y = 0; Y < j.length; Y++) {
                      var J = j[Y];
                      if (
                        (r.beginPath(),
                        r.setStrokeStyle(e.color),
                        r.setStrokeStyle(n(e.color, p.opacity)),
                        p.gradient)
                      ) {
                        var Z = r.createLinearGradient(
                          0,
                          a.area[0],
                          0,
                          a.height - a.area[2]
                        );
                        Z.addColorStop("0", n(e.color, p.opacity)),
                          Z.addColorStop("1.0", n("#FFFFFF", 0.1)),
                          r.setFillStyle(Z);
                      } else r.setFillStyle(n(e.color, p.opacity));
                      if ((r.setLineWidth(2 * a.pix), J.length > 1)) {
                        var $ = J[0],
                          K = J[J.length - 1];
                        r.moveTo($.x, $.y);
                        var Q = 0;
                        if ("curve" === e.style)
                          for (var U = 0; U < J.length; U++) {
                            var V = J[U];
                            if (
                              (0 == Q &&
                                V.x > A &&
                                (r.moveTo(V.x, V.y), (Q = 1)),
                              U > 0 && V.x > A && V.x < T)
                            ) {
                              var tt = c(J, U - 1);
                              r.bezierCurveTo(
                                tt.ctrA.x,
                                tt.ctrA.y,
                                tt.ctrB.x,
                                tt.ctrB.y,
                                V.x,
                                V.y
                              );
                            }
                          }
                        else
                          for (var et = 0; et < J.length; et++) {
                            var it = J[et];
                            0 == Q &&
                              it.x > A &&
                              (r.moveTo(it.x, it.y), (Q = 1)),
                              et > 0 &&
                                it.x > A &&
                                it.x < T &&
                                r.lineTo(it.x, it.y);
                          }
                        r.lineTo(K.x, g), r.lineTo($.x, g), r.lineTo($.x, $.y);
                      } else {
                        var ot = J[0];
                        r.moveTo(ot.x - x / 2, ot.y);
                      }
                      r.closePath(), r.fill();
                    }
                  "line" == e.type &&
                    _(w, e).forEach(function (t, i) {
                      if ("dash" == e.lineType) {
                        var o = e.dashLength ? e.dashLength : 8;
                        (o *= a.pix), r.setLineDash([o, o]);
                      }
                      if (
                        (r.beginPath(),
                        r.setStrokeStyle(e.color),
                        r.setLineWidth(u.width * a.pix),
                        1 === t.length)
                      )
                        r.moveTo(t[0].x, t[0].y);
                      else {
                        r.moveTo(t[0].x, t[0].y);
                        var n = 0;
                        if ("curve" == e.style)
                          for (var l = 0; l < t.length; l++) {
                            var s = t[l];
                            if (
                              (0 == n &&
                                s.x > A &&
                                (r.moveTo(s.x, s.y), (n = 1)),
                              l > 0 && s.x > A && s.x < T)
                            ) {
                              var h = c(t, l - 1);
                              r.bezierCurveTo(
                                h.ctrA.x,
                                h.ctrA.y,
                                h.ctrB.x,
                                h.ctrB.y,
                                s.x,
                                s.y
                              );
                            }
                          }
                        else
                          for (var x = 0; x < t.length; x++) {
                            var d = t[x];
                            0 == n && d.x > A && (r.moveTo(d.x, d.y), (n = 1)),
                              x > 0 && d.x > A && d.x < T && r.lineTo(d.x, d.y);
                          }
                        r.moveTo(t[0].x, t[0].y);
                      }
                      r.stroke(), r.setLineDash([]);
                    });
                  "point" == e.type && (e.addPoint = !0),
                    1 == e.addPoint &&
                      "column" !== e.type &&
                      at(w, e.color, e.pointShape, r, a);
                }),
                !1 !== a.dataLabel && 1 === l)
              ) {
                v = 0;
                e.forEach(function (t, e) {
                  var o, n, s;
                  (n = (o = [].concat(
                    a.chartData.yAxisData.ranges[t.index]
                  )).pop()),
                    (s = o.shift());
                  var c = q(t.data, n, s, h, x, a, i, l);
                  "column" !== t.type
                    ? rt(c, t, i, r, a)
                    : (rt((c = B(c, x, m, v, 0, a)), t, i, r, a), (v += 1));
                });
              }
              return (
                r.restore(), { xAxisPoints: h, calPoints: y, eachSpacing: x }
              );
            })(v, l, s, h, e),
            i = a.xAxisPoints,
            r = a.calPoints,
            x = a.eachSpacing;
          (l.chartData.xAxisPoints = i),
            (l.chartData.calPoints = r),
            (l.chartData.eachSpacing = x),
            St(0, l, s, h),
            !1 !== l.enableMarkLine && 1 === e && dt(l, 0, h),
            bt(l.series, l, s, h, l.chartData),
            yt(l, s, h, e),
            kt(0, h);
        },
        onAnimationFinish: function () {
          y.uevent.trigger("renderComplete");
        },
      });
      break;
    case "column":
      this.animationInstance = new Ot({
        timing: l.timing,
        duration: T,
        onProcess: function (e) {
          h.clearRect(0, 0, l.width, l.height),
            l.rotate && et(h, l),
            mt(0, l, 0, h),
            vt(m, l, s, h);
          var a = (function (e, a, i, r) {
              var l =
                  arguments.length > 4 && void 0 !== arguments[4]
                    ? arguments[4]
                    : 1,
                s = a.chartData.xAxisData,
                h = s.xAxisPoints,
                c = s.eachSpacing,
                x = o(
                  {},
                  {
                    type: "group",
                    width: c / 2,
                    meterBorder: 4,
                    meterFillColor: "#FFFFFF",
                    barBorderCircle: !1,
                    barBorderRadius: [],
                    seriesGap: 2,
                    linearType: "none",
                    linearOpacity: 1,
                    customColor: [],
                    colorStop: 0,
                    labelPosition: "outside",
                  },
                  a.extra.column
                ),
                d = [];
              r.save();
              var p = -2,
                u = h.length + 2;
              return (
                a._scrollDistance_ &&
                  0 !== a._scrollDistance_ &&
                  !0 === a.enableScroll &&
                  (r.translate(a._scrollDistance_, 0),
                  (p = Math.floor(-a._scrollDistance_ / c) - 2),
                  (u = p + a.xAxis.itemCount + 4)),
                a.tooltip &&
                  a.tooltip.textList &&
                  a.tooltip.textList.length &&
                  1 === l &&
                  ft(a.tooltip.offset.x, a, 0, r, c),
                (x.customColor = f(x.linearType, x.customColor, e, i)),
                e.forEach(function (o, s) {
                  var f, g, y;
                  (g = (f = [].concat(
                    a.chartData.yAxisData.ranges[o.index]
                  )).pop()),
                    (y = f.shift());
                  var v =
                      ((a.height - a.area[0] - a.area[2]) * (0 - g)) / (y - g),
                    m = a.height - Math.round(v) - a.area[2];
                  o.zeroPoints = m;
                  var S = o.data;
                  switch (x.type) {
                    case "group":
                      var b = Z(S, g, y, h, c, a, i, m, l),
                        A = Q(S, g, y, h, c, a, i, s, e, l);
                      d.push(A), (b = B(b, c, e.length, s, 0, a));
                      for (var T = 0; T < b.length; T++) {
                        var P = b[T];
                        if (null !== P && T > p && T < u) {
                          var w = P.x - P.width / 2,
                            C = a.height - P.y - a.area[2];
                          r.beginPath();
                          var M = P.color || o.color,
                            _ = P.color || o.color;
                          if ("none" !== x.linearType) {
                            var F = r.createLinearGradient(w, P.y, w, m);
                            "opacity" == x.linearType
                              ? (F.addColorStop(0, n(M, x.linearOpacity)),
                                F.addColorStop(1, n(M, 1)))
                              : (F.addColorStop(
                                  0,
                                  n(
                                    x.customColor[o.linearIndex],
                                    x.linearOpacity
                                  )
                                ),
                                F.addColorStop(
                                  x.colorStop,
                                  n(
                                    x.customColor[o.linearIndex],
                                    x.linearOpacity
                                  )
                                ),
                                F.addColorStop(1, n(M, 1))),
                              (M = F);
                          }
                          if (
                            (x.barBorderRadius &&
                              4 === x.barBorderRadius.length) ||
                            !0 === x.barBorderCircle
                          ) {
                            var D = w,
                              L = P.y > m ? m : P.y,
                              k = P.width,
                              I = Math.abs(m - P.y);
                            x.barBorderCircle &&
                              (x.barBorderRadius = [k / 2, k / 2, 0, 0]),
                              P.y > m &&
                                (x.barBorderRadius = [0, 0, k / 2, k / 2]);
                            var O = t(x.barBorderRadius, 4),
                              z = O[0],
                              W = O[1],
                              R = O[2],
                              E = O[3],
                              G = Math.min(k / 2, I / 2);
                            (z = (z = z > G ? G : z) < 0 ? 0 : z),
                              (W = (W = W > G ? G : W) < 0 ? 0 : W),
                              (R = (R = R > G ? G : R) < 0 ? 0 : R),
                              (E = (E = E > G ? G : E) < 0 ? 0 : E),
                              r.arc(D + z, L + z, z, -Math.PI, -Math.PI / 2),
                              r.arc(D + k - W, L + W, W, -Math.PI / 2, 0),
                              r.arc(D + k - R, L + I - R, R, 0, Math.PI / 2),
                              r.arc(D + E, L + I - E, E, Math.PI / 2, Math.PI);
                          } else
                            r.moveTo(w, P.y),
                              r.lineTo(w + P.width, P.y),
                              r.lineTo(w + P.width, m),
                              r.lineTo(w, m),
                              r.lineTo(w, P.y),
                              r.setLineWidth(1),
                              r.setStrokeStyle(_);
                          r.setFillStyle(M), r.closePath(), r.fill();
                        }
                      }
                      break;
                    case "stack":
                      b = Q(S, g, y, h, c, a, i, s, e, l);
                      d.push(b), (b = N(b, c, e.length, 0, 0, a));
                      for (var H = 0; H < b.length; H++) {
                        var j = b[H];
                        if (null !== j && H > p && H < u) {
                          r.beginPath();
                          (M = j.color || o.color),
                            (w = j.x - j.width / 2 + 1),
                            (C = a.height - j.y - a.area[2]);
                          var Y = a.height - j.y0 - a.area[2];
                          s > 0 && (C -= Y),
                            r.setFillStyle(M),
                            r.moveTo(w, j.y),
                            r.fillRect(w, j.y, j.width, C),
                            r.closePath(),
                            r.fill();
                        }
                      }
                      break;
                    case "meter":
                      b = q(S, g, y, h, c, a, i, l);
                      d.push(b),
                        (b = X(b, c, e.length, s, 0, a, x.meterBorder));
                      for (var J = 0; J < b.length; J++) {
                        var $ = b[J];
                        if (null !== $ && J > p && J < u) {
                          r.beginPath(),
                            0 == s &&
                              x.meterBorder > 0 &&
                              (r.setStrokeStyle(o.color),
                              r.setLineWidth(x.meterBorder * a.pix)),
                            0 == s
                              ? r.setFillStyle(x.meterFillColor)
                              : r.setFillStyle($.color || o.color);
                          (w = $.x - $.width / 2),
                            (C = a.height - $.y - a.area[2]);
                          if (
                            (x.barBorderRadius &&
                              4 === x.barBorderRadius.length) ||
                            !0 === x.barBorderCircle
                          ) {
                            var K = w,
                              U = $.y,
                              V = $.width,
                              tt = m - $.y;
                            x.barBorderCircle &&
                              (x.barBorderRadius = [V / 2, V / 2, 0, 0]);
                            var et = t(x.barBorderRadius, 4),
                              at = et[0],
                              it = et[1],
                              ot = et[2],
                              rt = et[3],
                              nt = Math.min(V / 2, tt / 2);
                            (at = (at = at > nt ? nt : at) < 0 ? 0 : at),
                              (it = (it = it > nt ? nt : it) < 0 ? 0 : it),
                              (ot = (ot = ot > nt ? nt : ot) < 0 ? 0 : ot),
                              (rt = (rt = rt > nt ? nt : rt) < 0 ? 0 : rt),
                              r.arc(K + at, U + at, at, -Math.PI, -Math.PI / 2),
                              r.arc(K + V - it, U + it, it, -Math.PI / 2, 0),
                              r.arc(
                                K + V - ot,
                                U + tt - ot,
                                ot,
                                0,
                                Math.PI / 2
                              ),
                              r.arc(
                                K + rt,
                                U + tt - rt,
                                rt,
                                Math.PI / 2,
                                Math.PI
                              ),
                              r.fill();
                          } else
                            r.moveTo(w, $.y),
                              r.lineTo(w + $.width, $.y),
                              r.lineTo(w + $.width, m),
                              r.lineTo(w, m),
                              r.lineTo(w, $.y),
                              r.fill();
                          0 == s &&
                            x.meterBorder > 0 &&
                            (r.closePath(), r.stroke());
                        }
                      }
                  }
                }),
                !1 !== a.dataLabel &&
                  1 === l &&
                  e.forEach(function (t, o) {
                    var n, s, d;
                    (s = (n = [].concat(
                      a.chartData.yAxisData.ranges[t.index]
                    )).pop()),
                      (d = n.shift());
                    var p = t.data;
                    switch (x.type) {
                      case "group":
                        nt(
                          B(Z(p, s, d, h, c, a, i, l), c, e.length, o, 0, a),
                          t,
                          i,
                          r,
                          a
                        );
                        break;
                      case "stack":
                        nt(Q(p, s, d, h, c, a, i, o, e, l), t, i, r, a);
                        break;
                      case "meter":
                        nt(q(p, s, d, h, c, a, i, l), t, i, r, a);
                    }
                  }),
                r.restore(),
                { xAxisPoints: h, calPoints: d, eachSpacing: c }
              );
            })(v, l, s, h, e),
            i = a.xAxisPoints,
            r = a.calPoints,
            c = a.eachSpacing;
          (l.chartData.xAxisPoints = i),
            (l.chartData.calPoints = r),
            (l.chartData.eachSpacing = c),
            St(0, l, s, h),
            !1 !== l.enableMarkLine && 1 === e && dt(l, 0, h),
            bt(l.series, l, s, h, l.chartData),
            yt(l, s, h, e),
            kt(0, h);
        },
        onAnimationFinish: function () {
          y.uevent.trigger("renderComplete");
        },
      });
      break;
    case "mount":
      this.animationInstance = new Ot({
        timing: l.timing,
        duration: T,
        onProcess: function (e) {
          h.clearRect(0, 0, l.width, l.height),
            l.rotate && et(h, l),
            mt(0, l, 0, h),
            vt(m, l, s, h);
          var a = (function (e, a, i, r) {
              var l =
                  arguments.length > 4 && void 0 !== arguments[4]
                    ? arguments[4]
                    : 1,
                s = a.chartData.xAxisData,
                h = s.xAxisPoints,
                c = s.eachSpacing,
                x = o(
                  {},
                  {
                    type: "mount",
                    widthRatio: 1,
                    borderWidth: 1,
                    barBorderCircle: !1,
                    barBorderRadius: [],
                    linearType: "none",
                    linearOpacity: 1,
                    customColor: [],
                    colorStop: 0,
                  },
                  a.extra.mount
                );
              (x.widthRatio = x.widthRatio <= 0 ? 0 : x.widthRatio),
                (x.widthRatio = x.widthRatio >= 2 ? 2 : x.widthRatio),
                r.save();
              var d,
                p,
                u,
                g = -2,
                y = h.length + 2;
              a._scrollDistance_ &&
                0 !== a._scrollDistance_ &&
                !0 === a.enableScroll &&
                (r.translate(a._scrollDistance_, 0),
                (y =
                  (g = Math.floor(-a._scrollDistance_ / c) - 2) +
                  a.xAxis.itemCount +
                  4)),
                (x.customColor = f(x.linearType, x.customColor, e, i)),
                (p = (d = [].concat(a.chartData.yAxisData.ranges[0])).pop()),
                (u = d.shift());
              var v,
                m = a.height - a.area[0] - a.area[2],
                S = (m * (0 - p)) / (u - p),
                b = a.height - Math.round(S) - a.area[2],
                A = $(e, p, u, h, c, a, x, b, l);
              switch (x.type) {
                case "bar":
                  for (var T = 0; T < A.length; T++) {
                    var P = A[T];
                    if (null !== P && T > g && T < y) {
                      var w = P.x - (c * x.widthRatio) / 2,
                        C = a.height - P.y - a.area[2];
                      r.beginPath();
                      var M = P.color || e[T].color,
                        _ = P.color || e[T].color;
                      if ("none" !== x.linearType) {
                        var F = r.createLinearGradient(w, P.y, w, b);
                        "opacity" == x.linearType
                          ? (F.addColorStop(0, n(M, x.linearOpacity)),
                            F.addColorStop(1, n(M, 1)))
                          : (F.addColorStop(
                              0,
                              n(
                                x.customColor[e[T].linearIndex],
                                x.linearOpacity
                              )
                            ),
                            F.addColorStop(
                              x.colorStop,
                              n(
                                x.customColor[e[T].linearIndex],
                                x.linearOpacity
                              )
                            ),
                            F.addColorStop(1, n(M, 1))),
                          (M = F);
                      }
                      if (
                        (x.barBorderRadius && 4 === x.barBorderRadius.length) ||
                        !0 === x.barBorderCircle
                      ) {
                        var D = w,
                          L = P.y > b ? b : P.y,
                          k = P.width,
                          I = Math.abs(b - P.y);
                        x.barBorderCircle &&
                          (x.barBorderRadius = [k / 2, k / 2, 0, 0]),
                          P.y > b && (x.barBorderRadius = [0, 0, k / 2, k / 2]);
                        var O = t(x.barBorderRadius, 4),
                          z = O[0],
                          W = O[1],
                          R = O[2],
                          E = O[3],
                          B = Math.min(k / 2, I / 2);
                        (z = (z = z > B ? B : z) < 0 ? 0 : z),
                          (W = (W = W > B ? B : W) < 0 ? 0 : W),
                          (R = (R = R > B ? B : R) < 0 ? 0 : R),
                          (E = (E = E > B ? B : E) < 0 ? 0 : E),
                          r.arc(D + z, L + z, z, -Math.PI, -Math.PI / 2),
                          r.arc(D + k - W, L + W, W, -Math.PI / 2, 0),
                          r.arc(D + k - R, L + I - R, R, 0, Math.PI / 2),
                          r.arc(D + E, L + I - E, E, Math.PI / 2, Math.PI);
                      } else
                        r.moveTo(w, P.y),
                          r.lineTo(w + P.width, P.y),
                          r.lineTo(w + P.width, b),
                          r.lineTo(w, b),
                          r.lineTo(w, P.y);
                      r.setStrokeStyle(_),
                        r.setFillStyle(M),
                        x.borderWidth > 0 &&
                          (r.setLineWidth(x.borderWidth * a.pix),
                          r.closePath(),
                          r.stroke()),
                        r.fill();
                    }
                  }
                  break;
                case "triangle":
                  for (var G = 0; G < A.length; G++) {
                    var X = A[G];
                    if (null !== X && G > g && G < y) {
                      (w = X.x - (c * x.widthRatio) / 2),
                        (C = a.height - X.y - a.area[2]);
                      r.beginPath();
                      (M = X.color || e[G].color), (_ = X.color || e[G].color);
                      if ("none" !== x.linearType) {
                        F = r.createLinearGradient(w, X.y, w, b);
                        "opacity" == x.linearType
                          ? (F.addColorStop(0, n(M, x.linearOpacity)),
                            F.addColorStop(1, n(M, 1)))
                          : (F.addColorStop(
                              0,
                              n(
                                x.customColor[e[G].linearIndex],
                                x.linearOpacity
                              )
                            ),
                            F.addColorStop(
                              x.colorStop,
                              n(
                                x.customColor[e[G].linearIndex],
                                x.linearOpacity
                              )
                            ),
                            F.addColorStop(1, n(M, 1))),
                          (M = F);
                      }
                      r.moveTo(w, b),
                        r.lineTo(X.x, X.y),
                        r.lineTo(w + X.width, b),
                        r.setStrokeStyle(_),
                        r.setFillStyle(M),
                        x.borderWidth > 0 &&
                          (r.setLineWidth(x.borderWidth * a.pix), r.stroke()),
                        r.fill();
                    }
                  }
                  break;
                case "mount":
                  for (var N = 0; N < A.length; N++) {
                    var H = A[N];
                    if (null !== H && N > g && N < y) {
                      (w = H.x - (c * x.widthRatio) / 2),
                        (C = a.height - H.y - a.area[2]);
                      r.beginPath();
                      (M = H.color || e[N].color), (_ = H.color || e[N].color);
                      if ("none" !== x.linearType) {
                        F = r.createLinearGradient(w, H.y, w, b);
                        "opacity" == x.linearType
                          ? (F.addColorStop(0, n(M, x.linearOpacity)),
                            F.addColorStop(1, n(M, 1)))
                          : (F.addColorStop(
                              0,
                              n(
                                x.customColor[e[N].linearIndex],
                                x.linearOpacity
                              )
                            ),
                            F.addColorStop(
                              x.colorStop,
                              n(
                                x.customColor[e[N].linearIndex],
                                x.linearOpacity
                              )
                            ),
                            F.addColorStop(1, n(M, 1))),
                          (M = F);
                      }
                      r.moveTo(w, b),
                        r.bezierCurveTo(
                          H.x - H.width / 4,
                          b,
                          H.x - H.width / 4,
                          H.y,
                          H.x,
                          H.y
                        ),
                        r.bezierCurveTo(
                          H.x + H.width / 4,
                          H.y,
                          H.x + H.width / 4,
                          b,
                          w + H.width,
                          b
                        ),
                        r.setStrokeStyle(_),
                        r.setFillStyle(M),
                        x.borderWidth > 0 &&
                          (r.setLineWidth(x.borderWidth * a.pix), r.stroke()),
                        r.fill();
                    }
                  }
                  break;
                case "sharp":
                  for (var j = 0; j < A.length; j++) {
                    var Y = A[j];
                    if (null !== Y && j > g && j < y) {
                      (w = Y.x - (c * x.widthRatio) / 2),
                        (C = a.height - Y.y - a.area[2]);
                      r.beginPath();
                      (M = Y.color || e[j].color), (_ = Y.color || e[j].color);
                      if ("none" !== x.linearType) {
                        F = r.createLinearGradient(w, Y.y, w, b);
                        "opacity" == x.linearType
                          ? (F.addColorStop(0, n(M, x.linearOpacity)),
                            F.addColorStop(1, n(M, 1)))
                          : (F.addColorStop(
                              0,
                              n(
                                x.customColor[e[j].linearIndex],
                                x.linearOpacity
                              )
                            ),
                            F.addColorStop(
                              x.colorStop,
                              n(
                                x.customColor[e[j].linearIndex],
                                x.linearOpacity
                              )
                            ),
                            F.addColorStop(1, n(M, 1))),
                          (M = F);
                      }
                      r.moveTo(w, b),
                        r.quadraticCurveTo(Y.x - 0, b - C / 4, Y.x, Y.y),
                        r.quadraticCurveTo(Y.x + 0, b - C / 4, w + Y.width, b),
                        r.setStrokeStyle(_),
                        r.setFillStyle(M),
                        x.borderWidth > 0 &&
                          (r.setLineWidth(x.borderWidth * a.pix), r.stroke()),
                        r.fill();
                    }
                  }
              }
              return (
                !1 !== a.dataLabel &&
                  1 === l &&
                  lt(
                    (A = $(
                      e,
                      (v = [].concat(a.chartData.yAxisData.ranges[0])).pop(),
                      v.shift(),
                      h,
                      c,
                      a,
                      x,
                      b,
                      l
                    )),
                    e,
                    i,
                    r,
                    a,
                    b
                  ),
                r.restore(),
                { xAxisPoints: h, calPoints: A, eachSpacing: c }
              );
            })(v, l, s, h, e),
            i = a.xAxisPoints,
            r = a.calPoints,
            c = a.eachSpacing;
          (l.chartData.xAxisPoints = i),
            (l.chartData.calPoints = r),
            (l.chartData.eachSpacing = c),
            St(0, l, s, h),
            !1 !== l.enableMarkLine && 1 === e && dt(l, 0, h),
            bt(l.series, l, s, h, l.chartData),
            yt(l, s, h, e),
            kt(0, h);
        },
        onAnimationFinish: function () {
          y.uevent.trigger("renderComplete");
        },
      });
      break;
    case "bar":
      this.animationInstance = new Ot({
        timing: l.timing,
        duration: T,
        onProcess: function (e) {
          h.clearRect(0, 0, l.width, l.height),
            l.rotate && et(h, l),
            vt(m, l, s, h);
          var a = (function (e, a, i, r) {
              for (
                var l =
                    arguments.length > 4 && void 0 !== arguments[4]
                      ? arguments[4]
                      : 1,
                  s = [],
                  h = (a.height - a.area[0] - a.area[2]) / a.categories.length,
                  c = 0;
                c < a.categories.length;
                c++
              )
                s.push(a.area[0] + h / 2 + h * c);
              var x = o(
                  {},
                  {
                    type: "group",
                    width: h / 2,
                    meterBorder: 4,
                    meterFillColor: "#FFFFFF",
                    barBorderCircle: !1,
                    barBorderRadius: [],
                    seriesGap: 2,
                    linearType: "none",
                    linearOpacity: 1,
                    customColor: [],
                    colorStop: 0,
                  },
                  a.extra.bar
                ),
                d = [];
              r.save();
              var p = -2,
                u = s.length + 2;
              return (
                a.tooltip &&
                  a.tooltip.textList &&
                  a.tooltip.textList.length &&
                  1 === l &&
                  ut(a.tooltip.offset.y, a, 0, r, h),
                (x.customColor = f(x.linearType, x.customColor, e, i)),
                e.forEach(function (o, c) {
                  var f, g, y;
                  (y = (f = [].concat(a.chartData.xAxisData.ranges)).pop()),
                    (g = f.shift());
                  var v = o.data;
                  switch (x.type) {
                    case "group":
                      var m = K(v, g, y, s, h, a, i, l),
                        S = U(v, g, y, s, h, a, i, c, e, l);
                      d.push(S), (m = G(m, h, e.length, c, 0, a));
                      for (var b = 0; b < m.length; b++) {
                        var A = m[b];
                        if (null !== A && b > p && b < u) {
                          var T = a.area[3],
                            P = A.y - A.width / 2;
                          A.height, r.beginPath();
                          var w = A.color || o.color,
                            C = A.color || o.color;
                          if ("none" !== x.linearType) {
                            var M = r.createLinearGradient(T, A.y, A.x, A.y);
                            "opacity" == x.linearType
                              ? (M.addColorStop(0, n(w, x.linearOpacity)),
                                M.addColorStop(1, n(w, 1)))
                              : (M.addColorStop(
                                  0,
                                  n(
                                    x.customColor[o.linearIndex],
                                    x.linearOpacity
                                  )
                                ),
                                M.addColorStop(
                                  x.colorStop,
                                  n(
                                    x.customColor[o.linearIndex],
                                    x.linearOpacity
                                  )
                                ),
                                M.addColorStop(1, n(w, 1))),
                              (w = M);
                          }
                          if (
                            (x.barBorderRadius &&
                              4 === x.barBorderRadius.length) ||
                            !0 === x.barBorderCircle
                          ) {
                            var _ = T,
                              F = A.width,
                              D = A.y - A.width / 2,
                              L = A.height;
                            x.barBorderCircle &&
                              (x.barBorderRadius = [F / 2, F / 2, 0, 0]);
                            var k = t(x.barBorderRadius, 4),
                              I = k[0],
                              O = k[1],
                              z = k[2],
                              W = k[3],
                              R = Math.min(F / 2, L / 2);
                            (I = (I = I > R ? R : I) < 0 ? 0 : I),
                              (O = (O = O > R ? R : O) < 0 ? 0 : O),
                              (z = (z = z > R ? R : z) < 0 ? 0 : z),
                              (W = (W = W > R ? R : W) < 0 ? 0 : W),
                              r.arc(_ + W, D + W, W, -Math.PI, -Math.PI / 2),
                              r.arc(A.x - I, D + I, I, -Math.PI / 2, 0),
                              r.arc(A.x - O, D + F - O, O, 0, Math.PI / 2),
                              r.arc(_ + z, D + F - z, z, Math.PI / 2, Math.PI);
                          } else
                            r.moveTo(T, P),
                              r.lineTo(A.x, P),
                              r.lineTo(A.x, P + A.width),
                              r.lineTo(T, P + A.width),
                              r.lineTo(T, P),
                              r.setLineWidth(1),
                              r.setStrokeStyle(C);
                          r.setFillStyle(w), r.closePath(), r.fill();
                        }
                      }
                      break;
                    case "stack":
                      m = U(v, g, y, s, h, a, i, c, e, l);
                      d.push(m), (m = H(m, h, e.length, 0, 0, a));
                      for (var E = 0; E < m.length; E++) {
                        var B = m[E];
                        if (null !== B && E > p && E < u) {
                          r.beginPath();
                          (w = B.color || o.color), (T = B.x0);
                          r.setFillStyle(w),
                            r.moveTo(T, B.y - B.width / 2),
                            r.fillRect(T, B.y - B.width / 2, B.height, B.width),
                            r.closePath(),
                            r.fill();
                        }
                      }
                  }
                }),
                !1 !== a.dataLabel &&
                  1 === l &&
                  e.forEach(function (t, o) {
                    var n, c, d;
                    (d = (n = [].concat(a.chartData.xAxisData.ranges)).pop()),
                      (c = n.shift());
                    var p = t.data;
                    switch (x.type) {
                      case "group":
                        st(
                          G(K(p, c, d, s, h, a, i, l), h, e.length, o, 0, a),
                          t,
                          i,
                          r,
                          a
                        );
                        break;
                      case "stack":
                        st(U(p, c, d, s, h, a, i, o, e, l), t, i, r, a);
                    }
                  }),
                { yAxisPoints: s, calPoints: d, eachSpacing: h }
              );
            })(v, l, s, h, e),
            i = a.yAxisPoints,
            r = a.calPoints,
            c = a.eachSpacing;
          (l.chartData.yAxisPoints = i),
            (l.chartData.xAxisPoints = l.chartData.xAxisData.xAxisPoints),
            (l.chartData.calPoints = r),
            (l.chartData.eachSpacing = c),
            St(0, l, s, h),
            !1 !== l.enableMarkLine && 1 === e && dt(l, 0, h),
            bt(l.series, l, s, h, l.chartData),
            yt(l, s, h, e),
            kt(0, h);
        },
        onAnimationFinish: function () {
          y.uevent.trigger("renderComplete");
        },
      });
      break;
    case "area":
      this.animationInstance = new Ot({
        timing: l.timing,
        duration: T,
        onProcess: function (t) {
          h.clearRect(0, 0, l.width, l.height),
            l.rotate && et(h, l),
            mt(0, l, 0, h),
            vt(m, l, s, h);
          var e = (function (t, e, a, i) {
              var r =
                  arguments.length > 4 && void 0 !== arguments[4]
                    ? arguments[4]
                    : 1,
                l = o(
                  {},
                  {
                    type: "straight",
                    opacity: 0.2,
                    addLine: !1,
                    width: 2,
                    gradient: !1,
                    activeType: "none",
                  },
                  e.extra.area
                ),
                s = e.chartData.xAxisData,
                h = s.xAxisPoints,
                x = s.eachSpacing,
                d = e.height - e.area[2],
                p = [];
              i.save();
              var f = 0,
                u = e.width + x;
              return (
                e._scrollDistance_ &&
                  0 !== e._scrollDistance_ &&
                  !0 === e.enableScroll &&
                  (i.translate(e._scrollDistance_, 0),
                  (f = -e._scrollDistance_ - 2 * x + e.area[3]),
                  (u = f + (e.xAxis.itemCount + 4) * x)),
                t.forEach(function (t, o) {
                  var s, g, y;
                  (g = (s = [].concat(
                    e.chartData.yAxisData.ranges[t.index]
                  )).pop()),
                    (y = s.shift());
                  var v = q(t.data, g, y, h, x, e, a, r);
                  p.push(v);
                  for (var m = _(v, t), S = 0; S < m.length; S++) {
                    var b = m[S];
                    if (
                      (i.beginPath(),
                      i.setStrokeStyle(n(t.color, l.opacity)),
                      l.gradient)
                    ) {
                      var A = i.createLinearGradient(
                        0,
                        e.area[0],
                        0,
                        e.height - e.area[2]
                      );
                      A.addColorStop("0", n(t.color, l.opacity)),
                        A.addColorStop("1.0", n("#FFFFFF", 0.1)),
                        i.setFillStyle(A);
                    } else i.setFillStyle(n(t.color, l.opacity));
                    if ((i.setLineWidth(l.width * e.pix), b.length > 1)) {
                      var T = b[0],
                        P = b[b.length - 1];
                      i.moveTo(T.x, T.y);
                      var w = 0;
                      if ("curve" === l.type)
                        for (var C = 0; C < b.length; C++) {
                          var M = b[C];
                          if (
                            (0 == w && M.x > f && (i.moveTo(M.x, M.y), (w = 1)),
                            C > 0 && M.x > f && M.x < u)
                          ) {
                            var F = c(b, C - 1);
                            i.bezierCurveTo(
                              F.ctrA.x,
                              F.ctrA.y,
                              F.ctrB.x,
                              F.ctrB.y,
                              M.x,
                              M.y
                            );
                          }
                        }
                      if ("straight" === l.type)
                        for (var D = 0; D < b.length; D++) {
                          var L = b[D];
                          0 == w && L.x > f && (i.moveTo(L.x, L.y), (w = 1)),
                            D > 0 && L.x > f && L.x < u && i.lineTo(L.x, L.y);
                        }
                      if ("step" === l.type)
                        for (var k = 0; k < b.length; k++) {
                          var I = b[k];
                          0 == w && I.x > f && (i.moveTo(I.x, I.y), (w = 1)),
                            k > 0 &&
                              I.x > f &&
                              I.x < u &&
                              (i.lineTo(I.x, b[k - 1].y), i.lineTo(I.x, I.y));
                        }
                      i.lineTo(P.x, d), i.lineTo(T.x, d), i.lineTo(T.x, T.y);
                    } else {
                      var O = b[0];
                      i.moveTo(O.x - x / 2, O.y);
                    }
                    if ((i.closePath(), i.fill(), l.addLine)) {
                      if ("dash" == t.lineType) {
                        var z = t.dashLength ? t.dashLength : 8;
                        (z *= e.pix), i.setLineDash([z, z]);
                      }
                      if (
                        (i.beginPath(),
                        i.setStrokeStyle(t.color),
                        i.setLineWidth(l.width * e.pix),
                        1 === b.length)
                      )
                        i.moveTo(b[0].x, b[0].y);
                      else {
                        i.moveTo(b[0].x, b[0].y);
                        var W = 0;
                        if ("curve" === l.type)
                          for (var R = 0; R < b.length; R++) {
                            var E = b[R];
                            if (
                              (0 == W &&
                                E.x > f &&
                                (i.moveTo(E.x, E.y), (W = 1)),
                              R > 0 && E.x > f && E.x < u)
                            ) {
                              var B = c(b, R - 1);
                              i.bezierCurveTo(
                                B.ctrA.x,
                                B.ctrA.y,
                                B.ctrB.x,
                                B.ctrB.y,
                                E.x,
                                E.y
                              );
                            }
                          }
                        if ("straight" === l.type)
                          for (var G = 0; G < b.length; G++) {
                            var X = b[G];
                            0 == W && X.x > f && (i.moveTo(X.x, X.y), (W = 1)),
                              G > 0 && X.x > f && X.x < u && i.lineTo(X.x, X.y);
                          }
                        if ("step" === l.type)
                          for (var N = 0; N < b.length; N++) {
                            var H = b[N];
                            0 == W && H.x > f && (i.moveTo(H.x, H.y), (W = 1)),
                              N > 0 &&
                                H.x > f &&
                                H.x < u &&
                                (i.lineTo(H.x, b[N - 1].y), i.lineTo(H.x, H.y));
                          }
                        i.moveTo(b[0].x, b[0].y);
                      }
                      i.stroke(), i.setLineDash([]);
                    }
                  }
                  !1 !== e.dataPointShape && at(v, t.color, t.pointShape, i, e),
                    it(v, t.color, t.pointShape, i, e, l, o);
                }),
                !1 !== e.dataLabel &&
                  1 === r &&
                  t.forEach(function (t, o) {
                    var n, l, s;
                    (l = (n = [].concat(
                      e.chartData.yAxisData.ranges[t.index]
                    )).pop()),
                      (s = n.shift()),
                      rt(q(t.data, l, s, h, x, e, a, r), t, a, i, e);
                  }),
                i.restore(),
                { xAxisPoints: h, calPoints: p, eachSpacing: x }
              );
            })(v, l, s, h, t),
            a = e.xAxisPoints,
            i = e.calPoints,
            r = e.eachSpacing;
          (l.chartData.xAxisPoints = a),
            (l.chartData.calPoints = i),
            (l.chartData.eachSpacing = r),
            St(0, l, s, h),
            !1 !== l.enableMarkLine && 1 === t && dt(l, 0, h),
            bt(l.series, l, s, h, l.chartData),
            yt(l, s, h, t),
            kt(0, h);
        },
        onAnimationFinish: function () {
          y.uevent.trigger("renderComplete");
        },
      });
      break;
    case "ring":
    case "pie":
      this.animationInstance = new Ot({
        timing: l.timing,
        duration: T,
        onProcess: function (t) {
          h.clearRect(0, 0, l.width, l.height),
            l.rotate && et(h, l),
            (l.chartData.pieData = At(v, l, s, h, t)),
            bt(l.series, l, s, h, l.chartData),
            yt(l, s, h, t),
            kt(0, h);
        },
        onAnimationFinish: function () {
          y.uevent.trigger("renderComplete");
        },
      });
      break;
    case "rose":
      this.animationInstance = new Ot({
        timing: l.timing,
        duration: T,
        onProcess: function (t) {
          h.clearRect(0, 0, l.width, l.height),
            l.rotate && et(h, l),
            (l.chartData.pieData = (function (t, e, a, i) {
              var r =
                  arguments.length > 4 && void 0 !== arguments[4]
                    ? arguments[4]
                    : 1,
                l = o(
                  {},
                  {
                    type: "area",
                    activeOpacity: 0.5,
                    activeRadius: 10,
                    offsetAngle: 0,
                    labelWidth: 15,
                    border: !1,
                    borderWidth: 2,
                    borderColor: "#FFFFFF",
                    linearType: "none",
                    customColor: [],
                  },
                  e.extra.rose
                );
              0 == a.pieChartLinePadding &&
                (a.pieChartLinePadding = l.activeRadius * e.pix);
              var s = {
                  x: e.area[3] + (e.width - e.area[1] - e.area[3]) / 2,
                  y: e.area[0] + (e.height - e.area[0] - e.area[2]) / 2,
                },
                h = Math.min(
                  (e.width - e.area[1] - e.area[3]) / 2 -
                    a.pieChartLinePadding -
                    a.pieChartTextPadding -
                    a._pieTextMaxLength_,
                  (e.height - e.area[0] - e.area[2]) / 2 -
                    a.pieChartLinePadding -
                    a.pieChartTextPadding
                );
              h = h < 10 ? 10 : h;
              var c = l.minRadius || 0.5 * h;
              h < c && (h = c + 10), (t = O(t, l.type, c, h, r));
              var x = l.activeRadius * e.pix;
              return (
                (l.customColor = f(l.linearType, l.customColor, t, a)),
                (t = t.map(function (t) {
                  return (
                    (t._start_ += ((l.offsetAngle || 0) * Math.PI) / 180), t
                  );
                })).forEach(function (t, a) {
                  e.tooltip &&
                    e.tooltip.index == a &&
                    (i.beginPath(),
                    i.setFillStyle(n(t.color, l.activeOpacity || 0.5)),
                    i.moveTo(s.x, s.y),
                    i.arc(
                      s.x,
                      s.y,
                      x + t._radius_,
                      t._start_,
                      t._start_ + 2 * t._rose_proportion_ * Math.PI
                    ),
                    i.closePath(),
                    i.fill()),
                    i.beginPath(),
                    i.setLineWidth(l.borderWidth * e.pix),
                    (i.lineJoin = "round"),
                    i.setStrokeStyle(l.borderColor);
                  var o,
                    r = t.color;
                  "custom" == l.linearType &&
                    ((o = i.createCircularGradient
                      ? i.createCircularGradient(s.x, s.y, t._radius_)
                      : i.createRadialGradient(
                          s.x,
                          s.y,
                          0,
                          s.x,
                          s.y,
                          t._radius_
                        )).addColorStop(0, n(l.customColor[t.linearIndex], 1)),
                    o.addColorStop(1, n(t.color, 1)),
                    (r = o));
                  i.setFillStyle(r),
                    i.moveTo(s.x, s.y),
                    i.arc(
                      s.x,
                      s.y,
                      t._radius_,
                      t._start_,
                      t._start_ + 2 * t._rose_proportion_ * Math.PI
                    ),
                    i.closePath(),
                    i.fill(),
                    1 == l.border && i.stroke();
                }),
                !1 !== e.dataLabel && 1 === r && xt(t, e, a, i, 0, s),
                { center: s, radius: h, series: t }
              );
            })(v, l, s, h, t)),
            bt(l.series, l, s, h, l.chartData),
            yt(l, s, h, t),
            kt(0, h);
        },
        onAnimationFinish: function () {
          y.uevent.trigger("renderComplete");
        },
      });
      break;
    case "radar":
      this.animationInstance = new Ot({
        timing: l.timing,
        duration: T,
        onProcess: function (t) {
          h.clearRect(0, 0, l.width, l.height),
            l.rotate && et(h, l),
            (l.chartData.radarData = (function (t, e, a, i) {
              var r =
                  arguments.length > 4 && void 0 !== arguments[4]
                    ? arguments[4]
                    : 1,
                l = o(
                  {},
                  {
                    gridColor: "#cccccc",
                    gridType: "radar",
                    gridEval: 1,
                    axisLabel: !1,
                    axisLabelTofix: 0,
                    labelShow: !0,
                    labelColor: "#666666",
                    labelPointShow: !1,
                    labelPointRadius: 3,
                    labelPointColor: "#cccccc",
                    opacity: 0.2,
                    gridCount: 3,
                    border: !1,
                    borderWidth: 2,
                    linearType: "none",
                    customColor: [],
                  },
                  e.extra.radar
                ),
                s = b(e.categories.length),
                h = {
                  x: e.area[3] + (e.width - e.area[1] - e.area[3]) / 2,
                  y: e.area[0] + (e.height - e.area[0] - e.area[2]) / 2,
                },
                c = (e.width - e.area[1] - e.area[3]) / 2,
                d = (e.height - e.area[0] - e.area[2]) / 2,
                p = Math.min(
                  c - (S(e.categories, a.fontSize, i) + a.radarLabelTextMargin),
                  d - a.radarLabelTextMargin
                );
              (p = (p -= a.radarLabelTextMargin * e.pix) < 10 ? 10 : p),
                (p = l.radius ? l.radius : p),
                i.beginPath(),
                i.setLineWidth(1 * e.pix),
                i.setStrokeStyle(l.gridColor),
                s.forEach(function (t, e) {
                  var a = x(p * Math.cos(t), p * Math.sin(t), h);
                  i.moveTo(h.x, h.y), e % l.gridEval == 0 && i.lineTo(a.x, a.y);
                }),
                i.stroke(),
                i.closePath();
              for (
                var u = function (t) {
                    var a = {};
                    if (
                      (i.beginPath(),
                      i.setLineWidth(1 * e.pix),
                      i.setStrokeStyle(l.gridColor),
                      "radar" == l.gridType)
                    )
                      s.forEach(function (e, o) {
                        var r = x(
                          (p / l.gridCount) * t * Math.cos(e),
                          (p / l.gridCount) * t * Math.sin(e),
                          h
                        );
                        0 === o
                          ? ((a = r), i.moveTo(r.x, r.y))
                          : i.lineTo(r.x, r.y);
                      }),
                        i.lineTo(a.x, a.y);
                    else {
                      var o = x(
                        (p / l.gridCount) * t * Math.cos(1.5),
                        (p / l.gridCount) * t * Math.sin(1.5),
                        h
                      );
                      i.arc(h.x, h.y, h.y - o.y, 0, 2 * Math.PI, !1);
                    }
                    i.stroke(), i.closePath();
                  },
                  y = 1;
                y <= l.gridCount;
                y++
              )
                u(y);
              l.customColor = f(l.linearType, l.customColor, t, a);
              var v = L(s, h, p, t, e, r);
              if (
                (v.forEach(function (a, o) {
                  i.beginPath(),
                    i.setLineWidth(l.borderWidth * e.pix),
                    i.setStrokeStyle(a.color);
                  var r,
                    s = n(a.color, l.opacity);
                  "custom" == l.linearType &&
                    ((r = i.createCircularGradient
                      ? i.createCircularGradient(h.x, h.y, p)
                      : i.createRadialGradient(
                          h.x,
                          h.y,
                          0,
                          h.x,
                          h.y,
                          p
                        )).addColorStop(
                      0,
                      n(l.customColor[t[o].linearIndex], l.opacity)
                    ),
                    r.addColorStop(1, n(a.color, l.opacity)),
                    (s = r));
                  (i.setFillStyle(s),
                  a.data.forEach(function (t, e) {
                    0 === e
                      ? i.moveTo(t.position.x, t.position.y)
                      : i.lineTo(t.position.x, t.position.y);
                  }),
                  i.closePath(),
                  i.fill(),
                  !0 === l.border && i.stroke(),
                  i.closePath(),
                  !1 !== e.dataPointShape) &&
                    at(
                      a.data.map(function (t) {
                        return t.position;
                      }),
                      a.color,
                      a.pointShape,
                      i,
                      e
                    );
                }),
                !0 === l.axisLabel)
              ) {
                var m = Math.max(l.max, Math.max.apply(null, g(t))),
                  A = p / l.gridCount,
                  T = e.fontSize * e.pix;
                i.setFontSize(T),
                  i.setFillStyle(e.fontColor),
                  i.setTextAlign("left");
                for (y = 0; y < l.gridCount + 1; y++) {
                  var P = (y * m) / l.gridCount;
                  (P = P.toFixed(l.axisLabelTofix)),
                    i.fillText(String(P), h.x + 3 * e.pix, h.y - y * A + T / 2);
                }
              }
              return (
                ct(s, p, h, e, a, i),
                !1 !== e.dataLabel &&
                  1 === r &&
                  (v.forEach(function (t, o) {
                    i.beginPath();
                    var r = t.textSize * e.pix || a.fontSize;
                    i.setFontSize(r),
                      i.setFillStyle(t.textColor || e.fontColor),
                      t.data.forEach(function (t, e) {
                        Math.abs(t.position.x - h.x) < 2
                          ? t.position.y < h.y
                            ? (i.setTextAlign("center"),
                              i.fillText(
                                t.value,
                                t.position.x,
                                t.position.y - 4
                              ))
                            : (i.setTextAlign("center"),
                              i.fillText(
                                t.value,
                                t.position.x,
                                t.position.y + r + 2
                              ))
                          : t.position.x < h.x
                          ? (i.setTextAlign("right"),
                            i.fillText(
                              t.value,
                              t.position.x - 4,
                              t.position.y + r / 2 - 2
                            ))
                          : (i.setTextAlign("left"),
                            i.fillText(
                              t.value,
                              t.position.x + 4,
                              t.position.y + r / 2 - 2
                            ));
                      }),
                      i.closePath(),
                      i.stroke();
                  }),
                  i.setTextAlign("left")),
                { center: h, radius: p, angleList: s }
              );
            })(v, l, s, h, t)),
            bt(l.series, l, s, h, l.chartData),
            yt(l, s, h, t),
            kt(0, h);
        },
        onAnimationFinish: function () {
          y.uevent.trigger("renderComplete");
        },
      });
      break;
    case "arcbar":
      this.animationInstance = new Ot({
        timing: l.timing,
        duration: T,
        onProcess: function (t) {
          h.clearRect(0, 0, l.width, l.height),
            l.rotate && et(h, l),
            (l.chartData.arcbarData = (function (t, e, a, i) {
              var r,
                l,
                s =
                  arguments.length > 4 && void 0 !== arguments[4]
                    ? arguments[4]
                    : 1,
                h = o(
                  {},
                  {
                    startAngle: 0.75,
                    endAngle: 0.25,
                    type: "default",
                    direction: "cw",
                    lineCap: "round",
                    width: 12,
                    gap: 2,
                    linearType: "none",
                    customColor: [],
                  },
                  e.extra.arcbar
                );
              (t = z(t, h, s)),
                (r =
                  h.centerX || h.centerY
                    ? {
                        x: h.centerX ? h.centerX : e.width / 2,
                        y: h.centerY ? h.centerY : e.height / 2,
                      }
                    : { x: e.width / 2, y: e.height / 2 }),
                h.radius
                  ? (l = h.radius)
                  : ((l = Math.min(r.x, r.y)),
                    (l -= 5 * e.pix),
                    (l -= h.width / 2)),
                (l = l < 10 ? 10 : l),
                (h.customColor = f(h.linearType, h.customColor, t, a));
              for (var c = 0; c < t.length; c++) {
                var x = t[c];
                i.setLineWidth(h.width * e.pix),
                  i.setStrokeStyle(h.backgroundColor || "#E9E9E9"),
                  i.setLineCap(h.lineCap),
                  i.beginPath(),
                  "default" == h.type
                    ? i.arc(
                        r.x,
                        r.y,
                        l - (h.width * e.pix + h.gap * e.pix) * c,
                        h.startAngle * Math.PI,
                        h.endAngle * Math.PI,
                        "ccw" == h.direction
                      )
                    : i.arc(
                        r.x,
                        r.y,
                        l - (h.width * e.pix + h.gap * e.pix) * c,
                        0,
                        2 * Math.PI,
                        "ccw" == h.direction
                      ),
                  i.stroke();
                var d = x.color;
                if ("custom" == h.linearType) {
                  var p = i.createLinearGradient(r.x - l, r.y, r.x + l, r.y);
                  p.addColorStop(1, n(h.customColor[x.linearIndex], 1)),
                    p.addColorStop(0, n(x.color, 1)),
                    (d = p);
                }
                i.setLineWidth(h.width * e.pix),
                  i.setStrokeStyle(d),
                  i.setLineCap(h.lineCap),
                  i.beginPath(),
                  i.arc(
                    r.x,
                    r.y,
                    l - (h.width * e.pix + h.gap * e.pix) * c,
                    h.startAngle * Math.PI,
                    x._proportion_ * Math.PI,
                    "ccw" == h.direction
                  ),
                  i.stroke();
              }
              return ot(e, a, i, r), { center: r, radius: l, series: t };
            })(v, l, s, h, t)),
            kt(0, h);
        },
        onAnimationFinish: function () {
          y.uevent.trigger("renderComplete");
        },
      });
      break;
    case "gauge":
      this.animationInstance = new Ot({
        timing: l.timing,
        duration: T,
        onProcess: function (t) {
          h.clearRect(0, 0, l.width, l.height),
            l.rotate && et(h, l),
            (l.chartData.gaugeData = (function (t, e, a, i, r) {
              var l =
                  arguments.length > 5 && void 0 !== arguments[5]
                    ? arguments[5]
                    : 1,
                s = o(
                  {},
                  {
                    type: "default",
                    startAngle: 0.75,
                    endAngle: 0.25,
                    width: 15,
                    labelOffset: 13,
                    splitLine: {
                      fixRadius: 0,
                      splitNumber: 10,
                      width: 15,
                      color: "#FFFFFF",
                      childNumber: 5,
                      childWidth: 5,
                    },
                    pointer: { width: 15, color: "auto" },
                  },
                  a.extra.gauge
                );
              null == s.oldAngle && (s.oldAngle = s.startAngle),
                null == s.oldData && (s.oldData = 0),
                (t = R(t, s.startAngle, s.endAngle));
              var h = { x: a.width / 2, y: a.height / 2 },
                c = Math.min(h.x, h.y);
              c -= 5 * a.pix;
              var x = (c = (c -= s.width / 2) < 10 ? 10 : c) - s.width,
                d = 0;
              if ("progress" == s.type) {
                var p = c - 3 * s.width;
                r.beginPath();
                var f = r.createLinearGradient(h.x, h.y - p, h.x, h.y + p);
                f.addColorStop("0", n(e[0].color, 0.3)),
                  f.addColorStop("1.0", n("#FFFFFF", 0.1)),
                  r.setFillStyle(f),
                  r.arc(h.x, h.y, p, 0, 2 * Math.PI, !1),
                  r.fill(),
                  r.setLineWidth(s.width),
                  r.setStrokeStyle(n(e[0].color, 0.3)),
                  r.setLineCap("round"),
                  r.beginPath(),
                  r.arc(
                    h.x,
                    h.y,
                    x,
                    s.startAngle * Math.PI,
                    s.endAngle * Math.PI,
                    !1
                  ),
                  r.stroke(),
                  (d =
                    s.endAngle < s.startAngle
                      ? 2 + s.endAngle - s.startAngle
                      : s.startAngle - s.endAngle),
                  s.splitLine.splitNumber;
                var u = d / s.splitLine.splitNumber / s.splitLine.childNumber,
                  g = -c - 0.5 * s.width - s.splitLine.fixRadius,
                  y = -c - s.width - s.splitLine.fixRadius + s.splitLine.width;
                r.save(),
                  r.translate(h.x, h.y),
                  r.rotate((s.startAngle - 1) * Math.PI);
                for (
                  var v = s.splitLine.splitNumber * s.splitLine.childNumber + 1,
                    m = e[0].data * l,
                    S = 0;
                  S < v;
                  S++
                )
                  r.beginPath(),
                    m > S / v
                      ? r.setStrokeStyle(n(e[0].color, 1))
                      : r.setStrokeStyle(n(e[0].color, 0.3)),
                    r.setLineWidth(3 * a.pix),
                    r.moveTo(g, 0),
                    r.lineTo(y, 0),
                    r.stroke(),
                    r.rotate(u * Math.PI);
                r.restore(),
                  (e = W(e, s, l)),
                  r.setLineWidth(s.width),
                  r.setStrokeStyle(e[0].color),
                  r.setLineCap("round"),
                  r.beginPath(),
                  r.arc(
                    h.x,
                    h.y,
                    x,
                    s.startAngle * Math.PI,
                    e[0]._proportion_ * Math.PI,
                    !1
                  ),
                  r.stroke();
                var b = c - 2.5 * s.width;
                r.save(),
                  r.translate(h.x, h.y),
                  r.rotate((e[0]._proportion_ - 1) * Math.PI),
                  r.beginPath(),
                  r.setLineWidth(s.width / 3);
                var A = r.createLinearGradient(0, 0.6 * -b, 0, 0.6 * b);
                A.addColorStop("0", n("#FFFFFF", 0)),
                  A.addColorStop("0.5", n(e[0].color, 1)),
                  A.addColorStop("1.0", n("#FFFFFF", 0)),
                  r.setStrokeStyle(A),
                  r.arc(0, 0, b, 0.85 * Math.PI, 1.15 * Math.PI, !1),
                  r.stroke(),
                  r.beginPath(),
                  r.setLineWidth(1),
                  r.setStrokeStyle(e[0].color),
                  r.setFillStyle(e[0].color),
                  r.moveTo(-b - s.width / 3 / 2, -4),
                  r.lineTo(-b - s.width / 3 / 2 - 4, 0),
                  r.lineTo(-b - s.width / 3 / 2, 4),
                  r.lineTo(-b - s.width / 3 / 2, -4),
                  r.stroke(),
                  r.fill(),
                  r.restore();
              } else {
                r.setLineWidth(s.width), r.setLineCap("butt");
                for (var T = 0; T < t.length; T++) {
                  var P = t[T];
                  r.beginPath(),
                    r.setStrokeStyle(P.color),
                    r.arc(
                      h.x,
                      h.y,
                      c,
                      P._startAngle_ * Math.PI,
                      P._endAngle_ * Math.PI,
                      !1
                    ),
                    r.stroke();
                }
                r.save();
                var w =
                    (d =
                      s.endAngle < s.startAngle
                        ? 2 + s.endAngle - s.startAngle
                        : s.startAngle - s.endAngle) / s.splitLine.splitNumber,
                  C = d / s.splitLine.splitNumber / s.splitLine.childNumber,
                  M = -c - 0.5 * s.width - s.splitLine.fixRadius,
                  _ =
                    -c -
                    0.5 * s.width -
                    s.splitLine.fixRadius +
                    s.splitLine.width,
                  F =
                    -c -
                    0.5 * s.width -
                    s.splitLine.fixRadius +
                    s.splitLine.childWidth;
                r.translate(h.x, h.y), r.rotate((s.startAngle - 1) * Math.PI);
                for (var D = 0; D < s.splitLine.splitNumber + 1; D++)
                  r.beginPath(),
                    r.setStrokeStyle(s.splitLine.color),
                    r.setLineWidth(2 * a.pix),
                    r.moveTo(M, 0),
                    r.lineTo(_, 0),
                    r.stroke(),
                    r.rotate(w * Math.PI);
                r.restore(),
                  r.save(),
                  r.translate(h.x, h.y),
                  r.rotate((s.startAngle - 1) * Math.PI);
                for (
                  var L = 0;
                  L < s.splitLine.splitNumber * s.splitLine.childNumber + 1;
                  L++
                )
                  r.beginPath(),
                    r.setStrokeStyle(s.splitLine.color),
                    r.setLineWidth(1 * a.pix),
                    r.moveTo(M, 0),
                    r.lineTo(F, 0),
                    r.stroke(),
                    r.rotate(C * Math.PI);
                r.restore(), (e = E(e, t, s, l));
                for (var k = 0; k < e.length; k++) {
                  var I = e[k];
                  r.save(),
                    r.translate(h.x, h.y),
                    r.rotate((I._proportion_ - 1) * Math.PI),
                    r.beginPath(),
                    r.setFillStyle(I.color),
                    r.moveTo(s.pointer.width, 0),
                    r.lineTo(0, -s.pointer.width / 2),
                    r.lineTo(-x, 0),
                    r.lineTo(0, s.pointer.width / 2),
                    r.lineTo(s.pointer.width, 0),
                    r.closePath(),
                    r.fill(),
                    r.beginPath(),
                    r.setFillStyle("#FFFFFF"),
                    r.arc(0, 0, s.pointer.width / 6, 0, 2 * Math.PI, !1),
                    r.fill(),
                    r.restore();
                }
                !1 !== a.dataLabel && ht(s, c, h, a, i, r);
              }
              return (
                ot(a, i, r, h),
                1 === l &&
                  "gauge" === a.type &&
                  ((a.extra.gauge.oldAngle = e[0]._proportion_),
                  (a.extra.gauge.oldData = e[0].data)),
                {
                  center: h,
                  radius: c,
                  innerRadius: x,
                  categories: t,
                  totalAngle: d,
                }
              );
            })(m, v, l, s, h, t)),
            kt(0, h);
        },
        onAnimationFinish: function () {
          y.uevent.trigger("renderComplete");
        },
      });
      break;
    case "candle":
      this.animationInstance = new Ot({
        timing: l.timing,
        duration: T,
        onProcess: function (t) {
          h.clearRect(0, 0, l.width, l.height),
            l.rotate && et(h, l),
            mt(0, l, 0, h),
            vt(m, l, s, h);
          var e = (function (t, e, a, i, r) {
              var n =
                  arguments.length > 5 && void 0 !== arguments[5]
                    ? arguments[5]
                    : 1,
                l = o({}, { color: {}, average: {} }, a.extra.candle);
              (l.color = o(
                {},
                {
                  upLine: "#f04864",
                  upFill: "#f04864",
                  downLine: "#2fc25b",
                  downFill: "#2fc25b",
                },
                l.color
              )),
                (l.average = o(
                  {},
                  { show: !1, name: [], day: [], color: i.color },
                  l.average
                )),
                (a.extra.candle = l);
              var s = a.chartData.xAxisData,
                h = s.xAxisPoints,
                x = s.eachSpacing,
                d = [];
              r.save();
              var p = -2,
                f = h.length + 2,
                u = 0,
                g = a.width + x;
              return (
                a._scrollDistance_ &&
                  0 !== a._scrollDistance_ &&
                  !0 === a.enableScroll &&
                  (r.translate(a._scrollDistance_, 0),
                  (p = Math.floor(-a._scrollDistance_ / x) - 2),
                  (f = p + a.xAxis.itemCount + 4),
                  (u = -a._scrollDistance_ - 2 * x + a.area[3]),
                  (g = u + (a.xAxis.itemCount + 4) * x)),
                (l.average.show || e) &&
                  e.forEach(function (t, e) {
                    var o, l, s;
                    (l = (o = [].concat(
                      a.chartData.yAxisData.ranges[t.index]
                    )).pop()),
                      (s = o.shift());
                    for (
                      var d = _(q(t.data, l, s, h, x, a, i, n), t), p = 0;
                      p < d.length;
                      p++
                    ) {
                      var f = d[p];
                      if (
                        (r.beginPath(),
                        r.setStrokeStyle(t.color),
                        r.setLineWidth(1),
                        1 === f.length)
                      )
                        r.moveTo(f[0].x, f[0].y),
                          r.arc(f[0].x, f[0].y, 1, 0, 2 * Math.PI);
                      else {
                        r.moveTo(f[0].x, f[0].y);
                        for (var y = 0, v = 0; v < f.length; v++) {
                          var m = f[v];
                          if (
                            (0 == y && m.x > u && (r.moveTo(m.x, m.y), (y = 1)),
                            v > 0 && m.x > u && m.x < g)
                          ) {
                            var S = c(f, v - 1);
                            r.bezierCurveTo(
                              S.ctrA.x,
                              S.ctrA.y,
                              S.ctrB.x,
                              S.ctrB.y,
                              m.x,
                              m.y
                            );
                          }
                        }
                        r.moveTo(f[0].x, f[0].y);
                      }
                      r.closePath(), r.stroke();
                    }
                  }),
                t.forEach(function (t, e) {
                  var o, s, c;
                  (s = (o = [].concat(
                    a.chartData.yAxisData.ranges[t.index]
                  )).pop()),
                    (c = o.shift());
                  var u = t.data,
                    g = Y(u, s, c, h, x, a, i, n);
                  d.push(g);
                  for (var y = _(g, t), v = 0; v < y[0].length; v++)
                    if (v > p && v < f) {
                      var m = y[0][v];
                      r.beginPath(),
                        u[v][1] - u[v][0] > 0
                          ? (r.setStrokeStyle(l.color.upLine),
                            r.setFillStyle(l.color.upFill),
                            r.setLineWidth(1 * a.pix),
                            r.moveTo(m[3].x, m[3].y),
                            r.lineTo(m[1].x, m[1].y),
                            r.lineTo(m[1].x - x / 4, m[1].y),
                            r.lineTo(m[0].x - x / 4, m[0].y),
                            r.lineTo(m[0].x, m[0].y),
                            r.lineTo(m[2].x, m[2].y),
                            r.lineTo(m[0].x, m[0].y),
                            r.lineTo(m[0].x + x / 4, m[0].y),
                            r.lineTo(m[1].x + x / 4, m[1].y),
                            r.lineTo(m[1].x, m[1].y),
                            r.moveTo(m[3].x, m[3].y))
                          : (r.setStrokeStyle(l.color.downLine),
                            r.setFillStyle(l.color.downFill),
                            r.setLineWidth(1 * a.pix),
                            r.moveTo(m[3].x, m[3].y),
                            r.lineTo(m[0].x, m[0].y),
                            r.lineTo(m[0].x - x / 4, m[0].y),
                            r.lineTo(m[1].x - x / 4, m[1].y),
                            r.lineTo(m[1].x, m[1].y),
                            r.lineTo(m[2].x, m[2].y),
                            r.lineTo(m[1].x, m[1].y),
                            r.lineTo(m[1].x + x / 4, m[1].y),
                            r.lineTo(m[0].x + x / 4, m[0].y),
                            r.lineTo(m[0].x, m[0].y),
                            r.moveTo(m[3].x, m[3].y)),
                        r.closePath(),
                        r.fill(),
                        r.stroke();
                    }
                }),
                r.restore(),
                { xAxisPoints: h, calPoints: d, eachSpacing: x }
              );
            })(v, P, l, s, h, t),
            a = e.xAxisPoints,
            i = e.calPoints,
            r = e.eachSpacing;
          (l.chartData.xAxisPoints = a),
            (l.chartData.calPoints = i),
            (l.chartData.eachSpacing = r),
            St(0, l, s, h),
            !1 !== l.enableMarkLine && 1 === t && dt(l, 0, h),
            bt(P ? 0 : l.series, l, s, h, l.chartData),
            yt(l, s, h, t),
            kt(0, h);
        },
        onAnimationFinish: function () {
          y.uevent.trigger("renderComplete");
        },
      });
  }
}
function Wt() {
  this.events = {};
}
(Ot.prototype.stop = function () {
  this.isStop = !0;
}),
  (Wt.prototype.addEventListener = function (t, e) {
    (this.events[t] = this.events[t] || []), this.events[t].push(e);
  }),
  (Wt.prototype.delEventListener = function (t) {
    this.events[t] = [];
  }),
  (Wt.prototype.trigger = function () {
    for (var t = arguments.length, e = Array(t), a = 0; a < t; a++)
      e[a] = arguments[a];
    var i = e[0],
      o = e.slice(1);
    this.events[i] &&
      this.events[i].forEach(function (t) {
        try {
          t.apply(null, o);
        } catch (t) {}
      });
  });
var Rt = function (t) {
  (t.pix = t.pixelRatio ? t.pixelRatio : 1),
    (t.fontSize = t.fontSize ? t.fontSize : 13),
    (t.fontColor = t.fontColor ? t.fontColor : i.fontColor),
    ("" != t.background && "none" != t.background) ||
      (t.background = "#FFFFFF"),
    (t.title = o({}, t.title)),
    (t.subtitle = o({}, t.subtitle)),
    (t.duration = t.duration ? t.duration : 1e3),
    (t.yAxis = o(
      {},
      {
        data: [],
        showTitle: !1,
        disabled: !1,
        disableGrid: !1,
        gridSet: "number",
        splitNumber: 5,
        gridType: "solid",
        dashLength: 4 * t.pix,
        gridColor: "#cccccc",
        padding: 10,
        fontColor: "#666666",
      },
      t.yAxis
    )),
    (t.xAxis = o(
      {},
      {
        rotateLabel: !1,
        rotateAngle: 45,
        disabled: !1,
        disableGrid: !1,
        splitNumber: 5,
        calibration: !1,
        fontColor: "#666666",
        fontSize: 13,
        lineHeight: 20,
        marginTop: 0,
        gridType: "solid",
        dashLength: 4,
        scrollAlign: "left",
        boundaryGap: "center",
        axisLine: !0,
        axisLineColor: "#cccccc",
        titleFontSize: 13,
        titleOffsetY: 0,
        titleOffsetX: 0,
        titleFontColor: "#666666",
      },
      t.xAxis
    )),
    (t.xAxis.scrollPosition = t.xAxis.scrollAlign),
    (t.legend = o(
      {},
      {
        show: !0,
        position: "bottom",
        float: "center",
        backgroundColor: "rgba(0,0,0,0)",
        borderColor: "rgba(0,0,0,0)",
        borderWidth: 0,
        padding: 5,
        margin: 5,
        itemGap: 10,
        fontSize: t.fontSize,
        lineHeight: t.fontSize,
        fontColor: t.fontColor,
        formatter: {},
        hiddenColor: "#CECECE",
      },
      t.legend
    )),
    (t.extra = o({ tooltip: { legendShape: "auto" } }, t.extra)),
    (t.rotate = !!t.rotate),
    (t.animation = !!t.animation),
    (t.rotate = !!t.rotate),
    (t.canvas2d = !!t.canvas2d);
  var e = o({}, i);
  if (
    ((e.color = t.color ? t.color : e.color),
    "pie" == t.type &&
      (e.pieChartLinePadding =
        !1 === t.dataLabel
          ? 0
          : t.extra.pie.labelWidth * t.pix || e.pieChartLinePadding * t.pix),
    "ring" == t.type &&
      (e.pieChartLinePadding =
        !1 === t.dataLabel
          ? 0
          : t.extra.ring.labelWidth * t.pix || e.pieChartLinePadding * t.pix),
    "rose" == t.type &&
      (e.pieChartLinePadding =
        !1 === t.dataLabel
          ? 0
          : t.extra.rose.labelWidth * t.pix || e.pieChartLinePadding * t.pix),
    (e.pieChartTextPadding =
      !1 === t.dataLabel ? 0 : e.pieChartTextPadding * t.pix),
    (e.rotate = t.rotate),
    t.rotate)
  ) {
    var a = t.width,
      r = t.height;
    (t.width = r), (t.height = a);
  }
  if (
    ((t.padding = t.padding ? t.padding : e.padding),
    (e.yAxisWidth = i.yAxisWidth * t.pix),
    (e.fontSize = t.fontSize * t.pix),
    (e.titleFontSize = i.titleFontSize * t.pix),
    (e.subtitleFontSize = i.subtitleFontSize * t.pix),
    !t.context)
  )
    throw new Error(
      "[uCharts] 未获取到context！注意：v2.0版本后，需要自行获取canvas的绘图上下文并传入opts.context！"
    );
  (this.context = t.context),
    this.context.setTextAlign ||
      ((this.context.setStrokeStyle = function (t) {
        return (this.strokeStyle = t);
      }),
      (this.context.setLineWidth = function (t) {
        return (this.lineWidth = t);
      }),
      (this.context.setLineCap = function (t) {
        return (this.lineCap = t);
      }),
      (this.context.setFontSize = function (t) {
        return (this.font = t + "px sans-serif");
      }),
      (this.context.setFillStyle = function (t) {
        return (this.fillStyle = t);
      }),
      (this.context.setTextAlign = function (t) {
        return (this.textAlign = t);
      }),
      (this.context.setTextBaseline = function (t) {
        return (this.textBaseline = t);
      }),
      (this.context.setShadow = function (t, e, a, i) {
        (this.shadowColor = i),
          (this.shadowOffsetX = t),
          (this.shadowOffsetY = e),
          (this.shadowBlur = a);
      }),
      (this.context.draw = function () {})),
    this.context.setLineDash || (this.context.setLineDash = function (t) {}),
    (t.chartData = {}),
    (this.uevent = new Wt()),
    (this.scrollOption = {
      currentOffset: 0,
      startTouchX: 0,
      distance: 0,
      lastMoveTime: 0,
    }),
    (this.opts = t),
    (this.config = e),
    zt.call(this, t.type, t, e, this.context);
};
(Rt.prototype.updateData = function () {
  var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  (this.opts = o({}, this.opts, t)), (this.opts.updateData = !0);
  var e = t.scrollPosition || "current";
  switch (e) {
    case "current":
      this.opts._scrollDistance_ = this.scrollOption.currentOffset;
      break;
    case "left":
      (this.opts._scrollDistance_ = 0),
        (this.scrollOption = {
          currentOffset: 0,
          startTouchX: 0,
          distance: 0,
          lastMoveTime: 0,
        });
      break;
    case "right":
      var a = tt(this.opts.series, this.opts, this.config, this.context),
        i = a.yAxisWidth;
      this.config.yAxisWidth = i;
      var r = 0,
        n = j(this.opts.categories, this.opts, this.config),
        l = n.xAxisPoints,
        s = n.startX,
        h = n.endX,
        c = n.eachSpacing,
        x = c * (l.length - 1),
        d = h - s;
      (r = d - x),
        (this.scrollOption = {
          currentOffset: r,
          startTouchX: r,
          distance: 0,
          lastMoveTime: 0,
        }),
        (this.opts._scrollDistance_ = r);
  }
  zt.call(this, this.opts.type, this.opts, this.config, this.context);
}),
  (Rt.prototype.zoom = function () {
    var t =
      arguments.length > 0 && void 0 !== arguments[0]
        ? arguments[0]
        : this.opts.xAxis.itemCount;
    if (!0 === this.opts.enableScroll) {
      var e =
        Math.round(
          Math.abs(this.scrollOption.currentOffset) /
            this.opts.chartData.eachSpacing
        ) + Math.round(this.opts.xAxis.itemCount / 2);
      (this.opts.animation = !1), (this.opts.xAxis.itemCount = t.itemCount);
      var a = tt(this.opts.series, this.opts, this.config, this.context),
        i = a.yAxisWidth;
      this.config.yAxisWidth = i;
      var o = 0,
        r = j(this.opts.categories, this.opts, this.config),
        n = r.xAxisPoints,
        l = r.startX,
        h = r.endX,
        c = r.eachSpacing,
        x = c * e,
        d = h - l,
        p = d - c * (n.length - 1);
      (o = d / 2 - x) > 0 && (o = 0),
        o < p && (o = p),
        (this.scrollOption = {
          currentOffset: o,
          startTouchX: 0,
          distance: 0,
          lastMoveTime: 0,
        }),
        s(this, o, this.opts.chartData, this.config, this.opts),
        (this.opts._scrollDistance_ = o),
        zt.call(this, this.opts.type, this.opts, this.config, this.context);
    } else console.log("[uCharts] 请启用滚动条后使用");
  }),
  (Rt.prototype.dobuleZoom = function (t) {
    if (!0 === this.opts.enableScroll) {
      var e = t.changedTouches;
      if (!(e.length < 2)) {
        for (var a = 0; a < e.length; a++)
          (e[a].x = e[a].x ? e[a].x : e[a].clientX),
            (e[a].y = e[a].y ? e[a].y : e[a].clientY);
        var i = [v(e[0], this.opts, t), v(e[1], this.opts, t)],
          o = Math.abs(i[0].x - i[1].x);
        if (!this.scrollOption.moveCount) {
          var r = {
              changedTouches: [
                { x: e[0].x, y: this.opts.area[0] / this.opts.pix + 2 },
              ],
            },
            n = {
              changedTouches: [
                { x: e[1].x, y: this.opts.area[0] / this.opts.pix + 2 },
              ],
            };
          this.opts.rotate &&
            ((r = {
              changedTouches: [
                {
                  x:
                    this.opts.height / this.opts.pix -
                    this.opts.area[0] / this.opts.pix -
                    2,
                  y: e[0].y,
                },
              ],
            }),
            (n = {
              changedTouches: [
                {
                  x:
                    this.opts.height / this.opts.pix -
                    this.opts.area[0] / this.opts.pix -
                    2,
                  y: e[1].y,
                },
              ],
            }));
          var l = this.getCurrentDataIndex(r).index,
            h = this.getCurrentDataIndex(n).index,
            c = Math.abs(l - h);
          return (
            (this.scrollOption.moveCount = c),
            (this.scrollOption.moveCurrent1 = Math.min(l, h)),
            void (this.scrollOption.moveCurrent2 = Math.max(l, h))
          );
        }
        var x = o / this.scrollOption.moveCount,
          d = (this.opts.width - this.opts.area[1] - this.opts.area[3]) / x;
        (d =
          (d = d <= 2 ? 2 : d) >= this.opts.categories.length
            ? this.opts.categories.length
            : d),
          (this.opts.animation = !1),
          (this.opts.xAxis.itemCount = d);
        var p = 0,
          f = j(this.opts.categories, this.opts, this.config),
          u = f.xAxisPoints,
          g = f.startX,
          y = f.endX,
          m = f.eachSpacing,
          S = m * this.scrollOption.moveCurrent1,
          b = y - g - m * (u.length - 1);
        (p = -S + Math.min(i[0].x, i[1].x) - this.opts.area[3] - m) > 0 &&
          (p = 0),
          p < b && (p = b),
          (this.scrollOption.currentOffset = p),
          (this.scrollOption.startTouchX = 0),
          (this.scrollOption.distance = 0),
          s(this, p, this.opts.chartData, this.config, this.opts),
          (this.opts._scrollDistance_ = p),
          zt.call(this, this.opts.type, this.opts, this.config, this.context);
      }
    } else console.log("[uCharts] 请启用滚动条后使用");
  }),
  (Rt.prototype.stopAnimation = function () {
    this.animationInstance && this.animationInstance.stop();
  }),
  (Rt.prototype.addEventListener = function (t, e) {
    this.uevent.addEventListener(t, e);
  }),
  (Rt.prototype.delEventListener = function (t) {
    this.uevent.delEventListener(t);
  }),
  (Rt.prototype.getCurrentDataIndex = function (t) {
    var e = null;
    if ((e = t.changedTouches ? t.changedTouches[0] : t.mp.changedTouches[0])) {
      var a = v(e, this.opts, t);
      return "pie" === this.opts.type || "ring" === this.opts.type
        ? (function (t, e, a) {
            var i = -1,
              o = k(e.series);
            if (e && e.center && M(t, e.center, e.radius)) {
              var r = Math.atan2(e.center.y - t.y, t.x - e.center.x);
              (r = -r),
                a.extra.pie &&
                  a.extra.pie.offsetAngle &&
                  (r -= (a.extra.pie.offsetAngle * Math.PI) / 180),
                a.extra.ring &&
                  a.extra.ring.offsetAngle &&
                  (r -= (a.extra.ring.offsetAngle * Math.PI) / 180);
              for (var n = 0, l = o.length; n < l; n++)
                if (
                  h(
                    r,
                    o[n]._start_,
                    o[n]._start_ + 2 * o[n]._proportion_ * Math.PI
                  )
                ) {
                  i = n;
                  break;
                }
            }
            return i;
          })({ x: a.x, y: a.y }, this.opts.chartData.pieData, this.opts)
        : "rose" === this.opts.type
        ? (function (t, e, a) {
            var i = -1,
              o = O(a._series_, a.extra.rose.type, e.radius, e.radius);
            if (e && e.center && M(t, e.center, e.radius)) {
              var r = Math.atan2(e.center.y - t.y, t.x - e.center.x);
              (r = -r),
                a.extra.rose &&
                  a.extra.rose.offsetAngle &&
                  (r -= (a.extra.rose.offsetAngle * Math.PI) / 180);
              for (var n = 0, l = o.length; n < l; n++)
                if (
                  h(
                    r,
                    o[n]._start_,
                    o[n]._start_ + 2 * o[n]._rose_proportion_ * Math.PI
                  )
                ) {
                  i = n;
                  break;
                }
            }
            return i;
          })({ x: a.x, y: a.y }, this.opts.chartData.pieData, this.opts)
        : "radar" === this.opts.type
        ? (function (t, e, a) {
            var i = (2 * Math.PI) / a,
              o = -1;
            if (M(t, e.center, e.radius)) {
              var r = function (t) {
                  return (
                    t < 0 && (t += 2 * Math.PI),
                    t > 2 * Math.PI && (t -= 2 * Math.PI),
                    t
                  );
                },
                n = Math.atan2(e.center.y - t.y, t.x - e.center.x);
              (n *= -1) < 0 && (n += 2 * Math.PI),
                e.angleList
                  .map(function (t) {
                    return (t = r(-1 * t));
                  })
                  .forEach(function (t, e) {
                    var a = r(t - i / 2),
                      l = r(t + i / 2);
                    l < a && (l += 2 * Math.PI),
                      ((n >= a && n <= l) ||
                        (n + 2 * Math.PI >= a && n + 2 * Math.PI <= l)) &&
                        (o = e);
                  });
            }
            return o;
          })(
            { x: a.x, y: a.y },
            this.opts.chartData.radarData,
            this.opts.categories.length
          )
        : "funnel" === this.opts.type
        ? (function (t, e) {
            for (var a = -1, i = 0, o = e.series.length; i < o; i++) {
              var r = e.series[i];
              if (
                t.x > r.funnelArea[0] &&
                t.x < r.funnelArea[2] &&
                t.y > r.funnelArea[1] &&
                t.y < r.funnelArea[3]
              ) {
                a = i;
                break;
              }
            }
            return a;
          })({ x: a.x, y: a.y }, this.opts.chartData.funnelData)
        : "map" === this.opts.type
        ? (function (t, e) {
            for (
              var a,
                i,
                o,
                r,
                n,
                l,
                s = -1,
                h = e.chartData.mapData,
                c = e.series,
                x =
                  ((a = t.y),
                  (i = t.x),
                  (o = h.bounds),
                  (r = h.scale),
                  (n = h.xoffset),
                  (l = h.yoffset),
                  { x: (i - n) / r + o.xMin, y: o.yMax - (a - l) / r }),
                d = [x.x, x.y],
                p = 0,
                f = c.length;
              p < f;
              p++
            ) {
              if (
                Ct(d, c[p].geometry.coordinates, e.chartData.mapData.mercator)
              ) {
                s = p;
                break;
              }
            }
            return s;
          })({ x: a.x, y: a.y }, this.opts)
        : "word" === this.opts.type
        ? (function (t, e) {
            for (var a = -1, i = 0, o = e.length; i < o; i++) {
              var r = e[i];
              if (
                t.x > r.area[0] &&
                t.x < r.area[2] &&
                t.y > r.area[1] &&
                t.y < r.area[3]
              ) {
                a = i;
                break;
              }
            }
            return a;
          })({ x: a.x, y: a.y }, this.opts.chartData.wordCloudData)
        : "bar" === this.opts.type
        ? (function (t, e, a, i) {
            var o =
                arguments.length > 4 && void 0 !== arguments[4]
                  ? arguments[4]
                  : 0,
              r = { index: -1, group: [] },
              n = a.chartData.eachSpacing / 2,
              l = a.chartData.yAxisPoints;
            return (
              e &&
                e.length > 0 &&
                C(t, a) &&
                l.forEach(function (e, a) {
                  t.y + o + n > e && (r.index = a);
                }),
              r
            );
          })(
            { x: a.x, y: a.y },
            this.opts.chartData.calPoints,
            this.opts,
            this.config,
            Math.abs(this.scrollOption.currentOffset)
          )
        : (function (t, e, a, i) {
            var o =
                arguments.length > 4 && void 0 !== arguments[4]
                  ? arguments[4]
                  : 0,
              r = { index: -1, group: [] },
              n = a.chartData.eachSpacing / 2,
              l = [];
            if (e && e.length > 0) {
              if (a.categories) {
                for (var s = 1; s < a.chartData.xAxisPoints.length; s++)
                  l.push(a.chartData.xAxisPoints[s] - n);
                ("line" != a.type && "area" != a.type) ||
                  "justify" != a.xAxis.boundaryGap ||
                  (l = a.chartData.xAxisPoints);
              } else n = 0;
              if (C(t, a))
                if (a.categories)
                  l.forEach(function (e, a) {
                    t.x + o + n > e && (r.index = a);
                  });
                else {
                  for (var h = Array(e.length), c = 0; c < e.length; c++) {
                    h[c] = Array(e[c].length);
                    for (var x = 0; x < e[c].length; x++)
                      h[c][x] = Math.abs(e[c][x].x - t.x);
                  }
                  for (
                    var d = Array(h.length), p = Array(h.length), f = 0;
                    f < h.length;
                    f++
                  )
                    (d[f] = Math.min.apply(null, h[f])),
                      (p[f] = h[f].indexOf(d[f]));
                  var u = Math.min.apply(null, d);
                  r.index = [];
                  for (var g = 0; g < d.length; g++)
                    d[g] == u && (r.group.push(g), r.index.push(p[g]));
                }
            }
            return r;
          })(
            { x: a.x, y: a.y },
            this.opts.chartData.calPoints,
            this.opts,
            this.config,
            Math.abs(this.scrollOption.currentOffset)
          );
    }
    return -1;
  }),
  (Rt.prototype.getLegendDataIndex = function (t) {
    var e = null;
    if ((e = t.changedTouches ? t.changedTouches[0] : t.mp.changedTouches[0])) {
      var a = v(e, this.opts, t);
      return (function (t, e, a) {
        var i = -1;
        if (
          (function (t, e) {
            return (
              t.x > e.start.x &&
              t.x < e.end.x &&
              t.y > e.start.y &&
              t.y < e.end.y
            );
          })(t, e.area)
        ) {
          for (var o = e.points, r = -1, n = 0, l = o.length; n < l; n++)
            for (var s = o[n], h = 0; h < s.length; h++) {
              r += 1;
              var c = s[h].area;
              if (
                c &&
                t.x > c[0] - 0 &&
                t.x < c[2] + 0 &&
                t.y > c[1] - 0 &&
                t.y < c[3] + 0
              ) {
                i = r;
                break;
              }
            }
          return i;
        }
        return i;
      })({ x: a.x, y: a.y }, this.opts.chartData.legendData);
    }
    return -1;
  }),
  (Rt.prototype.touchLegend = function (t) {
    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
      a = null;
    if ((a = t.changedTouches ? t.changedTouches[0] : t.mp.changedTouches[0])) {
      v(a, this.opts, t);
      var i = this.getLegendDataIndex(t);
      i >= 0 &&
        ("candle" == this.opts.type
          ? (this.opts.seriesMA[i].show = !this.opts.seriesMA[i].show)
          : (this.opts.series[i].show = !this.opts.series[i].show),
        (this.opts.animation = !!e.animation),
        (this.opts._scrollDistance_ = this.scrollOption.currentOffset),
        zt.call(this, this.opts.type, this.opts, this.config, this.context));
    }
  }),
  (Rt.prototype.showToolTip = function (t) {
    var e = this,
      a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
      i = null;
    (i = t.changedTouches ? t.changedTouches[0] : t.mp.changedTouches[0]) ||
      console.log("[uCharts] 未获取到event坐标信息");
    var r = v(i, this.opts, t),
      n = this.scrollOption.currentOffset,
      l = o({}, this.opts, { _scrollDistance_: n, animation: !1 });
    if (
      "line" === this.opts.type ||
      "area" === this.opts.type ||
      "column" === this.opts.type ||
      "scatter" === this.opts.type ||
      "bubble" === this.opts.type
    ) {
      var s = this.getCurrentDataIndex(t);
      if ((f = null == a.index ? s.index : a.index) > -1 || f.length > 0)
        if (0 !== (c = m(this.opts.series, f, s.group)).length) {
          var h = (p = A(c, this.opts, f, s.group, this.opts.categories, a))
            .textList;
          ((x = p.offset).y = r.y),
            (l.tooltip = {
              textList: void 0 !== a.textList ? a.textList : h,
              offset: void 0 !== a.offset ? a.offset : x,
              option: a,
              index: f,
              group: s.group,
            });
        }
      zt.call(this, l.type, l, this.config, this.context);
    }
    if ("mount" === this.opts.type) {
      if (
        (f = null == a.index ? this.getCurrentDataIndex(t).index : a.index) > -1
      ) {
        l = o({}, this.opts, { animation: !1 });
        var c = o({}, l._series_[f]),
          x =
            ((h = [
              {
                text: a.formatter
                  ? a.formatter(c, void 0, f, l)
                  : c.name + ": " + c.data,
                color: c.color,
                legendShape:
                  "auto" == this.opts.extra.tooltip.legendShape
                    ? c.legendShape
                    : this.opts.extra.tooltip.legendShape,
              },
            ]),
            { x: l.chartData.calPoints[f].x, y: r.y });
        l.tooltip = {
          textList: a.textList ? a.textList : h,
          offset: void 0 !== a.offset ? a.offset : x,
          option: a,
          index: f,
        };
      }
      zt.call(this, l.type, l, this.config, this.context);
    }
    if ("bar" === this.opts.type) {
      s = this.getCurrentDataIndex(t);
      if ((f = null == a.index ? s.index : a.index) > -1 || f.length > 0)
        if (0 !== (c = m(this.opts.series, f, s.group)).length) {
          h = (p = A(c, this.opts, f, s.group, this.opts.categories, a))
            .textList;
          ((x = p.offset).x = r.x),
            (l.tooltip = {
              textList: void 0 !== a.textList ? a.textList : h,
              offset: void 0 !== a.offset ? a.offset : x,
              option: a,
              index: f,
            });
        }
      zt.call(this, l.type, l, this.config, this.context);
    }
    if ("mix" === this.opts.type) {
      s = this.getCurrentDataIndex(t);
      if ((f = null == a.index ? s.index : a.index) > -1) {
        (n = this.scrollOption.currentOffset),
          (l = o({}, this.opts, { _scrollDistance_: n, animation: !1 }));
        if (0 !== (c = m(this.opts.series, f)).length) {
          var d = T(c, this.opts, f, this.opts.categories, a);
          h = d.textList;
          ((x = d.offset).y = r.y),
            (l.tooltip = {
              textList: a.textList ? a.textList : h,
              offset: void 0 !== a.offset ? a.offset : x,
              option: a,
              index: f,
            });
        }
      }
      zt.call(this, l.type, l, this.config, this.context);
    }
    if ("candle" === this.opts.type) {
      s = this.getCurrentDataIndex(t);
      if ((f = null == a.index ? s.index : a.index) > -1) {
        (n = this.scrollOption.currentOffset),
          (l = o({}, this.opts, { _scrollDistance_: n, animation: !1 }));
        if (0 !== (c = m(this.opts.series, f)).length) {
          var p;
          h = (p = P(
            this.opts.series[0].data,
            c,
            this.opts,
            f,
            this.opts.categories,
            this.opts.extra.candle
          )).textList;
          ((x = p.offset).y = r.y),
            (l.tooltip = {
              textList: a.textList ? a.textList : h,
              offset: void 0 !== a.offset ? a.offset : x,
              option: a,
              index: f,
            });
        }
      }
      zt.call(this, l.type, l, this.config, this.context);
    }
    if (
      "pie" === this.opts.type ||
      "ring" === this.opts.type ||
      "rose" === this.opts.type ||
      "funnel" === this.opts.type
    ) {
      if ((f = null == a.index ? this.getCurrentDataIndex(t) : a.index) > -1) {
        (l = o({}, this.opts, { animation: !1 })),
          (c = o({}, l._series_[f])),
          (h = [
            {
              text: a.formatter
                ? a.formatter(c, void 0, f, l)
                : c.name + ": " + c.data,
              color: c.color,
              legendShape:
                "auto" == this.opts.extra.tooltip.legendShape
                  ? c.legendShape
                  : this.opts.extra.tooltip.legendShape,
            },
          ]),
          (x = { x: r.x, y: r.y });
        l.tooltip = {
          textList: a.textList ? a.textList : h,
          offset: void 0 !== a.offset ? a.offset : x,
          option: a,
          index: f,
        };
      }
      zt.call(this, l.type, l, this.config, this.context);
    }
    if ("map" === this.opts.type) {
      if ((f = null == a.index ? this.getCurrentDataIndex(t) : a.index) > -1) {
        l = o({}, this.opts, { animation: !1 });
        (c = o({}, this.opts.series[f])).name = c.properties.name;
        (h = [
          {
            text: a.formatter ? a.formatter(c, void 0, f, this.opts) : c.name,
            color: c.color,
            legendShape:
              "auto" == this.opts.extra.tooltip.legendShape
                ? c.legendShape
                : this.opts.extra.tooltip.legendShape,
          },
        ]),
          (x = { x: r.x, y: r.y });
        l.tooltip = {
          textList: a.textList ? a.textList : h,
          offset: void 0 !== a.offset ? a.offset : x,
          option: a,
          index: f,
        };
      }
      (l.updateData = !1), zt.call(this, l.type, l, this.config, this.context);
    }
    if ("word" === this.opts.type) {
      if ((f = null == a.index ? this.getCurrentDataIndex(t) : a.index) > -1) {
        (l = o({}, this.opts, { animation: !1 })),
          (c = o({}, this.opts.series[f])),
          (h = [
            {
              text: a.formatter ? a.formatter(c, void 0, f, this.opts) : c.name,
              color: c.color,
              legendShape:
                "auto" == this.opts.extra.tooltip.legendShape
                  ? c.legendShape
                  : this.opts.extra.tooltip.legendShape,
            },
          ]),
          (x = { x: r.x, y: r.y });
        l.tooltip = {
          textList: a.textList ? a.textList : h,
          offset: void 0 !== a.offset ? a.offset : x,
          option: a,
          index: f,
        };
      }
      (l.updateData = !1), zt.call(this, l.type, l, this.config, this.context);
    }
    if ("radar" === this.opts.type) {
      var f;
      if ((f = null == a.index ? this.getCurrentDataIndex(t) : a.index) > -1) {
        l = o({}, this.opts, { animation: !1 });
        if (0 !== (c = m(this.opts.series, f)).length) {
          (h = c.map(function (t) {
            return {
              text: a.formatter
                ? a.formatter(t, e.opts.categories[f], f, e.opts)
                : t.name + ": " + t.data,
              color: t.color,
              legendShape:
                "auto" == e.opts.extra.tooltip.legendShape
                  ? t.legendShape
                  : e.opts.extra.tooltip.legendShape,
            };
          })),
            (x = { x: r.x, y: r.y });
          l.tooltip = {
            textList: a.textList ? a.textList : h,
            offset: void 0 !== a.offset ? a.offset : x,
            option: a,
            index: f,
          };
        }
      }
      zt.call(this, l.type, l, this.config, this.context);
    }
  }),
  (Rt.prototype.translate = function (t) {
    this.scrollOption = {
      currentOffset: t,
      startTouchX: t,
      distance: 0,
      lastMoveTime: 0,
    };
    var e = o({}, this.opts, { _scrollDistance_: t, animation: !1 });
    zt.call(this, this.opts.type, e, this.config, this.context);
  }),
  (Rt.prototype.scrollStart = function (t) {
    var e = null,
      a = v(
        (e = t.changedTouches ? t.changedTouches[0] : t.mp.changedTouches[0]),
        this.opts,
        t
      );
    e && !0 === this.opts.enableScroll && (this.scrollOption.startTouchX = a.x);
  }),
  (Rt.prototype.scroll = function (t) {
    0 === this.scrollOption.lastMoveTime &&
      (this.scrollOption.lastMoveTime = Date.now());
    var e = this.opts.touchMoveLimit || 60,
      a = Date.now();
    if (
      !(a - this.scrollOption.lastMoveTime < Math.floor(1e3 / e)) &&
      0 != this.scrollOption.startTouchX
    ) {
      this.scrollOption.lastMoveTime = a;
      var i = null;
      if (
        (i = t.changedTouches ? t.changedTouches[0] : t.mp.changedTouches[0]) &&
        !0 === this.opts.enableScroll
      ) {
        var r;
        r = v(i, this.opts, t).x - this.scrollOption.startTouchX;
        var n = this.scrollOption.currentOffset,
          l = s(this, n + r, this.opts.chartData, this.config, this.opts);
        this.scrollOption.distance = r = l - n;
        var h = o({}, this.opts, { _scrollDistance_: n + r, animation: !1 });
        return (
          (this.opts = h),
          zt.call(this, h.type, h, this.config, this.context),
          n + r
        );
      }
    }
  }),
  (Rt.prototype.scrollEnd = function (t) {
    if (!0 === this.opts.enableScroll) {
      var e = this.scrollOption,
        a = e.currentOffset,
        i = e.distance;
      (this.scrollOption.currentOffset = a + i),
        (this.scrollOption.distance = 0),
        (this.scrollOption.moveCount = 0);
    }
  }),
  (exports.uCharts = Rt);
