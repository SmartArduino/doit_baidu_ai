var t = require("../../../../@babel/runtime/helpers/typeof"),
  e = require("../../../../common/vendor.js"),
  o = require("../../js_sdk/u-charts/u-charts.js"),
  i = require("../../js_sdk/u-charts/config-ucharts.js");
function a() {
  for (
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
      o = arguments.length,
      i = new Array(o > 1 ? o - 1 : 0),
      n = 1;
    n < o;
    n++
  )
    i[n - 1] = arguments[n];
  for (var r in i)
    for (var s in i[r])
      i[r].hasOwnProperty(s) &&
        (e[s] =
          i[r][s] && "object" === t(i[r][s])
            ? a(Array.isArray(i[r][s]) ? [] : {}, e[s], i[r][s])
            : i[r][s]);
  return e;
}
var n = null;
var r = {
  name: "qiun-data-charts",
  mixins: [e.Vs.mixinDatacom],
  props: {
    type: { type: String, default: null },
    canvasId: { type: String, default: "uchartsid" },
    canvas2d: { type: Boolean, default: !1 },
    background: { type: String, default: "rgba(0,0,0,0)" },
    animation: { type: Boolean, default: !0 },
    chartData: {
      type: Object,
      default: function () {
        return { categories: [], series: [] };
      },
    },
    opts: {
      type: Object,
      default: function () {
        return {};
      },
    },
    eopts: {
      type: Object,
      default: function () {
        return {};
      },
    },
    loadingType: { type: Number, default: 2 },
    errorShow: { type: Boolean, default: !0 },
    errorReload: { type: Boolean, default: !0 },
    errorMessage: { type: String, default: null },
    inScrollView: { type: Boolean, default: !1 },
    reshow: { type: Boolean, default: !1 },
    reload: { type: Boolean, default: !1 },
    disableScroll: { type: Boolean, default: !1 },
    optsWatch: { type: Boolean, default: !0 },
    onzoom: { type: Boolean, default: !1 },
    ontap: { type: Boolean, default: !0 },
    ontouch: { type: Boolean, default: !1 },
    onmouse: { type: Boolean, default: !0 },
    onmovetip: { type: Boolean, default: !1 },
    echartsH5: { type: Boolean, default: !1 },
    echartsApp: { type: Boolean, default: !1 },
    tooltipShow: { type: Boolean, default: !0 },
    tooltipFormat: { type: String, default: void 0 },
    tooltipCustom: { type: Object, default: void 0 },
    startDate: { type: String, default: void 0 },
    endDate: { type: String, default: void 0 },
    textEnum: {
      type: Array,
      default: function () {
        return [];
      },
    },
    groupEnum: {
      type: Array,
      default: function () {
        return [];
      },
    },
    pageScrollTop: { type: Number, default: 0 },
    directory: { type: String, default: "/" },
    tapLegend: { type: Boolean, default: !0 },
    menus: {
      type: Array,
      default: function () {
        return [];
      },
    },
  },
  data: function () {
    return {
      cid: "uchartsid",
      inWx: !1,
      inAli: !1,
      inTt: !1,
      inBd: !1,
      inH5: !1,
      inApp: !1,
      inWin: !1,
      type2d: !0,
      disScroll: !1,
      openmouse: !1,
      pixel: 1,
      cWidth: 375,
      cHeight: 250,
      showchart: !1,
      echarts: !1,
      echartsResize: { state: !1 },
      uchartsOpts: {},
      echartsOpts: {},
      drawData: {},
      lastDrawTime: null,
    };
  },
  created: function () {
    if (
      ((this.cid = this.canvasId),
      "uchartsid" == this.canvasId || "" == this.canvasId)
    ) {
      for (
        var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
          o = t.length,
          i = "",
          a = 0;
        a < 32;
        a++
      )
        i += t.charAt(Math.floor(Math.random() * o));
      this.cid = i;
    }
    var n = e.index.getSystemInfoSync();
    ("windows" !== n.platform && "macos" !== n.platform) || (this.inWin = !0),
      (this.inWx = !0),
      !1 === this.canvas2d || "windows" === n.platform || "macos" === n.platform
        ? (this.type2d = !1)
        : ((this.type2d = !0), (this.pixel = n.pixelRatio)),
      (this.disScroll = this.disableScroll);
  },
  mounted: function () {
    var t = this;
    this.$nextTick(function () {
      t.beforeInit();
    });
    var o,
      i,
      a,
      n = this.inH5 ? 500 : 200,
      r = this;
    e.index.onWindowResize(
      ((o = function (t) {
        if (1 != r.mixinDatacomLoading) {
          var e = r.mixinDatacomErrorMessage;
          (null !== e && "null" !== e && "" !== e) ||
            (r.echarts
              ? (r.echartsResize.state = !r.echartsResize.state)
              : r.resizeHandler());
        }
      }),
      (i = n),
      (a = !1),
      function () {
        var t = arguments,
          e = this;
        clearTimeout(a),
          a && clearTimeout(a),
          (a = setTimeout(function () {
            (a = !1), o.apply(e, t);
          }, i));
      })
    );
  },
  destroyed: function () {
    !0 === this.echarts
      ? (delete cfe.option[this.cid], delete cfe.instance[this.cid])
      : (delete i.cfu.option[this.cid], delete i.cfu.instance[this.cid]),
      e.index.offWindowResize(function () {});
  },
  watch: {
    chartDataProps: {
      handler: function (e, o) {
        "object" === t(e)
          ? JSON.stringify(e) !== JSON.stringify(o) &&
            (this._clearChart(),
            e.series && e.series.length > 0
              ? this.beforeInit()
              : ((this.mixinDatacomLoading = !0),
                (this.showchart = !1),
                (this.mixinDatacomErrorMessage = null)))
          : ((this.mixinDatacomLoading = !1),
            this._clearChart(),
            (this.showchart = !1),
            (this.mixinDatacomErrorMessage =
              "参数错误：chartData数据类型错误"));
      },
      immediate: !1,
      deep: !0,
    },
    localdata: {
      handler: function (t, e) {
        JSON.stringify(t) !== JSON.stringify(e) &&
          (t.length > 0
            ? this.beforeInit()
            : ((this.mixinDatacomLoading = !0),
              this._clearChart(),
              (this.showchart = !1),
              (this.mixinDatacomErrorMessage = null)));
      },
      immediate: !1,
      deep: !0,
    },
    optsProps: {
      handler: function (e, o) {
        "object" === t(e)
          ? JSON.stringify(e) !== JSON.stringify(o) &&
            !1 === this.echarts &&
            1 == this.optsWatch &&
            this.checkData(this.drawData)
          : ((this.mixinDatacomLoading = !1),
            this._clearChart(),
            (this.showchart = !1),
            (this.mixinDatacomErrorMessage = "参数错误：opts数据类型错误"));
      },
      immediate: !1,
      deep: !0,
    },
    eoptsProps: {
      handler: function (e, o) {
        "object" === t(e)
          ? JSON.stringify(e) !== JSON.stringify(o) &&
            !0 === this.echarts &&
            this.checkData(this.drawData)
          : ((this.mixinDatacomLoading = !1),
            (this.showchart = !1),
            (this.mixinDatacomErrorMessage = "参数错误：eopts数据类型错误"));
      },
      immediate: !1,
      deep: !0,
    },
    reshow: function (t, e) {
      var o = this;
      !0 === t &&
        !1 === this.mixinDatacomLoading &&
        setTimeout(function () {
          (o.mixinDatacomErrorMessage = null),
            (o.echartsResize.state = !o.echartsResize.state),
            o.checkData(o.drawData);
        }, 200);
    },
    reload: function (t, e) {
      !0 === t &&
        ((this.showchart = !1),
        (this.mixinDatacomErrorMessage = null),
        this.reloading());
    },
    mixinDatacomErrorMessage: function (t, e) {
      t &&
        (this.emitMsg({
          name: "error",
          params: {
            type: "error",
            errorShow: this.errorShow,
            msg: t,
            id: this.cid,
          },
        }),
        this.errorShow && console.log("[秋云图表组件]" + t));
    },
    errorMessage: function (t, e) {
      t && this.errorShow && null !== t && "null" !== t && "" !== t
        ? ((this.showchart = !1),
          (this.mixinDatacomLoading = !1),
          (this.mixinDatacomErrorMessage = t))
        : ((this.showchart = !1),
          (this.mixinDatacomErrorMessage = null),
          this.reloading());
    },
  },
  computed: {
    optsProps: function () {
      return JSON.parse(JSON.stringify(this.opts));
    },
    eoptsProps: function () {
      return JSON.parse(JSON.stringify(this.eopts));
    },
    chartDataProps: function () {
      return JSON.parse(JSON.stringify(this.chartData));
    },
  },
  methods: {
    beforeInit: function () {
      (this.mixinDatacomErrorMessage = null),
        "object" === t(this.chartData) &&
        null != this.chartData &&
        void 0 !== this.chartData.series &&
        this.chartData.series.length > 0
          ? ((this.drawData = a({}, this.chartData)),
            (this.mixinDatacomLoading = !1),
            (this.showchart = !0),
            this.checkData(this.chartData))
          : this.localdata.length > 0
          ? ((this.mixinDatacomLoading = !1),
            (this.showchart = !0),
            this.localdataInit(this.localdata))
          : "" !== this.collection
          ? ((this.mixinDatacomLoading = !1), this.getCloudData())
          : (this.mixinDatacomLoading = !0);
    },
    localdataInit: function (t) {
      if (this.groupEnum.length > 0)
        for (var e = 0; e < t.length; e++)
          for (var o = 0; o < this.groupEnum.length; o++)
            t[e].group === this.groupEnum[o].value &&
              (t[e].group = this.groupEnum[o].text);
      if (this.textEnum.length > 0)
        for (var n = 0; n < t.length; n++)
          for (var r = 0; r < this.textEnum.length; r++)
            t[n].text === this.textEnum[r].value &&
              (t[n].text = this.textEnum[r].text);
      var s,
        c,
        h,
        u,
        l = !1,
        p = { categories: [], series: [] },
        d = [],
        f = [];
      if (
        !0 ===
        (l =
          !0 === this.echarts
            ? cfe.categories.includes(this.type)
            : i.cfu.categories.includes(this.type))
      ) {
        if (
          this.chartData &&
          this.chartData.categories &&
          this.chartData.categories.length > 0
        )
          d = this.chartData.categories;
        else if (this.startDate && this.endDate)
          for (
            var m = new Date(this.startDate), g = new Date(this.endDate);
            m <= g;

          )
            d.push(
              ((c = void 0),
              (h = void 0),
              (u = void 0),
              (c = (s = m).getFullYear()),
              (h = s.getMonth() + 1),
              (u = s.getDate()),
              h >= 1 && h <= 9 && (h = "0" + h),
              u >= 0 && u <= 9 && (u = "0" + u),
              c + "-" + h + "-" + u)
            ),
              (m = m.setDate(m.getDate() + 1)),
              (m = new Date(m));
        else {
          var x = {};
          t.map(function (t, e) {
            null == t.text || x[t.text] || (d.push(t.text), (x[t.text] = !0));
          });
        }
        p.categories = d;
      }
      var y = {};
      if (
        (t.map(function (t, e) {
          null == t.group ||
            y[t.group] ||
            (f.push({ name: t.group, data: [] }), (y[t.group] = !0));
        }),
        0 == f.length)
      )
        if (((f = [{ name: "默认分组", data: [] }]), !0 === l))
          for (var D = 0; D < d.length; D++) {
            for (var v = 0, w = 0; w < t.length; w++)
              t[w].text == d[D] && (v = t[w].value);
            f[0].data.push(v);
          }
        else
          for (var S = 0; S < t.length; S++)
            f[0].data.push({ name: t[S].text, value: t[S].value });
      else
        for (var _ = 0; _ < f.length; _++)
          if (d.length > 0)
            for (var T = 0; T < d.length; T++) {
              for (var M = 0, b = 0; b < t.length; b++)
                f[_].name == t[b].group &&
                  t[b].text == d[T] &&
                  (M = t[b].value);
              f[_].data.push(M);
            }
          else
            for (var L = 0; L < t.length; L++)
              f[_].name == t[L].group && f[_].data.push(t[L].value);
      (p.series = f), (this.drawData = a({}, p)), this.checkData(p);
    },
    reloading: function () {
      !1 !== this.errorReload &&
        ((this.showchart = !1),
        (this.mixinDatacomErrorMessage = null),
        "" !== this.collection
          ? ((this.mixinDatacomLoading = !1),
            this.onMixinDatacomPropsChange(!0))
          : this.beforeInit());
    },
    checkData: function (t) {
      var e = this,
        o = this.cid;
      !0 === this.echarts
        ? ((cfe.option[o] = a({}, this.eopts)),
          (cfe.option[o].id = o),
          (cfe.option[o].type = this.type))
        : this.type && i.cfu.type.includes(this.type)
        ? ((i.cfu.option[o] = a({}, i.cfu[this.type], this.opts)),
          (i.cfu.option[o].canvasId = o))
        : ((this.mixinDatacomLoading = !1),
          (this.showchart = !1),
          (this.mixinDatacomErrorMessage =
            "参数错误：props参数中type类型不正确"));
      var n = a({}, t);
      void 0 !== n.series &&
        n.series.length > 0 &&
        ((this.mixinDatacomErrorMessage = null),
        !0 === this.echarts
          ? ((cfe.option[o].chartData = n),
            this.$nextTick(function () {
              e.init();
            }))
          : ((i.cfu.option[o].categories = n.categories),
            (i.cfu.option[o].series = n.series),
            this.$nextTick(function () {
              e.init();
            })));
    },
    resizeHandler: function () {
      var t = this,
        o = Date.now();
      o - (this.lastDrawTime ? this.lastDrawTime : o - 3e3) < 1e3 ||
        e.index
          .createSelectorQuery()
          .in(this)
          .select("#ChartBoxId" + this.cid)
          .boundingClientRect(function (e) {
            (t.showchart = !0),
              e.width > 0 &&
                e.height > 0 &&
                ((e.width === t.cWidth && e.height === t.cHeight) ||
                  t.checkData(t.drawData));
          })
          .exec();
    },
    getCloudData: function () {
      var t = this;
      1 != this.mixinDatacomLoading &&
        ((this.mixinDatacomLoading = !0),
        this.mixinDatacomGet()
          .then(function (e) {
            (t.mixinDatacomResData = e.result.data),
              t.localdataInit(t.mixinDatacomResData);
          })
          .catch(function (e) {
            (t.mixinDatacomLoading = !1),
              (t.showchart = !1),
              (t.mixinDatacomErrorMessage = "请求错误：" + e);
          }));
    },
    onMixinDatacomPropsChange: function (t, e) {
      1 == t &&
        "" !== this.collection &&
        ((this.showchart = !1),
        (this.mixinDatacomErrorMessage = null),
        this._clearChart(),
        this.getCloudData());
    },
    _clearChart: function () {
      var e = this.cid;
      if (!0 !== this.echarts && i.cfu.option[e] && i.cfu.option[e].context) {
        var o = i.cfu.option[e].context;
        "object" !== t(o) ||
          i.cfu.option[e].update ||
          (o.clearRect(
            0,
            0,
            this.cWidth * this.pixel,
            this.cHeight * this.pixel
          ),
          o.draw());
      }
    },
    init: function () {
      var o = this,
        n = this.cid;
      e.index
        .createSelectorQuery()
        .in(this)
        .select("#ChartBoxId" + n)
        .boundingClientRect(function (r) {
          r.width > 0 && r.height > 0
            ? ((o.mixinDatacomLoading = !1),
              (o.showchart = !0),
              (o.lastDrawTime = Date.now()),
              (o.cWidth = r.width),
              (o.cHeight = r.height),
              !0 !== o.echarts &&
                ((i.cfu.option[n].background =
                  "rgba(0,0,0,0)" == o.background ? "#FFFFFF" : o.background),
                (i.cfu.option[n].canvas2d = o.type2d),
                (i.cfu.option[n].pixelRatio = o.pixel),
                (i.cfu.option[n].animation = o.animation),
                (i.cfu.option[n].width = r.width * o.pixel),
                (i.cfu.option[n].height = r.height * o.pixel),
                (i.cfu.option[n].onzoom = o.onzoom),
                (i.cfu.option[n].ontap = o.ontap),
                (i.cfu.option[n].ontouch = o.ontouch),
                (i.cfu.option[n].onmouse = o.openmouse),
                (i.cfu.option[n].onmovetip = o.onmovetip),
                (i.cfu.option[n].tooltipShow = o.tooltipShow),
                (i.cfu.option[n].tooltipFormat = o.tooltipFormat),
                (i.cfu.option[n].tooltipCustom = o.tooltipCustom),
                (i.cfu.option[n].inScrollView = o.inScrollView),
                (i.cfu.option[n].lastDrawTime = o.lastDrawTime),
                (i.cfu.option[n].tapLegend = o.tapLegend)),
              o.inH5 || o.inApp
                ? 1 == o.echarts
                  ? ((cfe.option[n].ontap = o.ontap),
                    (cfe.option[n].onmouse = o.openmouse),
                    (cfe.option[n].tooltipShow = o.tooltipShow),
                    (cfe.option[n].tooltipFormat = o.tooltipFormat),
                    (cfe.option[n].tooltipCustom = o.tooltipCustom),
                    (cfe.option[n].lastDrawTime = o.lastDrawTime),
                    (o.echartsOpts = a({}, cfe.option[n])))
                  : ((i.cfu.option[n].rotateLock = i.cfu.option[n].rotate),
                    (o.uchartsOpts = a({}, i.cfu.option[n])))
                : ((i.cfu.option[n] = (function e(o, i) {
                    for (var a in o)
                      o.hasOwnProperty(a) &&
                      null !== o[a] &&
                      "object" === t(o[a])
                        ? e(o[a], i)
                        : "format" === a &&
                          "string" == typeof o[a] &&
                          (o.formatter = i[o[a]] ? i[o[a]] : void 0);
                    return o;
                  })(i.cfu.option[n], i.cfu.formatter)),
                  (o.mixinDatacomErrorMessage = null),
                  (o.mixinDatacomLoading = !1),
                  (o.showchart = !0),
                  o.$nextTick(function () {
                    !0 === o.type2d
                      ? e.index
                          .createSelectorQuery()
                          .in(o)
                          .select("#" + n)
                          .fields({ node: !0, size: !0 })
                          .exec(function (t) {
                            if (t[0]) {
                              var e = t[0].node,
                                a = e.getContext("2d");
                              (i.cfu.option[n].context = a),
                                (i.cfu.option[n].rotateLock =
                                  i.cfu.option[n].rotate),
                                i.cfu.instance[n] &&
                                i.cfu.option[n] &&
                                !0 === i.cfu.option[n].update
                                  ? o._updataUChart(n)
                                  : ((e.width = r.width * o.pixel),
                                    (e.height = r.height * o.pixel),
                                    (e._width = r.width * o.pixel),
                                    (e._height = r.height * o.pixel),
                                    setTimeout(function () {
                                      i.cfu.option[n].context.restore(),
                                        i.cfu.option[n].context.save(),
                                        o._newChart(n);
                                    }, 100));
                            } else
                              (o.showchart = !1),
                                (o.mixinDatacomErrorMessage =
                                  "参数错误：开启2d模式后，未获取到dom节点，canvas-id:" +
                                  n);
                          })
                      : (o.inAli &&
                          (i.cfu.option[n].rotateLock = i.cfu.option[n].rotate),
                        (i.cfu.option[n].context = e.index.createCanvasContext(
                          n,
                          o
                        )),
                        i.cfu.instance[n] &&
                        i.cfu.option[n] &&
                        !0 === i.cfu.option[n].update
                          ? o._updataUChart(n)
                          : setTimeout(function () {
                              i.cfu.option[n].context.restore(),
                                i.cfu.option[n].context.save(),
                                o._newChart(n);
                            }, 100));
                  })))
            : ((o.mixinDatacomLoading = !1),
              (o.showchart = !1),
              1 == o.reshow &&
                (o.mixinDatacomErrorMessage =
                  "布局错误：未获取到父元素宽高尺寸！canvas-id:" + n));
        })
        .exec();
    },
    saveImage: function () {
      e.index.canvasToTempFilePath(
        {
          canvasId: this.cid,
          success: function (t) {
            e.index.saveImageToPhotosAlbum({
              filePath: t.tempFilePath,
              success: function () {
                e.index.showToast({ title: "保存成功", duration: 2e3 });
              },
            });
          },
        },
        this
      );
    },
    getImage: function () {
      var t = this;
      0 == this.type2d
        ? e.index.canvasToTempFilePath(
            {
              canvasId: this.cid,
              success: function (e) {
                t.emitMsg({
                  name: "getImage",
                  params: { type: "getImage", base64: e.tempFilePath },
                });
              },
            },
            this
          )
        : e.index
            .createSelectorQuery()
            .in(this)
            .select("#" + this.cid)
            .fields({ node: !0, size: !0 })
            .exec(function (e) {
              if (e[0]) {
                var o = e[0].node;
                t.emitMsg({
                  name: "getImage",
                  params: {
                    type: "getImage",
                    base64: o.toDataURL("image/png"),
                  },
                });
              }
            });
    },
    _newChart: function (t) {
      var e = this;
      1 != this.mixinDatacomLoading &&
        ((this.showchart = !0),
        (i.cfu.instance[t] = new o.uCharts(i.cfu.option[t])),
        i.cfu.instance[t].addEventListener("renderComplete", function () {
          e.emitMsg({
            name: "complete",
            params: {
              type: "complete",
              complete: !0,
              id: t,
              opts: i.cfu.instance[t].opts,
            },
          }),
            i.cfu.instance[t].delEventListener("renderComplete");
        }),
        i.cfu.instance[t].addEventListener("scrollLeft", function () {
          e.emitMsg({
            name: "scrollLeft",
            params: {
              type: "scrollLeft",
              scrollLeft: !0,
              id: t,
              opts: i.cfu.instance[t].opts,
            },
          });
        }),
        i.cfu.instance[t].addEventListener("scrollRight", function () {
          e.emitMsg({
            name: "scrollRight",
            params: {
              type: "scrollRight",
              scrollRight: !0,
              id: t,
              opts: i.cfu.instance[t].opts,
            },
          });
        }));
    },
    _updataUChart: function (t) {
      i.cfu.instance[t].updateData(i.cfu.option[t]);
    },
    _tooltipDefault: function (e, o, i, a) {
      if (o) {
        var n = e.data;
        return (
          "object" === t(e.data) && (n = e.data.value),
          o + " " + e.name + ":" + n
        );
      }
      return e.properties && e.properties.name
        ? e.properties.name
        : e.name + ":" + e.data;
    },
    _showTooltip: function (t) {
      var e = this,
        o = this.cid,
        a = i.cfu.option[o].tooltipCustom;
      if (a && null != a) {
        var n = void 0;
        a.x >= 0 && a.y >= 0 && (n = { x: a.x, y: a.y + 10 }),
          i.cfu.instance[o].showToolTip(t, {
            index: a.index,
            offset: n,
            textList: a.textList,
            formatter: function (t, a, n, r) {
              return "string" == typeof i.cfu.option[o].tooltipFormat &&
                i.cfu.formatter[i.cfu.option[o].tooltipFormat]
                ? i.cfu.formatter[i.cfu.option[o].tooltipFormat](t, a, n, r)
                : e._tooltipDefault(t, a, n, r);
            },
          });
      } else
        i.cfu.instance[o].showToolTip(t, {
          formatter: function (t, a, n, r) {
            return "string" == typeof i.cfu.option[o].tooltipFormat &&
              i.cfu.formatter[i.cfu.option[o].tooltipFormat]
              ? i.cfu.formatter[i.cfu.option[o].tooltipFormat](t, a, n, r)
              : e._tooltipDefault(t, a, n, r);
          },
        });
    },
    _tap: function (t, o) {
      var a = this,
        n = this.cid,
        r = null,
        s = null;
      !0 === this.inScrollView || this.inAli
        ? e.index
            .createSelectorQuery()
            .in(this)
            .select("#ChartBoxId" + n)
            .boundingClientRect(function (e) {
              (t.changedTouches = []),
                a.inAli
                  ? t.changedTouches.unshift({
                      x: t.detail.clientX - e.left,
                      y: t.detail.clientY - e.top,
                    })
                  : t.changedTouches.unshift({
                      x: t.detail.x - e.left,
                      y: t.detail.y - e.top - a.pageScrollTop,
                    }),
                o
                  ? !0 === a.tooltipShow && a._showTooltip(t)
                  : ((r = i.cfu.instance[n].getCurrentDataIndex(t)),
                    (s = i.cfu.instance[n].getLegendDataIndex(t)),
                    !0 === a.tapLegend && i.cfu.instance[n].touchLegend(t),
                    !0 === a.tooltipShow && a._showTooltip(t),
                    a.emitMsg({
                      name: "getIndex",
                      params: {
                        type: "getIndex",
                        event: {
                          x: t.detail.x - e.left,
                          y: t.detail.y - e.top,
                        },
                        currentIndex: r,
                        legendIndex: s,
                        id: n,
                        opts: i.cfu.instance[n].opts,
                      },
                    }));
            })
            .exec()
        : o
        ? !0 === this.tooltipShow && this._showTooltip(t)
        : ((t.changedTouches = []),
          t.changedTouches.unshift({
            x: t.detail.x - t.currentTarget.offsetLeft,
            y: t.detail.y - t.currentTarget.offsetTop,
          }),
          (r = i.cfu.instance[n].getCurrentDataIndex(t)),
          (s = i.cfu.instance[n].getLegendDataIndex(t)),
          !0 === this.tapLegend && i.cfu.instance[n].touchLegend(t),
          !0 === this.tooltipShow && this._showTooltip(t),
          this.emitMsg({
            name: "getIndex",
            params: {
              type: "getIndex",
              event: {
                x: t.detail.x,
                y: t.detail.y - t.currentTarget.offsetTop,
              },
              currentIndex: r,
              legendIndex: s,
              id: n,
              opts: i.cfu.instance[n].opts,
            },
          }));
    },
    _touchStart: function (t) {
      var e = this.cid;
      (n = Date.now()),
        !0 === i.cfu.option[e].enableScroll &&
          1 == t.touches.length &&
          i.cfu.instance[e].scrollStart(t),
        this.emitMsg({
          name: "getTouchStart",
          params: {
            type: "touchStart",
            event: t.changedTouches[0],
            id: e,
            opts: i.cfu.instance[e].opts,
          },
        });
    },
    _touchMove: function (t) {
      var e = this.cid,
        o = Date.now(),
        a = o - n,
        r = i.cfu.option[e].touchMoveLimit || 24;
      a < Math.floor(1e3 / r) ||
        ((n = o),
        !0 === i.cfu.option[e].enableScroll &&
          1 == t.changedTouches.length &&
          i.cfu.instance[e].scroll(t),
        !0 === this.ontap &&
          !1 === i.cfu.option[e].enableScroll &&
          !0 === this.onmovetip &&
          this._tap(t, !0),
        !0 === this.ontouch &&
          !0 === i.cfu.option[e].enableScroll &&
          !0 === this.onzoom &&
          2 == t.changedTouches.length &&
          i.cfu.instance[e].dobuleZoom(t),
        this.emitMsg({
          name: "getTouchMove",
          params: {
            type: "touchMove",
            event: t.changedTouches[0],
            id: e,
            opts: i.cfu.instance[e].opts,
          },
        }));
    },
    _touchEnd: function (t) {
      var e = this.cid;
      !0 === i.cfu.option[e].enableScroll &&
        0 == t.touches.length &&
        i.cfu.instance[e].scrollEnd(t),
        this.emitMsg({
          name: "getTouchEnd",
          params: {
            type: "touchEnd",
            event: t.changedTouches[0],
            id: e,
            opts: i.cfu.instance[e].opts,
          },
        }),
        !0 === this.ontap &&
          !1 === i.cfu.option[e].enableScroll &&
          !0 === this.onmovetip &&
          this._tap(t, !0);
    },
    _error: function (t) {
      this.mixinDatacomErrorMessage = t.detail.errMsg;
    },
    emitMsg: function (t) {
      this.$emit(t.name, t.params);
    },
    getRenderType: function () {
      !0 === this.echarts &&
        !1 === this.mixinDatacomLoading &&
        this.beforeInit();
    },
    toJSON: function () {
      return this;
    },
  },
};
Array ||
  (e.resolveComponent("qiun-loading") + e.resolveComponent("qiun-error"))();
Math ||
  (
    function () {
      return "../qiun-loading/qiun-loading.js";
    } +
    function () {
      return "../qiun-error/qiun-error.js";
    }
  )();
var s = e._export_sfc(r, [
  [
    "render",
    function (t, o, i, a, n, r) {
      return e.e(
        { a: t.mixinDatacomLoading },
        t.mixinDatacomLoading ? { b: e.p({ loadingType: i.loadingType }) } : {},
        { c: t.mixinDatacomErrorMessage && i.errorShow },
        t.mixinDatacomErrorMessage && i.errorShow
          ? {
              d: e.p({ errorMessage: i.errorMessage }),
              e: e.o(function () {
                return r.reloading && r.reloading.apply(r, arguments);
              }),
            }
          : {},
        { f: n.type2d },
        n.type2d
          ? e.e(
              { g: i.ontouch },
              i.ontouch
                ? {
                    h: n.cid,
                    i: n.cid,
                    j: n.cWidth + "px",
                    k: n.cHeight + "px",
                    l: i.background,
                    m: n.disScroll,
                    n: e.o(function () {
                      return r._touchStart && r._touchStart.apply(r, arguments);
                    }),
                    o: e.o(function () {
                      return r._touchMove && r._touchMove.apply(r, arguments);
                    }),
                    p: e.o(function () {
                      return r._touchEnd && r._touchEnd.apply(r, arguments);
                    }),
                    q: e.o(function () {
                      return r._error && r._error.apply(r, arguments);
                    }),
                    r: n.showchart,
                    s: e.o(function () {
                      return r._tap && r._tap.apply(r, arguments);
                    }),
                  }
                : {},
              { t: !i.ontouch },
              i.ontouch
                ? {}
                : {
                    v: n.cid,
                    w: n.cid,
                    x: n.cWidth + "px",
                    y: n.cHeight + "px",
                    z: i.background,
                    A: n.disScroll,
                    B: e.o(function () {
                      return r._error && r._error.apply(r, arguments);
                    }),
                    C: n.showchart,
                    D: e.o(function () {
                      return r._tap && r._tap.apply(r, arguments);
                    }),
                  }
            )
          : {},
        { E: !n.type2d },
        n.type2d
          ? {}
          : e.e(
              { F: i.ontouch },
              i.ontouch
                ? e.e(
                    { G: n.showchart },
                    n.showchart
                      ? {
                          H: n.cid,
                          I: n.cid,
                          J: n.cWidth + "px",
                          K: n.cHeight + "px",
                          L: i.background,
                          M: e.o(function () {
                            return (
                              r._touchStart && r._touchStart.apply(r, arguments)
                            );
                          }),
                          N: e.o(function () {
                            return (
                              r._touchMove && r._touchMove.apply(r, arguments)
                            );
                          }),
                          O: e.o(function () {
                            return (
                              r._touchEnd && r._touchEnd.apply(r, arguments)
                            );
                          }),
                          P: n.disScroll,
                          Q: e.o(function () {
                            return r._error && r._error.apply(r, arguments);
                          }),
                        }
                      : {},
                    {
                      R: e.o(function () {
                        return r._tap && r._tap.apply(r, arguments);
                      }),
                    }
                  )
                : {},
              { S: !i.ontouch },
              i.ontouch
                ? {}
                : e.e(
                    { T: n.showchart },
                    n.showchart
                      ? {
                          U: n.cid,
                          V: n.cid,
                          W: n.cWidth + "px",
                          X: n.cHeight + "px",
                          Y: i.background,
                          Z: n.disScroll,
                          aa: e.o(function () {
                            return r._tap && r._tap.apply(r, arguments);
                          }),
                          ab: e.o(function () {
                            return r._error && r._error.apply(r, arguments);
                          }),
                        }
                      : {}
                  )
            ),
        { ac: "ChartBoxId" + n.cid }
      );
    },
  ],
  ["__scopeId", "data-v-4f90b8bf"],
]);
wx.createComponent(s);
