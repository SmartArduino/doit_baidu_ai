var e = {
  name: "loading6",
  data: function () {
    return {};
  },
};
var r = require("../../../../common/vendor.js")._export_sfc(e, [
  [
    "render",
    function (e, r, n, t, o, a) {
      return {};
    },
  ],
  ["__scopeId", "data-v-3b2040f4"],
]);
wx.createComponent(r);
