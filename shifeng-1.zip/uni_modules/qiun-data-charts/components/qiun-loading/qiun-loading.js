var n = require("../../../../common/vendor.js"),
  o = {
    components: {
      Loading1: function () {
        return "./loading1.js";
      },
      Loading2: function () {
        return "./loading2.js";
      },
      Loading3: function () {
        return "./loading3.js";
      },
      Loading4: function () {
        return "./loading4.js";
      },
      Loading5: function () {
        return "./loading5.js";
      },
    },
    name: "qiun-loading",
    props: { loadingType: { type: Number, default: 2 } },
    data: function () {
      return {};
    },
  };
Array ||
  (
    n.resolveComponent("Loading1") +
    n.resolveComponent("Loading2") +
    n.resolveComponent("Loading3") +
    n.resolveComponent("Loading4") +
    n.resolveComponent("Loading5")
  )();
var e = n._export_sfc(o, [
  [
    "render",
    function (o, e, i, a, r, d) {
      return n.e(
        { a: 1 == i.loadingType },
        (i.loadingType, {}),
        { b: 2 == i.loadingType },
        (i.loadingType, {}),
        { c: 3 == i.loadingType },
        (i.loadingType, {}),
        { d: 4 == i.loadingType },
        (i.loadingType, {}),
        { e: 5 == i.loadingType },
        (i.loadingType, {})
      );
    },
  ],
]);
wx.createComponent(e);
