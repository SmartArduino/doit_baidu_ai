var e = {
  name: "loading1",
  data: function () {
    return {};
  },
};
var r = require("../../../../common/vendor.js")._export_sfc(e, [
  [
    "render",
    function (e, r, n, t, a, o) {
      return {};
    },
  ],
  ["__scopeId", "data-v-a59cc858"],
]);
wx.createComponent(r);
