var e = {
  name: "loading2",
  data: function () {
    return {};
  },
};
var r = require("../../../../common/vendor.js")._export_sfc(e, [
  [
    "render",
    function (e, r, n, a, t, o) {
      return {};
    },
  ],
  ["__scopeId", "data-v-ea750a45"],
]);
wx.createComponent(r);
