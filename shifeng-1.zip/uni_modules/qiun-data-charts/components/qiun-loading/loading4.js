var e = {
  name: "loading5",
  data: function () {
    return {};
  },
};
var r = require("../../../../common/vendor.js")._export_sfc(e, [
  [
    "render",
    function (e, r, n, t, o, a) {
      return {};
    },
  ],
  ["__scopeId", "data-v-7e96cf90"],
]);
wx.createComponent(r);
