var e = {
  name: "loading3",
  data: function () {
    return {};
  },
};
var r = require("../../../../common/vendor.js")._export_sfc(e, [
  [
    "render",
    function (e, r, n, t, a, o) {
      return {};
    },
  ],
  ["__scopeId", "data-v-9e18a663"],
]);
wx.createComponent(r);
