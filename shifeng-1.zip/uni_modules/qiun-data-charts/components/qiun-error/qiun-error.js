var r = require("../../../../common/vendor.js"),
  e = {
    name: "qiun-error",
    props: { errorMessage: { type: String, default: null } },
    data: function () {
      return {};
    },
  };
var n = r._export_sfc(e, [
  [
    "render",
    function (e, n, t, o, a, s) {
      return { a: r.t(null == t.errorMessage ? "请点击重试" : t.errorMessage) };
    },
  ],
]);
wx.createComponent(n);
