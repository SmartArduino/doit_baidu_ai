var e = {
  name: "uniSwipeAction",
  data: function () {
    return {};
  },
  created: function () {
    this.children = [];
  },
  methods: {
    resize: function () {},
    closeAll: function () {
      this.children.forEach(function (e) {
        e.is_show = "none";
      });
    },
    closeOther: function (e) {
      this.openItem && this.openItem !== e && (this.openItem.is_show = "none"),
        (this.openItem = e);
    },
  },
};
var n = require("../../../../common/vendor.js")._export_sfc(e, [
  [
    "render",
    function (e, n, t, o, i, r) {
      return {};
    },
  ],
]);
wx.createComponent(n);
