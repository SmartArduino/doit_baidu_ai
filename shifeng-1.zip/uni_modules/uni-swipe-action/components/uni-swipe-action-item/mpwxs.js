var i = {
  data: function () {
    return { is_show: "none" };
  },
  watch: {
    show: function (i) {
      this.is_show = this.show;
    },
  },
  created: function () {
    (this.swipeaction = this.getSwipeAction()),
      this.swipeaction &&
        Array.isArray(this.swipeaction.children) &&
        this.swipeaction.children.push(this);
  },
  mounted: function () {
    this.is_show = this.show;
  },
  methods: {
    closeSwipe: function (i) {
      this.autoClose && this.swipeaction && this.swipeaction.closeOther(this);
    },
    change: function (i) {
      this.$emit("change", i.open),
        this.is_show !== i.open && (this.is_show = i.open);
    },
    appTouchStart: function (i) {
      var t = i.changedTouches[0].clientX;
      (this.clientX = t), (this.timestamp = new Date().getTime());
    },
    appTouchEnd: function (i, t, s, e) {
      var n = i.changedTouches[0].clientX,
        h = Math.abs(this.clientX - n),
        o = new Date().getTime() - this.timestamp;
      h < 40 &&
        o < 300 &&
        this.$emit("click", { content: s, index: t, position: e });
    },
    onClickForPC: function (i, t, s) {},
  },
};
exports.mpwxs = i;
