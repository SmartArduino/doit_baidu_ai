var t = require("./mpwxs.js"),
  e = require("./bindingx.js"),
  n = require("./mpother.js"),
  o = require("../../../../common/vendor.js"),
  r = function (t) {
    t.wxsCallMethods || (t.wxsCallMethods = []),
      t.wxsCallMethods.push("closeSwipe", "change");
  },
  i = {},
  s = {
    mixins: [t.mpwxs, e.bindIngXMixins, n.otherMixins],
    emits: ["click", "change"],
    props: {
      show: { type: String, default: "none" },
      disabled: { type: Boolean, default: !1 },
      autoClose: { type: Boolean, default: !0 },
      threshold: { type: Number, default: 20 },
      leftOptions: {
        type: Array,
        default: function () {
          return [];
        },
      },
      rightOptions: {
        type: Array,
        default: function () {
          return [];
        },
      },
    },
    unmounted: function () {
      (this.__isUnmounted = !0), this.uninstall();
    },
    methods: {
      uninstall: function () {
        var t = this;
        this.swipeaction &&
          this.swipeaction.children.forEach(function (e, n) {
            e === t && t.swipeaction.children.splice(n, 1);
          });
      },
      getSwipeAction: function () {
        for (
          var t =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : "uniSwipeAction",
            e = this.$parent,
            n = e.$options.name;
          n !== t;

        ) {
          if (!(e = e.$parent)) return !1;
          n = e.$options.name;
        }
        return e;
      },
    },
  };
r(s), "function" == typeof i && i(s);
var l = o._export_sfc(s, [
  [
    "render",
    function (t, e, n, r, i, s) {
      return {
        a: o.f(n.leftOptions, function (e, n, r) {
          return {
            a: o.t(e.text),
            b: e.style && e.style.color ? e.style.color : "#FFFFFF",
            c: e.style && e.style.fontSize ? e.style.fontSize : "16px",
            d: n,
            e:
              e.style && e.style.backgroundColor
                ? e.style.backgroundColor
                : "#C7C6CD",
            f: o.o(function () {
              return t.appTouchStart && t.appTouchStart.apply(t, arguments);
            }, n),
            g: o.o(function (o) {
              return t.appTouchEnd(o, n, e, "left");
            }, n),
            h: o.o(function (o) {
              return t.onClickForPC(n, e, "left");
            }, n),
          };
        }),
        b: o.f(n.rightOptions, function (e, n, r) {
          return {
            a: o.t(e.text),
            b: e.style && e.style.color ? e.style.color : "#FFFFFF",
            c: e.style && e.style.fontSize ? e.style.fontSize : "16px",
            d: n,
            e:
              e.style && e.style.backgroundColor
                ? e.style.backgroundColor
                : "#C7C6CD",
            f: o.o(function () {
              return t.appTouchStart && t.appTouchStart.apply(t, arguments);
            }, n),
            g: o.o(function (o) {
              return t.appTouchEnd(o, n, e, "right");
            }, n),
            h: o.o(function (o) {
              return t.onClickForPC(n, e, "right");
            }, n),
          };
        }),
        c: t.is_show,
        d: n.threshold,
        e: n.disabled,
      };
    },
  ],
]);
wx.createComponent(l);
