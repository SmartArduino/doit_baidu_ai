var t = require("../../../../@babel/runtime/helpers/defineProperty"),
  n = require("../../../../common/vendor.js"),
  e = {
    name: "zero-markdown-view",
    components: {
      mpHtml: function () {
        return "../mp-html/mp-html.js";
      },
    },
    props: {
      markdown: { type: String, default: "" },
      selectable: { type: [Boolean, String], default: !0 },
      scrollTable: { type: Boolean, default: !0 },
      themeColor: { type: String, default: "#007AFF" },
      codeBgColor: { type: String, default: "#2d2d2d" },
    },
    data: function () {
      return { html: "", tagStyle: "", mpkey: "zero" };
    },
    watch: {
      markdown: function (t) {
        this.html = this.markdown;
      },
    },
    created: function () {
      this.initTagStyle();
    },
    mounted: function () {
      this.html = this.markdown;
    },
    methods: {
      initTagStyle: function () {
        var t = this.themeColor,
          n = this.codeBgColor,
          e = {
            p: "\n\t\t\t\tmargin:0px 0px;\n\t\t\t\tfont-size: 14px;\n\t\t\t\tline-height:1.75;\n\t\t\t\tletter-spacing:0.2em;\n\t\t\t\tword-spacing:0.1em;\n\t\t\t\t",
            h1: "\n\t\t\t\tmargin:0;\n\t\t\t\tfont-size: 24px;\n\t\t\t\ttext-align: center;\n\t\t\t\tfont-weight: bold;\n\t\t\t\tcolor: "
              .concat(
                t,
                ";\n\t\t\t\tpadding:3px 10px 1px;\n\t\t\t\tborder-bottom: 2px solid "
              )
              .concat(
                t,
                ";\n\t\t\t\tborder-top-right-radius:3px;\n\t\t\t\tborder-top-left-radius:3px;\n\t\t\t\t"
              ),
            h2: "\n\t\t\t\tmargin:0;\t\n\t\t\t\tfont-size: 20px;\n\t\t\t\ttext-align:center;\n\t\t\t\tcolor:"
              .concat(
                t,
                ";\n\t\t\t\tfont-weight:bolder;\n\t\t\t\tpadding-left:10px;\n\t\t\t\t// border:1px solid "
              )
              .concat(t, ";\n\t\t\t\t"),
            h3: "\n\t\t\t\tmargin:0;\n\t\t\t\tfont-size: 18px;\n\t\t\t\tcolor: "
              .concat(
                t,
                ";\n\t\t\t\tpadding-left:10px;\n\t\t\t\tborder-left:3px solid "
              )
              .concat(t, ";\n\t\t\t\t"),
            blockquote:
              "\n\t\t\t\tmargin:0;\n\t\t\t\tfont-size:15px;\n\t\t\t\tcolor: #777777;\n\t\t\t\tborder-left: 4px solid #dddddd;\n\t\t\t\tpadding: 0 10px;\n\t\t\t\t ",
            ul: "\n\t\t\t\tmargin: 0;\n\t\t\t\tcolor: #555;\n\t\t\t\t",
            li: "\n\t\t\t\tmargin: 5px 0;\n\t\t\t\tcolor: #555;\n\t\t\t\t",
            a: "\n\t\t\t\t// color: ".concat(t, ";\n\t\t\t\t"),
            strong: "\n\t\t\t\tfont-weight: border;\n\t\t\t\tcolor: ".concat(
              t,
              ";\n\t\t\t\t"
            ),
            em: "\n\t\t\t\tcolor: ".concat(
              t,
              ";\n\t\t\t\tletter-spacing:0.3em;\n\t\t\t\t"
            ),
            hr: "\n\t\t\t\theight:1px;\n\t\t\t\tpadding:0;\n\t\t\t\tborder:none;\n\t\t\t\t// border-top:medium solid #333;\n\t\t\t\ttext-align:center;\n\t\t\t\tbackground-image:linear-gradient(to right,rgba(248,57,41,0),".concat(
              t,
              ",rgba(248,57,41,0));\n\t\t\t\t"
            ),
            table:
              "\n\t\t\t\tborder-spacing:0;\n\t\t\t\toverflow:auto;\n\t\t\t\tmin-width:100%;\n\t\t\t\tmargin:10px 0;\n\t\t\t\tborder-collapse: collapse;\n\t\t\t\t",
            th: "\n\t\t\t\tborder: 1px solid #202121;\n\t\t\t\tcolor: #555;\n\t\t\t\t",
            td: "\n\t\t\t\tcolor:#555;\n\t\t\t\tborder: 1px solid #555555;\n\t\t\t\t",
            pre: "\n\t\t\t\tborder-radius: 5px;\n\t\t\t\twhite-space: pre;\n\t\t\t\tbackground: ".concat(
              n,
              ";\n\t\t\t\tfont-size:12px;\n\t\t\t\tposition: relative;\n\t\t\t\t"
            ),
          };
        this.tagStyle = e;
      },
    },
  };
Array || n.resolveComponent("mp-html")();
Math;
var o = n._export_sfc(e, [
  [
    "render",
    function (e, o, r, a, l, i) {
      return {
        a: l.mpkey,
        b: n.p(
          t(
            t(
              t(
                t({ selectable: r.selectable }, "scroll-table", r.scrollTable),
                "tag-style",
                l.tagStyle
              ),
              "markdown",
              !0
            ),
            "content",
            l.html
          )
        ),
      };
    },
  ],
]);
wx.createComponent(o);
