var e = require("./prism.min.js"),
  t = require("../parser.js");
function s(e) {
  this.vm = e;
}
(s.prototype.onParse = function (s, r) {
  if ("pre" === s.name) {
    if (r.options.editable)
      return void (s.attrs.class = (s.attrs.class || "") + " hl-pre");
    var a;
    for (a = s.children.length; a-- && "code" !== s.children[a].name; );
    if (-1 === a) return;
    var l,
      i = s.children[a],
      n = i.attrs.class + " " + s.attrs.class;
    for (
      -1 === (a = n.indexOf("language-"))
        ? -1 === (a = n.indexOf("lang-"))
          ? ((n = "language-text"), (a = 9))
          : (a += 5)
        : (a += 9),
        l = a;
      l < n.length && " " !== n[l];
      l++
    );
    var o = n.substring(a, l);
    if (i.children.length) {
      var c = this.vm.getText(i.children).replace(/&amp;/g, "&");
      if (!c) return;
      s.c && (s.c = void 0),
        e.Prism.languages[o] &&
          (i.children = new t.Parser(this.vm).parse(
            "<pre>" +
              e.Prism.highlight(c, e.Prism.languages[o], o).replace(
                /token /g,
                "hl-"
              ) +
              "</pre>"
          )[0].children),
        (s.attrs.class = "hl-pre"),
        (i.attrs.class = "hl-code"),
        (i.attrs.style = "display:block;overflow: auto;"),
        s.children.push({
          name: "div",
          attrs: {
            class: "hl-language",
            style:
              "user-select:none;position:absolute;top:0;right:2px;font-size:10px;",
          },
          children: [{ type: "text", text: o }],
        }),
        (s.attrs.style += (s.attrs.style || "") + ";user-select:none;"),
        (s.attrs["data-content"] = c),
        s.children.push({
          name: "div",
          attrs: {
            class: "hl-copy",
            style:
              "user-select:none;position:absolute;top:0;right:3px;font-size:10px;",
          },
        }),
        r.expose();
    }
  }
}),
  (exports.Highlight = s);
