var t = require("./marked.min.js"),
  a = 0;
function e(t) {
  (this.vm = t), (t._ids = {});
}
(e.prototype.onUpdate = function (a) {
  if (this.vm.markdown) return t.marked(a);
}),
  (e.prototype.onParse = function (t, e) {
    if (e.options.markdown) {
      if (
        e.options.useAnchor &&
        t.attrs &&
        /[\u4e00-\u9fa5]/.test(t.attrs.id)
      ) {
        var n = "t" + a++;
        (this.vm._ids[t.attrs.id] = n), (t.attrs.id = n);
      }
      ("p" !== t.name &&
        "table" !== t.name &&
        "tr" !== t.name &&
        "th" !== t.name &&
        "td" !== t.name &&
        "blockquote" !== t.name &&
        "pre" !== t.name &&
        "code" !== t.name) ||
        (t.attrs.class = "md-".concat(t.name, " ").concat(t.attrs.class || ""));
    }
  }),
  (exports.Markdown = e);
