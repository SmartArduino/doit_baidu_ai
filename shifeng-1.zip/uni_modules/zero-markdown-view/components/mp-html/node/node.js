var t = require("../../../../../common/vendor.js"),
  a = {},
  r = {
    name: "node",
    options: { virtualHost: !0 },
    data: function () {
      return {
        ctrl: {},
        isiOS: t.index.getSystemInfoSync().system.includes("iOS"),
      };
    },
    props: {
      name: String,
      attrs: {
        type: Object,
        default: function () {
          return {};
        },
      },
      childs: Array,
      opts: Array,
    },
    components: {
      node: function () {
        return Promise.resolve().then(function () {
          return e;
        });
      },
    },
    mounted: function () {
      var t = this;
      this.$nextTick(function () {
        for (
          t.root = t.$parent;
          "mp-html" !== t.root.$options.name;
          t.root = t.root.$parent
        );
      });
    },
    beforeDestroy: function () {},
    methods: {
      codeLongTap: function (a) {
        "hl-pre" == a.attrs.class &&
          t.index.setClipboardData({
            data: a.attrs["data-content"],
            showToast: !1,
            success: function () {
              t.index.showToast({ title: "代码复制成功", duration: 1e3 });
            },
            fail: function (t) {
              console.log("err", t);
            },
          });
      },
      toJSON: function () {
        return this;
      },
      play: function (a) {
        if ((this.root.$emit("play"), this.root.pauseVideo)) {
          for (var r = !1, s = a.target.id, e = this.root._videos.length; e--; )
            this.root._videos[e].id === s
              ? (r = !0)
              : this.root._videos[e].pause();
          if (!r) {
            var n = t.index.createVideoContext(s, this);
            (n.id = s),
              this.root.playbackRate && n.playbackRate(this.root.playbackRate),
              this.root._videos.push(n);
          }
        }
      },
      imgTap: function (a) {
        var r = this.childs[a.currentTarget.dataset.i];
        r.a
          ? this.linkTap(r.a)
          : r.attrs.ignore ||
            (this.root.$emit("imgtap", r.attrs),
            this.root.previewImg &&
              t.index.previewImage({
                showmenu: this.root.showImgMenu,
                current: parseInt(r.attrs.i),
                urls: this.root.imgList,
              }));
      },
      imgLongTap: function (t) {},
      imgLoad: function (t) {
        var a = t.currentTarget.dataset.i;
        this.childs[a].w
          ? ((this.opts[1] && !this.ctrl[a]) || -1 === this.ctrl[a]) &&
            this.$set(this.ctrl, a, 1)
          : this.$set(this.ctrl, a, t.detail.width),
          this.checkReady();
      },
      checkReady: function () {
        var t = this;
        this.root &&
          !this.root.lazyLoad &&
          ((this.root._unloadimgs -= 1),
          this.root._unloadimgs ||
            setTimeout(function () {
              t.root
                .getRect()
                .then(function (a) {
                  t.root.$emit("ready", a);
                })
                .catch(function () {
                  t.root.$emit("ready", {});
                });
            }, 350));
      },
      linkTap: function (a) {
        var r = a.currentTarget ? this.childs[a.currentTarget.dataset.i] : {},
          s = r.attrs || a,
          e = s.href;
        this.root.$emit(
          "linktap",
          Object.assign({ innerText: this.root.getText(r.children || []) }, s)
        ),
          e &&
            ("#" === e[0]
              ? this.root.navigateTo(e.substring(1)).catch(function () {})
              : e.split("?")[0].includes("://")
              ? this.root.copyLink &&
                t.index.setClipboardData({
                  data: e,
                  success: function () {
                    return t.index.showToast({ title: "链接已复制" });
                  },
                })
              : t.index.navigateTo({
                  url: e,
                  fail: function () {
                    t.index.switchTab({ url: e, fail: function () {} });
                  },
                }));
      },
      mediaError: function (t) {
        var a = t.currentTarget.dataset.i,
          r = this.childs[a];
        if ("video" === r.name || "audio" === r.name) {
          var s = (this.ctrl[a] || 0) + 1;
          if ((s > r.src.length && (s = 0), s < r.src.length))
            return void this.$set(this.ctrl, a, s);
        } else
          "img" === r.name &&
            (this.opts[2] && this.$set(this.ctrl, a, -1), this.checkReady());
        this.root &&
          this.root.$emit("error", {
            source: r.name,
            attrs: r.attrs,
            errMsg: t.detail.errMsg,
          });
      },
    },
  };
Array || t.resolveComponent("node")();
"function" == typeof a && a(r);
var s = t._export_sfc(r, [
  [
    "render",
    function (a, r, s, e, n, i) {
      return {
        a: t.f(s.childs, function (a, r, e) {
          return t.e(
            {
              a:
                "img" === a.name &&
                !a.t &&
                ((s.opts[1] && !n.ctrl[r]) || n.ctrl[r] < 0),
            },
            "img" === a.name &&
              !a.t &&
              ((s.opts[1] && !n.ctrl[r]) || n.ctrl[r] < 0)
              ? {
                  b: t.s(a.attrs.style),
                  c: n.ctrl[r] < 0 ? s.opts[2] : s.opts[1],
                }
              : {},
            { d: "img" === a.name && a.t },
            "img" === a.name && a.t
              ? {
                  e: t.s("display:" + a.t),
                  f: [
                    {
                      attrs: { style: a.attrs.style, src: a.attrs.src },
                      name: "img",
                    },
                  ],
                  g: r,
                  h: t.o(function () {
                    return i.imgTap && i.imgTap.apply(i, arguments);
                  }, r),
                }
              : "img" === a.name
              ? {
                  j: a.attrs.id,
                  k: t.n("_img " + a.attrs.class),
                  l: t.s(
                    (-1 === n.ctrl[r] ? "display:none;" : "") +
                      "width:" +
                      (n.ctrl[r] || 1) +
                      "px;height:1px;" +
                      a.attrs.style
                  ),
                  m: a.attrs.src,
                  n: a.h ? (a.w ? "" : "heightFix") : "widthFix",
                  o: s.opts[0],
                  p: a.webp,
                  q: s.opts[3] && !a.attrs.ignore,
                  r: !s.opts[3] || a.attrs.ignore,
                  s: r,
                  t: t.o(function () {
                    return i.imgLoad && i.imgLoad.apply(i, arguments);
                  }, r),
                  v: t.o(function () {
                    return i.mediaError && i.mediaError.apply(i, arguments);
                  }, r),
                  w: t.o(function () {
                    return i.imgTap && i.imgTap.apply(i, arguments);
                  }, r),
                  x: t.o(function () {
                    return i.imgLongTap && i.imgLongTap.apply(i, arguments);
                  }, r),
                }
              : a.text
              ? { z: t.t(a.text), A: "force" == s.opts[4] && n.isiOS }
              : "br" === a.name
              ? {}
              : "a" === a.name
              ? {
                  D: "dc531b90-0-" + e,
                  E: t.p({ name: "span", childs: a.children, opts: s.opts }),
                  F: a.attrs.id,
                  G: t.n((a.attrs.href ? "_a " : "") + a.attrs.class),
                  H: t.s("display:inline;" + a.attrs.style),
                  I: r,
                  J: t.o(function () {
                    return i.linkTap && i.linkTap.apply(i, arguments);
                  }, r),
                }
              : "video" === a.name
              ? {
                  L: a.attrs.id,
                  M: t.n(a.attrs.class),
                  N: t.s(a.attrs.style),
                  O: a.attrs.autoplay,
                  P: a.attrs.controls,
                  Q: a.attrs.loop,
                  R: a.attrs.muted,
                  S: a.attrs["object-fit"],
                  T: a.attrs.poster,
                  U: a.src[n.ctrl[r] || 0],
                  V: r,
                  W: t.o(function () {
                    return i.play && i.play.apply(i, arguments);
                  }, r),
                  X: t.o(function () {
                    return i.mediaError && i.mediaError.apply(i, arguments);
                  }, r),
                }
              : "audio" === a.name
              ? {
                  Z: a.attrs.id,
                  aa: t.n(a.attrs.class),
                  ab: t.s(a.attrs.style),
                  ac: a.attrs.author,
                  ad: a.attrs.controls,
                  ae: a.attrs.loop,
                  af: a.attrs.name,
                  ag: a.attrs.poster,
                  ah: a.src[n.ctrl[r] || 0],
                  ai: r,
                  aj: t.o(function () {
                    return i.play && i.play.apply(i, arguments);
                  }, r),
                  ak: t.o(function () {
                    return i.mediaError && i.mediaError.apply(i, arguments);
                  }, r),
                }
              : ("table" === a.name && a.c) || "li" === a.name
              ? t.e(
                  { am: "li" === a.name },
                  "li" === a.name
                    ? {
                        an: "dc531b90-1-" + e,
                        ao: t.p({ childs: a.children, opts: s.opts }),
                      }
                    : {
                        ap: t.f(a.children, function (a, r, n) {
                          return t.e(
                            { a: "td" === a.name || "th" === a.name },
                            "td" === a.name || "th" === a.name
                              ? {
                                  b: "dc531b90-2-" + e + "-" + n,
                                  c: t.p({ childs: a.children, opts: s.opts }),
                                }
                              : {
                                  d: t.f(a.children, function (a, r, i) {
                                    return t.e(
                                      { a: "td" === a.name || "th" === a.name },
                                      "td" === a.name || "th" === a.name
                                        ? {
                                            b:
                                              "dc531b90-3-" +
                                              e +
                                              "-" +
                                              n +
                                              "-" +
                                              i,
                                            c: t.p({
                                              childs: a.children,
                                              opts: s.opts,
                                            }),
                                            d: t.n(
                                              "_" + a.name + " " + a.attrs.class
                                            ),
                                            e: t.s(a.attrs.style),
                                          }
                                        : {
                                            f: t.f(
                                              a.children,
                                              function (a, r, o) {
                                                return {
                                                  a:
                                                    "dc531b90-4-" +
                                                    e +
                                                    "-" +
                                                    n +
                                                    "-" +
                                                    i +
                                                    "-" +
                                                    o,
                                                  b: t.p({
                                                    childs: a.children,
                                                    opts: s.opts,
                                                  }),
                                                  c: r,
                                                  d: t.n(
                                                    "_" +
                                                      a.name +
                                                      " " +
                                                      a.attrs.class
                                                  ),
                                                  e: t.s(a.attrs.style),
                                                };
                                              }
                                            ),
                                            g: t.n(
                                              "_" + a.name + " " + a.attrs.class
                                            ),
                                            h: t.s(a.attrs.style),
                                          },
                                      { i: r }
                                    );
                                  }),
                                },
                            {
                              e: r,
                              f: t.n("_" + a.name + " " + a.attrs.class),
                              g: t.s(a.attrs.style),
                            }
                          );
                        }),
                      },
                  {
                    aq: a.attrs.id,
                    ar: t.n("_" + a.name + " " + a.attrs.class),
                    as: t.s(a.attrs.style),
                  }
                )
              : a.c
              ? 2 === a.c
                ? {
                    aC: t.f(a.children, function (a, r, n) {
                      return {
                        a: r,
                        b: t.s(a.f),
                        c: "dc531b90-5-" + e + "-" + n,
                        d: t.p({
                          name: a.name,
                          attrs: a.attrs,
                          childs: a.children,
                          opts: s.opts,
                        }),
                      };
                    }),
                    aD: a.attrs.id,
                    aE: t.n("_block _" + a.name + " " + a.attrs.class),
                    aF: t.s(a.f + ";" + a.attrs.style),
                  }
                : {
                    aG: t.s(a.f),
                    aH: "dc531b90-6-" + e,
                    aI: t.p({
                      name: a.name,
                      attrs: a.attrs,
                      childs: a.children,
                      opts: s.opts,
                    }),
                  }
              : {
                  av: a.attrs.id,
                  aw: t.s("display:inline;" + a.f),
                  ax: s.opts[4],
                  ay: s.opts[4],
                  az: [a],
                  aA: t.o(function (t) {
                    return i.codeLongTap(a);
                  }, r),
                },
            {
              i: "img" === a.name,
              y: a.text,
              B: "br" === a.name,
              C: "a" === a.name,
              K: "video" === a.name,
              Y: "audio" === a.name,
              al: ("table" === a.name && a.c) || "li" === a.name,
              at: !a.c,
              aB: 2 === a.c,
              aJ: r,
            }
          );
        }),
        b: s.attrs.id,
        c: t.n("_block _" + s.name + " " + s.attrs.class),
        d: t.s(s.attrs.style),
      };
    },
  ],
]);
wx.createComponent(s);
var e = Object.freeze(
  Object.defineProperty({ __proto__: null }, Symbol.toStringTag, {
    value: "Module",
  })
);
