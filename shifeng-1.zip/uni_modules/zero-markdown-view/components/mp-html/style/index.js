var t = require("./parser.js");
function e() {
  this.styles = [];
}
function r(t, e) {
  function r(e) {
    if ("#" === e[0]) {
      if (t.attrs.id && t.attrs.id.trim() === e.substr(1)) return 3;
    } else if ("." === e[0]) {
      e = e.substr(1);
      for (var r = (t.attrs.class || "").split(" "), s = 0; s < r.length; s++)
        if (r[s].trim() === e) return 2;
    } else if (t.name === e) return 1;
    return 0;
  }
  if (e instanceof Array) {
    for (var s = 0, n = 0; n < e.length; n++) {
      var i = r(e[n]);
      if (!i) return 0;
      i > s && (s = i);
    }
    return s;
  }
  return r(e);
}
(e.prototype.onParse = function (e, s) {
  var n = this;
  if ("style" === e.name && e.children.length && "text" === e.children[0].type)
    this.styles = this.styles.concat(new t.Parser().parse(e.children[0].text));
  else if (e.name) {
    for (
      var i = ["", "", "", ""],
        l = function () {
          var t,
            l = n.styles[a],
            f = r(e, l.key || l.list[l.list.length - 1]);
          if (f) {
            if (!l.key) {
              t = l.list.length - 2;
              for (var c = s.stack.length; t >= 0 && c--; )
                if (">" === l.list[t]) {
                  if (t < 1 || t > l.list.length - 2) break;
                  r(s.stack[c], l.list[t - 1]) ? (t -= 2) : t++;
                } else r(s.stack[c], l.list[t]) && t--;
              f = 4;
            }
            if (l.key || t < 0)
              if (l.pseudo && e.children) {
                var u;
                l.style = l.style.replace(/content:([^;]+)/, function (t, r) {
                  return (
                    (u = r
                      .replace(/['"]/g, "")
                      .replace(/attr\((.+?)\)/, function (t, r) {
                        return e.attrs[r.trim()] || "";
                      })
                      .replace(/\\(\w{4})/, function (t, e) {
                        return String.fromCharCode(parseInt(e, 16));
                      })),
                    ""
                  );
                });
                var h = {
                  name: "span",
                  attrs: { style: l.style },
                  children: [{ type: "text", text: u }],
                };
                "before" === l.pseudo
                  ? e.children.unshift(h)
                  : e.children.push(h);
              } else
                i[f - 1] +=
                  l.style + (";" === l.style[l.style.length - 1] ? "" : ";");
          }
        },
        a = 0,
        f = this.styles.length;
      a < f;
      a++
    )
      l();
    (i = i.join("")).length > 2 && (e.attrs.style = i + (e.attrs.style || ""));
  }
}),
  (exports.Style = e);
