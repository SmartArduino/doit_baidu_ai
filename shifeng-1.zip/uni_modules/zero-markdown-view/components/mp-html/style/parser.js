require("../../../../../@babel/runtime/helpers/Arrayincludes");
var t = { " ": !0, "\n": !0, "\t": !0, "\r": !0, "\f": !0 };
function s() {
  (this.styles = []), (this.selectors = []);
}
function i(t) {
  (this.selector = ""), (this.style = ""), (this.handler = t);
}
(s.prototype.parse = function (t) {
  return new i(this).parse(t), this.styles;
}),
  (s.prototype.onSelector = function (t) {
    if (!(t.includes("[") || t.includes("*") || t.includes("@"))) {
      var s = {};
      if (t.includes(":")) {
        var i = t.split(":"),
          e = i.pop();
        if ("before" !== e && "after" !== e) return;
        (s.pseudo = e), (t = i[0]);
      }
      if (t.includes(" ")) {
        s.list = [];
        for (var n = t.split(" "), h = 0; h < n.length; h++)
          if (n[h].length)
            for (var o = n[h].split(">"), r = 0; r < o.length; r++)
              s.list.push(l(o[r])), r < o.length - 1 && s.list.push(">");
      } else s.key = l(t);
      this.selectors.push(s);
    }
    function l(t) {
      var s,
        i,
        e = [];
      for (s = 1, i = 0; s < t.length; s++)
        ("." !== t[s] && "#" !== t[s]) || (e.push(t.substring(i, s)), (i = s));
      return e.length ? (e.push(t.substring(i, s)), e) : t;
    }
  }),
  (s.prototype.onContent = function (t) {
    for (var s = 0; s < this.selectors.length; s++) this.selectors[s].style = t;
    (this.styles = this.styles.concat(this.selectors)), (this.selectors = []);
  }),
  (i.prototype.parse = function (t) {
    (this.i = 0), (this.content = t), (this.state = this.blank);
    for (var s = t.length; this.i < s; this.i++) this.state(t[this.i]);
  }),
  (i.prototype.comment = function () {
    (this.i = this.content.indexOf("*/", this.i) + 1),
      this.i || (this.i = this.content.length);
  }),
  (i.prototype.blank = function (s) {
    if (!t[s]) {
      if ("/" === s && "*" === this.content[this.i + 1])
        return void this.comment();
      (this.selector += s), (this.state = this.name);
    }
  }),
  (i.prototype.name = function (s) {
    if ("/" !== s || "*" !== this.content[this.i + 1])
      if ("{" === s || "," === s || ";" === s) {
        if (
          (this.handler.onSelector(this.selector.trimEnd()),
          (this.selector = ""),
          "{" !== s)
        )
          for (; t[this.content[++this.i]]; );
        "{" === this.content[this.i]
          ? ((this.floor = 1), (this.state = this.val))
          : (this.selector += this.content[this.i]);
      } else this.selector += t[s] ? " " : s;
    else this.comment();
  }),
  (i.prototype.val = function (t) {
    if ("/" !== t || "*" !== this.content[this.i + 1]) {
      if ("{" === t) this.floor++;
      else if ("}" === t && (this.floor--, !this.floor))
        return (
          this.handler.onContent(this.style),
          (this.style = ""),
          void (this.state = this.blank)
        );
      this.style += t;
    } else this.comment();
  }),
  (exports.Parser = s);
