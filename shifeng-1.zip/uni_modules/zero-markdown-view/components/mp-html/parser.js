require("../../../../@babel/runtime/helpers/Arrayincludes");
var t = require("../../../../common/vendor.js"),
  i = {
    trustTags: l(
      "a,abbr,ad,audio,b,blockquote,br,code,col,colgroup,dd,del,dl,dt,div,em,fieldset,h1,h2,h3,h4,h5,h6,hr,i,img,ins,label,legend,li,ol,p,q,ruby,rt,source,span,strong,sub,sup,table,tbody,td,tfoot,th,thead,tr,title,ul,video"
    ),
    blockTags: l(
      "address,article,aside,body,caption,center,cite,footer,header,html,nav,pre,section"
    ),
    inlineTags: l(
      "abbr,b,big,code,del,em,i,ins,label,q,small,span,strong,sub,sup"
    ),
    ignoreTags: l(
      "area,base,canvas,embed,frame,head,iframe,input,link,map,meta,param,rp,script,source,style,textarea,title,track,wbr"
    ),
    voidTags: l(
      "area,base,br,col,circle,ellipse,embed,frame,hr,img,input,line,link,meta,param,path,polygon,rect,source,track,use,wbr"
    ),
    entities: {
      lt: "<",
      gt: ">",
      quot: '"',
      apos: "'",
      ensp: " ",
      emsp: " ",
      nbsp: " ",
      semi: ";",
      ndash: "–",
      mdash: "—",
      middot: "·",
      lsquo: "‘",
      rsquo: "’",
      ldquo: "“",
      rdquo: "”",
      bull: "•",
      hellip: "…",
      larr: "←",
      uarr: "↑",
      rarr: "→",
      darr: "↓",
    },
    tagStyle: {
      address: "font-style:italic",
      big: "display:inline;font-size:1.2em",
      caption: "display:table-caption;text-align:center",
      center: "text-align:center",
      cite: "font-style:italic",
      dd: "margin-left:40px",
      mark: "background-color:yellow",
      pre: "font-family:monospace;white-space:pre",
      s: "text-decoration:line-through",
      small: "display:inline;font-size:0.8em",
      strike: "text-decoration:line-through",
      u: "text-decoration:underline",
    },
    svgDict: {
      animatetransform: "animateTransform",
      lineargradient: "linearGradient",
      viewbox: "viewBox",
      attributename: "attributeName",
      repeatcount: "repeatCount",
      repeatdur: "repeatDur",
    },
  },
  e = {},
  s = t.index.getSystemInfoSync(),
  a = s.windowWidth,
  n = s.system,
  r = l(" ,\r,\n,\t,\f"),
  o = 0;
function l(t) {
  for (var i = Object.create(null), e = t.split(","), s = e.length; s--; )
    i[e[s]] = !0;
  return i;
}
function h(t, e) {
  for (var s = t.indexOf("&"); -1 !== s; ) {
    var a = t.indexOf(";", s + 3),
      n = void 0;
    if (-1 === a) break;
    "#" === t[s + 1]
      ? ((n = parseInt(("x" === t[s + 2] ? "0" : "") + t.substring(s + 2, a))),
        isNaN(n) ||
          (t = t.substr(0, s) + String.fromCharCode(n) + t.substr(a + 1)))
      : ((n = t.substring(s + 1, a)),
        (i.entities[n] || ("amp" === n && e)) &&
          (t = t.substr(0, s) + (i.entities[n] || "&") + t.substr(a + 1))),
      (s = t.indexOf("&", s + 1));
  }
  return t;
}
function c(t) {
  for (var i = t.length - 1, e = i; e >= -1; e--)
    (-1 === e ||
      t[e].c ||
      !t[e].name ||
      ("div" !== t[e].name && "p" !== t[e].name && "h" !== t[e].name[0]) ||
      (t[e].attrs.style || "").includes("inline")) &&
      (i - e >= 5 &&
        t.splice(e + 1, i - e, {
          name: "div",
          attrs: {},
          children: t.slice(e + 1, i + 1),
        }),
      (i = e - 1));
}
function d(t) {
  (this.options = t || {}),
    (this.tagStyle = Object.assign({}, i.tagStyle, this.options.tagStyle)),
    (this.imgList = t.imgList || []),
    (this.imgList._unloadimgs = 0),
    (this.plugins = t.plugins || []),
    (this.attrs = Object.create(null)),
    (this.stack = []),
    (this.nodes = []),
    (this.pre =
      (this.options.containerStyle || "").includes("white-space") &&
      this.options.containerStyle.includes("pre")
        ? 2
        : 0);
}
function p(t) {
  this.handler = t;
}
(d.prototype.parse = function (t) {
  for (var e = this.plugins.length; e--; )
    this.plugins[e].onUpdate && (t = this.plugins[e].onUpdate(t, i) || t);
  for (new p(this).parse(t); this.stack.length; ) this.popNode();
  return this.nodes.length > 50 && c(this.nodes), this.nodes;
}),
  (d.prototype.expose = function () {
    for (var t = this.stack.length; t--; ) {
      var i = this.stack[t];
      if (i.c || "a" === i.name || "video" === i.name || "audio" === i.name)
        return;
      i.c = 1;
    }
  }),
  (d.prototype.hook = function (t) {
    for (var i = this.plugins.length; i--; )
      if (this.plugins[i].onParse && !1 === this.plugins[i].onParse(t, this))
        return !1;
    return !0;
  }),
  (d.prototype.getUrl = function (t) {
    var i = this.options.domain;
    return (
      "/" === t[0]
        ? "/" === t[1]
          ? (t = (i ? i.split("://")[0] : "http") + ":" + t)
          : i && (t = i + t)
        : t.includes("data:") || t.includes("://") || (i && (t = i + "/" + t)),
      t
    );
  }),
  (d.prototype.parseStyle = function (t) {
    var i = t.attrs,
      e = (this.tagStyle[t.name] || "")
        .split(";")
        .concat((i.style || "").split(";")),
      s = {},
      n = "";
    i.id &&
      !this.xml &&
      (this.options.useAnchor
        ? this.expose()
        : "img" !== t.name &&
          "a" !== t.name &&
          "video" !== t.name &&
          "audio" !== t.name &&
          (i.id = void 0)),
      i.width &&
        ((s.width = parseFloat(i.width) + (i.width.includes("%") ? "%" : "px")),
        (i.width = void 0)),
      i.height &&
        ((s.height =
          parseFloat(i.height) + (i.height.includes("%") ? "%" : "px")),
        (i.height = void 0));
    for (var o = 0, l = e.length; o < l; o++) {
      var h = e[o].split(":");
      if (!(h.length < 2)) {
        var c = h.shift().trim().toLowerCase(),
          d = h.join(":").trim();
        if (("-" === d[0] && d.lastIndexOf("-") > 0) || d.includes("safe"))
          n += ";".concat(c, ":").concat(d);
        else if (!s[c] || d.includes("import") || !s[c].includes("import")) {
          if (d.includes("url")) {
            var p = d.indexOf("(") + 1;
            if (p) {
              for (; '"' === d[p] || "'" === d[p] || r[d[p]]; ) p++;
              d = d.substr(0, p) + this.getUrl(d.substr(p));
            }
          } else
            d.includes("rpx") &&
              (d = d.replace(/[0-9.]+\s*rpx/g, function (t) {
                return (parseFloat(t) * a) / 750 + "px";
              }));
          s[c] = d;
        }
      }
    }
    return (t.attrs.style = n), s;
  }),
  (d.prototype.onTagName = function (t) {
    (this.tagName = this.xml ? t : t.toLowerCase()),
      "svg" === this.tagName &&
        ((this.xml = (this.xml || 0) + 1), (i.ignoreTags.style = void 0));
  }),
  (d.prototype.onAttrName = function (t) {
    "data-" === (t = this.xml ? t : t.toLowerCase()).substr(0, 5)
      ? "data-src" !== t || this.attrs.src
        ? "img" === this.tagName || "a" === this.tagName
          ? (this.attrName = t)
          : (this.attrName = void 0)
        : (this.attrName = "src")
      : ((this.attrName = t), (this.attrs[t] = "T"));
  }),
  (d.prototype.onAttrVal = function (t) {
    var i = this.attrName || "";
    "style" === i || "href" === i
      ? (this.attrs[i] = h(t, !0))
      : i.includes("src")
      ? (this.attrs[i] = this.getUrl(h(t, !0)))
      : i && (this.attrs[i] = t);
  }),
  (d.prototype.onOpenTag = function (t) {
    var s = Object.create(null);
    (s.name = this.tagName),
      (s.attrs = this.attrs),
      this.options.nodes.length && (s.type = "node"),
      (this.attrs = Object.create(null));
    var n = s.attrs,
      r = this.stack[this.stack.length - 1],
      l = r ? r.children : this.nodes,
      h = this.xml ? t : i.voidTags[s.name];
    if (
      (e[s.name] && (n.class = e[s.name] + (n.class ? " " + n.class : "")),
      "embed" === s.name)
    ) {
      var c = n.src || "";
      c.includes(".mp4") ||
      c.includes(".3gp") ||
      c.includes(".m3u8") ||
      (n.type || "").includes("video")
        ? (s.name = "video")
        : (c.includes(".mp3") ||
            c.includes(".wav") ||
            c.includes(".aac") ||
            c.includes(".m4a") ||
            (n.type || "").includes("audio")) &&
          (s.name = "audio"),
        n.autostart && (n.autoplay = "T"),
        (n.controls = "T");
    }
    if (
      (("video" !== s.name && "audio" !== s.name) ||
        ("video" !== s.name || n.id || (n.id = "v" + o++),
        n.controls || n.autoplay || (n.controls = "T"),
        (s.src = []),
        n.src && (s.src.push(n.src), (n.src = void 0)),
        this.expose()),
      h)
    ) {
      if (!this.hook(s) || i.ignoreTags[s.name])
        return void ("base" !== s.name || this.options.domain
          ? "source" === s.name &&
            r &&
            ("video" === r.name || "audio" === r.name) &&
            n.src &&
            r.src.push(n.src)
          : (this.options.domain = n.href));
      var d = this.parseStyle(s);
      if ("img" === s.name) {
        if (
          n.src &&
          (n.src.includes("webp") && (s.webp = "T"),
          n.src.includes("data:") && !n["original-src"] && (n.ignore = "T"),
          !n.ignore || s.webp || n.src.includes("cloud://"))
        ) {
          for (var p = this.stack.length; p--; ) {
            var u = this.stack[p];
            "a" === u.name && (s.a = u.attrs),
              "table" !== u.name ||
                s.webp ||
                n.src.includes("cloud://") ||
                (!d.display || d.display.includes("inline")
                  ? (s.t = "inline-block")
                  : (s.t = d.display),
                (d.display = void 0));
            var g = u.attrs.style || "";
            if (
              !g.includes("flex:") ||
              g.includes("flex:0") ||
              g.includes("flex: 0") ||
              (d.width && !(parseInt(d.width) > 100))
            )
              if (g.includes("flex") && "100%" === d.width)
                for (var f = p + 1; f < this.stack.length; f++) {
                  var m = this.stack[f].attrs.style || "";
                  if (
                    !m.includes(";width") &&
                    !m.includes(" width") &&
                    0 !== m.indexOf("width")
                  ) {
                    d.width = "";
                    break;
                  }
                }
              else
                g.includes("inline-block") &&
                  (d.width && "%" === d.width[d.width.length - 1]
                    ? ((u.attrs.style += ";max-width:" + d.width),
                      (d.width = ""))
                    : (u.attrs.style += ";max-width:100%"));
            else {
              (d.width = "100% !important"), (d.height = "");
              for (var v = p + 1; v < this.stack.length; v++)
                this.stack[v].attrs.style = (
                  this.stack[v].attrs.style || ""
                ).replace("inline-", "");
            }
            u.c = 1;
          }
          n.i = this.imgList.length.toString();
          var y = n["original-src"] || n.src;
          if (this.imgList.includes(y)) {
            var b = y.indexOf("://");
            if (-1 !== b) {
              b += 3;
              for (var x = y.substr(0, b); b < y.length && "/" !== y[b]; b++)
                x += Math.random() > 0.5 ? y[b].toUpperCase() : y[b];
              (x += y.substr(b)), (y = x);
            }
          }
          this.imgList.push(y), s.t || (this.imgList._unloadimgs += 1);
        }
        "inline" === d.display && (d.display = ""),
          n.ignore &&
            ((d["max-width"] = d["max-width"] || "100%"),
            (n.style += ";-webkit-touch-callout:none")),
          parseInt(d.width) > a && (d.height = void 0),
          isNaN(parseInt(d.width)) || (s.w = "T"),
          !isNaN(parseInt(d.height)) &&
            (!d.height.includes("%") ||
              (r && (r.attrs.style || "").includes("height"))) &&
            (s.h = "T");
      } else if ("svg" === s.name)
        return l.push(s), this.stack.push(s), void this.popNode();
      for (var w in d)
        d[w] &&
          (n.style += ";"
            .concat(w, ":")
            .concat(d[w].replace(" !important", "")));
      (n.style = n.style.substr(1) || void 0), n.style || delete n.style;
    } else
      ("pre" === s.name ||
        ((n.style || "").includes("white-space") && n.style.includes("pre"))) &&
        2 !== this.pre &&
        (this.pre = s.pre = 1),
        (s.children = []),
        this.stack.push(s);
    l.push(s);
  }),
  (d.prototype.onCloseTag = function (t) {
    var i;
    for (
      t = this.xml ? t : t.toLowerCase(), i = this.stack.length;
      i-- && this.stack[i].name !== t;

    );
    if (-1 !== i) for (; this.stack.length > i; ) this.popNode();
    else if ("p" === t || "br" === t) {
      (this.stack.length
        ? this.stack[this.stack.length - 1].children
        : this.nodes
      ).push({
        name: t,
        attrs: { class: e[t] || "", style: this.tagStyle[t] || "" },
      });
    }
  }),
  (d.prototype.popNode = function () {
    var e = this.stack.pop(),
      s = e.attrs,
      n = e.children,
      r = this.stack[this.stack.length - 1],
      o = r ? r.children : this.nodes;
    if (!this.hook(e) || i.ignoreTags[e.name])
      return (
        "title" === e.name &&
          n.length &&
          "text" === n[0].type &&
          this.options.setTitle &&
          t.index.setNavigationBarTitle({ title: n[0].text }),
        void o.pop()
      );
    if (e.pre && 2 !== this.pre) {
      this.pre = e.pre = void 0;
      for (var l = this.stack.length; l--; )
        this.stack[l].pre && (this.pre = 1);
    }
    var h = {};
    if ("svg" === e.name) {
      if (this.xml > 1) return void this.xml--;
      var d = "",
        p = s.style;
      return (
        (s.style = ""),
        (s.xmlns = "http://www.w3.org/2000/svg"),
        (function t(e) {
          if ("text" !== e.type) {
            var s = i.svgDict[e.name] || e.name;
            for (var a in ((d += "<" + s), e.attrs)) {
              var n = e.attrs[a];
              n && (d += " ".concat(i.svgDict[a] || a, '="').concat(n, '"'));
            }
            if (e.children) {
              d += ">";
              for (var r = 0; r < e.children.length; r++) t(e.children[r]);
              d += "</" + s + ">";
            } else d += "/>";
          } else d += e.text;
        })(e),
        (e.name = "img"),
        (e.attrs = {
          src: "data:image/svg+xml;utf8," + d.replace(/#/g, "%23"),
          style: p,
          ignore: "T",
        }),
        (e.children = void 0),
        (this.xml = !1),
        void (i.ignoreTags.style = !0)
      );
    }
    if (
      (s.align &&
        ("table" === e.name
          ? "center" === s.align
            ? (h["margin-inline-start"] = h["margin-inline-end"] = "auto")
            : (h.float = s.align)
          : (h["text-align"] = s.align),
        (s.align = void 0)),
      s.dir && ((h.direction = s.dir), (s.dir = void 0)),
      "font" === e.name &&
        (s.color && ((h.color = s.color), (s.color = void 0)),
        s.face && ((h["font-family"] = s.face), (s.face = void 0)),
        s.size))
    ) {
      var u = parseInt(s.size);
      isNaN(u) ||
        (u < 1 ? (u = 1) : u > 7 && (u = 7),
        (h["font-size"] = [
          "x-small",
          "small",
          "medium",
          "large",
          "x-large",
          "xx-large",
          "xxx-large",
        ][u - 1])),
        (s.size = void 0);
    }
    if (
      ((s.class || "").includes("align-center") && (h["text-align"] = "center"),
      Object.assign(h, this.parseStyle(e)),
      "table" !== e.name &&
        parseInt(h.width) > a &&
        ((h["max-width"] = "100%"), (h["box-sizing"] = "border-box")),
      i.blockTags[e.name]
        ? (e.name = "div")
        : i.trustTags[e.name] || this.xml || (e.name = "span"),
      "a" === e.name || "ad" === e.name)
    )
      this.expose();
    else if ("video" === e.name)
      (h.height || "").includes("auto") && (h.height = void 0);
    else if (("ul" !== e.name && "ol" !== e.name) || !e.c) {
      if ("table" === e.name) {
        var g = parseFloat(s.cellpadding),
          f = parseFloat(s.cellspacing),
          m = parseFloat(s.border),
          v = h["border-color"],
          y = h["border-style"];
        if (
          (e.c && (isNaN(g) && (g = 2), isNaN(f) && (f = 2)),
          m &&
            (s.style += ";border:"
              .concat(m, "px ")
              .concat(y || "solid", " ")
              .concat(v || "gray")),
          e.flag && e.c)
        ) {
          (h.display = "grid"),
            f
              ? ((h["grid-gap"] = f + "px"), (h.padding = f + "px"))
              : m && (s.style += ";border-left:0;border-top:0");
          var b = [],
            x = [],
            w = [],
            k = {};
          !(function t(i) {
            for (var e = 0; e < i.length; e++)
              "tr" === i[e].name ? x.push(i[e]) : t(i[e].children || []);
          })(n);
          for (var N = 1; N <= x.length; N++) {
            for (var T = 1, O = 0; O < x[N - 1].children.length; O++) {
              var C = x[N - 1].children[O];
              if ("td" === C.name || "th" === C.name) {
                for (; k[N + "." + T]; ) T++;
                var S = C.attrs.style || "",
                  I = S.indexOf("width") ? S.indexOf(";width") : 0;
                if (-1 !== I) {
                  var A = S.indexOf(";", I + 6);
                  -1 === A && (A = S.length),
                    C.attrs.colspan || (b[T] = S.substring(I ? I + 7 : 6, A)),
                    (S = S.substr(0, I) + S.substr(A));
                }
                if (
                  -1 !== (I = (S += ";display:flex").indexOf("vertical-align"))
                ) {
                  var j = S.substr(I + 15, 10);
                  j.includes("middle")
                    ? (S += ";align-items:center")
                    : j.includes("bottom") && (S += ";align-items:flex-end");
                } else S += ";align-items:center";
                if (-1 !== (I = S.indexOf("text-align"))) {
                  var L = S.substr(I + 11, 10);
                  L.includes("center")
                    ? (S += ";justify-content: center")
                    : L.includes("right") && (S += ";justify-content: right");
                }
                if (
                  ((S =
                    (m
                      ? ";border:"
                          .concat(m, "px ")
                          .concat(y || "solid", " ")
                          .concat(v || "gray") +
                        (f ? "" : ";border-right:0;border-bottom:0")
                      : "") +
                    (g ? ";padding:".concat(g, "px") : "") +
                    ";" +
                    S),
                  C.attrs.colspan &&
                    ((S += ";grid-column-start:"
                      .concat(T, ";grid-column-end:")
                      .concat(T + parseInt(C.attrs.colspan))),
                    C.attrs.rowspan ||
                      (S += ";grid-row-start:"
                        .concat(N, ";grid-row-end:")
                        .concat(N + 1)),
                    (T += parseInt(C.attrs.colspan) - 1)),
                  C.attrs.rowspan)
                ) {
                  (S += ";grid-row-start:"
                    .concat(N, ";grid-row-end:")
                    .concat(N + parseInt(C.attrs.rowspan))),
                    C.attrs.colspan ||
                      (S += ";grid-column-start:"
                        .concat(T, ";grid-column-end:")
                        .concat(T + 1));
                  for (var q = 1; q < C.attrs.rowspan; q++)
                    for (var z = 0; z < (C.attrs.colspan || 1); z++)
                      k[N + q + "." + (T - z)] = 1;
                }
                S && (C.attrs.style = S), w.push(C), T++;
              }
            }
            if (1 === N) {
              for (var F = "", U = 1; U < T; U++)
                F += (b[U] ? b[U] : "auto") + " ";
              h["grid-template-columns"] = F;
            }
          }
          e.children = w;
        } else
          e.c && (h.display = "table"),
            isNaN(f) || (h["border-spacing"] = f + "px"),
            (m || g) &&
              (function t(i) {
                for (var e = 0; e < i.length; e++) {
                  var s = i[e];
                  "th" === s.name || "td" === s.name
                    ? (m &&
                        (s.attrs.style = "border:"
                          .concat(m, "px ")
                          .concat(y || "solid", " ")
                          .concat(v || "gray", ";")
                          .concat(s.attrs.style || "")),
                      g &&
                        (s.attrs.style = "padding:"
                          .concat(g, "px;")
                          .concat(s.attrs.style || "")))
                    : s.children && t(s.children);
                }
              })(n);
        if (this.options.scrollTable && !(s.style || "").includes("inline")) {
          var V = Object.assign({}, e);
          (e.name = "div"),
            (e.attrs = { style: "overflow:auto" }),
            (e.children = [V]),
            (s = V.attrs);
        }
      } else if (
        ("td" !== e.name && "th" !== e.name) ||
        (!s.colspan && !s.rowspan)
      )
        if ("ruby" === e.name) {
          e.name = "span";
          for (var D = 0; D < n.length - 1; D++)
            "text" === n[D].type &&
              "rt" === n[D + 1].name &&
              ((n[D] = {
                name: "div",
                attrs: { style: "display:inline-block;text-align:center" },
                children: [
                  {
                    name: "div",
                    attrs: {
                      style: "font-size:50%;" + (n[D + 1].attrs.style || ""),
                    },
                    children: n[D + 1].children,
                  },
                  n[D],
                ],
              }),
              n.splice(D + 1, 1));
        } else
          e.c &&
            (function t(e) {
              e.c = 2;
              for (var s = e.children.length; s--; ) {
                var a = e.children[s];
                a.name &&
                  (i.inlineTags[a.name] ||
                    ((a.attrs.style || "").includes("inline") && a.children)) &&
                  !a.c &&
                  t(a),
                  (a.c && "table" !== a.name) || (e.c = 1);
              }
            })(e);
      else
        for (var P = this.stack.length; P--; )
          if ("table" === this.stack[P].name) {
            this.stack[P].flag = 1;
            break;
          }
    } else {
      var B = {
        a: "lower-alpha",
        A: "upper-alpha",
        i: "lower-roman",
        I: "upper-roman",
      };
      B[s.type] &&
        ((s.style += ";list-style-type:" + B[s.type]), (s.type = void 0));
      for (var Z = n.length; Z--; ) "li" === n[Z].name && (n[Z].c = 1);
    }
    if ((h.display || "").includes("flex") && !e.c)
      for (var _ = n.length; _--; ) {
        var G = n[_];
        G.f && ((G.attrs.style = (G.attrs.style || "") + G.f), (G.f = void 0));
      }
    var M =
      r &&
      ((r.attrs.style || "").includes("flex") ||
        (r.attrs.style || "").includes("grid")) &&
      !(e.c && t.wx$1.getNFCAdapter);
    for (var W in (M && (e.f = ";max-width:100%"),
    n.length >= 50 && e.c && !(h.display || "").includes("flex") && c(n),
    h))
      if (h[W]) {
        var $ = ";".concat(W, ":").concat(h[W].replace(" !important", ""));
        M &&
        ((W.includes("flex") && "flex-direction" !== W) ||
          "align-self" === W ||
          W.includes("grid") ||
          "-" === h[W][0] ||
          (W.includes("width") && $.includes("%")))
          ? ((e.f += $), "width" === W && (s.style += ";width:100%"))
          : (s.style += $);
      }
    for (var E in ((s.style = s.style.substr(1) || void 0), s))
      s[E] || delete s[E];
  }),
  (d.prototype.onText = function (i) {
    if (!this.pre) {
      for (var e, s = "", a = 0, o = i.length; a < o; a++)
        r[i[a]]
          ? (" " !== s[s.length - 1] && (s += " "),
            "\n" !== i[a] || e || (e = !0))
          : (s += i[a]);
      if (" " === s) {
        if (e) return;
        var l = this.stack[this.stack.length - 1];
        if (l && "t" === l.name[0]) return;
      }
      i = s;
    }
    var c = Object.create(null);
    ((c.type = "text"), (c.text = h(i)), this.hook(c)) &&
      ("force" === this.options.selectable &&
        n.includes("iOS") &&
        !t.index.canIUse("rich-text.user-select") &&
        this.expose(),
      (this.stack.length
        ? this.stack[this.stack.length - 1].children
        : this.nodes
      ).push(c));
  }),
  (p.prototype.parse = function (t) {
    (this.content = t || ""),
      (this.i = 0),
      (this.start = 0),
      (this.state = this.text);
    for (var i = this.content.length; -1 !== this.i && this.i < i; )
      this.state();
  }),
  (p.prototype.checkClose = function (t) {
    var i = "/" === this.content[this.i];
    return (
      !!(
        ">" === this.content[this.i] ||
        (i && ">" === this.content[this.i + 1])
      ) &&
      (t && this.handler[t](this.content.substring(this.start, this.i)),
      (this.i += i ? 2 : 1),
      (this.start = this.i),
      this.handler.onOpenTag(i),
      "script" === this.handler.tagName
        ? ((this.i = this.content.indexOf("</", this.i)),
          -1 !== this.i && ((this.i += 2), (this.start = this.i)),
          (this.state = this.endTag))
        : (this.state = this.text),
      !0)
    );
  }),
  (p.prototype.text = function () {
    if (((this.i = this.content.indexOf("<", this.i)), -1 !== this.i)) {
      var t = this.content[this.i + 1];
      if ((t >= "a" && t <= "z") || (t >= "A" && t <= "Z"))
        this.start !== this.i &&
          this.handler.onText(this.content.substring(this.start, this.i)),
          (this.start = ++this.i),
          (this.state = this.tagName);
      else if ("/" === t || "!" === t || "?" === t) {
        this.start !== this.i &&
          this.handler.onText(this.content.substring(this.start, this.i));
        var i = this.content[this.i + 2];
        if ("/" === t && ((i >= "a" && i <= "z") || (i >= "A" && i <= "Z")))
          return (
            (this.i += 2),
            (this.start = this.i),
            void (this.state = this.endTag)
          );
        var e = "--\x3e";
        ("!" === t &&
          "-" === this.content[this.i + 2] &&
          "-" === this.content[this.i + 3]) ||
          (e = ">"),
          (this.i = this.content.indexOf(e, this.i)),
          -1 !== this.i && ((this.i += e.length), (this.start = this.i));
      } else this.i++;
    } else
      this.start < this.content.length &&
        this.handler.onText(
          this.content.substring(this.start, this.content.length)
        );
  }),
  (p.prototype.tagName = function () {
    if (r[this.content[this.i]]) {
      for (
        this.handler.onTagName(this.content.substring(this.start, this.i));
        r[this.content[++this.i]];

      );
      this.i < this.content.length &&
        !this.checkClose() &&
        ((this.start = this.i), (this.state = this.attrName));
    } else this.checkClose("onTagName") || this.i++;
  }),
  (p.prototype.attrName = function () {
    var t = this.content[this.i];
    if (r[t] || "=" === t) {
      this.handler.onAttrName(this.content.substring(this.start, this.i));
      for (var i = "=" === t, e = this.content.length; ++this.i < e; )
        if (((t = this.content[this.i]), !r[t])) {
          if (this.checkClose()) return;
          if (i) return (this.start = this.i), void (this.state = this.attrVal);
          if ("=" !== this.content[this.i])
            return (this.start = this.i), void (this.state = this.attrName);
          i = !0;
        }
    } else this.checkClose("onAttrName") || this.i++;
  }),
  (p.prototype.attrVal = function () {
    var t = this.content[this.i],
      i = this.content.length;
    if ('"' === t || "'" === t) {
      if (
        ((this.start = ++this.i),
        (this.i = this.content.indexOf(t, this.i)),
        -1 === this.i)
      )
        return;
      this.handler.onAttrVal(this.content.substring(this.start, this.i));
    } else
      for (; this.i < i; this.i++) {
        if (r[this.content[this.i]]) {
          this.handler.onAttrVal(this.content.substring(this.start, this.i));
          break;
        }
        if (this.checkClose("onAttrVal")) return;
      }
    for (; r[this.content[++this.i]]; );
    this.i < i &&
      !this.checkClose() &&
      ((this.start = this.i), (this.state = this.attrName));
  }),
  (p.prototype.endTag = function () {
    var t = this.content[this.i];
    if (r[t] || ">" === t || "/" === t) {
      if (
        (this.handler.onCloseTag(this.content.substring(this.start, this.i)),
        ">" !== t &&
          ((this.i = this.content.indexOf(">", this.i)), -1 === this.i))
      )
        return;
      (this.start = ++this.i), (this.state = this.text);
    } else this.i++;
  }),
  (exports.Parser = d);
