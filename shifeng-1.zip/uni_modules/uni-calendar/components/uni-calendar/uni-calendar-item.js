var e = require("../../../../common/vendor.js"),
  a = require("./i18n/index.js"),
  t = e.initVueI18n(a.i18nMessages).t,
  l = {
    emits: ["change"],
    props: {
      weeks: {
        type: Object,
        default: function () {
          return {};
        },
      },
      calendar: {
        type: Object,
        default: function () {
          return {};
        },
      },
      selected: {
        type: Array,
        default: function () {
          return [];
        },
      },
      lunar: { type: Boolean, default: !1 },
    },
    computed: {
      todayText: function () {
        return t("uni-calender.today");
      },
    },
    methods: {
      choiceDate: function (e) {
        this.$emit("change", e);
      },
    },
  };
var s = e._export_sfc(l, [
  [
    "render",
    function (a, t, l, s, n, r) {
      return e.e(
        { a: l.selected && l.weeks.extraInfo },
        (l.selected && l.weeks.extraInfo, {}),
        {
          b: e.t(l.weeks.date),
          c: l.weeks.isDay ? 1 : "",
          d: l.calendar.fullDate === l.weeks.fullDate && l.weeks.isDay ? 1 : "",
          e: l.calendar.fullDate !== l.weeks.fullDate || l.weeks.isDay ? "" : 1,
          f: l.weeks.beforeMultiple ? 1 : "",
          g: l.weeks.multiple ? 1 : "",
          h: l.weeks.afterMultiple ? 1 : "",
          i: l.weeks.disable ? 1 : "",
          j: l.lunar && !l.weeks.extraInfo,
        },
        l.lunar && !l.weeks.extraInfo
          ? {
              k: e.t(
                l.weeks.isDay
                  ? r.todayText
                  : "初一" === l.weeks.lunar.IDayCn
                  ? l.weeks.lunar.IMonthCn
                  : l.weeks.lunar.IDayCn
              ),
              l: l.weeks.isDay ? 1 : "",
              m:
                l.calendar.fullDate === l.weeks.fullDate && l.weeks.isDay
                  ? 1
                  : "",
              n:
                l.calendar.fullDate !== l.weeks.fullDate || l.weeks.isDay
                  ? ""
                  : 1,
              o: l.weeks.beforeMultiple ? 1 : "",
              p: l.weeks.multiple ? 1 : "",
              q: l.weeks.afterMultiple ? 1 : "",
              r: l.weeks.disable ? 1 : "",
            }
          : {},
        { s: l.weeks.extraInfo && l.weeks.extraInfo.info },
        l.weeks.extraInfo && l.weeks.extraInfo.info
          ? {
              t: e.t(l.weeks.extraInfo.info),
              v: l.weeks.extraInfo.info ? 1 : "",
              w: l.weeks.isDay ? 1 : "",
              x:
                l.calendar.fullDate === l.weeks.fullDate && l.weeks.isDay
                  ? 1
                  : "",
              y:
                l.calendar.fullDate !== l.weeks.fullDate || l.weeks.isDay
                  ? ""
                  : 1,
              z: l.weeks.beforeMultiple ? 1 : "",
              A: l.weeks.multiple ? 1 : "",
              B: l.weeks.afterMultiple ? 1 : "",
              C: l.weeks.disable ? 1 : "",
            }
          : {},
        {
          D: l.weeks.disable ? 1 : "",
          E: l.calendar.fullDate === l.weeks.fullDate && l.weeks.isDay ? 1 : "",
          F: l.calendar.fullDate !== l.weeks.fullDate || l.weeks.isDay ? "" : 1,
          G: l.weeks.beforeMultiple ? 1 : "",
          H: l.weeks.multiple ? 1 : "",
          I: l.weeks.afterMultiple ? 1 : "",
          J: e.o(function (e) {
            return r.choiceDate(l.weeks);
          }),
        }
      );
    },
  ],
  ["__scopeId", "data-v-aa793075"],
]);
wx.createComponent(s);
