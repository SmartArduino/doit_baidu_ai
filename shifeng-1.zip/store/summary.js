var r = require("../common/vendor.js").defineStore("summaryStore", {
  state: function () {
    return { summary: {} };
  },
  actions: {
    setSummary: function (r) {
      this.summary = r;
    },
  },
  getters: {},
});
exports.useSummaryStore = r;
