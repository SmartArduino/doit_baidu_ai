var e = require("../@babel/runtime/helpers/objectSpread2"),
  n = require("../common/vendor.js"),
  r = n.defineStore("profile", {
    state: function () {
      return { child: null, lang: "ZH_CN" };
    },
    getters: {},
    actions: {
      changeChild: function (n) {
        this.child = e({}, n);
      },
      changeLang: function (e) {
        this.lang = e;
      },
    },
  });
exports.useProfileStore = r;
