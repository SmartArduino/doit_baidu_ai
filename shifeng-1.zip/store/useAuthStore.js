var e = require("../common/vendor.js"),
  u = e.defineStore("auth", function () {
    var u = e.ref(null),
      t = e.ref(null),
      n = e.ref(!1);
    function r() {
      (u.value = null), (t.value = null), (n.value = !1);
    }
    return {
      token: u,
      user: t,
      isAuthenticated: n,
      setToken: function (e) {
        (u.value = e), (n.value = !!e);
      },
      setUser: function (e) {
        t.value = e;
      },
      clearAuth: r,
      logout: function () {
        r(), e.index.removeStorageSync("auth-storage");
      },
    };
  });
exports.useAuthStore = u;
