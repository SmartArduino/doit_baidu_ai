var e = require("../common/vendor.js"),
  t = e.index.getAccountInfoSync().miniProgram.envVersion + "-deviceStore";
var i = e.defineStore("deviceStore", {
  state: function () {
    var i = (function () {
      try {
        var i = e.index.getStorageSync(t);
        if (i) return JSON.parse(i);
      } catch (e) {}
      return {};
    })();
    return {
      deviceSetting: i.deviceSetting || {
        volume: 0,
        brightness: 0,
        electricity: 0,
        customPrompt: -1,
        chatMode: -1,
        hasRemoteControl: -1,
        hasLetterControl: -1,
        hasCoding: -1,
      },
      devices: i.devices || [],
      deviceDetail: i.deviceDetail || null,
      device: i.device || null,
      versions: i.versions || [],
      product: i.product || { productImg: "", productName: "", sn: "" },
      commandList: i.commandList || [],
    };
  },
  actions: {
    setDeviceSetting: function (e) {
      (this.deviceSetting = e), this.saveToLocal();
    },
    setDevices: function (e) {
      (this.devices = e), this.saveToLocal();
    },
    setDeviceDetail: function (e) {
      (this.deviceDetail = e), this.saveToLocal();
    },
    setDevice: function (e) {
      (this.device = e), this.saveToLocal();
    },
    setVersions: function (e) {
      (this.versions = e), this.saveToLocal();
    },
    setProduct: function (e) {
      (this.product = e), this.saveToLocal();
    },
    setCommandList: function (e) {
      (this.commandList = e), this.saveToLocal();
    },
    saveToLocal: function () {
      e.index.setStorageSync(
        t,
        JSON.stringify({
          deviceSetting: this.deviceSetting,
          devices: this.devices,
          deviceDetail: this.deviceDetail,
          device: this.device,
          versions: this.versions,
          product: this.product,
          commandList: this.commandList,
        })
      );
    },
  },
});
exports.useDeviceStore = i;
