var t = require("../common/vendor.js"),
  e = t.defineStore("home", {
    state: function () {
      var e = t.dayjs().subtract(1, "day");
      return {
        date: e.format("YYYY-MM-DD"),
        month: e.format("YYYY-MM"),
        deviceId: "1",
        tab: "report",
      };
    },
    getters: {},
    actions: {
      changeDate: function (t) {
        this.date = t;
      },
      changeMonth: function (t) {
        this.month = t;
      },
      changeTab: function (t) {
        this.tab = t;
      },
    },
  });
exports.useHomeStore = e;
