var t = require("../common/vendor.js").defineStore("modalStatus", {
  state: function () {
    return { modalStatus: !1 };
  },
  actions: {
    setStatus: function (t) {
      this.modalStatus = t;
    },
  },
});
exports.useModalStatus = t;
