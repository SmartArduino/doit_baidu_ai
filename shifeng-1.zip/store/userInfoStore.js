var e = require("../common/vendor.js"),
  r = e.defineStore("userInfo", function () {
    var r = e.ref(null);
    return {
      userInfo: r,
      setUserInfo: function (e) {
        r.value = e;
      },
    };
  });
exports.useUserInfoStore = r;
