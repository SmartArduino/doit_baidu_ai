var e = require("../common/vendor.js"),
  o = e.defineStore("role", function () {
    var o = e.ref([]),
      r = e.ref(null),
      l = e.ref("");
    return {
      roleList: o,
      roleInfo: r,
      roleDetailPageHeader: l,
      setRoleList: function (e) {
        o.value = e;
      },
      setRole: function (e) {
        r.value = e;
      },
      clearRole: function () {
        r.value = null;
      },
      setRoleDetailPageHeader: function (e) {
        l.value = e;
      },
    };
  });
exports.useRoleStore = o;
