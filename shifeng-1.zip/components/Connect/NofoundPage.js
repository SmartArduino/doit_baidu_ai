var e = require("../../@babel/runtime/helpers/defineProperty"),
  t = require("../../common/vendor.js");
Math || r();
var r = function () {
    return "../MyButton/MyButton.js";
  },
  n = t.defineComponent({
    __name: "NofoundPage",
    emits: ["retry"],
    setup: function (r, n) {
      var o = n.emit,
        u = function () {
          o("retry");
        };
      return function (r, n) {
        return {
          a: t.o(u),
          b: t.p(
            e(
              e(e({ label: "重试" }, "button-width", 100), "button-height", 44),
              "border-radius",
              10
            )
          ),
        };
      };
    },
  }),
  o = t._export_sfc(n, [["__scopeId", "data-v-373c44ef"]]);
wx.createComponent(o);
