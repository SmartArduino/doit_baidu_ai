var e = require("../../@babel/runtime/helpers/defineProperty"),
  t = require("../../common/vendor.js");
Math || n();
var n = function () {
    return "../MyButton/MyButton.js";
  },
  o = t.defineComponent({
    __name: "BlueToothConnected",
    props: { deviceInfo: {} },
    emits: ["setStep"],
    setup: function (n, o) {
      var r = o.emit,
        u = function () {
          r("setStep", 6);
        };
      return function (n, o) {
        var r;
        return {
          a: null == (r = n.deviceInfo) ? void 0 : r.productImg,
          b: t.t(n.deviceInfo.sn),
          c: t.o(u),
          d: t.p(
            e(
              e(
                e({ label: "开始配网" }, "button-width", 157),
                "button-height",
                44
              ),
              "border-radius",
              10
            )
          ),
        };
      };
    },
  }),
  r = t._export_sfc(o, [["__scopeId", "data-v-b7fd4647"]]);
wx.createComponent(r);
