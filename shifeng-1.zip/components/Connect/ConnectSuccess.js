var e = require("../../@babel/runtime/helpers/defineProperty"),
  t = require("../../common/vendor.js");
Math || n();
var n = function () {
    return "../MyButton/MyButton.js";
  },
  o = t.defineComponent({
    __name: "ConnectSuccess",
    props: { wifiName: {}, successText: { default: "" } },
    emits: ["goHome"],
    setup: function (n, o) {
      var u = o.emit,
        r = function () {
          u("goHome");
        },
        i = t.ref({ navHeight: 0, statusBarHeight: 0, buttonMargin: 0 }),
        a = t.ref(""),
        s = t.ref("");
      return (
        t.onLoad(function (e) {
          var n = t.index.getMenuButtonBoundingClientRect(),
            o = n.top,
            u = n.height;
          (a.value = null == e ? void 0 : e.pageSource),
            (s.value = (null == e ? void 0 : e.sn) || ""),
            console.log("option", e),
            t.index.getSystemInfo({
              success: function (e) {
                var t = e.statusBarHeight,
                  n = o - t;
                (i.value.navHeight = u),
                  (i.value.statusBarHeight = t),
                  (i.value.buttonMargin = n);
              },
            });
        }),
        function (n, o) {
          return {
            a: t.t(n.wifiName),
            b: t.t(n.successText),
            c: t.o(r),
            d: t.p(
              e(
                e(
                  e(
                    e(
                      e(
                        e({ label: "完成" }, "background-color", "#00D550"),
                        "button-width",
                        304
                      ),
                      "button-height",
                      44
                    ),
                    "border-radius",
                    10
                  ),
                  "font-color",
                  "#FFFFFF"
                ),
                "font-size",
                17
              )
            ),
          };
        }
      );
    },
  }),
  u = t._export_sfc(o, [["__scopeId", "data-v-932c982d"]]);
wx.createComponent(u);
