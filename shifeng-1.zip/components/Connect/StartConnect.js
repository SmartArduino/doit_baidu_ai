var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  u = require("../../common/vendor.js"),
  r = require("../../common/assets.js"),
  t = require("../../api/index.js"),
  a = u.defineComponent({
    __name: "StartConnect",
    emits: ["setStep"],
    setup: function (a, o) {
      var l = o.emit,
        i = u.ref(!1),
        v = u.ref({ name: "", products: [] });
      u.onShow(
        n(
          e().mark(function n() {
            var r, a, o, l, d, s;
            return e().wrap(
              function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (
                        (e.prev = 0),
                        (o = u.index.getAccountInfoSync().miniProgram.appId),
                        (e.next = 4),
                        t.manufacturerNetworkTips(o)
                      );
                    case 4:
                      (l = e.sent),
                        "A00000" === (d = l.data).resultCode &&
                          ((i.value = !0),
                          (s =
                            null == (r = null == d ? void 0 : d.data)
                              ? void 0
                              : r.products.filter(function (e) {
                                  return e.img;
                                })),
                          (v.value = {
                            name:
                              null == (a = null == d ? void 0 : d.data)
                                ? void 0
                                : a.name,
                            products: s,
                          }),
                          (c.value = s.map(function (e) {
                            return { name: e.name };
                          }))),
                        (e.next = 12);
                      break;
                    case 9:
                      (e.prev = 9), (e.t0 = e.catch(0)), (i.value = !0);
                    case 12:
                    case "end":
                      return e.stop();
                  }
              },
              n,
              null,
              [[0, 9]]
            );
          })
        )
      );
      var c = u.ref([]),
        d = u.ref(0);
      u.computed(function () {
        return c.value[d.value];
      });
      var s = l,
        p = function () {
          s("setStep", 9);
        },
        m = function () {
          u.index.navigateTo({ url: "/pages/notFindPage/index" });
        };
      return function (e, n) {
        var t, a, o, l, s, f, g, x, _, b, h, w;
        return u.e(
          {
            a: u.f(c.value, function (e, n, r) {
              return {
                a: u.t(e.name),
                b: n === d.value ? 1 : "",
                c: e.id,
                d: n === d.value ? 1 : "",
                e: u.o(function (e) {
                  return (function (e) {
                    d.value = e;
                  })(n);
                }, e.id),
              };
            }),
            b:
              (null ==
              (a = null == (t = v.value) ? void 0 : t.products[d.value])
                ? void 0
                : a.img) && i.value,
          },
          (null == (l = null == (o = v.value) ? void 0 : o.products[d.value])
            ? void 0
            : l.img) && i.value
            ? {
                c: u.t(
                  null ==
                    (f = null == (s = v.value) ? void 0 : s.products[d.value])
                    ? void 0
                    : f.networkTips
                ),
                d:
                  null ==
                  (x = null == (g = v.value) ? void 0 : g.products[d.value])
                    ? void 0
                    : x.img,
              }
            : {},
          {
            e:
              i.value &&
              !(null ==
              (b = null == (_ = v.value) ? void 0 : _.products[d.value])
                ? void 0
                : b.img),
          },
          i.value &&
            !(null == (w = null == (h = v.value) ? void 0 : h.products[d.value])
              ? void 0
              : w.img)
            ? { f: r._imports_2$1 }
            : {},
          { g: u.o(p), h: u.o(m) }
        );
      };
    },
  }),
  o = u._export_sfc(a, [["__scopeId", "data-v-4546075c"]]);
wx.createComponent(o);
