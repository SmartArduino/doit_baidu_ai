var e = require("../../@babel/runtime/helpers/defineProperty"),
  t = require("../../common/vendor.js");
Math || r();
var r = function () {
    return "../MyButton/MyButton.js";
  },
  n = t.defineComponent({
    __name: "Failure",
    setup: function (r) {
      var n = t.ref(!0),
        u = function () {
          n.value = !1;
        };
      return function (r, o) {
        return t.e(
          { a: n.value },
          n.value
            ? {
                b: t.o(u),
                c: t.p(
                  e(
                    e(
                      e({ label: "确定" }, "button-width", 130),
                      "button-height",
                      44
                    ),
                    "border-radius",
                    10
                  )
                ),
              }
            : {}
        );
      };
    },
  }),
  u = t._export_sfc(n, [["__scopeId", "data-v-22bd0f4f"]]);
wx.createComponent(u);
