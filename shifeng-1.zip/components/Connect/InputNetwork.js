var e = require("../../@babel/runtime/helpers/defineProperty"),
  n = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  t = require("../../@babel/runtime/helpers/objectSpread2"),
  i = require("../../@babel/runtime/helpers/asyncToGenerator"),
  a = require("../../@babel/runtime/helpers/toConsumableArray"),
  u = require("../../common/vendor.js"),
  s = require("../../common/assets.js"),
  r = require("../../tools/base64.js");
Array || u.resolveComponent("uni-load-more")();
Math ||
  (
    function () {
      return "../../uni_modules/uni-load-more/components/uni-load-more/uni-load-more.js";
    } + o
  )();
var o = function () {
    return "../MyButton/MyButton.js";
  },
  l = u.defineComponent({
    __name: "InputNetwork",
    props: { wifiList: {}, deviceInfo: {}, wifiListState: {}, connectFlag: {} },
    emits: ["reGetWifiList", "setNet"],
    setup: function (o, l) {
      var c,
        v = l.emit,
        d = o,
        f =
          (null == (c = u.index.getSystemInfoSync().safeAreaInsets)
            ? void 0
            : c.bottom) || 0,
        p = u.ref(""),
        m = u.ref(""),
        g = u.ref(!1),
        h = u.ref({ auth: 0, channel: 0, rssi: 0, ssid: "", bssid: "" }),
        b = u.ref(!0),
        w = u.ref("开始配网"),
        y = u.ref([]),
        S = u.ref(!0);
      u.watch(
        function () {
          return [d.wifiList, h.value];
        },
        function (e) {
          var n;
          console.log("newVal==============", e[0]);
          var t = a(e[0]);
          console.log("wifiListCopy", p);
          var i = e[0].filter(function (n) {
            var t, i;
            return (
              console.log(
                n.ssid,
                null == (t = e[1]) ? void 0 : t.ssid,
                "================="
              ),
              n.ssid === (null == (i = e[1]) ? void 0 : i.ssid)
            );
          });
          0 === i.length ||
            ((p.value = r.BASE64.decrypt(null == (n = e[1]) ? void 0 : n.ssid)),
            (g.value = 0 === i[0].auth)),
            (y.value = t),
            console.log("排序成功了～～～～～", t);
        },
        { immediate: !0, deep: !0 }
      ),
        u.watch(
          function () {
            return d.wifiListState;
          },
          function (e) {
            102 === e && (S.value = !0);
          }
        ),
        0 === d.connectFlag &&
          u.index.startWifi({
            success: function (e) {
              u.index.getConnectedWifi({
                success: function (e) {
                  console.log("wifi INfo", e),
                    (h.value.ssid = r.BASE64.encoder(e.wifi.SSID));
                },
                fail: function (e) {
                  console.log(e, 11111),
                    (h.value = {
                      auth: 0,
                      channel: 0,
                      rssi: 0,
                      ssid: "",
                      bssid: "",
                    });
                },
                complete: function () {},
              });
            },
          });
      var x = function (e) {
          b.value = e.detail.value;
        },
        _ = function (e) {
          console.log("handleInput", e),
            (h.value = {
              rssi: "",
              channel: "",
              auth: "",
              ssid: "",
              bssid: "",
            }),
            console.log("selectedWifi================", e.detail.value),
            (p.value = e.detail.value),
            I();
        },
        k = function () {
          (g.value = !g.value), g.value && (m.value = "");
        },
        q = v,
        A = function () {
          (y.value = []), (S.value = !1), q("reGetWifiList");
        },
        I = function () {
          return p.value.length > 0 &&
            ((g.value && "" === m.value) || (!g.value && m.value))
            ? "#00D550"
            : "#E5E5E5";
        };
      function j(e, n) {
        e && u.index.showToast({ icon: "none", title: e, duration: 2e3 });
      }
      var E = u.index.getAccountInfoSync(),
        L = u.ref(E.miniProgram.envVersion),
        B = u.ref(!1),
        W = (function () {
          var e = i(
            n().mark(function e() {
              var i;
              return n().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      if (
                        p.value.trim()
                          ? g.value || m.value || (j("请输入WiFi密码"), 0)
                          : (j("请输入WiFi名称"), 0)
                      ) {
                        e.next = 2;
                        break;
                      }
                      return e.abrupt("return");
                    case 2:
                      if (p.value && "联网中..." !== w.value) {
                        e.next = 4;
                        break;
                      }
                      return e.abrupt("return");
                    case 4:
                      (B.value = !0),
                        (w.value = "联网中..."),
                        (i = u.index.getStorageSync(L.value + "token")),
                        q(
                          "setNet",
                          t(
                            t({}, h.value),
                            {},
                            {
                              base64ssid: r.BASE64.encoder(p.value),
                              password: m.value,
                              accessToken: i,
                              ssid: p.value,
                            }
                          )
                        );
                    case 8:
                    case "end":
                      return e.stop();
                  }
              }, e);
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })();
      return (
        u.onLoad(function () {}),
        function (n, t) {
          return u.e(
            {
              a: u.o([
                function (e) {
                  return (p.value = e.detail.value);
                },
                _,
              ]),
              b: p.value,
              c: g.value,
              d: g.value ? 1 : "",
              e: m.value,
              f: u.o(function (e) {
                return (m.value = e.detail.value);
              }),
              g: g.value
                ? "/static/images/app/checked.png"
                : "/static/images/app/unchecked.png",
              h: u.o(k),
              i: 0 == n.connectFlag,
            },
            0 == n.connectFlag
              ? u.e(
                  { j: b.value, k: u.o(x), l: b.value },
                  b.value
                    ? u.e(
                        { m: S.value },
                        S.value ? { n: s._imports_0$15 } : {},
                        { o: S.value },
                        (S.value, {}),
                        { p: u.o(A), q: 0 === y.value.length },
                        0 === y.value.length
                          ? { r: u.p({ status: "loading" }) }
                          : {
                              s: u.f(y.value, function (e, n, t) {
                                return u.e(
                                  { a: h.value.ssid === e.ssid },
                                  h.value.ssid === e.ssid
                                    ? { b: s._imports_1$7 }
                                    : {},
                                  {
                                    c: u.t(u.unref(r.BASE64).decrypt(e.ssid)),
                                    d: h.value.ssid === e.ssid ? 1 : "",
                                    e: 0 !== e.auth,
                                  },
                                  0 !== e.auth ? { f: s._imports_2$8 } : {},
                                  {
                                    g:
                                      ((i = e.rssi),
                                      i > -50
                                        ? "/static/images/app/device/wifi3.png"
                                        : i > -75
                                        ? "/static/images/app/device/wifi2.png"
                                        : "/static/images/app/device/wifi1.png"),
                                    h: n,
                                    i: n === y.value.length - 1 ? 1 : "",
                                    j: u.o(function (n) {
                                      return (
                                        (t = e),
                                        (h.value = {
                                          auth: t.auth || 0,
                                          channel: t.channel || 0,
                                          rssi: t.rssi || 0,
                                          ssid: t.ssid || "",
                                          bssid: t.bssid || "",
                                        }),
                                        (p.value = r.BASE64.decrypt(t.ssid)),
                                        (m.value = ""),
                                        console.log(
                                          "item.auth~~~~~~~~~~~~~~~~",
                                          t.auth
                                        ),
                                        void (g.value = 0 === t.auth)
                                      );
                                      var t;
                                    }, n),
                                  }
                                );
                                var i;
                              }),
                            }
                      )
                    : {}
                )
              : {},
            {
              t: u.o(W),
              v: u.p(
                e(
                  e(
                    e(
                      e({ label: w.value }, "bg-color", I()),
                      "button-width",
                      343
                    ),
                    "button-height",
                    44
                  ),
                  "border-radius",
                  10
                )
              ),
              w: u.unref(f) + "px",
              x: B.value,
            },
            (B.value, {})
          );
        }
      );
    },
  }),
  c = u._export_sfc(l, [["__scopeId", "data-v-e6fc45f5"]]);
wx.createComponent(c);
