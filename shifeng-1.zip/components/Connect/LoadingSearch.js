var n = require("../../common/vendor.js"),
  a = n.defineComponent({
    __name: "LoadingSearch",
    setup: function (a) {
      var o = n.ref([]);
      return (
        n.onMounted(function () {
          for (var n = [], a = 0; a < 15; a++) {
            var t = Math.round(566 * Math.random()),
              r = Math.round(566 * Math.random()),
              e = 2 * Math.random() + 1.5,
              c = 3 * Math.random();
            n.push({
              style: {
                top: "".concat(t, "rpx"),
                left: "".concat(r, "rpx"),
                animationDuration: "".concat(e, "s"),
                animationDelay: "".concat(c, "s"),
              },
            });
          }
          o.value = n;
        }),
        function (n, a) {
          return {};
        }
      );
    },
  }),
  o = n._export_sfc(a, [["__scopeId", "data-v-e719841a"]]);
wx.createComponent(o);
