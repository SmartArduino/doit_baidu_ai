var e = require("../../common/vendor.js"),
  n = require("../../common/assets.js"),
  o = e.defineComponent({
    __name: "index",
    props: { productName: {} },
    setup: function (o) {
      function t() {
        console.log("handleCheck"),
          e.index.navigateTo({ url: "/pages/letterList/index" });
      }
      return function (o, r) {
        return { a: n._imports_0$16, b: e.t(o.productName), c: e.o(t) };
      };
    },
  }),
  t = e._export_sfc(o, [["__scopeId", "data-v-47ede556"]]);
wx.createComponent(t);
