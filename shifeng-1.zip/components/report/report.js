var i = require("../../@babel/runtime/helpers/defineProperty"),
  e = require("../../common/vendor.js"),
  n = require("../../common/assets.js"),
  t = require("../../store/summary.js"),
  s = require("../../api/index.js"),
  u = require("../../store/home.js"),
  l = require("../../store/deviceStore.js");
Array || e.resolveComponent("uni-popup")();
Math;
var r = e.defineComponent({
    __name: "report",
    props: {
      activeTab: { type: String, default: "" },
      selectedSn: { type: String, default: "" },
      date: { type: String, default: "" },
    },
    emits: ["closeCalendar", "popupChange", "loadDataFinish"],
    setup: function (r, o) {
      var a = o.expose,
        g = o.emit,
        v = u.useHomeStore(),
        m = e.ref(!1),
        d = e.ref(),
        f = t.useSummaryStore(),
        c = e.ref(e.dayjs().subtract(1, "day").format("YYYY-MM-DD")),
        h = e.ref(1);
      l.useDeviceStore();
      var y = e.computed(function () {
          var i, e, n, t, s, u, l;
          return (
            (null == (i = f.summary) ? void 0 : i.emotionType) ||
            T.value.length > 0 ||
            (null ==
            (n = null == (e = f.summary) ? void 0 : e.insightPositiveMsgList)
              ? void 0
              : n.length) > 0 ||
            (null ==
            (s = null == (t = f.summary) ? void 0 : t.insightNegativeMsgList)
              ? void 0
              : s.length) > 0 ||
            (null ==
            (l = null == (u = f.summary) ? void 0 : u.insightNegativeMsgList)
              ? void 0
              : l.length) > 0
          );
        }),
        p = function (i) {
          L("popupChange", i.show);
        },
        L = g;
      e.onHide(function () {
        console.log("onHide"), v.changeDate(c.value);
      });
      var M = [
          { background: "rgba(255, 102, 167, 0.10)", color: "#FF66A7" },
          { background: "rgba(0, 213, 213, 0.10)", color: "#307B7B" },
          { background: "rgba(213, 107, 0, 0.10)", color: "#EB8116" },
          { background: "rgba(7, 0, 213, 0.10)", color: "#625EAE" },
          { background: "rgb(214, 224, 255)", color: "rgb(41, 82, 204)" },
          { background: "rgb(251, 221, 243)", color: "rgb(142, 51, 116)" },
          { background: "rgb(255, 235, 225)", color: "rgb(133, 70, 43)" },
        ],
        b = e.ref(!0),
        N = [],
        P = function (i) {
          if (b.value) {
            console.log("change", i),
              M.sort(function () {
                return Math.random() - 0.5;
              });
            var e = M[i % M.length];
            return N.push(e), e;
          }
        },
        T = e.computed(function () {
          var i,
            e = null == (i = f.summary) ? void 0 : i.emotionType;
          return e
            ? e
                .split(",")
                .map(function (i) {
                  return i.trim();
                })
                .filter(function (i) {
                  return i;
                })
            : [];
        }),
        _ = function (i) {
          (b.value = !1), (h.value = i);
        };
      return (
        a({
          fetchData: function (i, e) {
            (m.value = !0),
              (c.value = i),
              s.messageReportDaily({ reportDate: i, sn: e }).then(function (i) {
                var e, n;
                if (((m.value = !1), 200 == i.statusCode)) {
                  var t = i.data;
                  "A00000" == t.resultCode &&
                    (f.setSummary(
                      t.data || {
                        insightPositiveList: [],
                        insightPositiveMsgList: [],
                        insightNegativeList: [],
                        insightNegativeMsgList: [],
                        insightNeutralList: [],
                        insightNeutralMsgList: [],
                        insightList: [],
                        insightMsgList: [],
                        summary: {},
                      }
                    ),
                    null == (n = null == (e = t.data) ? void 0 : e.tagList) ||
                      n.forEach(function (i, e) {
                        P(e);
                      }));
                }
              });
          },
        }),
        function (t, s) {
          var u,
            l,
            r,
            o,
            a,
            g,
            v,
            m,
            c,
            L,
            M,
            b,
            P,
            k,
            S,
            C,
            D,
            j,
            q,
            x,
            A,
            E,
            B,
            F,
            Y,
            w,
            H,
            $,
            z,
            I,
            R,
            G,
            J,
            K,
            O,
            Q,
            U,
            V,
            W,
            X,
            Z,
            ii,
            ei,
            ni,
            ti,
            si,
            ui,
            li,
            ri,
            oi,
            ai,
            gi;
          return e.e(
            {
              a: e.o(function (i) {
                d.value.close();
              }),
              b: n._imports_0$20,
              c: 1 == h.value ? 1 : "",
              d: e.o(function (i) {
                return _(1);
              }),
              e: 2 == h.value ? 1 : "",
              f: e.o(function (i) {
                return _(2);
              }),
              g: e.f(
                null == (l = null == (u = e.unref(f)) ? void 0 : u.summary)
                  ? void 0
                  : l.insightPositiveMsgList,
                function (i, n, t) {
                  return {
                    a: e.t(i.insight),
                    b: e.t(i.messageTime && i.messageTime.slice(11, 16)),
                    c: e.t(i.message),
                    d: i.id,
                  };
                }
              ),
              h: 1 == h.value,
              i: e.f(
                null == (o = null == (r = e.unref(f)) ? void 0 : r.summary)
                  ? void 0
                  : o.insightNegativeMsgList,
                function (i, n, t) {
                  return {
                    a: e.t(i.insight),
                    b: e.t(i.messageTime && i.messageTime.slice(11, 16)),
                    c: e.t(i.message),
                    d: i.id,
                  };
                }
              ),
              j: 2 == h.value,
              k:
                (1 == h.value &&
                  0 ===
                    (null ==
                    (v =
                      null ==
                      (g = null == (a = e.unref(f)) ? void 0 : a.summary)
                        ? void 0
                        : g.insightPositiveMsgList)
                      ? void 0
                      : v.length)) ||
                (2 == h.value &&
                  0 ===
                    (null ==
                    (L =
                      null ==
                      (c = null == (m = e.unref(f)) ? void 0 : m.summary)
                        ? void 0
                        : c.insightNegativeMsgList)
                      ? void 0
                      : L.length)),
            },
            ((1 == h.value &&
              0 ===
                (null ==
                (P =
                  null == (b = null == (M = e.unref(f)) ? void 0 : M.summary)
                    ? void 0
                    : b.insightPositiveMsgList)
                  ? void 0
                  : P.length)) ||
              (2 == h.value &&
                (null ==
                  (C =
                    null == (S = null == (k = e.unref(f)) ? void 0 : k.summary)
                      ? void 0
                      : S.insightNegativeMsgList) ||
                  C.length)),
            {}),
            {
              l: e.sr(d, "c98f4073-0", { k: "popup" }),
              m: e.o(p),
              n: e.p(
                i(
                  i({ type: "bottom" }, "background-color", "#fff"),
                  "border-radius",
                  "0"
                )
              ),
              o: e.t(
                (null == (D = e.unref(f).summary) ? void 0 : D.duration) || 0
              ),
              p:
                (null ==
                (q = null == (j = e.unref(f).summary) ? void 0 : j.tagList)
                  ? void 0
                  : q.length) > 0,
            },
            (null == (A = null == (x = e.unref(f).summary) ? void 0 : x.tagList)
              ? void 0
              : A.length) > 0
              ? {
                  q: e.f(
                    (null == (E = e.unref(f).summary) ? void 0 : E.tagList) ||
                      [],
                    function (i, n, t) {
                      return { a: e.t(i), b: i, c: e.s(N[n] || {}) };
                    }
                  ),
                }
              : {},
            { r: y.value },
            y.value
              ? e.e(
                  {
                    s:
                      null == (B = e.unref(f).summary) ? void 0 : B.emotionType,
                  },
                  (null == (F = e.unref(f).summary) || F.emotionType, {}),
                  { t: T.value.length > 0 },
                  T.value.length > 0
                    ? {
                        v: e.f(T.value, function (i, n, t) {
                          return { a: e.t(i), b: e.s(N[n] || {}), c: i };
                        }),
                      }
                    : {},
                  {
                    w:
                      (null ==
                      (w =
                        null == (Y = e.unref(f).summary)
                          ? void 0
                          : Y.insightPositiveMsgList)
                        ? void 0
                        : w.length) > 0 ||
                      (null ==
                      ($ =
                        null == (H = e.unref(f).summary)
                          ? void 0
                          : H.insightNegativeMsgList)
                        ? void 0
                        : $.length) > 0,
                  },
                  (null ==
                  (I =
                    null == (z = e.unref(f).summary)
                      ? void 0
                      : z.insightPositiveMsgList)
                    ? void 0
                    : I.length) > 0 ||
                    (null ==
                    (G =
                      null == (R = e.unref(f).summary)
                        ? void 0
                        : R.insightNegativeMsgList)
                      ? void 0
                      : G.length) > 0
                    ? {
                        x: n._imports_1,
                        y: e.o(function (i) {
                          d.value.open();
                        }),
                      }
                    : {},
                  {
                    z:
                      (null ==
                      (K =
                        null == (J = e.unref(f).summary)
                          ? void 0
                          : J.insightPositiveMsgList)
                        ? void 0
                        : K.length) > 0,
                  },
                  (null ==
                    (Q =
                      null == (O = e.unref(f).summary)
                        ? void 0
                        : O.insightPositiveMsgList) || Q.length,
                  {}),
                  {
                    A:
                      (null ==
                      (V =
                        null == (U = e.unref(f).summary)
                          ? void 0
                          : U.insightPositiveMsgList)
                        ? void 0
                        : V.length) > 0,
                  },
                  (null ==
                  (X =
                    null == (W = e.unref(f).summary)
                      ? void 0
                      : W.insightPositiveMsgList)
                    ? void 0
                    : X.length) > 0
                    ? {
                        B: e.f(
                          (null ==
                          (ii =
                            null == (Z = e.unref(f).summary)
                              ? void 0
                              : Z.insightPositiveMsgList)
                            ? void 0
                            : ii.slice(0, 2)) || [],
                          function (i, n, t) {
                            return {
                              a: e.t(i.insight),
                              b: e.t(
                                i.messageTime && i.messageTime.slice(11, 16)
                              ),
                              c: e.t(i.message),
                              d: i.id,
                            };
                          }
                        ),
                      }
                    : {},
                  {
                    C:
                      (null ==
                      (ni =
                        null == (ei = e.unref(f).summary)
                          ? void 0
                          : ei.insightNegativeMsgList)
                        ? void 0
                        : ni.length) > 0,
                  },
                  (null ==
                    (si =
                      null == (ti = e.unref(f).summary)
                        ? void 0
                        : ti.insightNegativeMsgList) || si.length,
                  {}),
                  {
                    D:
                      (null ==
                      (li =
                        null == (ui = e.unref(f).summary)
                          ? void 0
                          : ui.insightNegativeMsgList)
                        ? void 0
                        : li.length) > 0,
                  },
                  (null ==
                  (oi =
                    null == (ri = e.unref(f).summary)
                      ? void 0
                      : ri.insightNegativeMsgList)
                    ? void 0
                    : oi.length) > 0
                    ? {
                        E: e.f(
                          (null ==
                          (gi =
                            null == (ai = e.unref(f).summary)
                              ? void 0
                              : ai.insightNegativeMsgList)
                            ? void 0
                            : gi.slice(0, 2)) || [],
                          function (i, n, t) {
                            var s, u;
                            return {
                              a: e.t(i.insight),
                              b: e.t(
                                i.messageTime && i.messageTime.slice(11, 16)
                              ),
                              c: e.t(i.message),
                              d: i.id,
                              e:
                                n ===
                                (null ==
                                (u =
                                  null == (s = e.unref(f).summary)
                                    ? void 0
                                    : s.insightNegativeMsgList)
                                  ? void 0
                                  : u.slice(0, 2).length) -
                                  1
                                  ? "0rpx"
                                  : "40rpx",
                            };
                          }
                        ),
                      }
                    : {}
                )
              : { F: n._imports_2$1 }
          );
        }
      );
    },
  }),
  o = e._export_sfc(r, [["__scopeId", "data-v-c98f4073"]]);
wx.createComponent(o);
