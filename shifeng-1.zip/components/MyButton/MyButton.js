var t = require("../../common/vendor.js"),
  o = t.defineComponent({
    __name: "MyButton",
    props: {
      label: {},
      onPress: {},
      buttonWidth: { default: 100 },
      buttonHeight: { default: 100 },
      fontSize: { default: 16 },
      color: { default: "#fff" },
      bgColor: { default: "#00D550" },
      borderRadius: { default: 0 },
    },
    emits: ["onPress"],
    setup: function (o, e) {
      var n = e.emit,
        r = o,
        u = t.computed(function () {
          return {
            width: "".concat(2 * r.buttonWidth, "rpx"),
            height: "".concat(2 * r.buttonHeight, "rpx"),
            backgroundColor: r.bgColor,
            borderRadius: "".concat(2 * r.borderRadius, "rpx"),
          };
        }),
        c = t.computed(function () {
          return { color: r.color, fontSize: "".concat(2 * r.fontSize, "rpx") };
        }),
        a = n,
        d = function () {
          a("onPress");
        };
      return function (o, e) {
        return { a: t.t(o.label), b: t.s(c.value), c: t.s(u.value), d: t.o(d) };
      };
    },
  }),
  e = t._export_sfc(o, [["__scopeId", "data-v-6c147e49"]]);
wx.createComponent(e);
