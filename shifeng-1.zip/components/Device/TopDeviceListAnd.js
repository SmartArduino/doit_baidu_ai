var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  t = require("../../@babel/runtime/helpers/asyncToGenerator"),
  n = require("../../common/vendor.js"),
  i = require("../../common/assets.js"),
  r = require("../../store/deviceStore.js"),
  u = require("../../api/index.js"),
  o = n.defineComponent({
    __name: "TopDeviceListAnd",
    props: { deviceList: {}, setDeviceFn: { type: Function } },
    setup: function (o) {
      var c = n.ref(""),
        s = o;
      function a() {
        s.deviceList.length &&
          ((c.value = ""),
          n.nextTick$1(function () {
            var e,
              t =
                (null ==
                (e = s.deviceList.find(function (e) {
                  return 1 === e.switchStatus;
                }))
                  ? void 0
                  : e.sn) || s.deviceList[0].sn;
            c.value = t;
          }));
      }
      n.watch(
        function () {
          return s.deviceList;
        },
        function () {
          a();
        },
        { deep: !0, immediate: !0 }
      ),
        n.onLoad(function () {
          a();
        }),
        n.onShow(function () {
          a();
        });
      var v = r.useDeviceStore(),
        d = n.computed(function () {
          return v.device || {};
        });
      function l() {
        n.index.navigateTo({ url: "/pages/device/device" });
      }
      function f() {
        return (f = t(
          e().mark(function t(i) {
            return e().wrap(
              function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (
                        (e.prev = 0), (e.next = 3), u.deviceSwitch({ sn: i.sn })
                      );
                    case 3:
                      v.setDevice(i), s.setDeviceFn(i), (e.next = 10);
                      break;
                    case 7:
                      (e.prev = 7),
                        (e.t0 = e.catch(0)),
                        n.index.showToast({ title: "切换失败", icon: "none" });
                    case 10:
                    case "end":
                      return e.stop();
                  }
              },
              t,
              null,
              [[0, 7]]
            );
          })
        )).apply(this, arguments);
      }
      var p = n.ref({
          navHeight: "",
          statusBarHeight: 0,
          buttonMargin: 0,
          buttonWidth: 0,
        }),
        h = n.ref("");
      return (
        n.onLoad(function () {
          var e = n.index.getMenuButtonBoundingClientRect(),
            t = e.top,
            i = e.height,
            r = e.width;
          (p.value.buttonWidth = r + 20),
            (h.value = "calc(100vw - " + (p.value.buttonWidth + 54) + "px)"),
            n.index.getSystemInfo({
              success: function (e) {
                console.log(e, "res==============");
                var n = e.statusBarHeight,
                  r = t - n;
                (p.value.navHeight = i + n),
                  (p.value.statusBarHeight = n),
                  (p.value.buttonMargin = r);
              },
            });
        }),
        function (e, t) {
          return {
            a: n.f(s.deviceList, function (e, t, i) {
              return n.e(
                { a: n.t(e.productName), b: e.sn === d.value.sn },
                (e.sn, d.value.sn, {}),
                {
                  c: e.sn,
                  d: e.sn,
                  e: e.sn === d.value.sn ? 1 : "",
                  f: n.o(function (t) {
                    return (function (e) {
                      return f.apply(this, arguments);
                    })(e);
                  }, e.sn),
                }
              );
            }),
            b: c.value,
            c: h.value,
            d: i._imports_0$17,
            e: n.o(l),
            f: "calc(100vw - " + p.value.buttonWidth + "px)",
          };
        }
      );
    },
  }),
  c = n._export_sfc(o, [["__scopeId", "data-v-6d6f898b"]]);
wx.createComponent(c);
