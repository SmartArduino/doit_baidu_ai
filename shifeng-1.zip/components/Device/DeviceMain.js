var e = require("../../common/vendor.js"),
  n = require("../../common/assets.js"),
  o = require("../../store/deviceStore.js"),
  t = require("../../store/useRoleStore.js"),
  u = e.defineComponent({
    __name: "DeviceMain",
    setup: function (u) {
      var r = o.useDeviceStore(),
        i = t.useRoleStore(),
        l = e.computed(function () {
          return r.device;
        }),
        a = e.computed(function () {
          return i.roleInfo;
        }),
        v = e.computed(function () {
          return i.roleList;
        });
      var c = function (e) {
        if (!(null == e ? void 0 : e.version)) return "";
        var n =
            null == (null == e ? void 0 : e.version) ? "" : String(e.version),
          o = n.split(".");
        return o.length
          ? "｜V " +
              o
                .map(function (e, n) {
                  var o = Number(e);
                  return 0 !== n || ("" !== e && 0 !== o) || (o = 1), String(o);
                })
                .join(".")
          : n;
      };
      return function (o, t) {
        var u, r, i, s, d, m, f;
        return e.e(
          { a: null == (u = l.value) ? void 0 : u.productImg },
          (null == (r = l.value) ? void 0 : r.productImg)
            ? { b: null == (i = l.value) ? void 0 : i.productImg }
            : {},
          {
            c: e.t(null == (s = l.value) ? void 0 : s.sn),
            d: e.t(c(l.value)),
            e: e.o(function (n) {
              return (function (n) {
                console.log(n);
                var o = n.version || "未知",
                  t = "SN：".concat(n.sn, "   版本：").concat(o);
                e.index.setClipboardData({
                  data: t,
                  success: function () {
                    e.index.showToast({ title: "复制成功", icon: "none" });
                  },
                });
              })(l.value);
            }),
            f: v.value.length > 0,
          },
          v.value.length > 0
            ? e.e(
                { g: null == (d = a.value) ? void 0 : d.thumbnailImg },
                (null == (m = a.value) ? void 0 : m.thumbnailImg)
                  ? { h: a.value.thumbnailImg }
                  : {},
                {
                  i: e.t((null == (f = a.value) ? void 0 : f.name) || ""),
                  j: n._imports_0$9,
                  k: e.o(function (n) {
                    return (function (n) {
                      var o,
                        t = null == (o = l.value) ? void 0 : o.sn;
                      t && e.index.navigateTo({ url: n + "?sn=".concat(t) });
                    })("/pages/secretCharacter/index");
                  }),
                }
              )
            : {}
        );
      };
    },
  }),
  r = e._export_sfc(u, [["__scopeId", "data-v-dfeb2b17"]]);
wx.createComponent(r);
