var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  t = require("../../@babel/runtime/helpers/asyncToGenerator"),
  n = require("../../common/vendor.js"),
  r = require("../../common/assets.js"),
  a = require("../../store/deviceStore.js"),
  u = require("../../store/useRoleStore.js"),
  i = require("../../store/useModalStore.js"),
  o = require("../../api/index.js");
Math || (p + c + l + v + f + d + s)();
var s = function () {
    return "../MessageList/index.js";
  },
  c = function () {
    return "./TopDeviceListAnd.js";
  },
  l = function () {
    return "./DeviceStatus.js";
  },
  v = function () {
    return "./DeviceOperation.js";
  },
  d = function () {
    return "./DeviceMain.js";
  },
  p = function () {
    return "./NotFound.js";
  },
  f = function () {
    return "./ControlDevice.js";
  },
  h = n.defineComponent({
    __name: "BoundPage",
    setup: function (s) {
      var c = i.useModalStatus(),
        l = a.useDeviceStore(),
        v = u.useRoleStore(),
        d = n.computed(function () {
          return l.devices;
        }),
        p = n.computed(function () {
          return l.deviceSetting;
        }),
        f = l.setDevices,
        h = l.setDevice,
        m = l.setDeviceSetting;
      l.setProduct;
      var g = v.setRoleList,
        x = v.setRole,
        w = n.ref({
          navHeight: "",
          statusBarHeight: 0,
          buttonMargin: 0,
          capsuleHeight: 0,
        }),
        y = n.ref(""),
        b = n.ref(!1),
        S = n.ref("");
      n.onLoad(function () {
        var e = n.index.getMenuButtonBoundingClientRect(),
          t = e.top,
          r = e.height;
        n.index.getSystemInfo({
          success: function (e) {
            var n = e.statusBarHeight,
              a = t - n;
            (w.value.navHeight = r + n),
              (w.value.statusBarHeight = n),
              (w.value.buttonMargin = a),
              (w.value.capsuleHeight = r);
          },
        });
        var a = n.index.getAccountInfoSync(),
          u = n.ref(a.miniProgram.envVersion);
        y.value = n.index.getStorageSync(u.value + "token");
      });
      var C = n.computed(function () {
          return (
            n.index.getSystemInfoSync().windowHeight -
            w.value.capsuleHeight -
            w.value.buttonMargin -
            w.value.statusBarHeight +
            "px"
          );
        }),
        k = n.ref(""),
        T = n.ref(!0),
        D = n.ref("");
      function H() {
        return (H = t(
          e().mark(function t() {
            var n, r, a, u, i;
            return e().wrap(
              function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (
                        (T.value = !0),
                        (e.prev = 1),
                        (e.next = 4),
                        o.userDeviceList()
                      );
                    case 4:
                      (r = e.sent),
                        "A00000" ===
                          (null == (a = r.data) ? void 0 : a.resultCode) &&
                          ((u = a.data.list || []),
                          f(u),
                          (i =
                            u.find(function (e) {
                              return 1 === e.switchStatus;
                            }) || u[0])
                            ? (h(i), (k.value = i.sn))
                            : h(null),
                          M((null == (n = l.device) ? void 0 : n.sn) || "")),
                        (e.next = 12);
                      break;
                    case 9:
                      (e.prev = 9), (e.t0 = e.catch(1)), console.error(e.t0);
                    case 12:
                      return (e.prev = 12), (T.value = !1), e.finish(12);
                    case 15:
                    case "end":
                      return e.stop();
                  }
              },
              t,
              null,
              [[1, 9, 12, 15]]
            );
          })
        )).apply(this, arguments);
      }
      function M(e) {
        e &&
          (j(e),
          (function (e) {
            A.apply(this, arguments);
          })(e),
          P(e),
          R(),
          O());
      }
      function j(e) {
        return L.apply(this, arguments);
      }
      function L() {
        return (L = t(
          e().mark(function t(n) {
            var r, a;
            return e().wrap(function (e) {
              for (;;)
                switch ((e.prev = e.next)) {
                  case 0:
                    return (e.next = 2), o.deviceSetting({ sn: n });
                  case 2:
                    (r = e.sent),
                      "A00000" ===
                        (null == (a = r.data) ? void 0 : a.resultCode) &&
                        m(a.data);
                  case 5:
                  case "end":
                    return e.stop();
                }
            }, t);
          })
        )).apply(this, arguments);
      }
      function A() {
        return (A = t(
          e().mark(function t(n) {
            var r, a, u, i;
            return e().wrap(function (e) {
              for (;;)
                switch ((e.prev = e.next)) {
                  case 0:
                    return (e.next = 2), o.characterList({ sn: n });
                  case 2:
                    (r = e.sent),
                      "A00000" ===
                        (null == (a = r.data) ? void 0 : a.resultCode) &&
                        ((u = a.data.list || []),
                        g(u),
                        (i = u.find(function (e) {
                          return 1 === e.bindStatus;
                        })) && x(i));
                  case 5:
                  case "end":
                    return e.stop();
                }
            }, t);
          })
        )).apply(this, arguments);
      }
      function _(e) {
        h(e), (k.value = e.sn), M(e.sn);
      }
      var q = n.ref([]),
        B = n.ref(!1),
        P = (function () {
          var n = t(
            e().mark(function t(n) {
              var r, a;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.prev = 0),
                          (B.value = !0),
                          (e.next = 4),
                          o.sceneList({ sn: n })
                        );
                      case 4:
                        (r = e.sent),
                          "A00000" === (a = r.data).resultCode &&
                            (q.value = a.data.categoryList),
                          (e.next = 12);
                        break;
                      case 9:
                        (e.prev = 9),
                          (e.t0 = e.catch(0)),
                          console.error("获取场景列表失败:", e.t0);
                      case 12:
                        return (e.prev = 12), (B.value = !1), e.finish(12);
                      case 15:
                      case "end":
                        return e.stop();
                    }
                },
                t,
                null,
                [[0, 9, 12, 15]]
              );
            })
          );
          return function (e) {
            return n.apply(this, arguments);
          };
        })(),
        R = (function () {
          var n = t(
            e().mark(function t() {
              var n, r, a, u, i, s, c, v;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (null == (n = l.device) ? void 0 : n.sn) {
                          e.next = 3;
                          break;
                        }
                        return (b.value = !1), e.abrupt("return");
                      case 3:
                        return (
                          (e.prev = 3),
                          (e.next = 6),
                          o.messageList({
                            sn: l.device.sn,
                            pageNum: 1,
                            pageSize: 1,
                          })
                        );
                      case 6:
                        (c = e.sent),
                          "A00000" === (v = c.data).resultCode
                            ? ((b.value =
                                (null == (r = v.data) ? void 0 : r.list) &&
                                v.data.list.length > 0),
                              (S.value =
                                (null ==
                                (i =
                                  null ==
                                  (u = null == (a = v.data) ? void 0 : a.list)
                                    ? void 0
                                    : u[0])
                                  ? void 0
                                  : i.title) || ""))
                            : (b.value = !1),
                          (e.next = 17);
                        break;
                      case 11:
                        if (
                          ((e.prev = 11),
                          (e.t0 = e.catch(3)),
                          console.error("获取信件列表失败:", e.t0),
                          (b.value = !1),
                          401 !== (null == e.t0 ? void 0 : e.t0.statusCode) &&
                            "A00002" !==
                              (null == (s = null == e.t0 ? void 0 : e.t0.data)
                                ? void 0
                                : s.resultCode))
                        ) {
                          e.next = 17;
                          break;
                        }
                        return e.abrupt("return");
                      case 17:
                      case "end":
                        return e.stop();
                    }
                },
                t,
                null,
                [[3, 11]]
              );
            })
          );
          return function () {
            return n.apply(this, arguments);
          };
        })();
      n.onShow(function () {
        !(function () {
          H.apply(this, arguments);
        })();
      });
      var I = (function () {
        var r = t(
          e().mark(function t(r, a, u, i) {
            var s, c, v, d, p, f, h, m, g, x, w;
            return e().wrap(
              function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      if (
                        ((p = i.styleType),
                        i.name,
                        (f = i.dataSource),
                        4 !== p || 0 !== u.enterDetailPage)
                      ) {
                        e.next = 14;
                        break;
                      }
                      return (
                        (e.prev = 2),
                        (e.next = 5),
                        o.contentH5Url({
                          sn: (null == (s = l.device) ? void 0 : s.sn) || "",
                        })
                      );
                    case 5:
                      (h = e.sent),
                        "A00000" === (m = h.data).resultCode &&
                          ((D.value = m.data || ""),
                          n.index.navigateTo({
                            url: "/pages/webContent/index?url=".concat(
                              encodeURIComponent(m.data),
                              "&title=内容点播"
                            ),
                          })),
                        (e.next = 13);
                      break;
                    case 10:
                      (e.prev = 10),
                        (e.t0 = e.catch(2)),
                        console.error("webContent error", e.t0);
                    case 13:
                      return e.abrupt("return");
                    case 14:
                      if (0 !== u.enterDetailPage) {
                        e.next = 27;
                        break;
                      }
                      return (
                        (e.prev = 15),
                        (e.next = 18),
                        o.functionOpen({
                          sn: (null == (c = l.device) ? void 0 : c.sn) || "",
                          functionType: u.functionType || 0,
                          id: u.id,
                          name: u.name,
                          dataSource: f,
                        })
                      );
                    case 18:
                      (g = e.sent),
                        "A00000" === (x = g.data).resultCode &&
                          (u.tips &&
                            n.index.showToast({ title: u.tips, icon: "none" }),
                          (null == (v = null == x ? void 0 : x.data)
                            ? void 0
                            : v.img) && (u.img = x.data.img)),
                        (e.next = 25);
                      break;
                    case 23:
                      (e.prev = 23), (e.t1 = e.catch(15));
                    case 25:
                      e.next = 29;
                      break;
                    case 27:
                      (w =
                        5 == p
                          ? "/pages/activityDetailsBC/index"
                          : "/pages/activityDetails/index"),
                        n.index.navigateTo({
                          url: ""
                            .concat(w, "?id=")
                            .concat(r, "&name=")
                            .concat(a, "&sn=")
                            .concat(
                              null == (d = l.device) ? void 0 : d.sn,
                              "&styleType="
                            )
                            .concat(p, "&dataSource=")
                            .concat(f),
                        });
                    case 29:
                    case "end":
                      return e.stop();
                  }
              },
              t,
              null,
              [
                [2, 10],
                [15, 23],
              ]
            );
          })
        );
        return function (e, t, n, a) {
          return r.apply(this, arguments);
        };
      })();
      var N = (function () {
          var r = t(
            e().mark(function t() {
              var r, a, u, i;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.prev = 0),
                          (u = 1 === p.value.chatMode ? 2 : 1),
                          (e.next = 4),
                          o.switchChatMode({
                            sn: (null == (r = l.device) ? void 0 : r.sn) || "",
                            chatMode: u,
                          })
                        );
                      case 4:
                        (i = e.sent),
                          "A00000" === i.data.resultCode &&
                            (n.index.showToast({
                              title: "切换模式成功",
                              icon: "none",
                            }),
                            j((null == (a = l.device) ? void 0 : a.sn) || "")),
                          (e.next = 12);
                        break;
                      case 9:
                        (e.prev = 9),
                          (e.t0 = e.catch(0)),
                          console.error("onSwitchMode error", e.t0);
                      case 12:
                      case "end":
                        return e.stop();
                    }
                },
                t,
                null,
                [[0, 9]]
              );
            })
          );
          return function () {
            return r.apply(this, arguments);
          };
        })(),
        $ = (function () {
          var r = t(
            e().mark(function t() {
              return e().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      n.index.navigateTo({ url: "/pages/selectCommand/index" });
                    case 1:
                    case "end":
                      return e.stop();
                  }
              }, t);
            })
          );
          return function () {
            return r.apply(this, arguments);
          };
        })(),
        F = (function () {
          var r = t(
            e().mark(function t() {
              return e().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      n.index.navigateTo({ url: "/pages/commandsPage/index" });
                    case 1:
                    case "end":
                      return e.stop();
                  }
              }, t);
            })
          );
          return function () {
            return r.apply(this, arguments);
          };
        })(),
        O = (function () {
          var n = t(
            e().mark(function t() {
              var n, r, a, u;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.prev = 0),
                          (e.next = 3),
                          o.deviceCommandConfig({
                            sn: (null == (n = l.device) ? void 0 : n.sn) || "",
                          })
                        );
                      case 3:
                        (a = e.sent),
                          "A00000" === (u = a.data).resultCode &&
                            l.setCommandList(
                              (null == (r = u.data) ? void 0 : r.commandList) ||
                                []
                            ),
                          (e.next = 11);
                        break;
                      case 8:
                        (e.prev = 8),
                          (e.t0 = e.catch(0)),
                          console.error("getCommandList error", e.t0);
                      case 11:
                      case "end":
                        return e.stop();
                    }
                },
                t,
                null,
                [[0, 8]]
              );
            })
          );
          return function () {
            return n.apply(this, arguments);
          };
        })();
      return (
        n.watch(
          function () {
            var e;
            return null == (e = l.device) ? void 0 : e.sn;
          },
          function (e) {
            R(), O();
          },
          { immediate: !0 }
        ),
        function (e, t) {
          return n.e(
            {
              a: (0 === d.value.length && !T.value) || !y.value,
              b: w.value.navHeight + 24 + "px",
              c: n.p({ deviceList: d.value, setDeviceFn: _ }),
              d: w.value.capsuleHeight + "px",
              e: w.value.statusBarHeight + w.value.buttonMargin + "px",
              f: 1 === p.value.customPrompt,
            },
            1 === p.value.customPrompt
              ? {
                  g: r._imports_0$12,
                  h: n.o(function (e) {
                    return (
                      (t = "/pages/AIHelp/index"),
                      void n.index.navigateTo({ url: t })
                    );
                    var t;
                  }),
                }
              : {},
            {
              i: n.p({ onSwitchMode: N, onRemoteControl: $ }),
              j: 1 === p.value.hasCoding,
            },
            1 === p.value.hasCoding ? { k: r._imports_0$9, l: n.o(F) } : {},
            {
              m: n.f(q.value, function (e, t, r) {
                return {
                  a: n.t(e.name),
                  b: n.f(e.functionList, function (t, r, a) {
                    return {
                      a: t.img,
                      b: n.t(t.name),
                      c: n.t(t.subtitle),
                      d: t.id,
                      e: n.o(function (n) {
                        return I(t.id, t.name, t, e);
                      }, t.id),
                    };
                  }),
                  c: n.n("module" + e.styleType),
                  d: e.id,
                  e:
                    1 === e.styleType
                      ? "320rpx"
                      : 2 === e.styleType
                      ? "364rpx"
                      : "254rpx",
                };
              }),
              n: r._imports_2$7,
              o: b.value,
            },
            b.value ? { p: n.p({ productName: S.value }) } : {},
            { q: y.value && d.value.length > 0 && !n.unref(c).modalStatus },
            (y.value && d.value.length > 0 && n.unref(c).modalStatus, {}),
            {
              r: n.unref(c).modalStatus ? "hidden" : "auto",
              s: C.value,
              t: !n.unref(c).modalStatus,
              v: !T.value && d.value.length > 0 && y.value,
              w: !y.value || 0 === d.value.length,
            },
            (y.value && d.value.length, {})
          );
        }
      );
    },
  }),
  m = n._export_sfc(h, [["__scopeId", "data-v-f0e7f70e"]]);
wx.createComponent(m);
