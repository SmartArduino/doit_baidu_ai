var e = require("../../common/vendor.js"),
  t = require("../../store/deviceStore.js"),
  i = e.defineComponent({
    __name: "DeviceStatus",
    setup: function (i) {
      var a = t.useDeviceStore(),
        n = e.computed(function () {
          var e;
          return null !== (e = a.deviceSetting.electricity) && void 0 !== e
            ? e
            : -1;
        }),
        c = e.computed(function () {
          var e, t;
          return null !==
            (e = null == (t = a.device) ? void 0 : t.networkStatus) &&
            void 0 !== e
            ? e
            : 0;
        }),
        u = e.computed(function () {
          var e = n.value;
          return e >= 86
            ? "/static/images/app/device/e-6.png"
            : e >= 70
            ? "/static/images/app/device/e-5.png"
            : e >= 45
            ? "/static/images/app/device/e-4.png"
            : e >= 21
            ? "/static/images/app/device/e-3.png"
            : e >= 13
            ? "/static/images/app/device/e-2.png"
            : e < 13 && e >= 0
            ? "/static/images/app/device/e-1.png"
            : "";
        });
      return function (t, i) {
        return e.e(
          { a: -1 !== n.value },
          -1 !== n.value
            ? e.e({ b: u.value }, u.value ? { c: u.value } : {})
            : {},
          {
            d: e.t(1 === c.value ? "在线" : "离线"),
            e: e.n(1 === c.value ? "online" : "offline"),
          }
        );
      };
    },
  }),
  a = e._export_sfc(i, [["__scopeId", "data-v-25396639"]]);
wx.createComponent(a);
