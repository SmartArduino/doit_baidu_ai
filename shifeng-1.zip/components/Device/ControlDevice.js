var e = require("../../common/vendor.js"),
  o = require("../../common/assets.js"),
  t = require("../../store/deviceStore.js"),
  n = e.defineComponent({
    __name: "ControlDevice",
    props: {
      onSwitchMode: {},
      onRemoteControl: {},
      showTip: { type: Boolean, default: !0 },
      tipText: { default: "可切换对话模式" },
    },
    setup: function (n) {
      e.useCssVars(function (e) {
        return { "345b264b": c.value };
      });
      var r = t.useDeviceStore(),
        u = e.computed(function () {
          return r.deviceSetting;
        }),
        a = e.computed(function () {
          return r.commandList;
        }),
        c = e.computed(function () {
          return -1 !== u.value.chatMode ? "100rpx" : "20rpx";
        });
      return function (t, n) {
        return e.e(
          { a: -1 !== u.value.chatMode || 1 === u.value.hasRemoteControl },
          -1 !== u.value.chatMode || 1 === u.value.hasRemoteControl
            ? e.e(
                { b: -1 !== u.value.chatMode },
                -1 !== u.value.chatMode
                  ? e.e(
                      { c: t.showTip },
                      t.showTip
                        ? { d: o._imports_0$19, e: e.t(t.tipText) }
                        : {},
                      {
                        f: o._imports_1$9,
                        g: e.o(function () {
                          return (
                            t.onSwitchMode && t.onSwitchMode.apply(t, arguments)
                          );
                        }),
                      }
                    )
                  : {},
                { h: a.value.length > 0 },
                a.value.length > 0
                  ? {
                      i: e.o(function () {
                        return (
                          t.onRemoteControl &&
                          t.onRemoteControl.apply(t, arguments)
                        );
                      }),
                    }
                  : {}
              )
            : {},
          { j: e.s(t.__cssVars()) }
        );
      };
    },
  }),
  r = e._export_sfc(n, [["__scopeId", "data-v-cb762ade"]]);
wx.createComponent(r);
