var e = require("../../common/vendor.js"),
  a = e.defineComponent({
    __name: "ScheduleControl",
    props: { initialValue: {}, minValue: {}, uri: {} },
    emits: ["change"],
    setup: function (a, t) {
      var u,
        o,
        n = t.emit,
        r = a,
        i = n,
        l = null !== (u = r.minValue) && void 0 !== u ? u : 4,
        v = null !== (o = r.initialValue) && void 0 !== o ? o : 50;
      console.log(v, "initVal============");
      var c = e.ref((520 * v) / 100);
      e.watch(
        function () {
          return r.initialValue;
        },
        function (e) {
          void 0 !== e && (c.value = (520 * e) / 100);
        }
      );
      var d = e.ref(0),
        f = e.ref(0);
      function m(e) {
        (d.value = c.value), (f.value = e.touches[0].pageY);
      }
      function h(e) {
        var a = e.touches[0].pageY;
        if (!(Math.abs(a - f.value) < 5)) {
          var t = a - f.value,
            u = d.value - t,
            o = (520 * l) / 100;
          (c.value = Math.max(o, Math.min(520, u))),
            t > 0 && (u = d.value - 1.2 * t);
          var n = Math.min(520, Math.max(o, u));
          (c.value = n), (f.value = a), (d.value = n);
        }
      }
      function p() {
        var e = (c.value / 520) * 100,
          a = Math.round(Math.max(l, e));
        i("change", a);
      }
      var s = e.computed(function () {
          return c.value >= 416 ? 30 : 15;
        }),
        x = e.computed(function () {
          return {
            height: "".concat(c.value, "rpx"),
            bottom: "0",
            left: "0",
            right: "0",
            borderBottomLeftRadius: "35rpx",
            borderBottomRightRadius: "35rpx",
            borderTopLeftRadius: "".concat(s.value, "rpx"),
            borderTopRightRadius: "".concat(s.value, "rpx"),
          };
        });
      return function (a, t) {
        return e.e(
          { a: e.s(x.value), b: e.o(m), c: e.o(h), d: e.o(p), e: a.uri },
          a.uri ? { f: a.uri } : {}
        );
      };
    },
  }),
  t = e._export_sfc(a, [["__scopeId", "data-v-7957a471"]]);
wx.createComponent(t);
