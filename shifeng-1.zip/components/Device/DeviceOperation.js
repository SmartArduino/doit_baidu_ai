var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  a = require("../../@babel/runtime/helpers/asyncToGenerator"),
  u = require("../../common/vendor.js"),
  t = require("../../common/assets.js"),
  n = require("../../store/deviceStore.js"),
  l = require("../../api/index.js"),
  r = require("../../store/useModalStore.js");
Math || i();
var i = function () {
    return "./ScheduleControl.js";
  },
  o = u.defineComponent({
    __name: "DeviceOperation",
    setup: function (i) {
      var o = n.useDeviceStore(),
        v = u.computed(function () {
          return o.device;
        }),
        s = u.computed(function () {
          return o.deviceSetting;
        }),
        c = r.useModalStatus(),
        m = u.ref(3),
        d = u.ref(!1),
        p = u.ref(0),
        f = u.ref(20 * s.value.brightness);
      function h(e) {
        var a,
          u = 99 / (m.value - 1),
          t = Math.ceil(e / u);
        (t =
          100 === e
            ? m.value
            : e <= 2
            ? 1
            : Math.max(2, Math.min(t, m.value - 1))),
          console.log(t),
          l.deviceSettingVolume({
            sn: null == (a = v.value) ? void 0 : a.sn,
            volume: t,
          });
      }
      function g(e) {
        var a;
        f.value = e;
        var u = Math.min(Math.floor(e / 20) + 1, 5);
        console.log(u),
          l.settingBrightness({
            sn: null == (a = v.value) ? void 0 : a.sn,
            brightness: u,
          });
      }
      function b() {
        (d.value = !0), c.setStatus(!0);
      }
      function S() {
        (d.value = !1), c.setStatus(!1);
      }
      return (
        u.watch(
          function () {
            return s.value.volume;
          },
          function (e) {
            p.value = 1 === e ? 2 : e * (100 / m.value);
          },
          { immediate: !0 }
        ),
        u.watch(
          function () {
            return s.value.brightness;
          },
          function (e) {
            f.value = 20 * e;
          },
          { immediate: !0 }
        ),
        u.watch(
          d,
          (function () {
            var u = a(
              e().mark(function a(u) {
                var t, n, r;
                return e().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (!u || !(null == (t = v.value) ? void 0 : t.sn)) {
                            e.next = 12;
                            break;
                          }
                          return (
                            (e.prev = 1),
                            (e.next = 4),
                            l.deviceSetting({ sn: v.value.sn })
                          );
                        case 4:
                          (n = e.sent),
                            "A00000" ===
                              (null == (r = n.data) ? void 0 : r.resultCode) &&
                              (console.log("函数调用成功"),
                              (m.value = r.data.volumeScale),
                              console.log(r.data.volume * (100 / m.value)),
                              1 === m.value
                                ? (p.value = 2)
                                : (p.value = r.data.volume * (100 / m.value)),
                              (f.value = 20 * r.data.brightness)),
                            (e.next = 12);
                          break;
                        case 9:
                          (e.prev = 9),
                            (e.t0 = e.catch(1)),
                            console.error(e.t0);
                        case 12:
                        case "end":
                          return e.stop();
                      }
                  },
                  a,
                  null,
                  [[1, 9]]
                );
              })
            );
            return function (e) {
              return u.apply(this, arguments);
            };
          })(),
          { immediate: !0 }
        ),
        u.onUnload(function () {
          (d.value = !1), c.setStatus(!1);
        }),
        function (e, a) {
          return u.e(
            { a: f.value > -1 || p.value > -1 },
            f.value > -1 || p.value > -1
              ? u.e(
                  { b: f.value > -1 },
                  f.value > -1 ? { c: t._imports_0$18 } : {},
                  { d: p.value > -1 && f.value > -1 },
                  (p.value > -1 && f.value, {}),
                  { e: p.value > -1 },
                  p.value > -1 ? { f: t._imports_1$8 } : {},
                  { g: u.o(b) }
                )
              : {},
            { h: d.value },
            d.value
              ? u.e(
                  {
                    i: t._imports_2$9,
                    j: u.o(S),
                    k: u.t(-1 !== s.value.brightness ? "亮度" : ""),
                    l: u.t(
                      -1 !== s.value.brightness && -1 !== s.value.volume
                        ? "和"
                        : ""
                    ),
                    m: u.t(-1 !== s.value.volume ? "音量" : ""),
                    n: -1 !== s.value.brightness,
                  },
                  -1 !== s.value.brightness
                    ? {
                        o: u.o(g),
                        p: u.p({
                          uri: "/static/images/app/device/sun.png",
                          initialValue: f.value,
                          minValue: 10,
                        }),
                      }
                    : {},
                  { q: -1 !== s.value.volume },
                  -1 !== s.value.volume
                    ? {
                        r: u.o(h),
                        s: u.p({
                          uri: "/static/images/app/device/volume.png",
                          initialValue: p.value,
                          minValue: 2,
                        }),
                      }
                    : {}
                )
              : {}
          );
        }
      );
    },
  }),
  v = u._export_sfc(o, [["__scopeId", "data-v-cbaf7537"]]);
wx.createComponent(v);
