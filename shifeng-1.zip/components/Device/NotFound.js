var e = require("../../common/vendor.js"),
  n = require("../../common/assets.js"),
  o = e.defineComponent({
    __name: "NotFound",
    setup: function (o) {
      function t() {
        var n = e.index.getAccountInfoSync(),
          o = e.ref(n.miniProgram.envVersion);
        e.index.getStorageSync(o.value + "token")
          ? e.index.navigateTo({ url: "/pages/device/device" })
          : e.index.navigateTo({ url: "/pages/login/index" });
      }
      return function (o, r) {
        return { a: n._imports_2$1, b: e.o(t) };
      };
    },
  }),
  t = e._export_sfc(o, [["__scopeId", "data-v-9ed13cc1"]]);
wx.createComponent(t);
