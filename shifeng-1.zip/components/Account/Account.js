var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  r = require("../../common/vendor.js"),
  t = require("../../common/assets.js"),
  a = require("../../store/userInfoStore.js"),
  o = require("../../api/index.js"),
  u = r.defineComponent({
    __name: "Account",
    setup: function (u) {
      var i = a.useUserInfoStore(),
        c = r.computed(function () {
          return i.userInfo;
        }),
        l = r.computed(function () {
          var e;
          return (null == (e = c.value) ? void 0 : e.gender)
            ? 1 === c.value.gender
              ? "/static/images/app/male_icon.png"
              : "/static/images/app/female_icon.png"
            : "";
        }),
        s = function () {
          var e = r.index.getAccountInfoSync(),
            n = r.ref(e.miniProgram.envVersion);
          r.index.getStorageSync(n.value + "token")
            ? r.index.navigateTo({ url: "/pages/personalEdit/index" })
            : r.index.reLaunch({ url: "/pages/login/index" });
        },
        v = r.ref("");
      return (
        r.onShow(
          n(
            e().mark(function n() {
              var t, a, u, c;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (t = r.index.getAccountInfoSync()),
                          (a = r.ref(t.miniProgram.envVersion)),
                          (v.value = r.index.getStorageSync(a.value + "token")),
                          (e.prev = 3),
                          (e.next = 6),
                          o.wechatUserInfo()
                        );
                      case 6:
                        (u = e.sent),
                          (c = u.data),
                          console.log("wechatUserInfo", c),
                          i.setUserInfo(c.data),
                          (e.next = 15);
                        break;
                      case 12:
                        (e.prev = 12),
                          (e.t0 = e.catch(3)),
                          console.error("数据获取失败:", e.t0);
                      case 15:
                      case "end":
                        return e.stop();
                    }
                },
                n,
                null,
                [[3, 12]]
              );
            })
          )
        ),
        function (e, n) {
          var a, o, u, i, d, f, p;
          return r.e(
            { a: v.value },
            v.value
              ? r.e(
                  {
                    b:
                      (null == (a = c.value) ? void 0 : a.avatar) ||
                      "https://vseed-toystory.cdn.bcebos.com/2025/08/18/d920ff4f-c994-4ca6-a03c-eefada0d5792.png",
                    c: r.t(
                      (null == (o = c.value) ? void 0 : o.nickname) ||
                        "宝贝信息"
                    ),
                    d: null == (u = c.value) ? void 0 : u.gender,
                  },
                  (null == (i = c.value) ? void 0 : i.gender)
                    ? { e: l.value }
                    : {},
                  { f: null == (d = c.value) ? void 0 : d.birthdate },
                  (null == (f = c.value) ? void 0 : f.birthdate)
                    ? { g: r.t(null == (p = c.value) ? void 0 : p.birthdate) }
                    : {}
                )
              : {},
            { h: v.value },
            v.value
              ? { i: t._imports_1 }
              : {
                  j: t._imports_1$6,
                  k: r.o(function (e) {
                    return s();
                  }),
                },
            { l: r.o(s) }
          );
        }
      );
    },
  }),
  i = r._export_sfc(u, [["__scopeId", "data-v-c6750859"]]);
wx.createComponent(i);
