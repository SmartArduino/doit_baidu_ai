var e = require("../../common/vendor.js"),
  r = require("../../common/assets.js"),
  a = e.defineComponent({
    __name: "recorder",
    emits: ["recordEnd"],
    setup: function (a, o) {
      var t = o.emit,
        n = e.index.getRecorderManager(),
        u = e.ref("1"),
        l = e.ref(!1),
        v = e.ref(0),
        c = e.ref(6e4),
        i = e.ref(""),
        f = e.ref({}),
        d = e.ref(!0),
        m = e.ref("松手结束录音"),
        s = e.ref("按住 说话");
      e.ref("");
      var p = function (e) {
          (f.value = e.touches[0]),
            (u.value = "2"),
            (s.value = "说话中..."),
            n.onStop(function (e) {
              i.value = e.tempFilePath;
            });
          var r = {
            duration: c.value,
            sampleRate: 16e3,
            numberOfChannels: 1,
            encodeBitRate: 96e3,
            format: "wav",
          };
          n.start(r), (d.value = !1), n.onStart(function (e) {});
        },
        h = t,
        b = function (e) {
          var r = e.touches[e.touches.length - 1].clientY - f.value.clientY;
          Math.abs(r) > 70
            ? ((m.value = "松开手指,取消发送"),
              (s.value = "松开手指,取消发送"),
              g(),
              (d.value = !0))
            : ((m.value = "松手结束录音"),
              (s.value = "松手结束录音"),
              (d.value = !1));
        },
        g = function () {
          (l.value = !1), (v.value = 0), (i.value = "");
        };
      return function (a, o) {
        return e.e(
          {
            a: r._imports_0$14,
            b: e.t(s.value),
            c: e.n("1" == u.value ? "record-btn-1" : "record-btn-2"),
            d: e.s(
              "松开手指,取消发送" != m.value && "1" != u.value
                ? "background-image: linear-gradient(to top, #cfd9df 0%, #e2ebf0 100%);"
                : "background-color: #fff;"
            ),
            e: e.o(p),
            f: e.o(function (r) {
              return (
                (u.value = "1"),
                (s.value = "按住 说话"),
                (m.value = "松手结束录音"),
                n.onStop(function (r) {
                  console.log(d.value),
                    d.value ||
                      (r.duration < 1e3
                        ? e.wx$1.showToast({
                            title: "录音时间太短",
                            icon: "none",
                            duration: 1e3,
                          })
                        : ((i.value = r.tempFilePath),
                          h("recordEnd", r.tempFilePath)));
                }),
                void n.stop()
              );
            }),
            g: e.o(b),
            h: e.o(p),
            i: "2" == u.value,
          },
          "2" == u.value
            ? {
                j: e.f(15, function (e, r, a) {
                  return { a: r };
                }),
                k: e.t(m.value),
                l: e.n(
                  "松开手指,取消发送" != m.value
                    ? "prompt-layer prompt-layer-1"
                    : "prompt-layer1 prompt-layer-1"
                ),
              }
            : {},
          {
            m: e.n("1" == u.value ? "record-box" : "record-box1"),
            n: e.n("1" == u.value ? "record-layer" : "record-layer1"),
          }
        );
      };
    },
  });
wx.createComponent(a);
