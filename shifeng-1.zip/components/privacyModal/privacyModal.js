var e = require("../../common/vendor.js"),
  n = e.defineComponent({
    __name: "privacyModal",
    emits: ["privacyAuthorization"],
    setup: function (n, o) {
      var t = o.expose,
        i = o.emit,
        a = e.ref("隐私保护指引"),
        r = e.ref(!1);
      e.onPageShow(function () {
        e.wx$1.getPrivacySetting({
          success: function (e) {
            e.needAuthorization &&
              ((a.value = e.privacyContractName), (r.value = !0));
          },
        });
      });
      t({
        openPrivacyModel: function () {
          r.value = !0;
        },
      });
      var u = function () {
          e.wx$1.openPrivacyContract({
            fail: function () {
              e.wx$1.showToast({ title: "遇到错误", icon: "error" });
            },
          });
        },
        c = i,
        v = function () {
          (r.value = !1), c("privacyAuthorization", !1);
        },
        f = function () {
          (r.value = !1), c("privacyAuthorization", !0);
        };
      return function (n, o) {
        return e.e(
          { a: r.value },
          r.value ? { b: e.t(a.value), c: e.o(u), d: e.o(v), e: e.o(f) } : {}
        );
      };
    },
  });
wx.createComponent(n);
