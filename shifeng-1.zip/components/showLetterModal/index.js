var e = require("../../common/vendor.js"),
  n = require("../../common/assets.js"),
  t = e.defineComponent({
    __name: "index",
    props: {
      title: { type: String, default: "你有一封来信" },
      messageId: { type: String, default: "" },
      type: Object,
    },
    setup: function (t, o) {
      var r = o.expose,
        u = e.ref(!1),
        c = e.ref({}),
        a = function () {
          (u.value = !1), (c.value = {});
        },
        l = function () {
          var e, n;
          null == (n = (e = c.value).reject) || n.call(e, { cancel: !0 }), a();
        },
        i = function () {},
        s = function () {
          var e, n;
          null == (n = (e = c.value).resolve) || n.call(e, { confirm: !0 }),
            a();
        };
      return (
        r({
          open: function () {
            return (
              (u.value = !0),
              new Promise(function (e, n) {
                c.value = { resolve: e, reject: n };
              })
            );
          },
          close: a,
        }),
        function (o, r) {
          return e.e(
            { a: u.value },
            u.value
              ? {
                  b: n._imports_0$13,
                  c: e.o(l),
                  d: e.t(t.title),
                  e: e.o(s),
                  f: e.o(function () {}),
                  g: e.o(i),
                }
              : {}
          );
        }
      );
    },
  }),
  o = e._export_sfc(t, [["__scopeId", "data-v-0f6c9d06"]]);
wx.createComponent(o);
