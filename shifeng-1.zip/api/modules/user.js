var e = (function (e) {
  return (
    (e[(e.Unknown = 0)] = "Unknown"),
    (e[(e.Male = 1)] = "Male"),
    (e[(e.Female = 2)] = "Female"),
    e
  );
})(e || {});
exports.Gender = e;
