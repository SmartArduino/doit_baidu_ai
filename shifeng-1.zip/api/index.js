var t = require("../tools/request.js");
(exports.actionCoding = function (e) {
  return t.request({
    url: "/api/v1/toystory/wechat/device/action/coding",
    method: "POST",
    data: e,
  });
}),
  (exports.actionList = function (e) {
    var r = e.sn;
    return t.request({
      url: "/api/v1/toystory/wechat/device/action/list",
      method: "GET",
      data: { sn: r },
    });
  }),
  (exports.bindTraceId = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/bindTraceId",
      method: "get",
      data: e,
    });
  }),
  (exports.characterBind = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/setting/character/bind",
      method: "POST",
      data: e,
    });
  }),
  (exports.characterInfo = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/setting/character/info",
      method: "GET",
      data: e,
    });
  }),
  (exports.characterList = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/setting/character/list",
      method: "get",
      data: e,
    });
  }),
  (exports.commonFileUpload = function (e) {
    return t.uploadFile({
      url: "/api/v1/toystory/wechat/common/fileUpload",
      filePath: e,
      name: "file",
    });
  }),
  (exports.contentH5Url = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/content/h5/url",
      method: "GET",
      data: e,
    });
  }),
  (exports.deviceCommandConfig = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/command/config",
      method: "GET",
      data: e,
    });
  }),
  (exports.deviceCommandSend = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/command/send",
      method: "POST",
      data: e,
    });
  }),
  (exports.deviceConnect = function (e) {
    return t.request({
      url: "http://192.168.1.1/connect",
      method: "GET",
      data: e,
    });
  }),
  (exports.deviceProduct = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/device/product",
      method: "GET",
      data: e,
    });
  }),
  (exports.deviceReset = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/reset",
      method: "POST",
      data: e,
    });
  }),
  (exports.deviceSetting = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/setting",
      method: "get",
      data: e,
    });
  }),
  (exports.deviceSettingVolume = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/setting/volume",
      method: "POST",
      data: e,
    });
  }),
  (exports.deviceSwitch = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/switch",
      method: "POST",
      data: e,
    });
  }),
  (exports.disableConfigDelete = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/setting/disableConfig/delete",
      method: "POST",
      data: e,
    });
  }),
  (exports.disableConfigList = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/setting/disableConfig/list",
      method: "GET",
      data: e,
    });
  }),
  (exports.disableConfigSave = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/setting/disableConfig/save",
      method: "POST",
      data: e,
    });
  }),
  (exports.familyUserList = function () {
    return t.request({
      url: "/api/v1/toystory/wechat/family/user/list",
      method: "GET",
    });
  }),
  (exports.familyUserOwner = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/family/user/owner",
      method: "POST",
      data: e,
    });
  }),
  (exports.familyUserRemove = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/family/user/remove",
      method: "POST",
      data: e,
    });
  }),
  (exports.familyUserShareCode = function () {
    return t.request({
      url: "/api/v1/toystory/wechat/family/shareCode",
      method: "GET",
    });
  }),
  (exports.familyUserUpdate = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/family/user/update",
      method: "POST",
      data: e,
    });
  }),
  (exports.familyUserUseShareCode = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/family/shareCode/".concat(e.shareCode),
      method: "POST",
    });
  }),
  (exports.feedbackSubmit = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/feedback/submit",
      method: "POST",
      data: e,
    });
  }),
  (exports.feedbackTypeList = function () {
    return t.request({
      url: "/api/v1/toystory/wechat/feedback/typeList",
      method: "GET",
    });
  }),
  (exports.functionOpen = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/function/open",
      method: "POST",
      data: e,
    });
  }),
  (exports.isBindDevice = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/isBind",
      method: "GET",
      data: e,
    });
  }),
  (exports.login = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/login/session",
      method: "POST",
      data: e,
    });
  }),
  (exports.logout = function () {
    return t.request({
      url: "/api/v1/toystory/wechat/login/logout",
      method: "POST",
    });
  }),
  (exports.manufacturerNetworkTips = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/device/manufacturer/networkTips?appId=".concat(
        e
      ),
      method: "GET",
    });
  }),
  (exports.messageInfo = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/notice/message/info",
      method: "GET",
      data: e,
    });
  }),
  (exports.messageList = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/notice/message/list",
      method: "GET",
      data: e,
    });
  }),
  (exports.messagePopup = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/notice/message/popup",
      method: "GET",
      data: e,
    });
  }),
  (exports.messageQuestionList = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/message/question/list".concat(
        e ? "?cursorId=".concat(e) : ""
      ),
      method: "GET",
    });
  }),
  (exports.messageReportDaily = function (e) {
    return t.request({
      url:
        "/api/v1/toystory/wechat/message/report/daily?reportDate=" +
        e.reportDate,
      method: "GET",
      data: e,
    });
  }),
  (exports.promptAddAPI = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/device/prompt/add",
      method: "POST",
      data: e,
    });
  }),
  (exports.promptDeleteAPI = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/device/prompt/delete/".concat(e),
      method: "POST",
    });
  }),
  (exports.promptListAPI = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/device/prompt/list/".concat(e.sn),
      method: "GET",
    });
  }),
  (exports.promptUpdateStatusAPI = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/device/prompt/update/status",
      method: "POST",
      data: e,
    });
  }),
  (exports.putDataTracking = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/dataTracking",
      method: "post",
      data: e,
    });
  }),
  (exports.readAllMessage = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/notice/message/readAll",
      method: "POST",
      data: e,
    });
  }),
  (exports.reportWeekly = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/message/report/weekly",
      method: "GET",
      data: e,
    });
  }),
  (exports.sceneInfo = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/function/scene/info",
      method: "GET",
      data: e,
    });
  }),
  (exports.sceneList = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/function/scene/list",
      method: "GET",
      data: e,
    });
  }),
  (exports.settingBrightness = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/setting/brightness",
      method: "POST",
      data: e,
    });
  }),
  (exports.settingNickname = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/setting/nickname",
      method: "POST",
      data: e,
    });
  }),
  (exports.switchChatMode = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/setting/chatMode",
      method: "POST",
      data: e,
    });
  }),
  (exports.userDeviceList = function () {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/list",
      method: "GET",
    });
  }),
  (exports.userDeviceUnbind = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/device/unbind",
      method: "POST",
      data: e,
    });
  }),
  (exports.versionInfo = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/version/info",
      method: "GET",
      data: e,
    });
  }),
  (exports.versionList = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/version/list?sn=".concat(e.sn),
      method: "GET",
      data: e,
    });
  }),
  (exports.wechatConfigBasic = function () {
    return t.request({
      url: "/api/v1/toystory/wechat/config/basic",
      method: "GET",
    });
  }),
  (exports.wechatMessageList = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/message/list?messageDate=" + e.messageDate,
      method: "GET",
      data: e,
    });
  }),
  (exports.wechatUserInfo = function () {
    return t.request({
      url: "/api/v1/toystory/wechat/user/info",
      method: "GET",
    });
  }),
  (exports.wechatUserInfoUpdate = function (e) {
    return t.request({
      url: "/api/v1/toystory/wechat/user/info/update",
      method: "POST",
      data: {
        nickname: e.nickname,
        gender: e.gender,
        birthdate: e.birthdate,
        avatar: e.avatar,
      },
    });
  });
