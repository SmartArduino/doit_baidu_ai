var e = require("../common/vendor.js"),
  o = require("../config/config.js");
function t(t, n, r) {
  var i = o.getConfig().apiUrl,
    s = e.index.getAccountInfoSync().miniProgram.envVersion,
    a = e.index.getStorageSync(s + "token");
  !(function (e) {
    for (
      var o = [
          "/api/v1/toystory/wechat/login/session" == e.url &&
            "POST" == e.method,
        ],
        t = !1,
        n = 0,
        r = o;
      n < r.length;
      n++
    ) {
      r[n] && (t = !0);
    }
    return t;
  })(t)
    ? e.index.request({
        url: t.url.includes("http") ? t.url : i + t.url,
        method: t.method,
        header: { accessToken: a },
        data: t.data,
        success: function (o) {
          return (
            console.log("response", o),
            401 == o.statusCode || "A00002" == o.data.resultCode
              ? (e.index.showToast({
                  icon: "none",
                  title: o.data.resultMsg || "登录已过期，请重新登录",
                  duration: 2e3,
                }),
                e.index.removeStorageSync(s + "token"),
                void setTimeout(function () {
                  r(o);
                }, 2e3))
              : ("A00000" !== o.data.resultCode &&
                  e.index.showToast({
                    icon: "none",
                    title: o.data.resultMsg,
                    duration: 2e3,
                  }),
                console.log("response.statusCode", o.statusCode),
                "A00000" === o.data.resultCode || 200 === o.statusCode
                  ? n(o)
                  : (e.index.showToast({
                      icon: "none",
                      title: o.data.resultMsg,
                      duration: 2e3,
                    }),
                    void r(o)))
          );
        },
        fail: function (e) {
          return console.log("error", e), r(e);
        },
        complete: function () {},
      })
    : e.index.request({
        url: i + t.url,
        method: t.method,
        data: t.data,
        success: function (e) {
          return n(e);
        },
        fail: function (e) {
          return r(e);
        },
        complete: function () {},
      });
}
(exports.request = function () {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  return new Promise(function (o, n) {
    t(e, o, n);
  });
}),
  (exports.uploadFile = function (t) {
    return new Promise(function (n, r) {
      var i = o.getConfig().apiUrl,
        s = e.index.getAccountInfoSync().miniProgram.envVersion,
        a = e.index.getStorageSync(s + "token");
      e.index.uploadFile({
        url: t.url.includes("http") ? t.url : i + t.url,
        filePath: t.filePath,
        name: t.name,
        formData: t.formData || {},
        header: { accessToken: a },
        success: function (o) {
          console.log("res upload", o);
          try {
            var t = JSON.parse(o.data);
            if (401 == o.statusCode || "A00002" == t.resultCode)
              return (
                e.index.showToast({
                  icon: "none",
                  title: t.resultMsg || "登录已过期，请重新登录",
                  duration: 2e3,
                }),
                e.index.removeStorageSync(s + "token"),
                void setTimeout(function () {
                  e.index.reLaunch({ url: "/pages/login/index" });
                }, 2e3)
              );
            console.log("data upload", t),
              "A00000" === t.resultCode
                ? n(t)
                : (e.index.showToast({
                    icon: "none",
                    title: t.resultMsg || "上传失败",
                    duration: 2e3,
                  }),
                  r(t));
          } catch (e) {
            r(o);
          }
        },
        fail: function (o) {
          e.index.showToast({ icon: "none", title: "上传失败", duration: 2e3 }),
            r(o);
        },
      });
    });
  });
