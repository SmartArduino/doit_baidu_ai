var o = require("../common/vendor.js");
exports.impower = function () {
  return new Promise(function (n, c) {
    o.wx$1.authorize({
      scope: "scope.userLocation",
      success: function (o) {
        n({ code: "200" });
      },
      fail: function () {
        c({ code: "400" }),
          o.wx$1.showModal({
            title: "提示",
            content: "您未授权定位，功能将无法使用",
            showCancel: !0,
            confirmText: "授权",
            confirmColor: "#AF1F25",
            success: function (n) {
              n.confirm
                ? o.wx$1.openSetting({
                    success: function (n) {
                      n.authSetting["scope.userLocation"] ||
                        o.wx$1.showModal({
                          title: "提示",
                          content: "您未授权定位服务，功能将无法使用",
                          showCancel: !1,
                          success: function (o) {},
                        });
                    },
                    fail: function () {
                      o.wx$1.showToast({
                        title: "定位授权失败",
                        icon: "error",
                        mask: !0,
                      });
                    },
                  })
                : n.cancel;
            },
            fail: function () {},
          });
      },
    });
  });
};
