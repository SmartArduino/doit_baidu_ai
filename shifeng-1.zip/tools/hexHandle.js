(exports.buf2hex = function (r) {
  return Array.prototype.map
    .call(new Uint8Array(r), function (r) {
      return ("00" + r.toString(16)).slice(-2);
    })
    .join("");
}),
  (exports.hexToStr = function (r) {
    for (var t = "", n = 0; n < r.length; n += 2)
      t += String.fromCharCode(parseInt(r.substr(n, 2), 16));
    return t;
  });
