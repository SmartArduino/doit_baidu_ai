exports.arrayBufferToString = function (r) {
  if ("string" == typeof r) return r;
  for (
    var t = new DataView(r), e = new Uint8Array(r.byteLength), n = 0;
    n < e.length;
    n++
  )
    e[n] = t.getUint8(n);
  for (var i = "", o = (r = e), a = 0; a < o.length; a++) {
    var g = o[a].toString(2),
      f = g.match(/^1+?(?=0)/);
    if (f && 8 === g.length) {
      for (
        var h = f[0].length, s = o[a].toString(2).slice(7 - h), l = 1;
        l < h;
        l++
      )
        s += o[l + a].toString(2).slice(2);
      (i += String.fromCharCode(parseInt(s, 2))), (a += h - 1);
    } else i += String.fromCharCode(o[a]);
  }
  return i;
};
