var o = require("../common/vendor.js");
exports.impower = function () {
  return new Promise(function (c, n) {
    o.wx$1.authorize({
      scope: "scope.record",
      success: function (o) {
        c({ code: "200" });
      },
      fail: function () {
        n({ code: "400" }),
          o.wx$1.showModal({
            title: "提示",
            content: "您未授权录音，功能将无法使用",
            showCancel: !0,
            confirmText: "授权",
            confirmColor: "#AF1F25",
            success: function (c) {
              c.confirm
                ? o.wx$1.openSetting({
                    success: function (c) {
                      c.authSetting["scope.record"] ||
                        o.wx$1.showModal({
                          title: "提示",
                          content: "您未授权录音，功能将无法使用",
                          showCancel: !1,
                          success: function (o) {},
                        });
                    },
                    fail: function () {
                      o.wx$1.showToast({
                        title: "授权设置录音失败",
                        icon: "error",
                        mask: !0,
                      });
                    },
                  })
                : c.cancel;
            },
            fail: function () {},
          });
      },
    });
  });
};
