var e = require("../@babel/runtime/helpers/assertThisInitialized");
require("../@babel/runtime/helpers/Arrayincludes");
var t,
  n,
  r = require("../@babel/runtime/helpers/regeneratorRuntime"),
  o = require("../@babel/runtime/helpers/asyncToGenerator"),
  i = require("../@babel/runtime/helpers/objectSpread2"),
  a = require("../@babel/runtime/helpers/wrapNativeSuper"),
  s = require("../@babel/runtime/helpers/possibleConstructorReturn"),
  c = require("../@babel/runtime/helpers/getPrototypeOf"),
  u = require("../@babel/runtime/helpers/inherits"),
  f = require("../@babel/runtime/helpers/classCallCheck"),
  l = require("../@babel/runtime/helpers/createClass"),
  p = require("../@babel/runtime/helpers/defineProperty"),
  h = require("../@babel/runtime/helpers/toConsumableArray"),
  d = require("../@babel/runtime/helpers/typeof"),
  v = require("../@babel/runtime/helpers/slicedToArray"),
  g = require("../@babel/runtime/helpers/createForOfIteratorHelper");
function m(e, t, n) {
  return (
    (t = c(t)),
    s(
      e,
      (function () {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
          return !Boolean.prototype.valueOf.call(
            Reflect.construct(Boolean, [], function () {})
          );
        } catch (e) {
          return !1;
        }
      })()
        ? Reflect.construct(t, n || [], c(e).constructor)
        : t.apply(e, n)
    )
  );
}
function y(e, t) {
  var n = new Set(e.split(","));
  return function (e) {
    return n.has(e);
  };
}
var _,
  b = Object.freeze({}),
  w = Object.freeze([]),
  k = function () {},
  x = function () {
    return !1;
  },
  S = function (e) {
    return (
      111 === e.charCodeAt(0) &&
      110 === e.charCodeAt(1) &&
      (e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97)
    );
  },
  P = function (e) {
    return e.startsWith("onUpdate:");
  },
  T = Object.assign,
  O = function (e, t) {
    var n = e.indexOf(t);
    n > -1 && e.splice(n, 1);
  },
  A = Object.prototype.hasOwnProperty,
  I = function (e, t) {
    return A.call(e, t);
  },
  C = Array.isArray,
  E = function (e) {
    return "[object Map]" === N(e);
  },
  L = function (e) {
    return "[object Set]" === N(e);
  },
  $ = function (e) {
    return "function" == typeof e;
  },
  R = function (e) {
    return "string" == typeof e;
  },
  j = function (e) {
    return "symbol" === d(e);
  },
  M = function (e) {
    return null !== e && "object" === d(e);
  },
  D = function (e) {
    return (M(e) || $(e)) && $(e.then) && $(e.catch);
  },
  U = Object.prototype.toString,
  N = function (e) {
    return U.call(e);
  },
  q = function (e) {
    return N(e).slice(8, -1);
  },
  B = function (e) {
    return "[object Object]" === N(e);
  },
  F = function (e) {
    return R(e) && "NaN" !== e && "-" !== e[0] && "" + parseInt(e, 10) === e;
  },
  H = y(
    ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"
  ),
  V = y(
    "bind,cloak,else-if,else,for,html,if,model,on,once,pre,show,slot,text,memo"
  ),
  K = function (e) {
    var t = Object.create(null);
    return function (n) {
      return t[n] || (t[n] = e(n));
    };
  },
  W = /-(\w)/g,
  z = K(function (e) {
    return e.replace(W, function (e, t) {
      return t ? t.toUpperCase() : "";
    });
  }),
  J = /\B([A-Z])/g,
  Y = K(function (e) {
    return e.replace(J, "-$1").toLowerCase();
  }),
  Q = K(function (e) {
    return e.charAt(0).toUpperCase() + e.slice(1);
  }),
  G = K(function (e) {
    return e ? "on".concat(Q(e)) : "";
  }),
  X = function (e, t) {
    return !Object.is(e, t);
  },
  Z = function (e, t) {
    for (var n = 0; n < e.length; n++) e[n](t);
  },
  ee = function (e) {
    var t = parseFloat(e);
    return isNaN(t) ? e : t;
  },
  te = function () {
    return (
      _ ||
      (_ =
        "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : {})
    );
  };
var ne = /;(?![^(]*\))/g,
  re = /:([^]+)/,
  oe = /\/\*[^]*?\*\//g;
function ie(e) {
  var t = {};
  return (
    e
      .replace(oe, "")
      .split(ne)
      .forEach(function (e) {
        if (e) {
          var n = e.split(re);
          n.length > 1 && (t[n[0].trim()] = n[1].trim());
        }
      }),
    t
  );
}
var ae = function e(t, n) {
    return n && n.__v_isRef
      ? e(t, n.value)
      : E(n)
      ? p(
          {},
          "Map(".concat(n.size, ")"),
          h(n.entries()).reduce(function (e, t, n) {
            var r = v(t, 2),
              o = r[0],
              i = r[1];
            return (e[se(o, n) + " =>"] = i), e;
          }, {})
        )
      : L(n)
      ? p(
          {},
          "Set(".concat(n.size, ")"),
          h(n.values()).map(function (e) {
            return se(e);
          })
        )
      : j(n)
      ? se(n)
      : !M(n) || C(n) || B(n)
      ? n
      : String(n);
  },
  se = function (e) {
    var t,
      n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
    return j(e)
      ? "Symbol(".concat(null != (t = e.description) ? t : n, ")")
      : e;
  },
  ce = /:/g;
function ue(e) {
  return z(e.replace(ce, "-"));
}
function fe(e) {
  var t,
    n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
  return function () {
    if (e) {
      for (var r = arguments.length, o = new Array(r), i = 0; i < r; i++)
        o[i] = arguments[i];
      (t = e.apply(n, o)), (e = null);
    }
    return t;
  };
}
function le(e) {
  var t = {};
  return (
    B(e) &&
      Object.keys(e)
        .sort()
        .forEach(function (n) {
          var r = n;
          t[r] = e[r];
        }),
    Object.keys(t) ? t : e
  );
}
var pe = encodeURIComponent;
function he(e) {
  var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : pe,
    n = e
      ? Object.keys(e)
          .map(function (n) {
            var r = e[n];
            return (
              void 0 === d(r) || null === r
                ? (r = "")
                : B(r) && (r = JSON.stringify(r)),
              t(n) + "=" + t(r)
            );
          })
          .filter(function (e) {
            return e.length > 0;
          })
          .join("&")
      : null;
  return n ? "?".concat(n) : "";
}
var de = [
  "onInit",
  "onLoad",
  "onShow",
  "onHide",
  "onUnload",
  "onBackPress",
  "onPageScroll",
  "onTabItemTap",
  "onReachBottom",
  "onPullDownRefresh",
  "onShareTimeline",
  "onShareAppMessage",
  "onAddToFavorites",
  "onSaveExitState",
  "onNavigationBarButtonTap",
  "onNavigationBarSearchInputClicked",
  "onNavigationBarSearchInputChanged",
  "onNavigationBarSearchInputConfirmed",
  "onNavigationBarSearchInputFocusChanged",
];
function ve(e) {
  return de.indexOf(e) > -1;
}
var ge,
  me = [
    "onShow",
    "onHide",
    "onLaunch",
    "onError",
    "onThemeChange",
    "onPageNotFound",
    "onUnhandledRejection",
    "onExit",
    "onInit",
    "onLoad",
    "onReady",
    "onUnload",
    "onResize",
    "onBackPress",
    "onPageScroll",
    "onTabItemTap",
    "onReachBottom",
    "onPullDownRefresh",
    "onShareTimeline",
    "onAddToFavorites",
    "onShareAppMessage",
    "onSaveExitState",
    "onNavigationBarButtonTap",
    "onNavigationBarSearchInputClicked",
    "onNavigationBarSearchInputChanged",
    "onNavigationBarSearchInputConfirmed",
    "onNavigationBarSearchInputFocusChanged",
  ],
  ye = (function () {
    return { onPageScroll: 1, onShareAppMessage: 2, onShareTimeline: 4 };
  })();
function _e(e, t) {
  var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
  return !(n && !$(t)) && (me.indexOf(e) > -1 || 0 === e.indexOf("on"));
}
var be = [];
var we = fe(function (e, t) {
    if ($(e._component.onError)) return t(e);
  }),
  ke = function () {};
ke.prototype = {
  on: function (e, t, n) {
    var r = this.e || (this.e = {});
    return (r[e] || (r[e] = [])).push({ fn: t, ctx: n }), this;
  },
  once: function (e, t, n) {
    var r = this;
    function o() {
      r.off(e, o), t.apply(n, arguments);
    }
    return (o._ = t), this.on(e, o, n);
  },
  emit: function (e) {
    for (
      var t = [].slice.call(arguments, 1),
        n = ((this.e || (this.e = {}))[e] || []).slice(),
        r = 0,
        o = n.length;
      r < o;
      r++
    )
      n[r].fn.apply(n[r].ctx, t);
    return this;
  },
  off: function (e, t) {
    var n = this.e || (this.e = {}),
      r = n[e],
      o = [];
    if (r && t) {
      for (var i = r.length - 1; i >= 0; i--)
        if (r[i].fn === t || r[i].fn._ === t) {
          r.splice(i, 1);
          break;
        }
      o = r;
    }
    return o.length ? (n[e] = o) : delete n[e], this;
  },
};
var xe = ke,
  Se = ["{", "}"],
  Pe = (function () {
    return l(
      function e() {
        f(this, e), (this._caches = Object.create(null));
      },
      [
        {
          key: "interpolate",
          value: function (e, t) {
            var n =
              arguments.length > 2 && void 0 !== arguments[2]
                ? arguments[2]
                : Se;
            if (!t) return [e];
            var r = this._caches[e];
            return r || ((r = Ae(e, n)), (this._caches[e] = r)), Ie(r, t);
          },
        },
      ]
    );
  })(),
  Te = /^(?:\d)+/,
  Oe = /^(?:\w)+/;
function Ae(e, t) {
  for (
    var n = v(t, 2), r = n[0], o = n[1], i = [], a = 0, s = "";
    a < e.length;

  ) {
    var c = e[a++];
    if (c === r) {
      s && i.push({ type: "text", value: s }), (s = "");
      var u = "";
      for (c = e[a++]; void 0 !== c && c !== o; ) (u += c), (c = e[a++]);
      var f = c === o,
        l = Te.test(u) ? "list" : f && Oe.test(u) ? "named" : "unknown";
      i.push({ value: u, type: l });
    } else s += c;
  }
  return s && i.push({ type: "text", value: s }), i;
}
function Ie(e, t) {
  var n,
    r = [],
    o = 0,
    i = Array.isArray(t)
      ? "list"
      : null !== (n = t) && "object" === d(n)
      ? "named"
      : "unknown";
  if ("unknown" === i) return r;
  for (; o < e.length; ) {
    var a = e[o];
    switch (a.type) {
      case "text":
        r.push(a.value);
        break;
      case "list":
        r.push(t[parseInt(a.value, 10)]);
        break;
      case "named":
        "named" === i
          ? r.push(t[a.value])
          : console.warn(
              "Type of token '"
                .concat(a.type, "' and format of value '")
                .concat(i, "' don't match!")
            );
        break;
      case "unknown":
        console.warn("Detect 'unknown' type of token!");
    }
    o++;
  }
  return r;
}
var Ce = Object.prototype.hasOwnProperty,
  Ee = function (e, t) {
    return Ce.call(e, t);
  },
  Le = new Pe();
function $e(e, t) {
  if (e) {
    if (((e = e.trim().replace(/_/g, "-")), t && t[e])) return e;
    if ("chinese" === (e = e.toLowerCase())) return "zh-Hans";
    if (0 === e.indexOf("zh"))
      return e.indexOf("-hans") > -1
        ? "zh-Hans"
        : e.indexOf("-hant") > -1
        ? "zh-Hant"
        : ((n = e),
          ["-tw", "-hk", "-mo", "-cht"].find(function (e) {
            return -1 !== n.indexOf(e);
          })
            ? "zh-Hant"
            : "zh-Hans");
    var n,
      r = ["en", "fr", "es"];
    t && Object.keys(t).length > 0 && (r = Object.keys(t));
    var o = (function (e, t) {
      return t.find(function (t) {
        return 0 === e.indexOf(t);
      });
    })(e, r);
    return o || void 0;
  }
}
var Re = (function () {
  return l(
    function e(t) {
      var n = t.locale,
        r = t.fallbackLocale,
        o = t.messages,
        i = t.watcher,
        a = t.formater;
      f(this, e),
        (this.locale = "en"),
        (this.fallbackLocale = "en"),
        (this.message = {}),
        (this.messages = {}),
        (this.watchers = []),
        r && (this.fallbackLocale = r),
        (this.formater = a || Le),
        (this.messages = o || {}),
        this.setLocale(n || "en"),
        i && this.watchLocale(i);
    },
    [
      {
        key: "setLocale",
        value: function (e) {
          var t = this,
            n = this.locale;
          (this.locale = $e(e, this.messages) || this.fallbackLocale),
            this.messages[this.locale] || (this.messages[this.locale] = {}),
            (this.message = this.messages[this.locale]),
            n !== this.locale &&
              this.watchers.forEach(function (e) {
                e(t.locale, n);
              });
        },
      },
      {
        key: "getLocale",
        value: function () {
          return this.locale;
        },
      },
      {
        key: "watchLocale",
        value: function (e) {
          var t = this,
            n = this.watchers.push(e) - 1;
          return function () {
            t.watchers.splice(n, 1);
          };
        },
      },
      {
        key: "add",
        value: function (e, t) {
          var n =
              !(arguments.length > 2 && void 0 !== arguments[2]) ||
              arguments[2],
            r = this.messages[e];
          r
            ? n
              ? Object.assign(r, t)
              : Object.keys(t).forEach(function (e) {
                  Ee(r, e) || (r[e] = t[e]);
                })
            : (this.messages[e] = t);
        },
      },
      {
        key: "f",
        value: function (e, t, n) {
          return this.formater.interpolate(e, t, n).join("");
        },
      },
      {
        key: "t",
        value: function (e, t, n) {
          var r = this.message;
          return (
            "string" == typeof t
              ? (t = $e(t, this.messages)) && (r = this.messages[t])
              : (n = t),
            Ee(r, e)
              ? this.formater.interpolate(r[e], n).join("")
              : (console.warn(
                  "Cannot translate the value of keypath ".concat(
                    e,
                    ". Use the value of keypath as default."
                  )
                ),
                e)
          );
        },
      },
    ]
  );
})();
function je(e, t) {
  e.$watchLocale
    ? e.$watchLocale(function (e) {
        t.setLocale(e);
      })
    : e.$watch(
        function () {
          return e.$locale;
        },
        function (e) {
          t.setLocale(e);
        }
      );
}
function Me() {
  return void 0 !== Dn && Dn.getLocale
    ? Dn.getLocale()
    : "undefined" != typeof global && global.getLocale
    ? global.getLocale()
    : "en";
}
function De(e, t) {
  console.warn("".concat(e, ": ").concat(t));
}
function Ue(e, t, n, r) {
  for (var o in (r || (r = De), n)) {
    var i = Ne(o, t[o], n[o], !I(t, o));
    R(i) && r(e, i);
  }
}
function Ne(e, t, n, r) {
  B(n) || (n = { type: n });
  var o = n,
    i = o.type,
    a = o.required,
    s = o.validator;
  if (a && r) return 'Missing required args: "' + e + '"';
  if (null != t || a) {
    if (null != i) {
      for (
        var c = !1, u = C(i) ? i : [i], f = [], l = 0;
        l < u.length && !c;
        l++
      ) {
        var p = Be(t, u[l]),
          h = p.valid,
          d = p.expectedType;
        f.push(d || ""), (c = h);
      }
      if (!c)
        return (function (e, t, n) {
          var r = 'Invalid args: type check failed for args "'
              .concat(e, '". Expected ')
              .concat(n.map(Q).join(", ")),
            o = n[0],
            i = q(t),
            a = Fe(t, o),
            s = Fe(t, i);
          1 === n.length &&
            He(o) &&
            !(function () {
              for (
                var e = arguments.length, t = new Array(e), n = 0;
                n < e;
                n++
              )
                t[n] = arguments[n];
              return t.some(function (e) {
                return "boolean" === e.toLowerCase();
              });
            })(o, i) &&
            (r += " with value ".concat(a));
          (r += ", got ".concat(i, " ")),
            He(i) && (r += "with value ".concat(s, "."));
          return r;
        })(e, t, f);
    }
    return s ? s(t) : void 0;
  }
}
var qe = y("String,Number,Boolean,Function,Symbol");
function Be(e, t) {
  var n,
    r,
    o,
    i = (o = (r = t) && r.toString().match(/^\s*function (\w+)/)) ? o[1] : "";
  if (qe(i)) {
    var a = d(e);
    (n = a === i.toLowerCase()) || "object" !== a || (n = e instanceof t);
  } else n = "Object" === i ? M(e) : "Array" === i ? C(e) : e instanceof t;
  return { valid: n, expectedType: i };
}
function Fe(e, t) {
  return "String" === t
    ? '"'.concat(e, '"')
    : "".concat("Number" === t ? Number(e) : e);
}
function He(e) {
  return ["string", "number", "boolean"].some(function (t) {
    return e.toLowerCase() === t;
  });
}
function Ve(e) {
  return function () {
    try {
      return e.apply(e, arguments);
    } catch (e) {
      console.error(e);
    }
  };
}
var Ke = 1,
  We = {};
function ze(e, t, n) {
  var r = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
  return (We[e] = { name: t, keepAlive: r, callback: n }), e;
}
function Je(e, t, n) {
  if ("number" == typeof e) {
    var r = We[e];
    if (r) return r.keepAlive || delete We[e], r.callback(t, n);
  }
  return t;
}
var Ye = "success",
  Qe = "fail",
  Ge = "complete";
function Xe(e) {
  var t = {};
  for (var n in e) {
    var r = e[n];
    $(r) && ((t[n] = Ve(r)), delete e[n]);
  }
  return t;
}
function Ze(e, t) {
  return e && -1 !== e.indexOf(":fail")
    ? t + e.substring(e.indexOf(":fail"))
    : t + ":ok";
}
var et = "success",
  tt = "fail",
  nt = "complete",
  rt = {},
  ot = {};
function it(e, t) {
  return function (n) {
    return e(n, t) || n;
  };
}
function at(e, t, n) {
  for (var r = !1, o = 0; o < e.length; o++) {
    var i = e[o];
    if (r) r = Promise.resolve(it(i, n));
    else {
      var a = i(t, n);
      if ((D(a) && (r = Promise.resolve(a)), !1 === a))
        return { then: function () {}, catch: function () {} };
    }
  }
  return (
    r || {
      then: function (e) {
        return e(t);
      },
      catch: function () {},
    }
  );
}
function st(e) {
  var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
  return (
    [et, tt, nt].forEach(function (n) {
      var r = e[n];
      if (C(r)) {
        var o = t[n];
        t[n] = function (e) {
          at(r, e, t).then(function (e) {
            return ($(o) && o(e)) || e;
          });
        };
      }
    }),
    t
  );
}
function ct(e, t) {
  var n = [];
  C(rt.returnValue) && n.push.apply(n, h(rt.returnValue));
  var r = ot[e];
  return (
    r && C(r.returnValue) && n.push.apply(n, h(r.returnValue)),
    n.forEach(function (e) {
      t = e(t) || t;
    }),
    t
  );
}
function ut(e) {
  var t = Object.create(null);
  Object.keys(rt).forEach(function (e) {
    "returnValue" !== e && (t[e] = rt[e].slice());
  });
  var n = ot[e];
  return (
    n &&
      Object.keys(n).forEach(function (e) {
        "returnValue" !== e && (t[e] = (t[e] || []).concat(n[e]));
      }),
    t
  );
}
function ft(e, t, n, r) {
  var o = ut(e);
  return o && Object.keys(o).length
    ? C(o.invoke)
      ? at(o.invoke, n).then(function (n) {
          return t.apply(void 0, [st(ut(e), n)].concat(h(r)));
        })
      : t.apply(void 0, [st(o, n)].concat(h(r)))
    : t.apply(void 0, [n].concat(h(r)));
}
function lt(e) {
  return !(
    !B(e) ||
    ![Ye, Qe, Ge].find(function (t) {
      return $(e[t]);
    })
  );
}
function pt(e, t, n) {
  var r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
    o = t + ":fail" + (n ? " " + n : "");
  delete r.errCode;
  var i = T({ errMsg: o }, r);
  return Je(e, i);
}
function ht(e, t, n, r) {
  !(function (e, t, n, r) {
    if (n) {
      if (!C(n)) return Ue(e, t[0] || Object.create(null), n, r);
      for (var o = n.length, i = t.length, a = 0; a < o; a++) {
        var s = n[a],
          c = Object.create(null);
        i > a && (c[s.name] = t[a]), Ue(e, c, p({}, s.name, s), r);
      }
    }
  })(e, t, n);
  var o = (function (e, t) {
    e[0];
  })(t);
  if (o) return o;
}
function dt(e, t, n, r) {
  return function (o) {
    var i = (function (e) {
        var t =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          n =
            arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
          r = n.beforeAll,
          o = n.beforeSuccess;
        B(t) || (t = {});
        var i = Xe(t),
          a = i.success,
          s = i.fail,
          c = i.complete,
          u = $(a),
          f = $(s),
          l = $(c),
          p = Ke++;
        return (
          ze(p, e, function (n) {
            ((n = n || {}).errMsg = Ze(n.errMsg, e)),
              $(r) && r(n),
              n.errMsg === e + ":ok" ? ($(o) && o(n, t), u && a(n)) : f && s(n),
              l && c(n);
          }),
          p
        );
      })(e, o, r),
      a = ht(e, [o], n);
    return a
      ? pt(i, e, a)
      : t(o, {
          resolve: function (t) {
            return (function (e, t, n) {
              return Je(e, T(n || {}, { errMsg: t + ":ok" }));
            })(i, e, t);
          },
          reject: function (t, n) {
            return pt(
              i,
              e,
              (function (e) {
                return !e || R(e)
                  ? e
                  : e.stack
                  ? (console.error(e.message + "\n" + e.stack), e.message)
                  : e;
              })(t),
              n
            );
          },
        });
  };
}
function vt(e, t, n, r) {
  return (function (e, t, n, r) {
    return function () {
      for (var r = arguments.length, o = new Array(r), i = 0; i < r; i++)
        o[i] = arguments[i];
      var a = ht(e, o, n);
      if (a) throw new Error(a);
      return t.apply(null, o);
    };
  })(e, t, n);
}
var gt = !1,
  mt = 0,
  yt = 0;
function _t() {
  var e = wx.getSystemInfoSync(),
    t = e.platform,
    n = e.pixelRatio,
    r = e.windowWidth;
  (mt = r), (yt = n), (gt = "ios" === t);
}
var bt = vt(
    "upx2px",
    function (e, t) {
      if ((0 === mt && _t(), 0 === (e = Number(e)))) return 0;
      var n = (e / 750) * (t || mt);
      return (
        n < 0 && (n = -n),
        0 === (n = Math.floor(n + 1e-4)) && (n = 1 !== yt && gt ? 0.5 : 1),
        e < 0 ? -n : n
      );
    },
    [{ name: "upx", type: [Number, String], required: !0 }]
  ),
  wt = [{ name: "method", type: [String, Object], required: !0 }],
  kt = wt;
function xt(e, t) {
  Object.keys(t).forEach(function (n) {
    var r, o, i;
    $(t[n]) &&
      (e[n] =
        ((r = e[n]),
        (o = t[n]),
        (i = o ? (r ? r.concat(o) : C(o) ? o : [o]) : r)
          ? (function (e) {
              for (var t = [], n = 0; n < e.length; n++)
                -1 === t.indexOf(e[n]) && t.push(e[n]);
              return t;
            })(i)
          : i));
  });
}
function St(e, t) {
  e &&
    t &&
    Object.keys(t).forEach(function (n) {
      var r = e[n],
        o = t[n];
      C(r) && $(o) && O(r, o);
    });
}
var Pt,
  Tt,
  Ot,
  At = vt(
    "addInterceptor",
    function (e, t) {
      R(e) && B(t) ? xt(ot[e] || (ot[e] = {}), t) : B(e) && xt(rt, e);
    },
    wt
  ),
  It = vt(
    "removeInterceptor",
    function (e, t) {
      R(e) ? (B(t) ? St(ot[e], t) : delete ot[e]) : B(e) && St(rt, e);
    },
    kt
  ),
  Ct = [
    { name: "event", type: String, required: !0 },
    { name: "callback", type: Function, required: !0 },
  ],
  Et = Ct,
  Lt = [
    { name: "event", type: [String, Array] },
    { name: "callback", type: Function },
  ],
  $t = [{ name: "event", type: String, required: !0 }],
  Rt = new xe(),
  jt = vt(
    "$on",
    function (e, t) {
      return (
        Rt.on(e, t),
        function () {
          return Rt.off(e, t);
        }
      );
    },
    Ct
  ),
  Mt = vt(
    "$once",
    function (e, t) {
      return (
        Rt.once(e, t),
        function () {
          return Rt.off(e, t);
        }
      );
    },
    Et
  ),
  Dt = vt(
    "$off",
    function (e, t) {
      e
        ? (C(e) || (e = [e]),
          e.forEach(function (e) {
            return Rt.off(e, t);
          }))
        : (Rt.e = {});
    },
    Lt
  ),
  Ut = vt(
    "$emit",
    function (e) {
      for (
        var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1;
        r < t;
        r++
      )
        n[r - 1] = arguments[r];
      Rt.emit.apply(Rt, [e].concat(n));
    },
    $t
  );
function Nt(e) {
  try {
    return JSON.parse(e);
  } catch (e) {}
  return e;
}
var qt = [];
function Bt(e, t) {
  qt.forEach(function (n) {
    n(e, t);
  }),
    (qt.length = 0);
}
var Ft,
  Ht,
  Vt,
  Kt = (function (e, t) {
    return function () {
      for (
        var n =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          r = arguments.length,
          o = new Array(r > 1 ? r - 1 : 0),
          i = 1;
        i < r;
        i++
      )
        o[i - 1] = arguments[i];
      return lt(n)
        ? ct(e, ft(e, t, n, o))
        : ct(
            e,
            new Promise(function (r, i) {
              ft(e, t, T(n, { success: r, fail: i }), o);
            })
          );
    };
  })(
    (Ft = "getPushClientId"),
    (function (e, t, n, r) {
      return dt(e, t, n, r);
    })(
      Ft,
      function (e, t) {
        var n = t.resolve,
          r = t.reject;
        Promise.resolve().then(function () {
          void 0 === Ot &&
            ((Ot = !1), (Pt = ""), (Tt = "uniPush is not enabled")),
            qt.push(function (e, t) {
              e ? n({ cid: e }) : r(t);
            }),
            void 0 !== Pt && Bt(Pt, Tt);
        });
      },
      Ht,
      Vt
    )
  ),
  Wt = [],
  zt =
    /^\$|getLocale|setLocale|sendNativeEvent|restoreGlobal|requireGlobal|getCurrentSubNVue|getMenuButtonBoundingClientRect|^report|interceptors|Interceptor$|getSubNVueById|requireNativePlugin|upx2px|hideKeyboard|canIUse|^create|Sync$|Manager$|base64ToArrayBuffer|arrayBufferToBase64|getDeviceInfo|getAppBaseInfo|getWindowInfo|getSystemSetting|getAppAuthorizeSetting/,
  Jt = /^create|Manager$/,
  Yt = ["createBLEConnection"],
  Qt = ["createBLEConnection"],
  Gt = /^on|^off/;
function Xt(e) {
  return Jt.test(e) && -1 === Yt.indexOf(e);
}
function Zt(e) {
  return zt.test(e) && -1 === Qt.indexOf(e);
}
function en(e) {
  return !(
    Xt(e) ||
    Zt(e) ||
    (function (e) {
      return Gt.test(e) && "onPush" !== e;
    })(e)
  );
}
function tn(e, t) {
  return en(e) && $(t)
    ? function () {
        for (
          var n =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : {},
            r = arguments.length,
            o = new Array(r > 1 ? r - 1 : 0),
            i = 1;
          i < r;
          i++
        )
          o[i - 1] = arguments[i];
        return $(n.success) || $(n.fail) || $(n.complete)
          ? ct(e, ft(e, t, n, o))
          : ct(
              e,
              new Promise(function (r, i) {
                ft(e, t, T({}, n, { success: r, fail: i }), o);
              })
            );
      }
    : t;
}
Promise.prototype.finally ||
  (Promise.prototype.finally = function (e) {
    var t = this.constructor;
    return this.then(
      function (n) {
        return t.resolve(e && e()).then(function () {
          return n;
        });
      },
      function (n) {
        return t.resolve(e && e()).then(function () {
          throw n;
        });
      }
    );
  });
var nn = ["success", "fail", "cancel", "complete"];
function rn(e) {
  function t(e, t, n) {
    return function (o) {
      return t(r(e, o, n));
    };
  }
  function n(e, n) {
    var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
      o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
      i = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
    if (B(n)) {
      var a = !0 === i ? n : {};
      for (var s in ($(r) && (r = r(n, a) || {}), n))
        if (I(r, s)) {
          var c = r[s];
          $(c) && (c = c(n[s], n, a)),
            c
              ? R(c)
                ? (a[c] = n[s])
                : B(c) && (a[c.name ? c.name : s] = c.value)
              : console.warn("微信小程序 ".concat(e, " 暂不支持 ").concat(s));
        } else if (-1 !== nn.indexOf(s)) {
          var u = n[s];
          $(u) && (a[s] = t(e, u, o));
        } else i || I(a, s) || (a[s] = n[s]);
      return a;
    }
    return $(n) && (n = t(e, n, o)), n;
  }
  function r(t, r, o) {
    var i = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
    return $(e.returnValue) && (r = e.returnValue(t, r)), n(t, r, o, {}, i);
  }
  return function (t, o) {
    if (!I(e, t)) return o;
    var i = e[t];
    return i
      ? function (e, o) {
          var a = i;
          $(i) && (a = i(e));
          var s = [(e = n(t, e, a.args, a.returnValue))];
          void 0 !== o && s.push(o);
          var c = wx[a.name || t].apply(wx, s);
          return Zt(t) ? r(t, c, a.returnValue, Xt(t)) : c;
        }
      : function () {
          console.error("微信小程序 暂不支持".concat(t));
        };
  };
}
var on = function () {
    var e = $(getApp) && getApp({ allowDefault: !0 });
    return e && e.$vm
      ? e.$vm.$locale
      : $e(wx.getSystemInfoSync().language) || "en";
  },
  an = [];
"undefined" != typeof global && (global.getLocale = on);
var sn,
  cn = "__DC_STAT_UUID";
function un() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : wx;
  return function (t, n) {
    (sn = sn || e.getStorageSync(cn)) ||
      ((sn = Date.now() + "" + Math.floor(1e7 * Math.random())),
      wx.setStorage({ key: cn, data: sn })),
      (n.deviceId = sn);
  };
}
function fn(e, t) {
  if (e.safeArea) {
    var n = e.safeArea;
    t.safeAreaInsets = {
      top: n.top,
      left: n.left,
      right: e.windowWidth - n.right,
      bottom: e.screenHeight - n.bottom,
    };
  }
}
function ln(e, t) {
  for (
    var n = e.deviceType || "phone",
      r = { ipad: "pad", windows: "pc", mac: "pc" },
      o = Object.keys(r),
      i = t.toLocaleLowerCase(),
      a = 0;
    a < o.length;
    a++
  ) {
    var s = o[a];
    if (-1 !== i.indexOf(s)) {
      n = r[s];
      break;
    }
  }
  return n;
}
function pn(e) {
  var t = e;
  return t && (t = t.toLocaleLowerCase()), t;
}
function hn(e) {
  return on ? on() : e;
}
function dn(e) {
  var t = e.hostName || "WeChat";
  return (
    e.environment
      ? (t = e.environment)
      : e.host && e.host.env && (t = e.host.env),
    t
  );
}
var vn = {
    returnValue: function (e, t) {
      fn(e, t),
        un()(e, t),
        (function (e, t) {
          var n,
            r = e.brand,
            o = void 0 === r ? "" : r,
            i = e.model,
            a = void 0 === i ? "" : i,
            s = e.system,
            c = void 0 === s ? "" : s,
            u = e.language,
            f = void 0 === u ? "" : u,
            l = e.theme,
            p = e.version,
            h = (e.platform, e.fontSizeSetting),
            d = e.SDKVersion,
            v = e.pixelRatio,
            g = e.deviceOrientation,
            m = "";
          (m = c.split(" ")[0] || ""), (n = c.split(" ")[1] || "");
          var y = p,
            _ = ln(e, a),
            b = pn(o),
            w = dn(e),
            k = g,
            x = v,
            S = d,
            P = f.replace(/_/g, "-"),
            O = {
              appId: "__UNI__1281306",
              appName: "BC TOYS",
              appVersion: "1.0.0",
              appVersionCode: "100",
              appLanguage: hn(P),
              uniCompileVersion: "4.24",
              uniRuntimeVersion: "4.24",
              uniPlatform: "mp-weixin",
              deviceBrand: b,
              deviceModel: a,
              deviceType: _,
              devicePixelRatio: x,
              deviceOrientation: k,
              osName: m.toLocaleLowerCase(),
              osVersion: n,
              hostTheme: l,
              hostVersion: y,
              hostLanguage: P,
              hostName: w,
              hostSDKVersion: S,
              hostFontSizeSetting: h,
              windowTop: 0,
              windowBottom: 0,
              osLanguage: void 0,
              osTheme: void 0,
              ua: void 0,
              hostPackageName: void 0,
              browserName: void 0,
              browserVersion: void 0,
            };
          T(t, O);
        })(e, t);
    },
  },
  gn = vn,
  mn = {
    args: function (e, t) {
      var n = parseInt(e.current);
      if (!isNaN(n)) {
        var r = e.urls;
        if (C(r)) {
          var o = r.length;
          if (o)
            return (
              n < 0 ? (n = 0) : n >= o && (n = o - 1),
              n > 0
                ? ((t.current = r[n]),
                  (t.urls = r.filter(function (e, t) {
                    return !(t < n) || e !== r[n];
                  })))
                : (t.current = r[0]),
              { indicator: !1, loop: !1 }
            );
        }
      }
    },
  },
  yn = {
    returnValue: function (e, t) {
      var n = e.brand,
        r = e.model,
        o = ln(e, r),
        i = pn(n);
      un()(e, t),
        (t = le(T(t, { deviceType: o, deviceBrand: i, deviceModel: r })));
    },
  },
  _n = {
    returnValue: function (e, t) {
      var n = e.version,
        r = e.language,
        o = e.SDKVersion,
        i = e.theme,
        a = dn(e),
        s = r.replace(/_/g, "-");
      t = le(
        T(t, {
          hostVersion: n,
          hostLanguage: s,
          hostName: a,
          hostSDKVersion: o,
          hostTheme: i,
          appId: "__UNI__1281306",
          appName: "BC TOYS",
          appVersion: "1.0.0",
          appVersionCode: "100",
          appLanguage: hn(s),
        })
      );
    },
  },
  bn = {
    returnValue: function (e, t) {
      fn(e, t), (t = le(T(t, { windowTop: 0, windowBottom: 0 })));
    },
  },
  wn = {
    $on: jt,
    $off: Dt,
    $once: Mt,
    $emit: Ut,
    upx2px: bt,
    interceptors: {},
    addInterceptor: At,
    removeInterceptor: It,
    onCreateVueApp: function (e) {
      if (ge) return e(ge);
      be.push(e);
    },
    invokeCreateVueAppHook: function (e) {
      (ge = e),
        be.forEach(function (t) {
          return t(e);
        });
    },
    getLocale: on,
    setLocale: function (e) {
      var t = $(getApp) && getApp();
      return (
        !!t &&
        t.$vm.$locale !== e &&
        ((t.$vm.$locale = e),
        an.forEach(function (t) {
          return t({ locale: e });
        }),
        !0)
      );
    },
    onLocaleChange: function (e) {
      -1 === an.indexOf(e) && an.push(e);
    },
    getPushClientId: Kt,
    onPushMessage: function (e) {
      -1 === Wt.indexOf(e) && Wt.push(e);
    },
    offPushMessage: function (e) {
      if (e) {
        var t = Wt.indexOf(e);
        t > -1 && Wt.splice(t, 1);
      } else Wt.length = 0;
    },
    invokePushCallback: function (e) {
      if ("enabled" === e.type) Ot = !0;
      else if ("clientId" === e.type)
        (Pt = e.cid), (Tt = e.errMsg), Bt(Pt, e.errMsg);
      else if ("pushMsg" === e.type)
        for (
          var t = { type: "receive", data: Nt(e.message) }, n = 0;
          n < Wt.length;
          n++
        ) {
          if (((0, Wt[n])(t), t.stopped)) break;
        }
      else
        "click" === e.type &&
          Wt.forEach(function (t) {
            t({ type: "click", data: Nt(e.message) });
          });
    },
  };
var kn = [
    "qy",
    "env",
    "error",
    "version",
    "lanDebug",
    "cloud",
    "serviceMarket",
    "router",
    "worklet",
    "__webpack_require_UNI_MP_PLUGIN__",
  ],
  xn = ["lanDebug", "router", "worklet"],
  Sn = wx.getLaunchOptionsSync ? wx.getLaunchOptionsSync() : null;
function Pn(e) {
  return (
    (!Sn || 1154 !== Sn.scene || !xn.includes(e)) &&
    (kn.indexOf(e) > -1 || "function" == typeof wx[e])
  );
}
function Tn() {
  var e = {};
  for (var t in wx) Pn(t) && (e[t] = wx[t]);
  return (
    "undefined" != typeof globalThis &&
      "undefined" == typeof requireMiniProgram &&
      (globalThis.wx = e),
    e
  );
}
var On,
  An = ["__route__", "__wxExparserNodeId__", "__wxWebviewId__"],
  In =
    ((On = {
      oauth: ["weixin"],
      share: ["weixin"],
      payment: ["wxpay"],
      push: ["weixin"],
    }),
    function (e) {
      var t,
        n = e.service,
        r = e.success,
        o = e.fail,
        i = e.complete;
      On[n]
        ? ((t = { errMsg: "getProvider:ok", service: n, provider: On[n] }),
          $(r) && r(t))
        : ((t = { errMsg: "getProvider:fail:服务[" + n + "]不存在" }),
          $(o) && o(t)),
        $(i) && i(t);
    });
var Cn = Tn(),
  En = Cn.getAppBaseInfo && Cn.getAppBaseInfo();
En || (En = Cn.getSystemInfoSync());
var Ln = En ? En.host : null,
  $n =
    Ln && "SAAASDK" === Ln.env
      ? Cn.miniapp.shareVideoMessage
      : Cn.shareVideoMessage,
  Rn = Object.freeze({
    __proto__: null,
    createSelectorQuery: function () {
      var e = Cn.createSelectorQuery(),
        t = e.in;
      return (
        (e.in = function (e) {
          return t.call(
            this,
            (function (e) {
              var t = Object.create(null);
              return (
                An.forEach(function (n) {
                  t[n] = e[n];
                }),
                t
              );
            })(e)
          );
        }),
        e
      );
    },
    getProvider: In,
    shareVideoMessage: $n,
  }),
  jn = Object.freeze({
    __proto__: null,
    compressImage: {
      args: function (e, t) {
        e.compressedHeight &&
          !t.compressHeight &&
          (t.compressHeight = e.compressedHeight),
          e.compressedWidth &&
            !t.compressWidth &&
            (t.compressWidth = e.compressedWidth);
      },
    },
    getAppAuthorizeSetting: {
      returnValue: function (e, t) {
        var n = e.locationReducedAccuracy;
        (t.locationAccuracy = "unsupported"),
          !0 === n
            ? (t.locationAccuracy = "reduced")
            : !1 === n && (t.locationAccuracy = "full");
      },
    },
    getAppBaseInfo: _n,
    getDeviceInfo: yn,
    getSystemInfo: vn,
    getSystemInfoSync: gn,
    getWindowInfo: bn,
    previewImage: mn,
    redirectTo: {},
    showActionSheet: {
      args: function (e, t) {
        t.alertText = e.title;
      },
    },
  }),
  Mn = Tn(),
  Dn = (function (e, t) {
    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : wx,
      r = rn(t),
      o = {
        get: function (t, o) {
          return I(t, o)
            ? t[o]
            : I(e, o)
            ? tn(o, e[o])
            : I(wn, o)
            ? tn(o, wn[o])
            : tn(o, r(o, n[o]));
        },
      };
    return new Proxy({}, o);
  })(Rn, jn, Mn);
function Un(e) {
  var t = e && e.__v_raw;
  return t ? Un(t) : e;
}
new Set(
  Object.getOwnPropertyNames(Symbol)
    .filter(function (e) {
      return "arguments" !== e && "caller" !== e;
    })
    .map(function (e) {
      return Symbol[e];
    })
    .filter(j)
);
var Nn = [];
function qn(e) {
  Nn.push(e);
}
function Bn() {
  Nn.pop();
}
function Fn(e) {
  for (
    var t = Nn.length ? Nn[Nn.length - 1].component : null,
      n = t && t.appContext.config.warnHandler,
      r = Hn(),
      o = arguments.length,
      i = new Array(o > 1 ? o - 1 : 0),
      a = 1;
    a < o;
    a++
  )
    i[a - 1] = arguments[a];
  if (n)
    Wn(n, t, 11, [
      e +
        i
          .map(function (e) {
            var t, n;
            return null != (n = null == (t = e.toString) ? void 0 : t.call(e))
              ? n
              : JSON.stringify(e);
          })
          .join(""),
      t && t.proxy,
      r
        .map(function (e) {
          var n = e.vnode;
          return "at <".concat(br(t, n.type), ">");
        })
        .join("\n"),
      r,
    ]);
  else {
    var s,
      c = ["[Vue warn]: ".concat(e)].concat(i);
    r.length && c.push.apply(c, ["\n"].concat(h(Vn(r)))),
      (s = console).warn.apply(s, h(c));
  }
}
function Hn() {
  var e = Nn[Nn.length - 1];
  if (!e) return [];
  for (var t = []; e; ) {
    var n = t[0];
    n && n.vnode === e
      ? n.recurseCount++
      : t.push({ vnode: e, recurseCount: 0 });
    var r = e.component && e.component.parent;
    e = r && r.vnode;
  }
  return t;
}
function Vn(e) {
  var t = [];
  return (
    e.forEach(function (e, n) {
      var r, o, i, a, s, c, u, f, l, p;
      t.push.apply(
        t,
        h(0 === n ? [] : ["\n"]).concat(
          h(
            ((s = (a = e).vnode),
            (c = a.recurseCount),
            (u = c > 0 ? "... (".concat(c, " recursive calls)") : ""),
            (f = !!s.component && null == s.component.parent),
            (l = " at <".concat(br(s.component, s.type, f))),
            (p = ">" + u),
            s.props
              ? [l].concat(
                  h(
                    ((r = s.props),
                    (o = []),
                    (i = Object.keys(r)).slice(0, 3).forEach(function (e) {
                      o.push.apply(
                        o,
                        h(
                          (function e(t, n, r) {
                            return R(n)
                              ? ((n = JSON.stringify(n)),
                                r ? n : ["".concat(t, "=").concat(n)])
                              : "number" == typeof n ||
                                "boolean" == typeof n ||
                                null == n
                              ? r
                                ? n
                                : ["".concat(t, "=").concat(n)]
                              : (o = n) && !0 === o.__v_isRef
                              ? ((n = e(t, Un(n.value), !0)),
                                r ? n : ["".concat(t, "=Ref<"), n, ">"])
                              : $(n)
                              ? [
                                  ""
                                    .concat(t, "=fn")
                                    .concat(
                                      n.name ? "<".concat(n.name, ">") : ""
                                    ),
                                ]
                              : ((n = Un(n)), r ? n : ["".concat(t, "="), n]);
                            var o;
                          })(e, r[e])
                        )
                      );
                    }),
                    i.length > 3 && o.push(" ..."),
                    o)
                  ),
                  [p]
                )
              : [l + p])
          )
        )
      );
    }),
    t
  );
}
var Kn =
  (p(
    p(
      p(
        p(
          p(
            p(
              p(
                p(
                  p(
                    p((t = {}), "sp", "serverPrefetch hook"),
                    "bc",
                    "beforeCreate hook"
                  ),
                  "c",
                  "created hook"
                ),
                "bm",
                "beforeMount hook"
              ),
              "m",
              "mounted hook"
            ),
            "bu",
            "beforeUpdate hook"
          ),
          "u",
          "updated"
        ),
        "bum",
        "beforeUnmount hook"
      ),
      "um",
      "unmounted hook"
    ),
    "a",
    "activated hook"
  ),
  p(
    p(
      p(
        p(
          p(
            p(
              p(
                p(
                  p(p(t, "da", "deactivated hook"), "ec", "errorCaptured hook"),
                  "rtc",
                  "renderTracked hook"
                ),
                "rtg",
                "renderTriggered hook"
              ),
              0,
              "setup function"
            ),
            1,
            "render function"
          ),
          2,
          "watcher getter"
        ),
        3,
        "watcher callback"
      ),
      4,
      "watcher cleanup function"
    ),
    5,
    "native event handler"
  ),
  p(
    p(
      p(
        p(
          p(
            p(
              p(
                p(p(t, 6, "component event handler"), 7, "vnode hook"),
                8,
                "directive hook"
              ),
              9,
              "transition hook"
            ),
            10,
            "app errorHandler"
          ),
          11,
          "app warnHandler"
        ),
        12,
        "ref function"
      ),
      13,
      "async component loader"
    ),
    14,
    "scheduler flush. This is likely a Vue internals bug. Please open an issue at https://github.com/vuejs/core ."
  ));
function Wn(e, t, n, r) {
  try {
    return r ? e.apply(void 0, h(r)) : e();
  } catch (e) {
    zn(e, t, n);
  }
}
function zn(e, t, n) {
  var r = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
    o = t ? t.vnode : null;
  if (t) {
    for (var i = t.parent, a = t.proxy, s = Kn[n]; i; ) {
      var c = i.ec;
      if (c)
        for (var u = 0; u < c.length; u++) if (!1 === c[u](e, a, s)) return;
      i = i.parent;
    }
    var f = t.appContext.config.errorHandler;
    if (f) return void Wn(f, null, 10, [e, a, s]);
  }
  Jn(e, n, o, r);
}
function Jn(e, t, n) {
  var r = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
    o = Kn[t];
  if (
    (n && qn(n),
    Fn("Unhandled error".concat(o ? " during execution of ".concat(o) : "")),
    n && Bn(),
    r)
  )
    throw e;
  console.error(e);
}
var Yn = !1,
  Qn = !1,
  Gn = [],
  Xn = 0,
  Zn = [],
  er = null,
  tr = 0,
  nr = Promise.resolve();
function rr(e) {
  (Gn.length && Gn.includes(e, Yn && e.allowRecurse ? Xn + 1 : Xn)) ||
    (null == e.id
      ? Gn.push(e)
      : Gn.splice(
          (function (e) {
            for (var t = Xn + 1, n = Gn.length; t < n; ) {
              var r = (t + n) >>> 1,
                o = Gn[r],
                i = ir(o);
              i < e || (i === e && o.pre) ? (t = r + 1) : (n = r);
            }
            return t;
          })(e.id),
          0,
          e
        ),
    or());
}
function or() {
  Yn || Qn || ((Qn = !0), nr.then(sr));
}
var ir = function (e) {
    return null == e.id ? 1 / 0 : e.id;
  },
  ar = function (e, t) {
    var n = ir(e) - ir(t);
    if (0 === n) {
      if (e.pre && !t.pre) return -1;
      if (t.pre && !e.pre) return 1;
    }
    return n;
  };
function sr(e) {
  (Qn = !1), (Yn = !0), (e = e || new Map()), Gn.sort(ar);
  var t = function (t) {
    return cr(e, t);
  };
  try {
    for (Xn = 0; Xn < Gn.length; Xn++) {
      var n = Gn[Xn];
      if (n && !1 !== n.active) {
        if (t(n)) continue;
        Wn(n, null, 14);
      }
    }
  } finally {
    (Xn = 0),
      (Gn.length = 0),
      (function (e) {
        if (Zn.length) {
          var t,
            n = h(new Set(Zn)).sort(function (e, t) {
              return ir(e) - ir(t);
            });
          if (((Zn.length = 0), er)) return void (t = er).push.apply(t, h(n));
          for (er = n, e = e || new Map(), tr = 0; tr < er.length; tr++)
            cr(e, er[tr]) || er[tr]();
          (er = null), (tr = 0);
        }
      })(e),
      (Yn = !1),
      (Gn.length || Zn.length) && sr(e);
  }
}
function cr(e, t) {
  if (e.has(t)) {
    var n = e.get(t);
    if (n > 100) {
      var r = t.ownerInstance,
        o = r && _r(r.type);
      return (
        zn(
          "Maximum recursive updates exceeded".concat(
            o ? " in component <".concat(o, ">") : "",
            ". This means you have a reactive effect that is mutating its own dependencies and thus recursively triggering itself. Possible sources include component template, render function, updated hook or watcher source function."
          ),
          null,
          10
        ),
        !0
      );
    }
    e.set(t, n + 1);
  } else e.set(t, 1);
}
var ur = new Set();
te().__VUE_HMR_RUNTIME__ = {
  createRecord: hr(function (e, t) {
    if (fr.has(e)) return !1;
    return fr.set(e, { initialDef: lr(t), instances: new Set() }), !0;
  }),
  rerender: hr(function (e, t) {
    var n = fr.get(e);
    if (!n) return;
    (n.initialDef.render = t),
      h(n.instances).forEach(function (e) {
        t && ((e.render = t), (lr(e.type).render = t)),
          (e.renderCache = []),
          (e.effect.dirty = !0),
          e.update();
      });
  }),
  reload: hr(function (e, t) {
    var n = fr.get(e);
    if (!n) return;
    (t = lr(t)), pr(n.initialDef, t);
    var r,
      o = h(n.instances),
      i = g(o);
    try {
      for (i.s(); !(r = i.n()).done; ) {
        var a = r.value,
          s = lr(a.type);
        ur.has(s) || (s !== n.initialDef && pr(s, t), ur.add(s)),
          a.appContext.propsCache.delete(a.type),
          a.appContext.emitsCache.delete(a.type),
          a.appContext.optionsCache.delete(a.type),
          a.ceReload
            ? (ur.add(s), a.ceReload(t.styles), ur.delete(s))
            : a.parent
            ? ((a.parent.effect.dirty = !0), rr(a.parent.update))
            : a.appContext.reload
            ? a.appContext.reload()
            : "undefined" != typeof window
            ? window.location.reload()
            : console.warn(
                "[HMR] Root or manually mounted instance modified. Full reload required."
              );
      }
    } catch (e) {
      i.e(e);
    } finally {
      i.f();
    }
    (c = function () {
      var e,
        t = g(o);
      try {
        for (t.s(); !(e = t.n()).done; ) {
          var n = e.value;
          ur.delete(lr(n.type));
        }
      } catch (e) {
        t.e(e);
      } finally {
        t.f();
      }
    }),
      C(c)
        ? Zn.push.apply(Zn, h(c))
        : (er && er.includes(c, c.allowRecurse ? tr + 1 : tr)) || Zn.push(c),
      or();
    var c;
  }),
};
var fr = new Map();
function lr(e) {
  return $((t = e)) && "__vccOpts" in t ? e.__vccOpts : e;
  var t;
  /**
   * @dcloudio/uni-mp-vue v3.4.21
   * (c) 2018-present Yuxi (Evan) You and Vue contributors
   * @license MIT
   **/
}
function pr(e, t) {
  for (var n in (T(e, t), e)) "__file" === n || n in t || delete e[n];
}
function hr(e) {
  return function (t, n) {
    try {
      return e(t, n);
    } catch (e) {
      console.error(e),
        console.warn(
          "[HMR] Something went wrong during Vue component hot-reload. Full reload required."
        );
    }
  };
}
var dr = te(),
  vr = function (e, t) {
    var n;
    return (
      (n = dr[e]) || (n = dr[e] = []),
      n.push(t),
      function (e) {
        n.length > 1
          ? n.forEach(function (t) {
              return t(e);
            })
          : n[0](e);
      }
    );
  };
vr("__VUE_INSTANCE_SETTERS__", function (e) {
  return e;
}),
  vr("__VUE_SSR_SETTERS__", function (e) {
    return e;
  });
var gr,
  mr = /(?:^|[-_])(\w)/g,
  yr = function (e) {
    return e
      .replace(mr, function (e) {
        return e.toUpperCase();
      })
      .replace(/[-_]/g, "");
  };
function _r(e) {
  var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
  return $(e) ? e.displayName || e.name : e.name || (t && e.__name);
}
function br(e, t) {
  var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
    r = _r(t);
  if (!r && t.__file) {
    var o = t.__file.match(/([^/\\]+)\.\w+$/);
    o && (r = o[1]);
  }
  if (!r && e && e.parent) {
    var i = function (e) {
      for (var n in e) if (e[n] === t) return n;
    };
    r =
      i(e.components || e.parent.type.components) || i(e.appContext.components);
  }
  return r ? yr(r) : n ? "App" : "Anonymous";
}
function wr(e) {
  for (
    var t, n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), o = 1;
    o < n;
    o++
  )
    r[o - 1] = arguments[o];
  (t = console).warn.apply(t, ["[Vue warn] ".concat(e)].concat(r));
}
var kr,
  xr = (function () {
    return l(
      function e() {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        f(this, e),
          (this.detached = t),
          (this._active = !0),
          (this.effects = []),
          (this.cleanups = []),
          (this.parent = gr),
          !t &&
            gr &&
            (this.index = (gr.scopes || (gr.scopes = [])).push(this) - 1);
      },
      [
        {
          key: "active",
          get: function () {
            return this._active;
          },
        },
        {
          key: "run",
          value: function (e) {
            if (this._active) {
              var t = gr;
              try {
                return (gr = this), e();
              } finally {
                gr = t;
              }
            } else wr("cannot run an inactive effect scope.");
          },
        },
        {
          key: "on",
          value: function () {
            gr = this;
          },
        },
        {
          key: "off",
          value: function () {
            gr = this.parent;
          },
        },
        {
          key: "stop",
          value: function (e) {
            if (this._active) {
              var t, n;
              for (t = 0, n = this.effects.length; t < n; t++)
                this.effects[t].stop();
              for (t = 0, n = this.cleanups.length; t < n; t++)
                this.cleanups[t]();
              if (this.scopes)
                for (t = 0, n = this.scopes.length; t < n; t++)
                  this.scopes[t].stop(!0);
              if (!this.detached && this.parent && !e) {
                var r = this.parent.scopes.pop();
                r &&
                  r !== this &&
                  ((this.parent.scopes[this.index] = r),
                  (r.index = this.index));
              }
              (this.parent = void 0), (this._active = !1);
            }
          },
        },
      ]
    );
  })();
function Sr(e) {
  return new xr(e);
}
function Pr() {
  return gr;
}
function Tr(e) {
  gr
    ? gr.cleanups.push(e)
    : wr(
        "onScopeDispose() is called when there is no active effect scope to be associated with."
      );
}
var Or = (function () {
  return l(
    function e(t, n, r, o) {
      f(this, e),
        (this.fn = t),
        (this.trigger = n),
        (this.scheduler = r),
        (this.active = !0),
        (this.deps = []),
        (this._dirtyLevel = 4),
        (this._trackId = 0),
        (this._runnings = 0),
        (this._shouldSchedule = !1),
        (this._depsLength = 0),
        (function (e) {
          var t =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : gr;
          t && t.active && t.effects.push(e);
        })(this, o);
    },
    [
      {
        key: "dirty",
        get: function () {
          if (2 === this._dirtyLevel || 3 === this._dirtyLevel) {
            (this._dirtyLevel = 1), Rr();
            for (var e = 0; e < this._depsLength; e++) {
              var t = this.deps[e];
              if (t.computed && (t.computed.value, this._dirtyLevel >= 4))
                break;
            }
            1 === this._dirtyLevel && (this._dirtyLevel = 0), jr();
          }
          return this._dirtyLevel >= 4;
        },
        set: function (e) {
          this._dirtyLevel = e ? 4 : 0;
        },
      },
      {
        key: "run",
        value: function () {
          if (((this._dirtyLevel = 0), !this.active)) return this.fn();
          var e = Er,
            t = kr;
          try {
            return (
              (Er = !0), (kr = this), this._runnings++, Ar(this), this.fn()
            );
          } finally {
            Ir(this), this._runnings--, (kr = t), (Er = e);
          }
        },
      },
      {
        key: "stop",
        value: function () {
          var e;
          this.active &&
            (Ar(this),
            Ir(this),
            null == (e = this.onStop) || e.call(this),
            (this.active = !1));
        },
      },
    ]
  );
})();
function Ar(e) {
  e._trackId++, (e._depsLength = 0);
}
function Ir(e) {
  if (e.deps.length > e._depsLength) {
    for (var t = e._depsLength; t < e.deps.length; t++) Cr(e.deps[t], e);
    e.deps.length = e._depsLength;
  }
}
function Cr(e, t) {
  var n = e.get(t);
  void 0 !== n &&
    t._trackId !== n &&
    (e.delete(t), 0 === e.size && e.cleanup());
}
var Er = !0,
  Lr = 0,
  $r = [];
function Rr() {
  $r.push(Er), (Er = !1);
}
function jr() {
  var e = $r.pop();
  Er = void 0 === e || e;
}
function Mr() {
  Lr++;
}
function Dr() {
  for (Lr--; !Lr && Nr.length; ) Nr.shift()();
}
function Ur(e, t, n) {
  var r;
  if (t.get(e) !== e._trackId) {
    t.set(e, e._trackId);
    var o = e.deps[e._depsLength];
    o !== t ? (o && Cr(o, e), (e.deps[e._depsLength++] = t)) : e._depsLength++,
      null == (r = e.onTrack) || r.call(e, T({ effect: e }, n));
  }
}
var Nr = [];
function qr(e, t, n) {
  var r;
  Mr();
  var o,
    i = g(e.keys());
  try {
    for (i.s(); !(o = i.n()).done; ) {
      var a = o.value,
        s = void 0;
      a._dirtyLevel < t &&
        (null != s ? s : (s = e.get(a) === a._trackId)) &&
        (a._shouldSchedule || (a._shouldSchedule = 0 === a._dirtyLevel),
        (a._dirtyLevel = t)),
        a._shouldSchedule &&
          (null != s ? s : (s = e.get(a) === a._trackId)) &&
          (null == (r = a.onTrigger) || r.call(a, T({ effect: a }, n)),
          a.trigger(),
          (a._runnings && !a.allowRecurse) ||
            2 === a._dirtyLevel ||
            ((a._shouldSchedule = !1), a.scheduler && Nr.push(a.scheduler)));
    }
  } catch (e) {
    i.e(e);
  } finally {
    i.f();
  }
  Dr();
}
var Br = function (e, t) {
    var n = new Map();
    return (n.cleanup = e), (n.computed = t), n;
  },
  Fr = new WeakMap(),
  Hr = Symbol("iterate"),
  Vr = Symbol("Map key iterate");
function Kr(e, t, n) {
  if (Er && kr) {
    var r = Fr.get(e);
    r || Fr.set(e, (r = new Map()));
    var o = r.get(n);
    o ||
      r.set(
        n,
        (o = Br(function () {
          return r.delete(n);
        }))
      ),
      Ur(kr, o, { target: e, type: t, key: n });
  }
}
function Wr(e, t, n, r, o, i) {
  var a = Fr.get(e);
  if (a) {
    var s = [];
    if ("clear" === t) s = h(a.values());
    else if ("length" === n && C(e)) {
      var c = Number(r);
      a.forEach(function (e, t) {
        ("length" === t || (!j(t) && t >= c)) && s.push(e);
      });
    } else
      switch ((void 0 !== n && s.push(a.get(n)), t)) {
        case "add":
          C(e)
            ? F(n) && s.push(a.get("length"))
            : (s.push(a.get(Hr)), E(e) && s.push(a.get(Vr)));
          break;
        case "delete":
          C(e) || (s.push(a.get(Hr)), E(e) && s.push(a.get(Vr)));
          break;
        case "set":
          E(e) && s.push(a.get(Hr));
      }
    Mr();
    var u,
      f = g(s);
    try {
      for (f.s(); !(u = f.n()).done; ) {
        var l = u.value;
        l &&
          qr(l, 4, {
            target: e,
            type: t,
            key: n,
            newValue: r,
            oldValue: o,
            oldTarget: i,
          });
      }
    } catch (e) {
      f.e(e);
    } finally {
      f.f();
    }
    Dr();
  }
}
var zr = y("__proto__,__v_isRef,__isVue"),
  Jr = new Set(
    Object.getOwnPropertyNames(Symbol)
      .filter(function (e) {
        return "arguments" !== e && "caller" !== e;
      })
      .map(function (e) {
        return Symbol[e];
      })
      .filter(j)
  ),
  Yr = Qr();
function Qr() {
  var e = {};
  return (
    ["includes", "indexOf", "lastIndexOf"].forEach(function (t) {
      e[t] = function () {
        for (var e = Ho(this), n = 0, r = this.length; n < r; n++)
          Kr(e, "get", n + "");
        for (var o = arguments.length, i = new Array(o), a = 0; a < o; a++)
          i[a] = arguments[a];
        var s = e[t].apply(e, i);
        return -1 === s || !1 === s ? e[t].apply(e, h(i.map(Ho))) : s;
      };
    }),
    ["push", "pop", "shift", "unshift", "splice"].forEach(function (t) {
      e[t] = function () {
        Rr(), Mr();
        for (var e = arguments.length, n = new Array(e), r = 0; r < e; r++)
          n[r] = arguments[r];
        var o = Ho(this)[t].apply(this, n);
        return Dr(), jr(), o;
      };
    }),
    e
  );
}
function Gr(e) {
  var t = Ho(this);
  return Kr(t, "has", e), t.hasOwnProperty(e);
}
var Xr = (function () {
    return l(
      function e() {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        f(this, e), (this._isReadonly = t), (this._isShallow = n);
      },
      [
        {
          key: "get",
          value: function (e, t, n) {
            var r = this._isReadonly,
              o = this._isShallow;
            if ("__v_isReactive" === t) return !r;
            if ("__v_isReadonly" === t) return r;
            if ("__v_isShallow" === t) return o;
            if ("__v_raw" === t)
              return n === (r ? (o ? $o : Lo) : o ? Eo : Co).get(e) ||
                Object.getPrototypeOf(e) === Object.getPrototypeOf(n)
                ? e
                : void 0;
            var i = C(e);
            if (!r) {
              if (i && I(Yr, t)) return Reflect.get(Yr, t, n);
              if ("hasOwnProperty" === t) return Gr;
            }
            var a = Reflect.get(e, t, n);
            return (j(t) ? Jr.has(t) : zr(t))
              ? a
              : (r || Kr(e, "get", t),
                o
                  ? a
                  : Qo(a)
                  ? i && F(t)
                    ? a
                    : a.value
                  : M(a)
                  ? r
                    ? Mo(a)
                    : Ro(a)
                  : a);
          },
        },
      ]
    );
  })(),
  Zr = (function (e) {
    function t() {
      var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
      return f(this, t), m(this, t, [!1, e]);
    }
    return (
      u(t, Xr),
      l(t, [
        {
          key: "set",
          value: function (e, t, n, r) {
            var o = e[t];
            if (!this._isShallow) {
              var i = qo(o);
              if (
                (Bo(n) || qo(n) || ((o = Ho(o)), (n = Ho(n))),
                !C(e) && Qo(o) && !Qo(n))
              )
                return !i && ((o.value = n), !0);
            }
            var a = C(e) && F(t) ? Number(t) < e.length : I(e, t),
              s = Reflect.set(e, t, n, r);
            return (
              e === Ho(r) &&
                (a ? X(n, o) && Wr(e, "set", t, n, o) : Wr(e, "add", t, n)),
              s
            );
          },
        },
        {
          key: "deleteProperty",
          value: function (e, t) {
            var n = I(e, t),
              r = e[t],
              o = Reflect.deleteProperty(e, t);
            return o && n && Wr(e, "delete", t, void 0, r), o;
          },
        },
        {
          key: "has",
          value: function (e, t) {
            var n = Reflect.has(e, t);
            return (j(t) && Jr.has(t)) || Kr(e, "has", t), n;
          },
        },
        {
          key: "ownKeys",
          value: function (e) {
            return Kr(e, "iterate", C(e) ? "length" : Hr), Reflect.ownKeys(e);
          },
        },
      ])
    );
  })(),
  eo = (function (e) {
    function t() {
      var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
      return f(this, t), m(this, t, [!0, e]);
    }
    return (
      u(t, Xr),
      l(t, [
        {
          key: "set",
          value: function (e, t) {
            return (
              wr(
                'Set operation on key "'.concat(
                  String(t),
                  '" failed: target is readonly.'
                ),
                e
              ),
              !0
            );
          },
        },
        {
          key: "deleteProperty",
          value: function (e, t) {
            return (
              wr(
                'Delete operation on key "'.concat(
                  String(t),
                  '" failed: target is readonly.'
                ),
                e
              ),
              !0
            );
          },
        },
      ])
    );
  })(),
  to = new Zr(),
  no = new eo(),
  ro = new Zr(!0),
  oo = new eo(!0),
  io = function (e) {
    return e;
  },
  ao = function (e) {
    return Reflect.getPrototypeOf(e);
  };
function so(e, t) {
  var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
    r = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
    o = Ho((e = e.__v_raw)),
    i = Ho(t);
  n || (X(t, i) && Kr(o, "get", t), Kr(o, "get", i));
  var a = ao(o),
    s = a.has,
    c = r ? io : n ? Wo : Ko;
  return s.call(o, t)
    ? c(e.get(t))
    : s.call(o, i)
    ? c(e.get(i))
    : void (e !== o && e.get(t));
}
function co(e) {
  var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
    n = this.__v_raw,
    r = Ho(n),
    o = Ho(e);
  return (
    t || (X(e, o) && Kr(r, "has", e), Kr(r, "has", o)),
    e === o ? n.has(e) : n.has(e) || n.has(o)
  );
}
function uo(e) {
  var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
  return (
    (e = e.__v_raw), !t && Kr(Ho(e), "iterate", Hr), Reflect.get(e, "size", e)
  );
}
function fo(e) {
  e = Ho(e);
  var t = Ho(this);
  return ao(t).has.call(t, e) || (t.add(e), Wr(t, "add", e, e)), this;
}
function lo(e, t) {
  t = Ho(t);
  var n = Ho(this),
    r = ao(n),
    o = r.has,
    i = r.get,
    a = o.call(n, e);
  a ? Io(n, o, e) : ((e = Ho(e)), (a = o.call(n, e)));
  var s = i.call(n, e);
  return (
    n.set(e, t), a ? X(t, s) && Wr(n, "set", e, t, s) : Wr(n, "add", e, t), this
  );
}
function po(e) {
  var t = Ho(this),
    n = ao(t),
    r = n.has,
    o = n.get,
    i = r.call(t, e);
  i ? Io(t, r, e) : ((e = Ho(e)), (i = r.call(t, e)));
  var a = o ? o.call(t, e) : void 0,
    s = t.delete(e);
  return i && Wr(t, "delete", e, void 0, a), s;
}
function ho() {
  var e = Ho(this),
    t = 0 !== e.size,
    n = E(e) ? new Map(e) : new Set(e),
    r = e.clear();
  return t && Wr(e, "clear", void 0, void 0, n), r;
}
function vo(e, t) {
  return function (n, r) {
    var o = this,
      i = o.__v_raw,
      a = Ho(i),
      s = t ? io : e ? Wo : Ko;
    return (
      !e && Kr(a, "iterate", Hr),
      i.forEach(function (e, t) {
        return n.call(r, s(e), s(t), o);
      })
    );
  };
}
function go(e, t, n) {
  return function () {
    var r = this.__v_raw,
      o = Ho(r),
      i = E(o),
      a = "entries" === e || (e === Symbol.iterator && i),
      s = "keys" === e && i,
      c = r[e].apply(r, arguments),
      u = n ? io : t ? Wo : Ko;
    return (
      !t && Kr(o, "iterate", s ? Vr : Hr),
      p(
        {
          next: function () {
            var e = c.next(),
              t = e.value,
              n = e.done;
            return n
              ? { value: t, done: n }
              : { value: a ? [u(t[0]), u(t[1])] : u(t), done: n };
          },
        },
        Symbol.iterator,
        function () {
          return this;
        }
      )
    );
  };
}
function mo(e) {
  return function () {
    var t = (arguments.length <= 0 ? void 0 : arguments[0])
      ? 'on key "'.concat(arguments.length <= 0 ? void 0 : arguments[0], '" ')
      : "";
    return (
      wr(
        "".concat(Q(e), " operation ").concat(t, "failed: target is readonly."),
        Ho(this)
      ),
      "delete" !== e && ("clear" === e ? void 0 : this)
    );
  };
}
function yo() {
  var e = {
      get: function (e) {
        return so(this, e);
      },
      get size() {
        return uo(this);
      },
      has: co,
      add: fo,
      set: lo,
      delete: po,
      clear: ho,
      forEach: vo(!1, !1),
    },
    t = {
      get: function (e) {
        return so(this, e, !1, !0);
      },
      get size() {
        return uo(this);
      },
      has: co,
      add: fo,
      set: lo,
      delete: po,
      clear: ho,
      forEach: vo(!1, !0),
    },
    n = {
      get: function (e) {
        return so(this, e, !0);
      },
      get size() {
        return uo(this, !0);
      },
      has: function (e) {
        return co.call(this, e, !0);
      },
      add: mo("add"),
      set: mo("set"),
      delete: mo("delete"),
      clear: mo("clear"),
      forEach: vo(!0, !1),
    },
    r = {
      get: function (e) {
        return so(this, e, !0, !0);
      },
      get size() {
        return uo(this, !0);
      },
      has: function (e) {
        return co.call(this, e, !0);
      },
      add: mo("add"),
      set: mo("set"),
      delete: mo("delete"),
      clear: mo("clear"),
      forEach: vo(!0, !0),
    };
  return (
    ["keys", "values", "entries", Symbol.iterator].forEach(function (o) {
      (e[o] = go(o, !1, !1)),
        (n[o] = go(o, !0, !1)),
        (t[o] = go(o, !1, !0)),
        (r[o] = go(o, !0, !0));
    }),
    [e, n, t, r]
  );
}
var _o = v(yo(), 4),
  bo = _o[0],
  wo = _o[1],
  ko = _o[2],
  xo = _o[3];
function So(e, t) {
  var n = t ? (e ? xo : ko) : e ? wo : bo;
  return function (t, r, o) {
    return "__v_isReactive" === r
      ? !e
      : "__v_isReadonly" === r
      ? e
      : "__v_raw" === r
      ? t
      : Reflect.get(I(n, r) && r in t ? n : t, r, o);
  };
}
var Po = { get: So(!1, !1) },
  To = { get: So(!1, !0) },
  Oo = { get: So(!0, !1) },
  Ao = { get: So(!0, !0) };
function Io(e, t, n) {
  var r = Ho(n);
  if (r !== n && t.call(e, r)) {
    var o = q(e);
    wr(
      "Reactive "
        .concat(
          o,
          " contains both the raw and reactive versions of the same object"
        )
        .concat(
          "Map" === o ? " as keys" : "",
          ", which can lead to inconsistencies. Avoid differentiating between the raw and reactive versions of an object and only use the reactive version if possible."
        )
    );
  }
}
var Co = new WeakMap(),
  Eo = new WeakMap(),
  Lo = new WeakMap(),
  $o = new WeakMap();
function Ro(e) {
  return qo(e) ? e : Uo(e, !1, to, Po, Co);
}
function jo(e) {
  return Uo(e, !1, ro, To, Eo);
}
function Mo(e) {
  return Uo(e, !0, no, Oo, Lo);
}
function Do(e) {
  return Uo(e, !0, oo, Ao, $o);
}
function Uo(e, t, n, r, o) {
  if (!M(e)) return wr("value cannot be made reactive: ".concat(String(e))), e;
  if (e.__v_raw && (!t || !e.__v_isReactive)) return e;
  var i = o.get(e);
  if (i) return i;
  var a,
    s =
      (a = e).__v_skip || !Object.isExtensible(a)
        ? 0
        : (function (e) {
            switch (e) {
              case "Object":
              case "Array":
                return 1;
              case "Map":
              case "Set":
              case "WeakMap":
              case "WeakSet":
                return 2;
              default:
                return 0;
            }
          })(q(a));
  if (0 === s) return e;
  var c = new Proxy(e, 2 === s ? r : n);
  return o.set(e, c), c;
}
function No(e) {
  return qo(e) ? No(e.__v_raw) : !(!e || !e.__v_isReactive);
}
function qo(e) {
  return !(!e || !e.__v_isReadonly);
}
function Bo(e) {
  return !(!e || !e.__v_isShallow);
}
function Fo(e) {
  return No(e) || qo(e);
}
function Ho(e) {
  var t = e && e.__v_raw;
  return t ? Ho(t) : e;
}
function Vo(e) {
  return (
    Object.isExtensible(e) &&
      (function (e, t, n) {
        Object.defineProperty(e, t, {
          configurable: !0,
          enumerable: !1,
          value: n,
        });
      })(e, "__v_skip", !0),
    e
  );
}
var Ko = function (e) {
    return M(e) ? Ro(e) : e;
  },
  Wo = function (e) {
    return M(e) ? Mo(e) : e;
  },
  zo = (function () {
    return l(
      function e(t, n, r, o) {
        var i = this;
        f(this, e),
          (this.getter = t),
          (this._setter = n),
          (this.dep = void 0),
          (this.__v_isRef = !0),
          (this.__v_isReadonly = !1),
          (this.effect = new Or(
            function () {
              return t(i._value);
            },
            function () {
              return Yo(i, 2 === i.effect._dirtyLevel ? 2 : 3);
            }
          )),
          (this.effect.computed = this),
          (this.effect.active = this._cacheable = !o),
          (this.__v_isReadonly = r);
      },
      [
        {
          key: "value",
          get: function () {
            var e = Ho(this);
            return (
              (e._cacheable && !e.effect.dirty) ||
                !X(e._value, (e._value = e.effect.run())) ||
                Yo(e, 4),
              Jo(e),
              e.effect._dirtyLevel >= 2 &&
                (this._warnRecursive &&
                  wr(
                    "Computed is still dirty after getter evaluation, likely because a computed is mutating its own dependency in its getter. State mutations in computed getters should be avoided.  Check the docs for more details: https://vuejs.org/guide/essentials/computed.html#getters-should-be-side-effect-free",
                    "\n\ngetter: ",
                    this.getter
                  ),
                Yo(e, 2)),
              e._value
            );
          },
          set: function (e) {
            this._setter(e);
          },
        },
        {
          key: "_dirty",
          get: function () {
            return this.effect.dirty;
          },
          set: function (e) {
            this.effect.dirty = e;
          },
        },
      ]
    );
  })();
function Jo(e) {
  var t;
  Er &&
    kr &&
    ((e = Ho(e)),
    Ur(
      kr,
      null != (t = e.dep)
        ? t
        : (e.dep = Br(
            function () {
              return (e.dep = void 0);
            },
            e instanceof zo ? e : void 0
          )),
      { target: e, type: "get", key: "value" }
    ));
}
function Yo(e) {
  var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 4,
    n = arguments.length > 2 ? arguments[2] : void 0,
    r = (e = Ho(e)).dep;
  r && qr(r, t, { target: e, type: "set", key: "value", newValue: n });
}
function Qo(e) {
  return !(!e || !0 !== e.__v_isRef);
}
function Go(e) {
  return (function (e, t) {
    if (Qo(e)) return e;
    return new Xo(e, t);
  })(e, !1);
}
var Xo = (function () {
  return l(
    function e(t, n) {
      f(this, e),
        (this.__v_isShallow = n),
        (this.dep = void 0),
        (this.__v_isRef = !0),
        (this._rawValue = n ? t : Ho(t)),
        (this._value = n ? t : Ko(t));
    },
    [
      {
        key: "value",
        get: function () {
          return Jo(this), this._value;
        },
        set: function (e) {
          var t = this.__v_isShallow || Bo(e) || qo(e);
          (e = t ? e : Ho(e)),
            X(e, this._rawValue) &&
              ((this._rawValue = e),
              (this._value = t ? e : Ko(e)),
              Yo(this, 4, e));
        },
      },
    ]
  );
})();
function Zo(e) {
  return Qo(e) ? e.value : e;
}
var ei = {
  get: function (e, t, n) {
    return Zo(Reflect.get(e, t, n));
  },
  set: function (e, t, n, r) {
    var o = e[t];
    return Qo(o) && !Qo(n) ? ((o.value = n), !0) : Reflect.set(e, t, n, r);
  },
};
function ti(e) {
  return No(e) ? e : new Proxy(e, ei);
}
function ni(e) {
  Fo(e) || wr("toRefs() expects a reactive object but received a plain one.");
  var t = C(e) ? new Array(e.length) : {};
  for (var n in e) t[n] = ai(e, n);
  return t;
}
var ri = (function () {
    return l(
      function e(t, n, r) {
        f(this, e),
          (this._object = t),
          (this._key = n),
          (this._defaultValue = r),
          (this.__v_isRef = !0);
      },
      [
        {
          key: "value",
          get: function () {
            var e = this._object[this._key];
            return void 0 === e ? this._defaultValue : e;
          },
          set: function (e) {
            this._object[this._key] = e;
          },
        },
        {
          key: "dep",
          get: function () {
            return (
              (e = Ho(this._object)),
              (t = this._key),
              null == (n = Fr.get(e)) ? void 0 : n.get(t)
            );
            var e, t, n;
          },
        },
      ]
    );
  })(),
  oi = (function () {
    return l(
      function e(t) {
        f(this, e),
          (this._getter = t),
          (this.__v_isRef = !0),
          (this.__v_isReadonly = !0);
      },
      [
        {
          key: "value",
          get: function () {
            return this._getter();
          },
        },
      ]
    );
  })();
function ii(e, t, n) {
  return Qo(e)
    ? e
    : $(e)
    ? new oi(e)
    : M(e) && arguments.length > 1
    ? ai(e, t, n)
    : Go(e);
}
function ai(e, t, n) {
  var r = e[t];
  return Qo(r) ? r : new ri(e, t, n);
}
var si = [];
function ci(e) {
  si.push(e);
}
function ui() {
  si.pop();
}
function fi(e) {
  Rr();
  for (
    var t = si.length ? si[si.length - 1].component : null,
      n = t && t.appContext.config.warnHandler,
      r = li(),
      o = arguments.length,
      i = new Array(o > 1 ? o - 1 : 0),
      a = 1;
    a < o;
    a++
  )
    i[a - 1] = arguments[a];
  if (n)
    di(n, t, 11, [
      e +
        i
          .map(function (e) {
            var t, n;
            return null != (n = null == (t = e.toString) ? void 0 : t.call(e))
              ? n
              : JSON.stringify(e);
          })
          .join(""),
      t && t.proxy,
      r
        .map(function (e) {
          var n = e.vnode;
          return "at <".concat(Ns(t, n.type), ">");
        })
        .join("\n"),
      r,
    ]);
  else {
    var s,
      c = ["[Vue warn]: ".concat(e)].concat(i);
    r.length && c.push.apply(c, ["\n"].concat(h(pi(r)))),
      (s = console).warn.apply(s, h(c));
  }
  jr();
}
function li() {
  var e = si[si.length - 1];
  if (!e) return [];
  for (var t = []; e; ) {
    var n = t[0];
    n && n.vnode === e
      ? n.recurseCount++
      : t.push({ vnode: e, recurseCount: 0 });
    var r = e.component && e.component.parent;
    e = r && r.vnode;
  }
  return t;
}
function pi(e) {
  var t = [];
  return (
    e.forEach(function (e, n) {
      var r, o, i, a, s, c, u, f, l, p;
      t.push.apply(
        t,
        h(0 === n ? [] : ["\n"]).concat(
          h(
            ((s = (a = e).vnode),
            (c = a.recurseCount),
            (u = c > 0 ? "... (".concat(c, " recursive calls)") : ""),
            (f = !!s.component && null == s.component.parent),
            (l = " at <".concat(Ns(s.component, s.type, f))),
            (p = ">" + u),
            s.props
              ? [l].concat(
                  h(
                    ((r = s.props),
                    (o = []),
                    (i = Object.keys(r)).slice(0, 3).forEach(function (e) {
                      o.push.apply(
                        o,
                        h(
                          (function e(t, n, r) {
                            return R(n)
                              ? ((n = JSON.stringify(n)),
                                r ? n : ["".concat(t, "=").concat(n)])
                              : "number" == typeof n ||
                                "boolean" == typeof n ||
                                null == n
                              ? r
                                ? n
                                : ["".concat(t, "=").concat(n)]
                              : Qo(n)
                              ? ((n = e(t, Ho(n.value), !0)),
                                r ? n : ["".concat(t, "=Ref<"), n, ">"])
                              : $(n)
                              ? [
                                  ""
                                    .concat(t, "=fn")
                                    .concat(
                                      n.name ? "<".concat(n.name, ">") : ""
                                    ),
                                ]
                              : ((n = Ho(n)), r ? n : ["".concat(t, "="), n]);
                          })(e, r[e])
                        )
                      );
                    }),
                    i.length > 3 && o.push(" ..."),
                    o)
                  ),
                  [p]
                )
              : [l + p])
          )
        )
      );
    }),
    t
  );
}
var hi =
  (p(
    p(
      p(
        p(
          p(
            p(
              p(
                p(
                  p(
                    p((n = {}), "sp", "serverPrefetch hook"),
                    "bc",
                    "beforeCreate hook"
                  ),
                  "c",
                  "created hook"
                ),
                "bm",
                "beforeMount hook"
              ),
              "m",
              "mounted hook"
            ),
            "bu",
            "beforeUpdate hook"
          ),
          "u",
          "updated"
        ),
        "bum",
        "beforeUnmount hook"
      ),
      "um",
      "unmounted hook"
    ),
    "a",
    "activated hook"
  ),
  p(
    p(
      p(
        p(
          p(
            p(
              p(
                p(
                  p(p(n, "da", "deactivated hook"), "ec", "errorCaptured hook"),
                  "rtc",
                  "renderTracked hook"
                ),
                "rtg",
                "renderTriggered hook"
              ),
              0,
              "setup function"
            ),
            1,
            "render function"
          ),
          2,
          "watcher getter"
        ),
        3,
        "watcher callback"
      ),
      4,
      "watcher cleanup function"
    ),
    5,
    "native event handler"
  ),
  p(
    p(
      p(
        p(
          p(
            p(
              p(
                p(p(n, 6, "component event handler"), 7, "vnode hook"),
                8,
                "directive hook"
              ),
              9,
              "transition hook"
            ),
            10,
            "app errorHandler"
          ),
          11,
          "app warnHandler"
        ),
        12,
        "ref function"
      ),
      13,
      "async component loader"
    ),
    14,
    "scheduler flush. This is likely a Vue internals bug. Please open an issue at https://github.com/vuejs/core ."
  ));
function di(e, t, n, r) {
  try {
    return r ? e.apply(void 0, h(r)) : e();
  } catch (e) {
    gi(e, t, n);
  }
}
function vi(e, t, n, r) {
  if ($(e)) {
    var o = di(e, t, n, r);
    return (
      o &&
        D(o) &&
        o.catch(function (e) {
          gi(e, t, n);
        }),
      o
    );
  }
  for (var i = [], a = 0; a < e.length; a++) i.push(vi(e[a], t, n, r));
  return i;
}
function gi(e, t, n) {
  var r = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
    o = t ? t.vnode : null;
  if (t) {
    for (var i = t.parent, a = t.proxy, s = hi[n] || n; i; ) {
      var c = i.ec;
      if (c)
        for (var u = 0; u < c.length; u++) if (!1 === c[u](e, a, s)) return;
      i = i.parent;
    }
    var f = t.appContext.config.errorHandler;
    if (f) return void di(f, null, 10, [e, a, s]);
  }
  mi(e, n, o, r);
}
function mi(e, t, n) {
  var r = hi[t] || t;
  n && ci(n),
    fi("Unhandled error".concat(r ? " during execution of ".concat(r) : "")),
    n && ui(),
    console.error(e);
}
var yi = !1,
  _i = !1,
  bi = [],
  wi = 0,
  ki = [],
  xi = null,
  Si = 0,
  Pi = Promise.resolve(),
  Ti = null;
function Oi(e) {
  var t = Ti || Pi;
  return e ? t.then(this ? e.bind(this) : e) : t;
}
function Ai(e) {
  (bi.length && bi.includes(e, yi && e.allowRecurse ? wi + 1 : wi)) ||
    (null == e.id
      ? bi.push(e)
      : bi.splice(
          (function (e) {
            for (var t = wi + 1, n = bi.length; t < n; ) {
              var r = (t + n) >>> 1,
                o = bi[r],
                i = $i(o);
              i < e || (i === e && o.pre) ? (t = r + 1) : (n = r);
            }
            return t;
          })(e.id),
          0,
          e
        ),
    Ii());
}
function Ii() {
  yi || _i || ((_i = !0), (Ti = Pi.then(ji)));
}
function Ci(e) {
  C(e)
    ? ki.push.apply(ki, h(e))
    : (xi && xi.includes(e, e.allowRecurse ? Si + 1 : Si)) || ki.push(e),
    Ii();
}
function Ei(e, t) {
  var n =
    arguments.length > 2 && void 0 !== arguments[2]
      ? arguments[2]
      : yi
      ? wi + 1
      : 0;
  for (t = t || new Map(); n < bi.length; n++) {
    var r = bi[n];
    if (r && r.pre) {
      if (Mi(t, r)) continue;
      bi.splice(n, 1), n--, r();
    }
  }
}
var Li,
  $i = function (e) {
    return null == e.id ? 1 / 0 : e.id;
  },
  Ri = function (e, t) {
    var n = $i(e) - $i(t);
    if (0 === n) {
      if (e.pre && !t.pre) return -1;
      if (t.pre && !e.pre) return 1;
    }
    return n;
  };
function ji(e) {
  (_i = !1), (yi = !0), (e = e || new Map()), bi.sort(Ri);
  var t = function (t) {
    return Mi(e, t);
  };
  try {
    for (wi = 0; wi < bi.length; wi++) {
      var n = bi[wi];
      if (n && !1 !== n.active) {
        if (t(n)) continue;
        di(n, null, 14);
      }
    }
  } finally {
    (wi = 0),
      (bi.length = 0),
      (function (e) {
        if (ki.length) {
          var t,
            n = h(new Set(ki)).sort(function (e, t) {
              return $i(e) - $i(t);
            });
          if (((ki.length = 0), xi)) return void (t = xi).push.apply(t, h(n));
          for (xi = n, e = e || new Map(), Si = 0; Si < xi.length; Si++)
            Mi(e, xi[Si]) || xi[Si]();
          (xi = null), (Si = 0);
        }
      })(e),
      (yi = !1),
      (Ti = null),
      (bi.length || ki.length) && ji(e);
  }
}
function Mi(e, t) {
  if (e.has(t)) {
    var n = e.get(t);
    if (n > 100) {
      var r = t.ownerInstance,
        o = r && Us(r.type);
      return (
        gi(
          "Maximum recursive updates exceeded".concat(
            o ? " in component <".concat(o, ">") : "",
            ". This means you have a reactive effect that is mutating its own dependencies and thus recursively triggering itself. Possible sources include component template, render function, updated hook or watcher source function."
          ),
          null,
          10
        ),
        !0
      );
    }
    e.set(t, n + 1);
  } else e.set(t, 1);
}
var Di = [],
  Ui = !1;
function Ni(e) {
  for (
    var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1;
    r < t;
    r++
  )
    n[r - 1] = arguments[r];
  var o;
  Li
    ? (o = Li).emit.apply(o, [e].concat(n))
    : Ui || Di.push({ event: e, args: n });
}
function qi(e, t) {
  var n, r;
  if ((Li = e))
    (Li.enabled = !0),
      Di.forEach(function (e) {
        var t,
          n = e.event,
          r = e.args;
        return (t = Li).emit.apply(t, [n].concat(h(r)));
      }),
      (Di = []);
  else if (
    "undefined" != typeof window &&
    window.HTMLElement &&
    !(null == (r = null == (n = window.navigator) ? void 0 : n.userAgent)
      ? void 0
      : r.includes("jsdom"))
  ) {
    (t.__VUE_DEVTOOLS_HOOK_REPLAY__ =
      t.__VUE_DEVTOOLS_HOOK_REPLAY__ || []).push(function (e) {
      qi(e, t);
    }),
      setTimeout(function () {
        Li || ((t.__VUE_DEVTOOLS_HOOK_REPLAY__ = null), (Ui = !0), (Di = []));
      }, 3e3);
  } else (Ui = !0), (Di = []);
}
function Bi(e, t) {
  Ni("app:init", e, t, { Fragment: vs, Text: gs, Comment: ms, Static: ys });
}
var Fi = Ki("component:added"),
  Hi = Ki("component:updated"),
  Vi = Ki("component:removed");
function Ki(e) {
  return function (t) {
    Ni(
      e,
      t.appContext.app,
      t.uid,
      0 === t.uid ? void 0 : t.parent ? t.parent.uid : 0,
      t
    );
  };
}
var Wi = Ji("perf:start"),
  zi = Ji("perf:end");
function Ji(e) {
  return function (t, n, r) {
    Ni(e, t.appContext.app, t.uid, t, n, r);
  };
}
function Yi(e, t, n) {
  Ni("component:emit", e.appContext.app, e, t, n);
}
function Qi(e, t) {
  if (!e.isUnmounted) {
    for (
      var n = e.vnode.props || b,
        r = arguments.length,
        o = new Array(r > 2 ? r - 2 : 0),
        i = 2;
      i < r;
      i++
    )
      o[i - 2] = arguments[i];
    var a = e.emitsOptions,
      s = v(e.propsOptions, 1),
      c = s[0];
    if (a)
      if (t in a) {
        var u = a[t];
        if ($(u)) {
          var f = u.apply(void 0, o);
          f ||
            fi(
              'Invalid event arguments: event validation failed for event "'.concat(
                t,
                '".'
              )
            );
        }
      } else
        (c && G(t) in c) ||
          fi(
            'Component emitted event "'
              .concat(
                t,
                '" but it is neither declared in the emits option nor as an "'
              )
              .concat(G(t), '" prop.')
          );
    var l = o,
      p = t.startsWith("update:"),
      h = p && t.slice(7);
    if (h && h in n) {
      var d = "".concat("modelValue" === h ? "model" : h, "Modifiers"),
        g = n[d] || b,
        m = g.number,
        y = g.trim;
      y &&
        (l = o.map(function (e) {
          return R(e) ? e.trim() : e;
        })),
        m && (l = o.map(ee));
    }
    Yi(e, t, l);
    var _,
      w = t.toLowerCase();
    w !== t &&
      n[G(w)] &&
      fi(
        'Event "'
          .concat(w, '" is emitted in component ')
          .concat(Ns(e, e.type), ' but the handler is registered for "')
          .concat(
            t,
            '". Note that HTML attributes are case-insensitive and you cannot use v-on to listen to camelCase events when using in-DOM templates. You should probably use "'
          )
          .concat(Y(t), '" instead of "')
          .concat(t, '".')
      );
    var k = n[(_ = G(t))] || n[(_ = G(z(t)))];
    !k && p && (k = n[(_ = G(Y(t)))]), k && vi(k, e, 6, l);
    var x = n[_ + "Once"];
    if (x) {
      if (e.emitted) {
        if (e.emitted[_]) return;
      } else e.emitted = {};
      (e.emitted[_] = !0), vi(x, e, 6, l);
    }
  }
}
function Gi(e, t) {
  var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
    r = t.emitsCache,
    o = r.get(e);
  if (void 0 !== o) return o;
  var i = e.emits,
    a = {},
    s = !1;
  if (!$(e)) {
    var c = function (e) {
      var n = Gi(e, t, !0);
      n && ((s = !0), T(a, n));
    };
    !n && t.mixins.length && t.mixins.forEach(c),
      e.extends && c(e.extends),
      e.mixins && e.mixins.forEach(c);
  }
  return i || s
    ? (C(i)
        ? i.forEach(function (e) {
            return (a[e] = null);
          })
        : T(a, i),
      M(e) && r.set(e, a),
      a)
    : (M(e) && r.set(e, null), null);
}
function Xi(e, t) {
  return (
    !(!e || !S(t)) &&
    ((t = t.slice(2).replace(/Once$/, "")),
    I(e, t[0].toLowerCase() + t.slice(1)) || I(e, Y(t)) || I(e, t))
  );
}
var Zi = null;
function ea(e) {
  var t = Zi;
  return (Zi = e), e && e.type.__scopeId, t;
}
function ta(e, t) {
  return e && (e[t] || e[z(t)] || e[Q(z(t))]);
}
var na = {};
function ra(e, t, n) {
  return (
    $(t) ||
      fi(
        "`watch(fn, options?)` signature has been moved to a separate API. Use `watchEffect(fn, options?)` instead. `watch` now only supports `watch(source, cb, options?) signature."
      ),
    oa(e, t, n)
  );
}
function oa(e, t) {
  var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : b,
    r = n.immediate,
    o = n.deep,
    i = n.flush,
    a = n.once,
    s = n.onTrack,
    c = n.onTrigger;
  if (t && a) {
    var u = t;
    t = function () {
      u.apply(void 0, arguments), T();
    };
  }
  void 0 !== o &&
    "number" == typeof o &&
    fi(
      'watch() "deep" option with number value will be used as watch depth in future versions. Please use a boolean instead to avoid potential breakage.'
    ),
    t ||
      (void 0 !== r &&
        fi(
          'watch() "immediate" option is only respected when using the watch(source, callback, options?) signature.'
        ),
      void 0 !== o &&
        fi(
          'watch() "deep" option is only respected when using the watch(source, callback, options?) signature.'
        ),
      void 0 !== a &&
        fi(
          'watch() "once" option is only respected when using the watch(source, callback, options?) signature.'
        ));
  var f,
    l,
    p = function (e) {
      fi(
        "Invalid watch source: ",
        e,
        "A watch source can only be a getter/effect function, a ref, a reactive object, or an array of these types."
      );
    },
    h = Ss,
    d = function (e) {
      return !0 === o ? e : sa(e, !1 === o ? 1 : void 0);
    },
    v = !1,
    g = !1;
  if (
    (Qo(e)
      ? ((f = function () {
          return e.value;
        }),
        (v = Bo(e)))
      : No(e)
      ? ((f = function () {
          return d(e);
        }),
        (v = !0))
      : C(e)
      ? ((g = !0),
        (v = e.some(function (e) {
          return No(e) || Bo(e);
        })),
        (f = function () {
          return e.map(function (e) {
            return Qo(e)
              ? e.value
              : No(e)
              ? d(e)
              : $(e)
              ? di(e, h, 2)
              : void p(e);
          });
        }))
      : $(e)
      ? (f = t
          ? function () {
              return di(e, h, 2);
            }
          : function () {
              return l && l(), vi(e, h, 3, [_]);
            })
      : ((f = k), p(e)),
    t && o)
  ) {
    var m = f;
    f = function () {
      return sa(m());
    };
  }
  var y,
    _ = function (e) {
      l = S.onStop = function () {
        di(e, h, 4), (l = S.onStop = void 0);
      };
    },
    w = g ? new Array(e.length).fill(na) : na,
    x = function () {
      if (S.active && S.dirty)
        if (t) {
          var e = S.run();
          (o ||
            v ||
            (g
              ? e.some(function (e, t) {
                  return X(e, w[t]);
                })
              : X(e, w))) &&
            (l && l(),
            vi(t, h, 3, [e, w === na ? void 0 : g && w[0] === na ? [] : w, _]),
            (w = e));
        } else S.run();
    };
  (x.allowRecurse = !!t),
    "sync" === i
      ? (y = x)
      : "post" === i
      ? (y = function () {
          return ds(x, h && h.suspense);
        })
      : ((x.pre = !0),
        h && (x.id = h.uid),
        (y = function () {
          return Ai(x);
        }));
  var S = new Or(f, k, y),
    P = Pr(),
    T = function () {
      S.stop(), P && O(P.effects, S);
    };
  return (
    (S.onTrack = s),
    (S.onTrigger = c),
    t
      ? r
        ? x()
        : (w = S.run())
      : "post" === i
      ? ds(S.run.bind(S), h && h.suspense)
      : S.run(),
    T
  );
}
function ia(e, t, n) {
  var r,
    o = this.proxy,
    i = R(e)
      ? e.includes(".")
        ? aa(o, e)
        : function () {
            return o[e];
          }
      : e.bind(o, o);
  $(t) ? (r = t) : ((r = t.handler), (n = t));
  var a = Ts(this),
    s = oa(i, r.bind(o), n);
  return a(), s;
}
function aa(e, t) {
  var n = t.split(".");
  return function () {
    for (var t = e, r = 0; r < n.length && t; r++) t = t[n[r]];
    return t;
  };
}
function sa(e, t) {
  var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
    r = arguments.length > 3 ? arguments[3] : void 0;
  if (!M(e) || e.__v_skip) return e;
  if (t && t > 0) {
    if (n >= t) return e;
    n++;
  }
  if ((r = r || new Set()).has(e)) return e;
  if ((r.add(e), Qo(e))) sa(e.value, t, n, r);
  else if (C(e)) for (var o = 0; o < e.length; o++) sa(e[o], t, n, r);
  else if (L(e) || E(e))
    e.forEach(function (e) {
      sa(e, t, n, r);
    });
  else if (B(e)) for (var i in e) sa(e[i], t, n, r);
  return e;
}
function ca(e) {
  V(e) && fi("Do not use built-in directive ids as custom directive id: " + e);
}
function ua() {
  return {
    app: null,
    config: {
      isNativeTag: x,
      performance: !1,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {},
    },
    mixins: [],
    components: {},
    directives: {},
    provides: Object.create(null),
    optionsCache: new WeakMap(),
    propsCache: new WeakMap(),
    emitsCache: new WeakMap(),
  };
}
var fa = 0;
var la = null;
function pa(e, t) {
  var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
    r = Ss || Zi;
  if (r || la) {
    var o = r
      ? null == r.parent
        ? r.vnode.appContext && r.vnode.appContext.provides
        : r.parent.provides
      : la._context.provides;
    if (o && e in o) return o[e];
    if (arguments.length > 1) return n && $(t) ? t.call(r && r.proxy) : t;
    fi('injection "'.concat(String(e), '" not found.'));
  } else
    fi("inject() can only be used inside setup() or functional components.");
}
function ha() {
  return !!(Ss || Zi || la);
}
var da = function (e) {
  return e.type.__isKeepAlive;
};
function va(e, t) {
  ma(e, "a", t);
}
function ga(e, t) {
  ma(e, "da", t);
}
function ma(e, t) {
  var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Ss,
    r =
      e.__wdc ||
      (e.__wdc = function () {
        for (var t = n; t; ) {
          if (t.isDeactivated) return;
          t = t.parent;
        }
        return e();
      });
  if ((_a(t, r, n), n))
    for (var o = n.parent; o && o.parent; )
      da(o.parent.vnode) && ya(r, t, n, o), (o = o.parent);
}
function ya(e, t, n, r) {
  var o = _a(t, e, r, !0);
  Ta(function () {
    O(r[t], o);
  }, n);
}
function _a(e, t) {
  var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Ss,
    r = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
  if (n) {
    ve(e) && (n = n.root);
    var o = n[e] || (n[e] = []),
      i =
        t.__weh ||
        (t.__weh = function () {
          if (!n.isUnmounted) {
            Rr();
            for (
              var r = Ts(n), o = arguments.length, i = new Array(o), a = 0;
              a < o;
              a++
            )
              i[a] = arguments[a];
            var s = vi(t, n, e, i);
            return r(), jr(), s;
          }
        });
    return r ? o.unshift(i) : o.push(i), i;
  }
  var a = G((hi[e] || e.replace(/^on/, "")).replace(/ hook$/, ""));
  fi(
    "".concat(
      a,
      " is called when there is no active component instance to be associated with. Lifecycle injection APIs can only be used during execution of setup()."
    )
  );
}
var ba = function (e) {
    return function (t) {
      var n =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Ss;
      return (
        (!Es || "sp" === e) &&
        _a(
          e,
          function () {
            return t.apply(void 0, arguments);
          },
          n
        )
      );
    };
  },
  wa = ba("bm"),
  ka = ba("m"),
  xa = ba("bu"),
  Sa = ba("u"),
  Pa = ba("bum"),
  Ta = ba("um"),
  Oa = ba("sp"),
  Aa = ba("rtg"),
  Ia = ba("rtc");
function Ca(e) {
  var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Ss;
  _a("ec", e, t);
}
var Ea = function e(t) {
    return t ? (Cs(t) ? js(t) || t.proxy : e(t.parent)) : null;
  },
  La = T(Object.create(null), {
    $: function (e) {
      return e;
    },
    $el: function (e) {
      return e.__$el || (e.__$el = {});
    },
    $data: function (e) {
      return e.data;
    },
    $props: function (e) {
      return Do(e.props);
    },
    $attrs: function (e) {
      return Do(e.attrs);
    },
    $slots: function (e) {
      return Do(e.slots);
    },
    $refs: function (e) {
      return Do(e.refs);
    },
    $parent: function (e) {
      return Ea(e.parent);
    },
    $root: function (e) {
      return Ea(e.root);
    },
    $emit: function (e) {
      return e.emit;
    },
    $options: function (e) {
      return Ba(e);
    },
    $forceUpdate: function (e) {
      return (
        e.f ||
        (e.f = function () {
          (e.effect.dirty = !0), Ai(e.update);
        })
      );
    },
    $watch: function (e) {
      return ia.bind(e);
    },
  }),
  $a = function (e) {
    return "_" === e || "$" === e;
  },
  Ra = function (e, t) {
    return e !== b && !e.__isScriptSetup && I(e, t);
  },
  ja = {
    get: function (e, t) {
      var n,
        r = e._,
        o = r.ctx,
        i = r.setupState,
        a = r.data,
        s = r.props,
        c = r.accessCache,
        u = r.type,
        f = r.appContext;
      if ("__isVue" === t) return !0;
      if ("$" !== t[0]) {
        var l = c[t];
        if (void 0 !== l)
          switch (l) {
            case 1:
              return i[t];
            case 2:
              return a[t];
            case 4:
              return o[t];
            case 3:
              return s[t];
          }
        else {
          if (Ra(i, t)) return (c[t] = 1), i[t];
          if (a !== b && I(a, t)) return (c[t] = 2), a[t];
          if ((n = r.propsOptions[0]) && I(n, t)) return (c[t] = 3), s[t];
          if (o !== b && I(o, t)) return (c[t] = 4), o[t];
          Da && (c[t] = 0);
        }
      }
      var p,
        h,
        d = La[t];
      return d
        ? (("$attrs" === t || "$slots" === t) && Kr(r, "get", t), d(r))
        : (p = u.__cssModules) && (p = p[t])
        ? p
        : o !== b && I(o, t)
        ? ((c[t] = 4), o[t])
        : ((h = f.config.globalProperties),
          I(h, t)
            ? h[t]
            : void (
                !Zi ||
                (R(t) && 0 === t.indexOf("__v")) ||
                (a !== b && $a(t[0]) && I(a, t)
                  ? fi(
                      "Property ".concat(
                        JSON.stringify(t),
                        ' must be accessed via $data because it starts with a reserved character ("$" or "_") and is not proxied on the render context.'
                      )
                    )
                  : r === Zi &&
                    fi(
                      "Property ".concat(
                        JSON.stringify(t),
                        " was accessed during render but is not defined on instance."
                      )
                    ))
              ));
    },
    set: function (e, t, n) {
      var r = e._,
        o = r.data,
        i = r.setupState,
        a = r.ctx;
      return Ra(i, t)
        ? ((i[t] = n), !0)
        : i.__isScriptSetup && I(i, t)
        ? (fi(
            'Cannot mutate <script setup> binding "'.concat(
              t,
              '" from Options API.'
            )
          ),
          !1)
        : o !== b && I(o, t)
        ? ((o[t] = n), !0)
        : I(r.props, t)
        ? (fi(
            'Attempting to mutate prop "'.concat(t, '". Props are readonly.')
          ),
          !1)
        : "$" === t[0] && t.slice(1) in r
        ? (fi(
            'Attempting to mutate public property "'.concat(
              t,
              '". Properties starting with $ are reserved and readonly.'
            )
          ),
          !1)
        : (t in r.appContext.config.globalProperties
            ? Object.defineProperty(a, t, {
                enumerable: !0,
                configurable: !0,
                value: n,
              })
            : (a[t] = n),
          !0);
    },
    has: function (e, t) {
      var n,
        r = e._,
        o = r.data,
        i = r.setupState,
        a = r.accessCache,
        s = r.ctx,
        c = r.appContext,
        u = r.propsOptions;
      return (
        !!a[t] ||
        (o !== b && I(o, t)) ||
        Ra(i, t) ||
        ((n = u[0]) && I(n, t)) ||
        I(s, t) ||
        I(La, t) ||
        I(c.config.globalProperties, t)
      );
    },
    defineProperty: function (e, t, n) {
      return (
        null != n.get
          ? (e._.accessCache[t] = 0)
          : I(n, "value") && this.set(e, t, n.value, null),
        Reflect.defineProperty(e, t, n)
      );
    },
  };
function Ma(e) {
  return C(e)
    ? e.reduce(function (e, t) {
        return (e[t] = null), e;
      }, {})
    : e;
}
ja.ownKeys = function (e) {
  return (
    fi(
      "Avoid app logic that relies on enumerating keys on a component instance. The keys will be empty in production mode to avoid performance overhead."
    ),
    Reflect.ownKeys(e)
  );
};
var Da = !0;
function Ua(e) {
  var t = Ba(e),
    n = e.proxy,
    r = e.ctx;
  (Da = !1), t.beforeCreate && Na(t.beforeCreate, e, "bc");
  var o,
    i = t.data,
    a = t.computed,
    s = t.methods,
    c = t.watch,
    u = t.provide,
    f = t.inject,
    l = t.created,
    p = t.beforeMount,
    h = t.mounted,
    g = t.beforeUpdate,
    m = t.updated,
    y = t.activated,
    _ = t.deactivated,
    b = (t.beforeDestroy, t.beforeUnmount),
    w = (t.destroyed, t.unmounted),
    x = t.render,
    S = t.renderTracked,
    P = t.renderTriggered,
    T = t.errorCaptured,
    O = t.serverPrefetch,
    A = t.expose,
    I = t.inheritAttrs,
    E = t.components,
    L = t.directives,
    R =
      (t.filters,
      (o = Object.create(null)),
      function (e, t) {
        o[t]
          ? fi(
              ""
                .concat(e, ' property "')
                .concat(t, '" is already defined in ')
                .concat(o[t], ".")
            )
          : (o[t] = e);
      }),
    j = v(e.propsOptions, 1)[0];
  if (j) for (var U in j) R("Props", U);
  if (
    (f &&
      (function (e, t) {
        var n =
          arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : k;
        C(e) && (e = Ka(e));
        var r = function () {
          var r,
            i = e[o];
          Qo(
            (r = M(i)
              ? "default" in i
                ? pa(i.from || o, i.default, !0)
                : pa(i.from || o)
              : pa(i))
          )
            ? Object.defineProperty(t, o, {
                enumerable: !0,
                configurable: !0,
                get: function () {
                  return r.value;
                },
                set: function (e) {
                  return (r.value = e);
                },
              })
            : (t[o] = r),
            n("Inject", o);
        };
        for (var o in e) r();
      })(f, r, R),
    s)
  )
    for (var N in s) {
      var q = s[N];
      $(q)
        ? (Object.defineProperty(r, N, {
            value: q.bind(n),
            configurable: !0,
            enumerable: !0,
            writable: !0,
          }),
          R("Methods", N))
        : fi(
            'Method "'
              .concat(N, '" has type "')
              .concat(
                d(q),
                '" in the component definition. Did you reference the function correctly?'
              )
          );
    }
  if (i) {
    $(i) ||
      fi(
        "The data option must be a function. Plain object usage is no longer supported."
      );
    var B = i.call(n, n);
    if (
      (D(B) &&
        fi(
          "data() returned a Promise - note data() cannot be async; If you intend to perform data fetching before component renders, use async setup() + <Suspense>."
        ),
      M(B))
    ) {
      e.data = Ro(B);
      var F = function (e) {
        R("Data", e),
          $a(e[0]) ||
            Object.defineProperty(r, e, {
              configurable: !0,
              enumerable: !0,
              get: function () {
                return B[e];
              },
              set: k,
            });
      };
      for (var H in B) F(H);
    } else fi("data() should return an object.");
  }
  if (((Da = !0), a)) {
    var V = function (e) {
      var t = a[e],
        o = $(t) ? t.bind(n, n) : $(t.get) ? t.get.bind(n, n) : k;
      o === k && fi('Computed property "'.concat(e, '" has no getter.'));
      var i =
          !$(t) && $(t.set)
            ? t.set.bind(n)
            : function () {
                fi(
                  'Write operation failed: computed property "'.concat(
                    e,
                    '" is readonly.'
                  )
                );
              },
        s = qs({ get: o, set: i });
      Object.defineProperty(r, e, {
        enumerable: !0,
        configurable: !0,
        get: function () {
          return s.value;
        },
        set: function (e) {
          return (s.value = e);
        },
      }),
        R("Computed", e);
    };
    for (var K in a) V(K);
  }
  if (c) for (var W in c) qa(c[W], r, n, W);
  if (u) {
    var z = $(u) ? u.call(n) : u;
    Reflect.ownKeys(z).forEach(function (e) {
      !(function (e, t) {
        if (Ss) {
          var n = Ss.provides,
            r = Ss.parent && Ss.parent.provides;
          r === n && (n = Ss.provides = Object.create(r)),
            (n[e] = t),
            "app" === Ss.type.mpType && Ss.appContext.app.provide(e, t);
        } else fi("provide() can only be used inside setup().");
      })(e, z[e]);
    });
  }
  function J(e, t) {
    C(t)
      ? t.forEach(function (t) {
          return e(t.bind(n));
        })
      : t && e(t.bind(n));
  }
  if (
    (l && Na(l, e, "c"),
    J(wa, p),
    J(ka, h),
    J(xa, g),
    J(Sa, m),
    J(va, y),
    J(ga, _),
    J(Ca, T),
    J(Ia, S),
    J(Aa, P),
    J(Pa, b),
    J(Ta, w),
    J(Oa, O),
    C(A))
  )
    if (A.length) {
      var Y = e.exposed || (e.exposed = {});
      A.forEach(function (e) {
        Object.defineProperty(Y, e, {
          get: function () {
            return n[e];
          },
          set: function (t) {
            return (n[e] = t);
          },
        });
      });
    } else e.exposed || (e.exposed = {});
  x && e.render === k && (e.render = x),
    null != I && (e.inheritAttrs = I),
    E && (e.components = E),
    L && (e.directives = L),
    e.ctx.$onApplyOptions && e.ctx.$onApplyOptions(t, e, n);
}
function Na(e, t, n) {
  vi(
    C(e)
      ? e.map(function (e) {
          return e.bind(t.proxy);
        })
      : e.bind(t.proxy),
    t,
    n
  );
}
function qa(e, t, n, r) {
  var o = r.includes(".")
    ? aa(n, r)
    : function () {
        return n[r];
      };
  if (R(e)) {
    var i = t[e];
    $(i)
      ? ra(o, i)
      : fi('Invalid watch handler specified by key "'.concat(e, '"'), i);
  } else if ($(e)) ra(o, e.bind(n));
  else if (M(e))
    if (C(e))
      e.forEach(function (e) {
        return qa(e, t, n, r);
      });
    else {
      var a = $(e.handler) ? e.handler.bind(n) : t[e.handler];
      $(a)
        ? ra(o, a, e)
        : fi(
            'Invalid watch handler specified by key "'.concat(e.handler, '"'),
            a
          );
    }
  else fi('Invalid watch option: "'.concat(r, '"'), e);
}
function Ba(e) {
  var t,
    n = e.type,
    r = n.mixins,
    o = n.extends,
    i = e.appContext,
    a = i.mixins,
    s = i.optionsCache,
    c = i.config.optionMergeStrategies,
    u = s.get(n);
  return (
    u
      ? (t = u)
      : a.length || r || o
      ? ((t = {}),
        a.length &&
          a.forEach(function (e) {
            return Fa(t, e, c, !0);
          }),
        Fa(t, n, c))
      : (t = n),
    M(n) && s.set(n, t),
    t
  );
}
function Fa(e, t, n) {
  var r = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
    o = t.mixins,
    i = t.extends;
  for (var a in (i && Fa(e, i, n, !0),
  o &&
    o.forEach(function (t) {
      return Fa(e, t, n, !0);
    }),
  t))
    if (r && "expose" === a)
      fi(
        '"expose" option is ignored when declared in mixins or extends. It should only be declared in the base component itself.'
      );
    else {
      var s = Ha[a] || (n && n[a]);
      e[a] = s ? s(e[a], t[a]) : t[a];
    }
  return e;
}
var Ha = {
  data: Va,
  props: Ja,
  emits: Ja,
  methods: za,
  computed: za,
  beforeCreate: Wa,
  created: Wa,
  beforeMount: Wa,
  mounted: Wa,
  beforeUpdate: Wa,
  updated: Wa,
  beforeDestroy: Wa,
  beforeUnmount: Wa,
  destroyed: Wa,
  unmounted: Wa,
  activated: Wa,
  deactivated: Wa,
  errorCaptured: Wa,
  serverPrefetch: Wa,
  components: za,
  directives: za,
  watch: function (e, t) {
    if (!e) return t;
    if (!t) return e;
    var n = T(Object.create(null), e);
    for (var r in t) n[r] = Wa(e[r], t[r]);
    return n;
  },
  provide: Va,
  inject: function (e, t) {
    return za(Ka(e), Ka(t));
  },
};
function Va(e, t) {
  return t
    ? e
      ? function () {
          return T(
            $(e) ? e.call(this, this) : e,
            $(t) ? t.call(this, this) : t
          );
        }
      : t
    : e;
}
function Ka(e) {
  if (C(e)) {
    for (var t = {}, n = 0; n < e.length; n++) t[e[n]] = e[n];
    return t;
  }
  return e;
}
function Wa(e, t) {
  return e ? h(new Set([].concat(e, t))) : t;
}
function za(e, t) {
  return e ? T(Object.create(null), e, t) : t;
}
function Ja(e, t) {
  return e
    ? C(e) && C(t)
      ? h(new Set([].concat(h(e), h(t))))
      : T(Object.create(null), Ma(e), Ma(null != t ? t : {}))
    : t;
}
function Ya(e, t, n) {
  var r = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
    o = {},
    i = {};
  for (var a in ((e.propsDefaults = Object.create(null)),
  Qa(e, t, o, i),
  e.propsOptions[0]))
    a in o || (o[a] = void 0);
  rs(t || {}, o, e),
    n
      ? (e.props = r ? o : jo(o))
      : e.type.props
      ? (e.props = o)
      : (e.props = i),
    (e.attrs = i);
}
function Qa(e, t, n, r) {
  var o,
    i = v(e.propsOptions, 2),
    a = i[0],
    s = i[1],
    c = !1;
  if (t)
    for (var u in t)
      if (!H(u)) {
        var f = t[u],
          l = void 0;
        a && I(a, (l = z(u)))
          ? s && s.includes(l)
            ? ((o || (o = {}))[l] = f)
            : (n[l] = f)
          : Xi(e.emitsOptions, u) ||
            (u in r && f === r[u]) ||
            ((r[u] = f), (c = !0));
      }
  if (s)
    for (var p = Ho(n), h = o || b, d = 0; d < s.length; d++) {
      var g = s[d];
      n[g] = Ga(a, p, g, h[g], e, !I(h, g));
    }
  return c;
}
function Ga(e, t, n, r, o, i) {
  var a = e[n];
  if (null != a) {
    var s = I(a, "default");
    if (s && void 0 === r) {
      var c = a.default;
      if (a.type !== Function && !a.skipFactory && $(c)) {
        var u = o.propsDefaults;
        if (n in u) r = u[n];
        else {
          var f = Ts(o);
          (r = u[n] = c.call(null, t)), f();
        }
      } else r = c;
    }
    a[0] &&
      (i && !s ? (r = !1) : !a[1] || ("" !== r && r !== Y(n)) || (r = !0));
  }
  return r;
}
function Xa(e, t) {
  var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
    r = t.propsCache,
    o = r.get(e);
  if (o) return o;
  var i = e.props,
    a = {},
    s = [],
    c = !1;
  if (!$(e)) {
    var u = function (e) {
      c = !0;
      var n = Xa(e, t, !0),
        r = v(n, 2),
        o = r[0],
        i = r[1];
      T(a, o), i && s.push.apply(s, h(i));
    };
    !n && t.mixins.length && t.mixins.forEach(u),
      e.extends && u(e.extends),
      e.mixins && e.mixins.forEach(u);
  }
  if (!i && !c) return M(e) && r.set(e, w), w;
  if (C(i))
    for (var f = 0; f < i.length; f++) {
      R(i[f]) || fi("props must be strings when using array syntax.", i[f]);
      var l = z(i[f]);
      Za(l) && (a[l] = b);
    }
  else if (i)
    for (var p in (M(i) || fi("invalid props options", i), i)) {
      var d = z(p);
      if (Za(d)) {
        var g = i[p],
          m = (a[d] = C(g) || $(g) ? { type: g } : T({}, g));
        if (m) {
          var y = ns(Boolean, m.type),
            _ = ns(String, m.type);
          (m[0] = y > -1),
            (m[1] = _ < 0 || y < _),
            (y > -1 || I(m, "default")) && s.push(d);
        }
      }
    }
  var k = [a, s];
  return M(e) && r.set(e, k), k;
}
function Za(e) {
  return (
    ("$" !== e[0] && !H(e)) ||
    (fi('Invalid prop name: "'.concat(e, '" is a reserved property.')), !1)
  );
}
function es(e) {
  return null === e
    ? "null"
    : "function" == typeof e
    ? e.name || ""
    : ("object" === d(e) && e.constructor && e.constructor.name) || "";
}
function ts(e, t) {
  return es(e) === es(t);
}
function ns(e, t) {
  return C(t)
    ? t.findIndex(function (t) {
        return ts(t, e);
      })
    : $(t) && ts(t, e)
    ? 0
    : -1;
}
function rs(e, t, n) {
  var r = Ho(t),
    o = n.propsOptions[0];
  for (var i in o) {
    var a = o[i];
    null != a && os(i, r[i], a, Do(r), !I(e, i) && !I(e, Y(i)));
  }
}
function os(e, t, n, r, o) {
  var i = n.type,
    a = n.required,
    s = n.validator,
    c = n.skipCheck;
  if (a && o) fi('Missing required prop: "' + e + '"');
  else if (null != t || a) {
    if (null != i && !0 !== i && !c) {
      for (
        var u = !1, f = C(i) ? i : [i], l = [], p = 0;
        p < f.length && !u;
        p++
      ) {
        var h = cs(t, f[p]),
          d = h.valid,
          v = h.expectedType;
        l.push(v || ""), (u = d);
      }
      if (!u)
        return void fi(
          (function (e, t, n) {
            if (0 === n.length)
              return 'Prop type [] for prop "'.concat(
                e,
                "\" won't match anything. Did you mean to use type Array instead?"
              );
            var r = 'Invalid prop: type check failed for prop "'
                .concat(e, '". Expected ')
                .concat(n.map(Q).join(" | ")),
              o = n[0],
              i = q(t),
              a = us(t, o),
              s = us(t, i);
            1 === n.length &&
              fs(o) &&
              !(function () {
                for (
                  var e = arguments.length, t = new Array(e), n = 0;
                  n < e;
                  n++
                )
                  t[n] = arguments[n];
                return t.some(function (e) {
                  return "boolean" === e.toLowerCase();
                });
              })(o, i) &&
              (r += " with value ".concat(a));
            (r += ", got ".concat(i, " ")),
              fs(i) && (r += "with value ".concat(s, "."));
            return r;
          })(e, t, l)
        );
    }
    s &&
      !s(t, r) &&
      fi('Invalid prop: custom validator check failed for prop "' + e + '".');
  }
}
var is,
  as,
  ss = y("String,Number,Boolean,Function,Symbol,BigInt");
function cs(e, t) {
  var n,
    r = es(t);
  if (ss(r)) {
    var o = d(e);
    (n = o === r.toLowerCase()) || "object" !== o || (n = e instanceof t);
  } else
    n =
      "Object" === r
        ? M(e)
        : "Array" === r
        ? C(e)
        : "null" === r
        ? null === e
        : e instanceof t;
  return { valid: n, expectedType: r };
}
function us(e, t) {
  return "String" === t
    ? '"'.concat(e, '"')
    : "".concat("Number" === t ? Number(e) : e);
}
function fs(e) {
  return ["string", "number", "boolean"].some(function (t) {
    return e.toLowerCase() === t;
  });
}
function ls(e, t) {
  e.appContext.config.performance &&
    hs() &&
    as.mark("vue-".concat(t, "-").concat(e.uid)),
    Wi(e, t, hs() ? as.now() : Date.now());
}
function ps(e, t) {
  if (e.appContext.config.performance && hs()) {
    var n = "vue-".concat(t, "-").concat(e.uid),
      r = n + ":end";
    as.mark(r),
      as.measure("<".concat(Ns(e, e.type), "> ").concat(t), n, r),
      as.clearMarks(n),
      as.clearMarks(r);
  }
  zi(e, t, hs() ? as.now() : Date.now());
}
function hs() {
  return (
    void 0 !== is ||
      ("undefined" != typeof window && window.performance
        ? ((is = !0), (as = window.performance))
        : (is = !1)),
    is
  );
}
var ds = Ci,
  vs = Symbol.for("v-fgt"),
  gs = Symbol.for("v-txt"),
  ms = Symbol.for("v-cmt"),
  ys = Symbol.for("v-stc");
var _s = ua(),
  bs = 0;
function ws(e, t, n) {
  var r = e.type,
    o = (t ? t.appContext : e.appContext) || _s,
    i = {
      uid: bs++,
      vnode: e,
      type: r,
      parent: t,
      appContext: o,
      root: null,
      next: null,
      subTree: null,
      effect: null,
      update: null,
      scope: new xr(!0),
      render: null,
      proxy: null,
      exposed: null,
      exposeProxy: null,
      withProxy: null,
      provides: t ? t.provides : Object.create(o.provides),
      accessCache: null,
      renderCache: [],
      components: null,
      directives: null,
      propsOptions: Xa(r, o),
      emitsOptions: Gi(r, o),
      emit: null,
      emitted: null,
      propsDefaults: b,
      inheritAttrs: r.inheritAttrs,
      ctx: b,
      data: b,
      props: b,
      attrs: b,
      slots: b,
      refs: b,
      setupState: b,
      setupContext: null,
      attrsProxy: null,
      slotsProxy: null,
      suspense: n,
      suspenseId: n ? n.pendingId : 0,
      asyncDep: null,
      asyncResolved: !1,
      isMounted: !1,
      isUnmounted: !1,
      isDeactivated: !1,
      bc: null,
      c: null,
      bm: null,
      m: null,
      bu: null,
      u: null,
      um: null,
      bum: null,
      da: null,
      a: null,
      rtg: null,
      rtc: null,
      ec: null,
      sp: null,
    };
  return (
    (i.ctx = (function (e) {
      var t = {};
      return (
        Object.defineProperty(t, "_", {
          configurable: !0,
          enumerable: !1,
          get: function () {
            return e;
          },
        }),
        Object.keys(La).forEach(function (n) {
          Object.defineProperty(t, n, {
            configurable: !0,
            enumerable: !1,
            get: function () {
              return La[n](e);
            },
            set: k,
          });
        }),
        t
      );
    })(i)),
    (i.root = t ? t.root : i),
    (i.emit = Qi.bind(null, i)),
    e.ce && e.ce(i),
    i
  );
}
var ks,
  xs,
  Ss = null,
  Ps = function () {
    return Ss || Zi;
  };
(ks = function (e) {
  Ss = e;
}),
  (xs = function (e) {
    Es = e;
  });
var Ts = function (e) {
    var t = Ss;
    return (
      ks(e),
      e.scope.on(),
      function () {
        e.scope.off(), ks(t);
      }
    );
  },
  Os = function () {
    Ss && Ss.scope.off(), ks(null);
  },
  As = y("slot,component");
function Is(e, t) {
  var n = t.isNativeTag;
  (As(e) || n(e)) &&
    fi("Do not use built-in or reserved HTML elements as component id: " + e);
}
function Cs(e) {
  return 4 & e.vnode.shapeFlag;
}
var Es = !1;
function Ls(e, t) {
  var n = e.type;
  if ((n.name && Is(n.name, e.appContext.config), n.components))
    for (var r = Object.keys(n.components), o = 0; o < r.length; o++)
      Is(r[o], e.appContext.config);
  if (n.directives)
    for (var i = Object.keys(n.directives), a = 0; a < i.length; a++) ca(i[a]);
  n.compilerOptions &&
    $s() &&
    fi(
      '"compilerOptions" is only supported when using a build of Vue that includes the runtime compiler. Since you are using a runtime-only build, the options should be passed via your build tool config instead.'
    ),
    (e.accessCache = Object.create(null)),
    (e.proxy = Vo(new Proxy(e.ctx, ja))),
    (function (e) {
      var t = e.ctx,
        n = v(e.propsOptions, 1)[0];
      n &&
        Object.keys(n).forEach(function (n) {
          Object.defineProperty(t, n, {
            enumerable: !0,
            configurable: !0,
            get: function () {
              return e.props[n];
            },
            set: k,
          });
        });
    })(e);
  var s = n.setup;
  if (s) {
    var c = (e.setupContext =
        s.length > 1
          ? (function (e) {
              return Object.freeze({
                get attrs() {
                  return (function (e) {
                    return (
                      e.attrsProxy ||
                      (e.attrsProxy = new Proxy(e.attrs, {
                        get: function (t, n) {
                          return Kr(e, "get", "$attrs"), t[n];
                        },
                        set: function () {
                          return fi("setupContext.attrs is readonly."), !1;
                        },
                        deleteProperty: function () {
                          return fi("setupContext.attrs is readonly."), !1;
                        },
                      }))
                    );
                  })(e);
                },
                get slots() {
                  return (function (e) {
                    return (
                      e.slotsProxy ||
                      (e.slotsProxy = new Proxy(e.slots, {
                        get: function (t, n) {
                          return Kr(e, "get", "$slots"), t[n];
                        },
                      }))
                    );
                  })(e);
                },
                get emit() {
                  return function (t) {
                    for (
                      var n = arguments.length,
                        r = new Array(n > 1 ? n - 1 : 0),
                        o = 1;
                      o < n;
                      o++
                    )
                      r[o - 1] = arguments[o];
                    return e.emit.apply(e, [t].concat(r));
                  };
                },
                expose: function (t) {
                  if (
                    (e.exposed &&
                      fi("expose() should be called only once per setup()."),
                    null != t)
                  ) {
                    var n = d(t);
                    "object" === n &&
                      (C(t) ? (n = "array") : Qo(t) && (n = "ref")),
                      "object" !== n &&
                        fi(
                          "expose() should be passed a plain object, received ".concat(
                            n,
                            "."
                          )
                        );
                  }
                  e.exposed = t || {};
                },
              });
            })(e)
          : null),
      u = Ts(e);
    Rr();
    var f = di(s, e, 0, [Do(e.props), c]);
    jr(),
      u(),
      D(f)
        ? (f.then(Os, Os),
          fi(
            "setup() returned a Promise, but the version of Vue you are using does not support it yet."
          ))
        : (function (e, t, n) {
            $(t)
              ? (e.render = t)
              : M(t)
              ? ((r = t) &&
                  !0 === r.__v_isVNode &&
                  fi(
                    "setup() should not return VNodes directly - return a render function instead."
                  ),
                (e.devtoolsRawSetupState = t),
                (e.setupState = ti(t)),
                (function (e) {
                  var t = e.ctx,
                    n = e.setupState;
                  Object.keys(Ho(n)).forEach(function (e) {
                    if (!n.__isScriptSetup) {
                      if ($a(e[0]))
                        return void fi(
                          "setup() return property ".concat(
                            JSON.stringify(e),
                            ' should not start with "$" or "_" which are reserved prefixes for Vue internals.'
                          )
                        );
                      Object.defineProperty(t, e, {
                        enumerable: !0,
                        configurable: !0,
                        get: function () {
                          return n[e];
                        },
                        set: k,
                      });
                    }
                  });
                })(e))
              : void 0 !== t &&
                fi(
                  "setup() should return an object. Received: ".concat(
                    null === t ? "null" : d(t)
                  )
                );
            var r;
            Rs(e, n);
          })(e, f, t);
  } else Rs(e, t);
}
var $s = function () {
  return !0;
};
function Rs(e, t, n) {
  var r = e.type;
  e.render || (e.render = r.render || k);
  var o = Ts(e);
  Rr();
  try {
    Ua(e);
  } finally {
    jr(), o();
  }
  r.render ||
    e.render !== k ||
    t ||
    (r.template
      ? fi(
          'Component provided template option but runtime compilation is not supported in this build of Vue. Configure your bundler to alias "vue" to "vue/dist/vue.esm-bundler.js".'
        )
      : fi("Component is missing template or render function."));
}
function js(e) {
  if (e.exposed)
    return (
      e.exposeProxy ||
      (e.exposeProxy = new Proxy(ti(Vo(e.exposed)), {
        get: function (t, n) {
          return n in t ? t[n] : e.proxy[n];
        },
        has: function (e, t) {
          return t in e || t in La;
        },
      }))
    );
}
var Ms = /(?:^|[-_])(\w)/g,
  Ds = function (e) {
    return e
      .replace(Ms, function (e) {
        return e.toUpperCase();
      })
      .replace(/[-_]/g, "");
  };
function Us(e) {
  var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
  return $(e) ? e.displayName || e.name : e.name || (t && e.__name);
}
function Ns(e, t) {
  var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
    r = Us(t);
  if (!r && t.__file) {
    var o = t.__file.match(/([^/\\]+)\.\w+$/);
    o && (r = o[1]);
  }
  if (!r && e && e.parent) {
    var i = function (e) {
      for (var n in e) if (e[n] === t) return n;
    };
    r =
      i(e.components || e.parent.type.components) || i(e.appContext.components);
  }
  return r ? Ds(r) : n ? "App" : "Anonymous";
}
var qs = function (e, t) {
    var n = (function (e, t) {
        var n,
          r,
          o = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          i = $(e);
        i
          ? ((n = e),
            (r = function () {
              wr("Write operation failed: computed value is readonly");
            }))
          : ((n = e.get), (r = e.set));
        var a = new zo(n, r, i || !r, o);
        return a;
      })(e, t, Es),
      r = Ps();
    return (
      r && r.appContext.config.warnRecursiveComputed && (n._warnRecursive = !0),
      n
    );
  },
  Bs = "3.4.21",
  Fs = fi;
function Hs(e) {
  return Zo(e);
}
var Vs = "[object Array]",
  Ks = "[object Object]";
function Ws(e, t) {
  var n = {};
  return (
    (function e(t, n) {
      if ((t = Hs(t)) === n) return;
      var r = N(t),
        o = N(n);
      if (r == Ks && o == Ks)
        for (var i in n) {
          var a = t[i];
          void 0 === a ? (t[i] = null) : e(a, n[i]);
        }
      else
        r == Vs &&
          o == Vs &&
          t.length >= n.length &&
          n.forEach(function (n, r) {
            e(t[r], n);
          });
    })(e, t),
    (function e(t, n, r, o) {
      if ((t = Hs(t)) === n) return;
      var i = N(t),
        a = N(n);
      if (i == Ks)
        if (a != Ks || Object.keys(t).length < Object.keys(n).length)
          zs(o, r, t);
        else {
          var s = function (i) {
            var a = Hs(t[i]),
              s = n[i],
              c = N(a),
              u = N(s);
            if (c != Vs && c != Ks)
              a != s && zs(o, ("" == r ? "" : r + ".") + i, a);
            else if (c == Vs)
              u != Vs || a.length < s.length
                ? zs(o, ("" == r ? "" : r + ".") + i, a)
                : a.forEach(function (t, n) {
                    e(t, s[n], ("" == r ? "" : r + ".") + i + "[" + n + "]", o);
                  });
            else if (c == Ks)
              if (u != Ks || Object.keys(a).length < Object.keys(s).length)
                zs(o, ("" == r ? "" : r + ".") + i, a);
              else
                for (var f in a)
                  e(a[f], s[f], ("" == r ? "" : r + ".") + i + "." + f, o);
          };
          for (var c in t) s(c);
        }
      else
        i == Vs
          ? a != Vs || t.length < n.length
            ? zs(o, r, t)
            : t.forEach(function (t, i) {
                e(t, n[i], r + "[" + i + "]", o);
              })
          : zs(o, r, t);
    })(e, t, "", n),
    n
  );
}
function zs(e, t, n) {
  e[t] = n;
}
function Js(e) {
  var t = e.ctx.__next_tick_callbacks;
  if (t && t.length) {
    var n = t.slice(0);
    t.length = 0;
    for (var r = 0; r < n.length; r++) n[r]();
  }
}
function Ys(e, t) {
  var n,
    r = e.ctx;
  return r.__next_tick_pending ||
    (function (e) {
      return bi.includes(e.update);
    })(e)
    ? (r.__next_tick_callbacks || (r.__next_tick_callbacks = []),
      r.__next_tick_callbacks.push(function () {
        t ? di(t.bind(e.proxy), e, 14) : n && n(e.proxy);
      }),
      new Promise(function (e) {
        n = e;
      }))
    : Oi(t && t.bind(e.proxy));
}
function Qs(e) {
  return (function e(t, n) {
    t = Hs(t);
    var r = d(t);
    if ("object" === r && null !== t) {
      var o = n.get(t);
      if (void 0 !== o) return o;
      if (C(t)) {
        var i = t.length;
        (o = new Array(i)), n.set(t, o);
        for (var a = 0; a < i; a++) o[a] = e(t[a], n);
      } else
        for (var s in ((o = {}), n.set(t, o), t))
          I(t, s) && (o[s] = e(t[s], n));
      return o;
    }
    if ("symbol" !== r) return t;
  })(e, "undefined" != typeof WeakMap ? new WeakMap() : new Map());
}
function Gs(e, t, n) {
  if (t) {
    t = Qs(t);
    var r = e.ctx,
      o = r.mpType;
    if ("page" === o || "component" === o) {
      t.r0 = 1;
      var i = r.$scope,
        a = Ws(
          t,
          (function (e, t) {
            var n = e.data,
              r = Object.create(null);
            return (
              t.forEach(function (e) {
                r[e] = n[e];
              }),
              r
            );
          })(i, Object.keys(t))
        );
      Object.keys(a).length
        ? ((r.__next_tick_pending = !0),
          i.setData(a, function () {
            (r.__next_tick_pending = !1), Js(e);
          }),
          Ei())
        : Js(e);
    }
  }
}
function Xs(e) {
  e.globalProperties.$nextTick = function (e) {
    return Ys(this.$, e);
  };
}
function Zs(e, t, n) {
  t.appContext.config.globalProperties.$applyOptions(e, t, n);
  var r = e.computed;
  if (r) {
    var o = Object.keys(r);
    if (o.length) {
      var i,
        a = t.ctx;
      a.$computedKeys || (a.$computedKeys = []),
        (i = a.$computedKeys).push.apply(i, o);
    }
  }
  delete t.ctx.$onApplyOptions;
}
function ec(e) {
  var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
    n = e.setupState,
    r = e.$templateRefs,
    o = e.ctx,
    i = o.$scope,
    a = o.$mpPlatform;
  if ("mp-alipay" !== a && r && i) {
    if (t)
      return r.forEach(function (e) {
        return nc(e, null, n);
      });
    var s = "mp-baidu" === a || "mp-toutiao" === a,
      c = function (e) {
        var t = (i.selectAllComponents(".r") || []).concat(
          i.selectAllComponents(".r-i-f") || []
        );
        return e.filter(function (e) {
          var r = tc(t, e.i);
          return !(!s || null !== r) || (nc(e, r, n), !1);
        });
      },
      u = function () {
        var t = c(r);
        t.length &&
          e.proxy &&
          e.proxy.$scope &&
          e.proxy.$scope.setData({ r1: 1 }, function () {
            c(t);
          });
      };
    i._$setRef ? i._$setRef(u) : Ys(e, u);
  }
}
function tc(e, t) {
  var n,
    r = e.find(function (e) {
      return e && (e.properties || e.props).uI === t;
    });
  if (r) {
    var o = r.$vm;
    return o ? js(o.$) || o : (M((n = r)) && Vo(n), n);
  }
  return null;
}
function nc(e, t, n) {
  var r = e.r,
    o = e.f;
  if ($(r)) r(t, {});
  else {
    var i = R(r),
      a = Qo(r);
    if (i || a)
      if (o) {
        if (!a) return;
        C(r.value) || (r.value = []);
        var s = r.value;
        if (-1 === s.indexOf(t)) {
          if ((s.push(t), !t)) return;
          Pa(function () {
            return O(s, t);
          }, t.$);
        }
      } else i ? I(n, r) && (n[r] = t) : Qo(r) ? (r.value = t) : rc(r);
    else rc(r);
  }
}
function rc(e) {
  Fs("Invalid template ref type:", e, "(".concat(d(e), ")"));
}
var oc = Ci;
function ic(e, t) {
  var n = (e.component = ws(e, t.parentComponent, null));
  return (
    (n.ctx.$onApplyOptions = Zs),
    (n.ctx.$children = []),
    "app" === t.mpType && (n.render = k),
    t.onBeforeSetup && t.onBeforeSetup(n, t),
    ci(e),
    ls(n, "mount"),
    ls(n, "init"),
    (function (e) {
      var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
      t && xs(t);
      var n = e.vnode.props,
        r = Cs(e);
      Ya(e, n, r, t);
      var o = r ? Ls(e, t) : void 0;
      t && xs(!1);
    })(n),
    ps(n, "init"),
    t.parentComponent &&
      n.proxy &&
      t.parentComponent.ctx.$children.push(js(n) || n.proxy),
    (function (e) {
      var t = cc.bind(e);
      e.$updateScopedSlots = function () {
        return Oi(function () {
          return Ai(t);
        });
      };
      var n = (e.effect = new Or(
          function () {
            if (e.isMounted) {
              var t = e.next,
                n = e.bu,
                r = e.u;
              ci(t || e.vnode),
                uc(e, !1),
                Rr(),
                Ei(),
                jr(),
                n && Z(n),
                uc(e, !0),
                ls(e, "patch"),
                Gs(e, ac(e)),
                ps(e, "patch"),
                r && oc(r),
                Hi(e),
                ui();
            } else
              Pa(function () {
                ec(e, !0);
              }, e),
                ls(e, "patch"),
                Gs(e, ac(e)),
                ps(e, "patch"),
                Fi(e);
          },
          k,
          function () {
            return Ai(r);
          },
          e.scope
        )),
        r = (e.update = function () {
          n.dirty && n.run();
        });
      (r.id = e.uid),
        uc(e, !0),
        (n.onTrack = e.rtc
          ? function (t) {
              return Z(e.rtc, t);
            }
          : void 0),
        (n.onTrigger = e.rtg
          ? function (t) {
              return Z(e.rtg, t);
            }
          : void 0),
        (r.ownerInstance = e),
        r();
    })(n),
    ui(),
    ps(n, "mount"),
    n.proxy
  );
}
function ac(e) {
  var t,
    n = e.type,
    r = e.vnode,
    o = e.proxy,
    i = e.withProxy,
    a = e.props,
    s = v(e.propsOptions, 1)[0],
    c = e.slots,
    u = e.attrs,
    f = e.emit,
    l = e.render,
    p = e.renderCache,
    h = e.data,
    d = e.setupState,
    g = e.ctx,
    m = e.uid,
    y = e.appContext.app.config.globalProperties.pruneComponentPropsCache,
    _ = e.inheritAttrs;
  (e.$templateRefs = []),
    (e.$ei = 0),
    y(m),
    (e.__counter = 0 === e.__counter ? 1 : 0);
  var b = ea(e);
  try {
    if (4 & r.shapeFlag) {
      sc(_, a, s, u);
      var w = i || o;
      t = l.call(w, w, p, a, d, h, g);
    } else {
      sc(
        _,
        a,
        s,
        n.props
          ? u
          : (function (e) {
              var t;
              for (var n in e)
                ("class" === n || "style" === n || S(n)) &&
                  ((t || (t = {}))[n] = e[n]);
              return t;
            })(u)
      );
      var k = n;
      t = k.length > 1 ? k(a, { attrs: u, slots: c, emit: f }) : k(a, null);
    }
  } catch (n) {
    gi(n, e, 1), (t = !1);
  }
  return ec(e), ea(b), t;
}
function sc(e, t, n, r) {
  if (t && r && !1 !== e) {
    var o = Object.keys(r).filter(function (e) {
      return "class" !== e && "style" !== e;
    });
    if (!o.length) return;
    n && o.some(P)
      ? o.forEach(function (e) {
          (P(e) && e.slice(9) in n) || (t[e] = r[e]);
        })
      : o.forEach(function (e) {
          return (t[e] = r[e]);
        });
  }
}
function cc() {
  var e = this.$scopedSlotsData;
  if (e && 0 !== e.length) {
    var t = this.ctx.$scope,
      n = t.data,
      r = Object.create(null);
    e.forEach(function (e) {
      var t = e.path,
        o = e.index,
        i = e.data,
        a = (function e(t, n) {
          if (R(n)) {
            var r = (n = n.replace(/\[(\d+)\]/g, ".$1")).split("."),
              o = r[0];
            return (
              t || (t = {}),
              1 === r.length ? t[o] : e(t[o], r.slice(1).join("."))
            );
          }
        })(n, t),
        s = R(o)
          ? "".concat(t, ".").concat(o)
          : "".concat(t, "[").concat(o, "]");
      if (void 0 === a || void 0 === a[o]) r[s] = i;
      else {
        var c = Ws(i, a[o]);
        Object.keys(c).forEach(function (e) {
          r[s + "." + e] = c[e];
        });
      }
    }),
      (e.length = 0),
      Object.keys(r).length && t.setData(r);
  }
}
function uc(e, t) {
  var n = e.effect,
    r = e.update;
  n.allowRecurse = r.allowRecurse = t;
}
function fc(e) {
  var t,
    n = e.bum,
    r = e.scope,
    o = e.update,
    i = e.um;
  n && Z(n),
    r.stop(),
    o && (o.active = !1),
    i && oc(i),
    oc(function () {
      e.isUnmounted = !0;
    }),
    (t = e),
    Li &&
      "function" == typeof Li.cleanupBuffer &&
      !Li.cleanupBuffer(t) &&
      Vi(t);
}
var lc,
  pc = function (e) {
    var t =
      arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
    $(e) || (e = T({}, e)),
      null == t ||
        M(t) ||
        (fi("root props passed to app.mount() must be an object."), (t = null));
    var n = ua(),
      r = new WeakSet(),
      o = (n.app = {
        _uid: fa++,
        _component: e,
        _props: t,
        _container: null,
        _context: n,
        _instance: null,
        version: Bs,
        get config() {
          return n.config;
        },
        set config(e) {
          fi(
            "app.config cannot be replaced. Modify individual options instead."
          );
        },
        use: function (e) {
          for (
            var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), i = 1;
            i < t;
            i++
          )
            n[i - 1] = arguments[i];
          return (
            r.has(e)
              ? fi("Plugin has already been applied to target app.")
              : e && $(e.install)
              ? (r.add(e), e.install.apply(e, [o].concat(n)))
              : $(e)
              ? (r.add(e), e.apply(void 0, [o].concat(n)))
              : fi(
                  'A plugin must either be a function or an object with an "install" function.'
                ),
            o
          );
        },
        mixin: function (e) {
          return (
            n.mixins.includes(e)
              ? fi(
                  "Mixin has already been applied to target app" +
                    (e.name ? ": ".concat(e.name) : "")
                )
              : n.mixins.push(e),
            o
          );
        },
        component: function (e, t) {
          return (
            Is(e, n.config),
            t
              ? (n.components[e] &&
                  fi(
                    'Component "'.concat(
                      e,
                      '" has already been registered in target app.'
                    )
                  ),
                (n.components[e] = t),
                o)
              : n.components[e]
          );
        },
        directive: function (e, t) {
          return (
            ca(e),
            t
              ? (n.directives[e] &&
                  fi(
                    'Directive "'.concat(
                      e,
                      '" has already been registered in target app.'
                    )
                  ),
                (n.directives[e] = t),
                o)
              : n.directives[e]
          );
        },
        mount: function () {},
        unmount: function () {},
        provide: function (e, t) {
          return (
            e in n.provides &&
              fi(
                'App already provides property with key "'.concat(
                  String(e),
                  '". It will be overwritten with the new value.'
                )
              ),
            (n.provides[e] = t),
            o
          );
        },
        runWithContext: function (e) {
          var t = la;
          la = o;
          try {
            return e();
          } finally {
            la = t;
          }
        },
      });
    return o;
  };
function hc() {
  return "undefined" != typeof window
    ? window
    : "undefined" != typeof globalThis
    ? globalThis
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof my
    ? my
    : void 0;
}
function dc(e) {
  var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
    n = hc();
  (n.__VUE__ = !0), qi(n.__VUE_DEVTOOLS_GLOBAL_HOOK__, n);
  var r = pc(e, t),
    o = r._context;
  Xs(o.config);
  var i = function (e) {
      return (e.appContext = o), (e.shapeFlag = 6), e;
    },
    a = function (e, t) {
      return ic(i(e), t);
    },
    s = function (e) {
      return e && fc(e.$);
    };
  return (
    (r.mount = function () {
      e.render = k;
      var t = ic(i({ type: e }), {
        mpType: "app",
        mpInstance: null,
        parentComponent: null,
        slots: [],
        props: null,
      });
      return (
        (r._instance = t.$),
        Bi(r, Bs),
        (t.$app = r),
        (t.$createComponent = a),
        (t.$destroyComponent = s),
        (o.$appInstance = t),
        t
      );
    }),
    (r.unmount = function () {
      Fs("Cannot unmount an app.");
    }),
    r
  );
}
function vc(e, t, n, r) {
  $(t) && _a(e, t.bind(n), r);
}
function gc(e, t, n) {
  !(function (e, t, n) {
    var r = e.mpType || n.$mpType;
    r &&
      "component" !== r &&
      Object.keys(e).forEach(function (r) {
        if (_e(r, e[r], !1)) {
          var o = e[r];
          C(o)
            ? o.forEach(function (e) {
                return vc(r, e, n, t);
              })
            : vc(r, o, n, t);
        }
      });
  })(e, t, n);
}
function mc(e, t, n) {
  return (e[t] = n);
}
function yc(e) {
  var t = this[e];
  if (t) {
    for (
      var n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), o = 1;
      o < n;
      o++
    )
      r[o - 1] = arguments[o];
    return t.apply(void 0, r);
  }
  return console.error("method ".concat(e, " not found")), null;
}
function _c(e) {
  return function (t, n, r) {
    if (!n) throw t;
    var o = e._instance;
    if (!o || !o.proxy) throw t;
    o.proxy.$callHook("onError", t);
  };
}
function bc(e, t) {
  return e ? h(new Set([].concat(e, t))) : t;
}
var wc = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
  kc = /^(?:[A-Za-z\d+/]{4})*?(?:[A-Za-z\d+/]{2}(?:==)?|[A-Za-z\d+/]{3}=?)?$/;
function xc() {
  var e,
    t,
    n = Dn.getStorageSync("uni_id_token") || "",
    r = n.split(".");
  if (!n || 3 !== r.length)
    return { uid: null, role: [], permission: [], tokenExpired: 0 };
  try {
    e = JSON.parse(
      ((t = r[1]),
      decodeURIComponent(
        lc(t)
          .split("")
          .map(function (e) {
            return "%" + ("00" + e.charCodeAt(0).toString(16)).slice(-2);
          })
          .join("")
      ))
    );
  } catch (e) {
    throw new Error("获取当前用户信息出错，详细错误信息为：" + e.message);
  }
  return (e.tokenExpired = 1e3 * e.exp), delete e.exp, delete e.iat, e;
}
function Sc(e) {
  var t,
    n = e._context.config;
  (n.errorHandler = we(e, _c)),
    (t = n.optionMergeStrategies),
    me.forEach(function (e) {
      t[e] = bc;
    });
  var r = n.globalProperties;
  !(function (e) {
    (e.uniIDHasRole = function (e) {
      return xc().role.indexOf(e) > -1;
    }),
      (e.uniIDHasPermission = function (e) {
        var t = xc().permission;
        return this.uniIDHasRole("admin") || t.indexOf(e) > -1;
      }),
      (e.uniIDTokenValid = function () {
        return xc().tokenExpired > Date.now();
      });
  })(r),
    (r.$set = mc),
    (r.$applyOptions = gc),
    (r.$callMethod = yc),
    Dn.invokeCreateVueAppHook(e);
}
lc =
  "function" != typeof atob
    ? function (e) {
        if (((e = String(e).replace(/[\t\n\f\r ]+/g, "")), !kc.test(e)))
          throw new Error(
            "Failed to execute 'atob' on 'Window': The string to be decoded is not correctly encoded."
          );
        var t;
        e += "==".slice(2 - (3 & e.length));
        for (var n, r, o = "", i = 0; i < e.length; )
          (t =
            (wc.indexOf(e.charAt(i++)) << 18) |
            (wc.indexOf(e.charAt(i++)) << 12) |
            ((n = wc.indexOf(e.charAt(i++))) << 6) |
            (r = wc.indexOf(e.charAt(i++)))),
            (o +=
              64 === n
                ? String.fromCharCode((t >> 16) & 255)
                : 64 === r
                ? String.fromCharCode((t >> 16) & 255, (t >> 8) & 255)
                : String.fromCharCode(
                    (t >> 16) & 255,
                    (t >> 8) & 255,
                    255 & t
                  ));
        return o;
      }
    : atob;
var Pc = Object.create(null);
function Tc(e) {
  var t = Ps(),
    n = t.uid,
    r = t.__counter;
  return (
    n +
    "," +
    ((Pc[n] || (Pc[n] = [])).push(
      (function (e) {
        return e ? (Fo(e) || "__vInternal" in e ? T({}, e) : e) : null;
      })(e)
    ) -
      1) +
    "," +
    r
  );
}
function Oc(e) {
  delete Pc[e];
}
function Ac(e) {
  if (e) {
    var t = e.split(","),
      n = v(t, 2),
      r = n[0],
      o = n[1];
    if (Pc[r]) return Pc[r][parseInt(o)];
  }
}
var Ic = {
  install: function (e) {
    Sc(e), (e.config.globalProperties.pruneComponentPropsCache = Oc);
    var t = e.mount;
    e.mount = function (n) {
      var r = t.call(e, n),
        o = (function () {
          if ("undefined" != typeof global && void 0 !== global.createApp)
            return global.createApp;
          if ("undefined" != typeof my) return my.createApp;
        })();
      return (
        o
          ? o(r)
          : "undefined" != typeof createMiniProgramApp &&
            createMiniProgramApp(r),
        r
      );
    };
  },
};
function Cc(e, t) {
  var n = Ps(),
    r = n.ctx,
    o =
      void 0 === t ||
      ("mp-weixin" !== r.$mpPlatform &&
        "mp-qq" !== r.$mpPlatform &&
        "mp-xhs" !== r.$mpPlatform) ||
      (!R(t) && "number" != typeof t)
        ? ""
        : "_" + t,
    i = "e" + n.$ei++ + o,
    a = r.$scope;
  if (!e) return delete a[i], i;
  var s = a[i];
  return (
    s
      ? (s.value = e)
      : (a[i] = (function (e, t) {
          var n = function e(n) {
            var r;
            (r = n).type &&
              r.target &&
              ((r.preventDefault = k),
              (r.stopPropagation = k),
              (r.stopImmediatePropagation = k),
              I(r, "detail") || (r.detail = {}),
              I(r, "markerId") &&
                ((r.detail = "object" === d(r.detail) ? r.detail : {}),
                (r.detail.markerId = r.markerId)),
              B(r.detail) &&
                I(r.detail, "checked") &&
                !I(r.detail, "value") &&
                (r.detail.value = r.detail.checked),
              B(r.detail) && (r.target = T({}, r.target, r.detail)));
            var o = [n];
            n.detail && n.detail.__args__ && (o = n.detail.__args__);
            var i = e.value,
              a = function () {
                return vi(
                  (function (e, t) {
                    if (C(t)) {
                      var n = e.stopImmediatePropagation;
                      return (
                        (e.stopImmediatePropagation = function () {
                          n && n.call(e), (e._stopped = !0);
                        }),
                        t.map(function (e) {
                          return function (t) {
                            return !t._stopped && e(t);
                          };
                        })
                      );
                    }
                    return t;
                  })(n, i),
                  t,
                  5,
                  o
                );
              },
              s = n.target,
              c = !!s && !!s.dataset && "true" === String(s.dataset.eventsync);
            if (!Ec.includes(n.type) || c) {
              var u = a();
              if ("input" === n.type && (C(u) || D(u))) return;
              return u;
            }
            setTimeout(a);
          };
          return (n.value = e), n;
        })(e, n)),
    i
  );
}
var Ec = [
  "tap",
  "longpress",
  "longtap",
  "transitionend",
  "animationstart",
  "animationiteration",
  "animationend",
  "touchforcechange",
];
function Lc(e) {
  return R(e)
    ? e
    : (function (e) {
        var t = "";
        if (!e || R(e)) return t;
        for (var n in e)
          t += "".concat(n.startsWith("--") ? n : Y(n), ":").concat(e[n], ";");
        return t;
      })(
        (function e(t) {
          if (C(t)) {
            for (var n = {}, r = 0; r < t.length; r++) {
              var o = t[r],
                i = R(o) ? ie(o) : e(o);
              if (i) for (var a in i) n[a] = i[a];
            }
            return n;
          }
          if (R(t) || M(t)) return t;
        })(e)
      );
}
var $c = function (e) {
    var t =
      arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
    return e && (e.mpType = "app"), dc(e, t).use(Ic);
  },
  Rc = [
    "createSelectorQuery",
    "createIntersectionObserver",
    "selectAllComponents",
    "selectComponent",
  ];
function jc(e, t) {
  var n = e.ctx;
  (n.mpType = t.mpType),
    (n.$mpType = t.mpType),
    (n.$mpPlatform = "mp-weixin"),
    (n.$scope = t.mpInstance),
    (n.$mp = {}),
    (n._self = {}),
    (e.slots = {}),
    C(t.slots) &&
      t.slots.length &&
      (t.slots.forEach(function (t) {
        e.slots[t] = !0;
      }),
      e.slots.d && (e.slots.default = !0)),
    (n.getOpenerEventChannel = function () {
      return t.mpInstance.getOpenerEventChannel();
    }),
    (n.$hasHook = Mc),
    (n.$callHook = Dc),
    (e.emit = (function (e, t) {
      return function (n) {
        for (
          var r = t.$scope,
            o = arguments.length,
            i = new Array(o > 1 ? o - 1 : 0),
            a = 1;
          a < o;
          a++
        )
          i[a - 1] = arguments[a];
        if (r && n) {
          var s = { __args__: i };
          r.triggerEvent(n, s);
        }
        return e.apply(this, [n].concat(i));
      };
    })(e.emit, n));
}
function Mc(e) {
  var t = this.$[e];
  return !(!t || !t.length);
}
function Dc(e, t) {
  "mounted" === e && (Dc.call(this, "bm"), (this.$.isMounted = !0), (e = "m"));
  var n = this.$[e];
  return (
    n &&
    (function (e, t) {
      for (var n, r = 0; r < e.length; r++) n = e[r](t);
      return n;
    })(n, t)
  );
}
var Uc = [
  "onLoad",
  "onShow",
  "onHide",
  "onUnload",
  "onResize",
  "onTabItemTap",
  "onReachBottom",
  "onPullDownRefresh",
  "onAddToFavorites",
];
function Nc(e) {
  var t =
    arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : new Set();
  if (e) {
    Object.keys(e).forEach(function (n) {
      _e(n, e[n]) && t.add(n);
    });
    var n = e.extends,
      r = e.mixins;
    r &&
      r.forEach(function (e) {
        return Nc(e, t);
      }),
      n && Nc(n, t);
  }
  return t;
}
function qc(e, t, n) {
  -1 !== n.indexOf(t) ||
    I(e, t) ||
    (e[t] = function (e) {
      return this.$vm && this.$vm.$callHook(t, e);
    });
}
var Bc = ["onReady"];
function Fc(e, t) {
  var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Bc;
  t.forEach(function (t) {
    return qc(e, t, n);
  });
}
function Hc(e, t) {
  var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Bc;
  Nc(t).forEach(function (t) {
    return qc(e, t, n);
  });
}
var Vc = fe(function () {
  var e = [],
    t = $(getApp) && getApp({ allowDefault: !0 });
  if (t && t.$vm && t.$vm.$) {
    var n = t.$vm.$.appContext.mixins;
    if (C(n)) {
      var r = Object.keys(ye);
      n.forEach(function (t) {
        r.forEach(function (n) {
          I(t, n) && !e.includes(n) && e.push(n);
        });
      });
    }
  }
  return e;
});
var Kc = [
  "onShow",
  "onHide",
  "onError",
  "onThemeChange",
  "onPageNotFound",
  "onUnhandledRejection",
];
function Wc(e, t) {
  var n,
    r,
    o = e.$,
    i = {
      globalData: (e.$options && e.$options.globalData) || {},
      $vm: e,
      onLaunch: function (t) {
        this.$vm = e;
        var n = o.ctx;
        (this.$vm && n.$scope) ||
          (jc(o, { mpType: "app", mpInstance: this, slots: [] }),
          (n.globalData = this.globalData),
          e.$callHook("onLaunch", t));
      },
    };
  o.onError &&
    (o.appContext.config.errorHandler = function (t) {
      e.$callHook("onError", t);
    }),
    (n = e),
    (r = Go($e(wx.getSystemInfoSync().language) || "en")),
    Object.defineProperty(n, "$locale", {
      get: function () {
        return r.value;
      },
      set: function (e) {
        r.value = e;
      },
    });
  var a = e.$.type;
  Fc(i, Kc), Hc(i, a);
  var s = a.methods;
  return s && T(i, s), i;
}
function zc(e, t) {
  if ($(e.onLaunch)) {
    var n = wx.getLaunchOptionsSync && wx.getLaunchOptionsSync();
    e.onLaunch(n);
  }
  $(e.onShow) &&
    wx.onAppShow &&
    wx.onAppShow(function (e) {
      t.$callHook("onShow", e);
    }),
    $(e.onHide) &&
      wx.onAppHide &&
      wx.onAppHide(function (e) {
        t.$callHook("onHide", e);
      });
}
var Jc = ["externalClasses"];
var Yc = /_(.*)_worklet_factory_/;
var Qc = ["eO", "uR", "uRIF", "uI", "uT", "uP", "uS"];
function Gc(e) {
  e.properties || (e.properties = {}),
    T(
      e.properties,
      (function (e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          n = {};
        return (
          t ||
            (Qc.forEach(function (e) {
              n[e] = { type: null, value: "" };
            }),
            (n.uS = {
              type: null,
              value: [],
              observer: function (e) {
                var t = Object.create(null);
                e &&
                  e.forEach(function (e) {
                    t[e] = !0;
                  }),
                  this.setData({ $slots: t });
              },
            })),
          e.behaviors &&
            e.behaviors.includes("wx://form-field") &&
            ((e.properties && e.properties.name) ||
              (n.name = { type: null, value: "" }),
            (e.properties && e.properties.value) ||
              (n.value = { type: null, value: "" })),
          n
        );
      })(e),
      (function (e) {
        var t = {};
        return (
          e &&
            e.virtualHost &&
            ((t.virtualHostStyle = { type: null, value: "" }),
            (t.virtualHostClass = { type: null, value: "" })),
          t
        );
      })(e.options)
    );
}
var Xc,
  Zc,
  eu = [String, Number, Boolean, Object, Array, null];
function tu(e, t) {
  var n = (function (e, t) {
    return C(e) && 1 === e.length ? e[0] : e;
  })(e);
  return -1 !== eu.indexOf(n) ? n : null;
}
function nu(e, t) {
  return (
    (t
      ? (function (e) {
          var t = {};
          B(e) &&
            Object.keys(e).forEach(function (n) {
              -1 === Qc.indexOf(n) && (t[n] = e[n]);
            });
          return t;
        })(e)
      : Ac(e.uP)) || {}
  );
}
function ru(e) {
  e.observers || (e.observers = {}),
    (e.observers.uP = function () {
      var e = this.properties.uP;
      e &&
        (this.$vm
          ? (function (e, t) {
              var n = Ho(t.props),
                r = Ac(e) || {};
              ou(n, r) &&
                (!(function (e, t, n, r) {
                  var o = e.props,
                    i = e.attrs,
                    a = e.vnode.patchFlag,
                    s = Ho(o),
                    c = v(e.propsOptions, 1)[0],
                    u = !1;
                  if (
                    (function (e) {
                      for (; e; ) {
                        if (e.type.__hmrId) return !0;
                        e = e.parent;
                      }
                    })(e) ||
                    !(a > 0) ||
                    16 & a
                  ) {
                    var f;
                    for (var l in (Qa(e, t, o, i) && (u = !0), s))
                      (t && (I(t, l) || ((f = Y(l)) !== l && I(t, f)))) ||
                        (c
                          ? !n ||
                            (void 0 === n[l] && void 0 === n[f]) ||
                            (o[l] = Ga(c, s, l, void 0, e, !0))
                          : delete o[l]);
                    if (i !== s)
                      for (var p in i)
                        (t && I(t, p)) || (delete i[p], (u = !0));
                  } else if (8 & a)
                    for (
                      var h = e.vnode.dynamicProps, d = 0;
                      d < h.length;
                      d++
                    ) {
                      var g = h[d];
                      if (!Xi(e.emitsOptions, g)) {
                        var m = t[g];
                        if (c)
                          if (I(i, g)) m !== i[g] && ((i[g] = m), (u = !0));
                          else {
                            var y = z(g);
                            o[y] = Ga(c, s, y, m, e, !1);
                          }
                        else m !== i[g] && ((i[g] = m), (u = !0));
                      }
                    }
                  u && Wr(e, "set", "$attrs"), rs(t || {}, o, e);
                })(t, r, n),
                (o = t.update),
                bi.indexOf(o) > -1 &&
                  (function (e) {
                    var t = bi.indexOf(e);
                    t > wi && bi.splice(t, 1);
                  })(t.update),
                t.update());
              var o;
            })(e, this.$vm.$)
          : "m" === this.properties.uT &&
            (function (e, t) {
              var n = t.properties,
                r = Ac(e) || {};
              ou(n, r, !1) && t.setData(r);
            })(e, this));
    });
}
function ou(e, t) {
  var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
    r = Object.keys(t);
  if (n && r.length !== Object.keys(e).length) return !0;
  for (var o = 0; o < r.length; o++) {
    var i = r[o];
    if (t[i] !== e[i]) return !0;
  }
  return !1;
}
function iu(e, t) {
  (e.data = {}),
    (e.behaviors = (function (e) {
      var t = e.behaviors,
        n = e.props;
      n || (e.props = n = []);
      var r = [];
      return (
        C(t) &&
          t.forEach(function (e) {
            r.push(e.replace("uni://", "wx://")),
              "uni://form-field" === e &&
                (C(n)
                  ? (n.push("name"), n.push("modelValue"))
                  : ((n.name = { type: String, default: "" }),
                    (n.modelValue = {
                      type: [String, Number, Boolean, Array, Object, Date],
                      default: "",
                    })));
          }),
        r
      );
    })(t));
}
function au(e, t) {
  var n = t.parse,
    r = t.mocks,
    o = t.isPage,
    i = t.initRelation,
    a = t.handleLink,
    s = t.initLifetimes;
  e = e.default || e;
  var c = { multipleSlots: !0, addGlobalClass: !0, pureDataPattern: /^uP$/ };
  C(e.mixins) &&
    e.mixins.forEach(function (e) {
      M(e.options) && T(c, e.options);
    }),
    e.options && T(c, e.options);
  var u,
    f,
    l,
    p,
    h = {
      options: c,
      lifetimes: s({ mocks: r, isPage: o, initRelation: i, vueOptions: e }),
      pageLifetimes: {
        show: function () {
          this.$vm && this.$vm.$callHook("onPageShow");
        },
        hide: function () {
          this.$vm && this.$vm.$callHook("onPageHide");
        },
        resize: function (e) {
          this.$vm && this.$vm.$callHook("onPageResize", e);
        },
      },
      methods: { __l: a },
    };
  return (
    iu(h, e),
    Gc(h),
    ru(h),
    (function (e, t) {
      Jc.forEach(function (n) {
        I(t, n) && (e[n] = t[n]);
      });
    })(h, e),
    (u = h.methods),
    (f = e.wxsCallMethods),
    C(f) &&
      f.forEach(function (e) {
        u[e] = function (t) {
          return this.$vm[e](t);
        };
      }),
    (l = h.methods),
    (p = e.methods) &&
      Object.keys(p).forEach(function (e) {
        var t = e.match(Yc);
        if (t) {
          var n = t[1];
          (l[e] = p[e]), (l[n] = p[n]);
        }
      }),
    n && n(h, { handleLink: a }),
    h
  );
}
function su() {
  return getApp().$vm;
}
function cu(e, t) {
  var n,
    r,
    o,
    i = t.parse,
    a = t.mocks,
    s = t.isPage,
    c = t.initRelation,
    u = t.handleLink,
    f = au(e, {
      mocks: a,
      isPage: s,
      initRelation: c,
      handleLink: u,
      initLifetimes: t.initLifetimes,
    });
  (n = f),
    (r = (e.default || e).props),
    (o = n.properties),
    C(r)
      ? r.forEach(function (e) {
          o[e] = { type: String, value: "" };
        })
      : B(r) &&
        Object.keys(r).forEach(function (e) {
          var t = r[e];
          if (B(t)) {
            var n = t.default;
            $(n) && (n = n());
            var i = t.type;
            (t.type = tu(i)), (o[e] = { type: t.type, value: n });
          } else o[e] = { type: tu(t) };
        });
  var l,
    p,
    h = f.methods;
  return (
    (h.onLoad = function (e) {
      var t;
      return (
        (this.options = e),
        (this.$page = {
          fullPath:
            ((t = this.route + he(e)),
            (function (e) {
              return 0 === e.indexOf("/");
            })(t)
              ? t
              : "/" + t),
        }),
        this.$vm && this.$vm.$callHook("onLoad", e)
      );
    }),
    Fc(h, Uc),
    Hc(h, e),
    (l = h),
    (p = e.__runtimeHooks) &&
      Object.keys(ye).forEach(function (e) {
        p & ye[e] && qc(l, e, []);
      }),
    (function (e) {
      Fc(e, Vc());
    })(h),
    i && i(f, { handleLink: u }),
    f
  );
}
var uu = Page,
  fu = Component;
function lu(e) {
  var t = e.triggerEvent,
    n = function (n) {
      for (
        var r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), i = 1;
        i < r;
        i++
      )
        o[i - 1] = arguments[i];
      return t.apply(e, [ue(n)].concat(o));
    };
  try {
    e.triggerEvent = n;
  } catch (t) {
    e._triggerEvent = n;
  }
}
function pu(e, t, n) {
  var r = t[e];
  t[e] = r
    ? function () {
        lu(this);
        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
          t[n] = arguments[n];
        return r.apply(this, t);
      }
    : function () {
        lu(this);
      };
}
(Page = function (e) {
  return pu("onLoad", e), uu(e);
}),
  (Component = function (e) {
    return (
      pu("created", e),
      (e.properties && e.properties.uP) || (Gc(e), ru(e)),
      fu(e)
    );
  });
var hu,
  du = Object.freeze({
    __proto__: null,
    handleLink: function (e) {
      var t,
        n = e.detail || e.value,
        r = n.vuePid;
      r &&
        (t = (function e(t, n) {
          for (var r, o = t.$children, i = o.length - 1; i >= 0; i--) {
            var a = o[i];
            if (a.$scope._$vueId === n) return a;
          }
          for (var s = o.length - 1; s >= 0; s--)
            if ((r = e(o[s], n))) return r;
        })(this.$vm, r)),
        t || (t = this.$vm),
        (n.parent = t);
    },
    initLifetimes: function (e) {
      var t = e.mocks,
        n = e.isPage,
        r = e.initRelation,
        o = e.vueOptions;
      return {
        attached: function () {
          var e = this.properties;
          !(function (e, t) {
            if (e) {
              var n = e.split(","),
                r = n.length;
              1 === r
                ? (t._$vueId = n[0])
                : 2 === r && ((t._$vueId = n[0]), (t._$vuePid = n[1]));
            }
          })(e.uI, this);
          var i = { vuePid: this._$vuePid };
          r(this, i);
          var a = this,
            s = n(a),
            c = e;
          (this.$vm = (function (e, t) {
            Xc || (Xc = su().$createComponent);
            var n = Xc(e, t);
            return js(n.$) || n;
          })(
            { type: o, props: nu(c, s) },
            {
              mpType: s ? "page" : "component",
              mpInstance: a,
              slots: e.uS || {},
              parentComponent: i.parent && i.parent.$,
              onBeforeSetup: function (e, n) {
                !(function (e, t) {
                  Object.defineProperty(e, "refs", {
                    get: function () {
                      var e = {};
                      return (
                        (function (e, t, n) {
                          e.selectAllComponents(t).forEach(function (e) {
                            var t = e.properties.uR;
                            n[t] = e.$vm || e;
                          });
                        })(t, ".r", e),
                        t.selectAllComponents(".r-i-f").forEach(function (t) {
                          var n = t.properties.uR;
                          n && (e[n] || (e[n] = []), e[n].push(t.$vm || t));
                        }),
                        e
                      );
                    },
                  });
                })(e, a),
                  (function (e, t, n) {
                    var r = e.ctx;
                    n.forEach(function (n) {
                      I(t, n) && (e[n] = r[n] = t[n]);
                    });
                  })(e, a, t),
                  (function (e, t) {
                    jc(e, t);
                    var n = e.ctx;
                    Rc.forEach(function (e) {
                      n[e] = function () {
                        var t = n.$scope;
                        if (t && t[e]) {
                          for (
                            var r = arguments.length, o = new Array(r), i = 0;
                            i < r;
                            i++
                          )
                            o[i] = arguments[i];
                          return t[e].apply(t, o);
                        }
                      };
                    });
                  })(e, n);
              },
            }
          )),
            s ||
              (function (e) {
                var t = e.$options;
                C(t.behaviors) &&
                  t.behaviors.includes("uni://form-field") &&
                  e.$watch(
                    "modelValue",
                    function () {
                      e.$scope &&
                        e.$scope.setData({ name: e.name, value: e.modelValue });
                    },
                    { immediate: !0 }
                  );
              })(this.$vm);
        },
        ready: function () {
          this.$vm &&
            (this.$vm.$callHook("mounted"), this.$vm.$callHook("onReady"));
        },
        detached: function () {
          var e;
          this.$vm &&
            (Oc(this.$vm.$.uid),
            (e = this.$vm),
            Zc || (Zc = su().$destroyComponent),
            Zc(e));
        },
      };
    },
    initRelation: function (e, t) {
      e.triggerEvent("__l", t);
    },
    isPage: function (e) {
      return !!e.route;
    },
    mocks: ["__route__", "__wxExparserNodeId__", "__wxWebviewId__"],
  }),
  vu = function (e) {
    return App(Wc(e));
  },
  gu =
    ((hu = du),
    function (e) {
      return Component(cu(e, hu));
    }),
  mu = (function (e) {
    return function (t) {
      return Component(au(t, e));
    };
  })(du),
  yu = function (e) {
    zc(Wc(e), e);
  },
  _u = function (e) {
    var t = Wc(e),
      n = $(getApp) && getApp({ allowDefault: !0 });
    if (n) {
      e.$.ctx.$scope = n;
      var r = n.globalData;
      r &&
        Object.keys(t.globalData).forEach(function (e) {
          I(r, e) || (r[e] = t.globalData[e]);
        }),
        Object.keys(t).forEach(function (e) {
          I(n, e) || (n[e] = t[e]);
        }),
        zc(t, e);
    }
  };
(wx.createApp = global.createApp = vu),
  (wx.createPage = gu),
  (wx.createComponent = mu),
  (wx.createPluginApp = global.createPluginApp = yu),
  (wx.createSubpackageApp = global.createSubpackageApp = _u);
var bu,
  wu = function (e) {
    return function (t) {
      var n =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Ps();
      !Es && _a(e, t, n);
    };
  },
  ku = wu("onShow"),
  xu = wu("onHide"),
  Su = wu("onLaunch"),
  Pu = wu("onLoad"),
  Tu = wu("onUnload"),
  Ou = wu("onTabItemTap"),
  Au = wu("onShareTimeline"),
  Iu = wu("onShareAppMessage"),
  Cu = ku;
function Eu(e, t, n) {
  return Array.isArray(e)
    ? ((e.length = Math.max(e.length, t)), e.splice(t, 1, n), n)
    : ((e[t] = n), n);
}
function Lu(e, t) {
  Array.isArray(e) ? e.splice(t, 1) : delete e[t];
}
var $u,
  Ru,
  ju = function (e) {
    return (bu = e);
  },
  Mu = Symbol("pinia");
function Du(e) {
  return (
    e &&
    "object" === d(e) &&
    "[object Object]" === Object.prototype.toString.call(e) &&
    "function" != typeof e.toJSON
  );
}
((Ru = $u || ($u = {})).direct = "direct"),
  (Ru.patchObject = "patch object"),
  (Ru.patchFunction = "patch function");
var Uu = "undefined" != typeof window,
  Nu = [],
  qu = function (e) {
    return "🍍 " + e;
  };
function Bu(e, t, n) {
  var r = t.reduce(function (t, n) {
      return (t[n] = Ho(e)[n]), t;
    }, {}),
    o = function (t) {
      e[t] = function () {
        var o = n
            ? new Proxy(e, {
                get: function () {
                  return Reflect.get.apply(Reflect, arguments);
                },
                set: function () {
                  return Reflect.set.apply(Reflect, arguments);
                },
              })
            : e,
          i = r[t].apply(o, arguments);
        return i;
      };
    };
  for (var i in r) o(i);
}
function Fu(e) {
  e.app;
  var t = e.store,
    n = e.options;
  if (!t.$id.startsWith("__hot:")) {
    if (((t._isOptionsAPI = !!n.state), !t._p._testing)) {
      Bu(t, Object.keys(n.actions), t._isOptionsAPI);
      var r = t._hotUpdate;
      Ho(t)._hotUpdate = function (e) {
        r.apply(this, arguments),
          Bu(t, Object.keys(e._hmrPayload.actions), !!t._isOptionsAPI);
      };
    }
    !(function (e, t) {
      Nu.includes(qu(t.$id)) || Nu.push(qu(t.$id));
    })(0, t);
  }
}
function Hu() {
  var e = Sr(!0),
    t = e.run(function () {
      return Go({});
    }),
    n = [],
    r = [],
    o = Vo({
      install: function (e) {
        ju(o),
          (o._a = e),
          e.provide(Mu, o),
          (e.config.globalProperties.$pinia = o),
          r.forEach(function (e) {
            return n.push(e);
          }),
          (r = []);
      },
      use: function (e) {
        return this._a ? n.push(e) : r.push(e), this;
      },
      _p: n,
      _a: null,
      _e: e,
      _s: new Map(),
      state: t,
    });
  return "undefined" != typeof Proxy && o.use(Fu), o;
}
var Vu = function (e) {
  return "function" == typeof e && "string" == typeof e.$id;
};
function Ku(e, t) {
  for (var n in t) {
    var r = t[n];
    if (n in e) {
      var o = e[n];
      Du(o) && Du(r) && !Qo(r) && !No(r) ? (e[n] = Ku(o, r)) : (e[n] = r);
    }
  }
  return e;
}
var Wu = function () {};
function zu(e, t, n) {
  var r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : Wu;
  e.push(t);
  var o = function () {
    var n = e.indexOf(t);
    n > -1 && (e.splice(n, 1), r());
  };
  return !n && Pr() && Tr(o), o;
}
function Ju(e) {
  for (
    var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1;
    r < t;
    r++
  )
    n[r - 1] = arguments[r];
  e.slice().forEach(function (e) {
    e.apply(void 0, n);
  });
}
var Yu = function (e) {
    return e();
  },
  Qu = Symbol(),
  Gu = Symbol();
function Xu(e, t) {
  for (var n in (e instanceof Map && t instanceof Map
    ? t.forEach(function (t, n) {
        return e.set(n, t);
      })
    : e instanceof Set && t instanceof Set && t.forEach(e.add, e),
  t))
    if (t.hasOwnProperty(n)) {
      var r = t[n],
        o = e[n];
      Du(o) && Du(r) && e.hasOwnProperty(n) && !Qo(r) && !No(r)
        ? (e[n] = Xu(o, r))
        : (e[n] = r);
    }
  return e;
}
var Zu = Symbol("pinia:skipHydration");
function ef(e) {
  return !Du(e) || !e.hasOwnProperty(Zu);
}
var tf = Object.assign;
function nf(e) {
  return !(!Qo(e) || !e.effect);
}
function rf(e, t, n, r) {
  var o = t.state,
    i = t.actions,
    a = t.getters,
    s = n.state.value[e];
  return of(
    e,
    function () {
      s || r || (n.state.value[e] = o ? o() : {});
      var t = ni(r ? Go(o ? o() : {}).value : n.state.value[e]);
      return tf(
        t,
        i,
        Object.keys(a || {}).reduce(function (r, o) {
          return (
            o in t &&
              console.warn(
                '[🍍]: A getter cannot have the same name as another state property. Rename one of them. Found with "'
                  .concat(o, '" in store "')
                  .concat(e, '".')
              ),
            (r[o] = Vo(
              qs(function () {
                ju(n);
                var t = n._s.get(e);
                return a[o].call(t, t);
              })
            )),
            r
          );
        }, {})
      );
    },
    t,
    n,
    r,
    !0
  );
}
function of(e, t) {
  var n,
    r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
    o = arguments.length > 3 ? arguments[3] : void 0,
    i = arguments.length > 4 ? arguments[4] : void 0,
    a = arguments.length > 5 ? arguments[5] : void 0,
    s = tf({ actions: {} }, r);
  if (!o._e.active) throw new Error("Pinia destroyed");
  var c,
    u,
    f = { deep: !0 };
  f.onTrigger = function (e) {
    c
      ? (l = e)
      : 0 != c ||
        S._hotUpdating ||
        (Array.isArray(l)
          ? l.push(e)
          : console.error(
              "🍍 debuggerEvents should be an array. This is most likely an internal Pinia bug."
            ));
  };
  var l,
    p = [],
    h = [],
    v = o.state.value[e];
  a || v || i || (o.state.value[e] = {});
  var g,
    m = Go({});
  function y(t) {
    var n;
    (c = u = !1),
      (l = []),
      "function" == typeof t
        ? (t(o.state.value[e]),
          (n = { type: $u.patchFunction, storeId: e, events: l }))
        : (Xu(o.state.value[e], t),
          (n = { type: $u.patchObject, payload: t, storeId: e, events: l }));
    var r = (g = Symbol());
    Oi().then(function () {
      g === r && (c = !0);
    }),
      (u = !0),
      Ju(p, n, o.state.value[e]);
  }
  var _ = a
    ? function () {
        var e = r.state,
          t = e ? e() : {};
        this.$patch(function (e) {
          tf(e, t);
        });
      }
    : function () {
        throw new Error(
          '🍍: Store "'.concat(
            e,
            '" is built using the setup syntax and does not implement $reset().'
          )
        );
      };
  function b() {
    n.stop(), (p = []), (h = []), o._s.delete(e);
  }
  var w = function (t) {
      var n =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
      if (Qu in t) return (t[Gu] = n), t;
      var r = function n() {
        ju(o);
        var r,
          i = Array.from(arguments),
          a = [],
          s = [];
        function c(e) {
          a.push(e);
        }
        function u(e) {
          s.push(e);
        }
        Ju(h, { args: i, name: n[Gu], store: S, after: c, onError: u });
        try {
          r = t.apply(this && this.$id === e ? this : S, i);
        } catch (e) {
          throw (Ju(s, e), e);
        }
        return r instanceof Promise
          ? r
              .then(function (e) {
                return Ju(a, e), e;
              })
              .catch(function (e) {
                return Ju(s, e), Promise.reject(e);
              })
          : (Ju(a, r), r);
      };
      return (r[Qu] = !0), (r[Gu] = n), r;
    },
    k = Vo({ actions: {}, getters: {}, state: [], hotState: m }),
    x = {
      _p: o,
      $id: e,
      $onAction: zu.bind(null, h),
      $patch: y,
      $reset: _,
      $subscribe: function (t) {
        var r =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          i = zu(p, t, r.detached, function () {
            return a();
          }),
          a = n.run(function () {
            return ra(
              function () {
                return o.state.value[e];
              },
              function (n) {
                ("sync" === r.flush ? u : c) &&
                  t({ storeId: e, type: $u.direct, events: l }, n);
              },
              tf({}, f, r)
            );
          });
        return i;
      },
      $dispose: b,
    },
    S = Ro(tf({ _hmrPayload: k, _customProperties: Vo(new Set()) }, x));
  o._s.set(e, S);
  var P = (o._a && o._a.runWithContext) || Yu,
    T = P(function () {
      return o._e.run(function () {
        return (n = Sr()).run(function () {
          return t({ action: w });
        });
      });
    });
  for (var O in T) {
    var A = T[O];
    if ((Qo(A) && !nf(A)) || No(A))
      i
        ? Eu(m.value, O, ii(T, O))
        : a ||
          (v && ef(A) && (Qo(A) ? (A.value = v[O]) : Xu(A, v[O])),
          (o.state.value[e][O] = A)),
        k.state.push(O);
    else if ("function" == typeof A) {
      var I = i ? A : w(A, O);
      (T[O] = I), (k.actions[O] = A), (s.actions[O] = A);
    } else if (nf(A) && ((k.getters[O] = a ? r.getters[O] : A), Uu)) {
      var C = T._getters || (T._getters = Vo([]));
      C.push(O);
    }
  }
  if (
    (tf(S, T),
    tf(Ho(S), T),
    Object.defineProperty(S, "$state", {
      get: function () {
        return i ? m.value : o.state.value[e];
      },
      set: function (e) {
        if (i) throw new Error("cannot set hotState");
        y(function (t) {
          tf(t, e);
        });
      },
    }),
    (S._hotUpdate = Vo(function (t) {
      for (var n in ((S._hotUpdating = !0),
      t._hmrPayload.state.forEach(function (e) {
        if (e in S.$state) {
          var n = t.$state[e],
            r = S.$state[e];
          "object" === d(n) && Du(n) && Du(r) ? Ku(n, r) : (t.$state[e] = r);
        }
        Eu(S, e, ii(t.$state, e));
      }),
      Object.keys(S.$state).forEach(function (e) {
        e in t.$state || Lu(S, e);
      }),
      (c = !1),
      (u = !1),
      (o.state.value[e] = ii(t._hmrPayload, "hotState")),
      (u = !0),
      Oi().then(function () {
        c = !0;
      }),
      t._hmrPayload.actions)) {
        var r = t[n];
        Eu(S, n, w(r, n));
      }
      var i = function () {
        var e = t._hmrPayload.getters[s],
          n = a
            ? qs(function () {
                return ju(o), e.call(S, S);
              })
            : e;
        Eu(S, s, n);
      };
      for (var s in t._hmrPayload.getters) i();
      Object.keys(S._hmrPayload.getters).forEach(function (e) {
        e in t._hmrPayload.getters || Lu(S, e);
      }),
        Object.keys(S._hmrPayload.actions).forEach(function (e) {
          e in t._hmrPayload.actions || Lu(S, e);
        }),
        (S._hmrPayload = t._hmrPayload),
        (S._getters = t._getters),
        (S._hotUpdating = !1);
    })),
    Uu)
  ) {
    var E = { writable: !0, configurable: !0, enumerable: !1 };
    ["_p", "_hmrPayload", "_getters", "_customProperties"].forEach(function (
      e
    ) {
      Object.defineProperty(S, e, tf({ value: S[e] }, E));
    });
  }
  return (
    o._p.forEach(function (e) {
      if (Uu) {
        var t = n.run(function () {
          return e({ store: S, app: o._a, pinia: o, options: s });
        });
        Object.keys(t || {}).forEach(function (e) {
          return S._customProperties.add(e);
        }),
          tf(S, t);
      } else
        tf(
          S,
          n.run(function () {
            return e({ store: S, app: o._a, pinia: o, options: s });
          })
        );
    }),
    S.$state &&
      "object" === d(S.$state) &&
      "function" == typeof S.$state.constructor &&
      !S.$state.constructor.toString().includes("[native code]") &&
      console.warn(
        '[🍍]: The "state" must be a plain object. It cannot be\n\tstate: () => new MyClass()\nFound in store "'.concat(
          S.$id,
          '".'
        )
      ),
    v && a && r.hydrate && r.hydrate(S.$state, v),
    (c = !0),
    (u = !0),
    S
  );
}
function af(e, t, n) {
  var r,
    o,
    i = "function" == typeof t;
  if ("string" == typeof e) (r = e), (o = i ? n : t);
  else if (((o = e), "string" != typeof (r = e.id)))
    throw new Error(
      '[🍍]: "defineStore()" must be passed a store id as its first argument.'
    );
  function a(e, n) {
    var s = ha();
    if (((e = e || (s ? pa(Mu, null) : null)) && ju(e), !bu))
      throw new Error(
        '[🍍]: "getActivePinia()" was called but there was no active Pinia. Are you trying to use a store before calling "app.use(pinia)"?\nSee https://pinia.vuejs.org/core-concepts/outside-component-usage.html for help.\nThis will fail in production.'
      );
    (e = bu)._s.has(r) || (i ? of(r, t, o, e) : rf(r, o, e), (a._pinia = e));
    var c = e._s.get(r);
    if (n) {
      var u = "__hot:" + r,
        f = i ? of(u, t, o, e, !0) : rf(u, tf({}, o), e, !0);
      n._hotUpdate(f), delete e.state.value[u], e._s.delete(u);
    }
    if (Uu) {
      var l = Ps();
      if (l && l.proxy && !n) {
        var p = l.proxy;
        ("_pStores" in p ? p._pStores : (p._pStores = {}))[r] = c;
      }
    }
    return c;
  }
  return (a.$id = r), a;
}
var sf = "Store";
function cf(e, t) {
  return Array.isArray(t)
    ? t.reduce(function (t, n) {
        return (
          (t[n] = function () {
            return e(this.$pinia)[n];
          }),
          t
        );
      }, {})
    : Object.keys(t).reduce(function (n, r) {
        return (
          (n[r] = function () {
            var n = e(this.$pinia),
              o = t[r];
            return "function" == typeof o ? o.call(this, n) : n[o];
          }),
          n
        );
      }, {});
}
var uf = cf;
var ff = Object.freeze(
  Object.defineProperty(
    {
      __proto__: null,
      get MutationType() {
        return $u;
      },
      PiniaVuePlugin: function (e) {
        e.mixin({
          beforeCreate: function () {
            var e = this.$options;
            if (e.pinia) {
              var t = e.pinia;
              if (!this._provided) {
                var n = {};
                Object.defineProperty(this, "_provided", {
                  get: function () {
                    return n;
                  },
                  set: function (e) {
                    return Object.assign(n, e);
                  },
                });
              }
              (this._provided[Mu] = t),
                this.$pinia || (this.$pinia = t),
                (t._a = this),
                Uu && ju(t),
                Uu && t._a;
            } else
              !this.$pinia &&
                e.parent &&
                e.parent.$pinia &&
                (this.$pinia = e.parent.$pinia);
          },
          destroyed: function () {
            delete this._pStores;
          },
        });
      },
      acceptHMRUpdate: function (e, t) {
        return function (n) {
          var r = t.data.pinia || e._pinia;
          if (r)
            for (var o in ((t.data.pinia = r), n)) {
              var i = n[o];
              if (Vu(i) && r._s.has(i.$id)) {
                var a = i.$id;
                if (a !== e.$id)
                  return (
                    console.warn(
                      'The id of the store changed from "'
                        .concat(e.$id, '" to "')
                        .concat(a, '". Reloading.')
                    ),
                    t.invalidate()
                  );
                var s = r._s.get(a);
                if (!s)
                  return void console.log(
                    "[Pinia]: skipping hmr because store doesn't exist yet"
                  );
                i(r, s);
              }
            }
        };
      },
      createPinia: Hu,
      defineStore: af,
      disposePinia: function (e) {
        e._e.stop(),
          e._s.clear(),
          e._p.splice(0),
          (e.state.value = {}),
          (e._a = null);
      },
      getActivePinia: function () {
        return (ha() && pa(Mu)) || bu;
      },
      mapActions: function (e, t) {
        return Array.isArray(t)
          ? t.reduce(function (t, n) {
              return (
                (t[n] = function () {
                  var t;
                  return (t = e(this.$pinia))[n].apply(t, arguments);
                }),
                t
              );
            }, {})
          : Object.keys(t).reduce(function (n, r) {
              return (
                (n[r] = function () {
                  var n;
                  return (n = e(this.$pinia))[t[r]].apply(n, arguments);
                }),
                n
              );
            }, {});
      },
      mapGetters: uf,
      mapState: cf,
      mapStores: function () {
        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
          t[n] = arguments[n];
        return (
          Array.isArray(t[0]) &&
            (console.warn(
              '[🍍]: Directly pass all stores to "mapStores()" without putting them in an array:\nReplace\n\tmapStores([useAuthStore, useCartStore])\nwith\n\tmapStores(useAuthStore, useCartStore)\nThis will fail in production if not fixed.'
            ),
            (t = t[0])),
          t.reduce(function (e, t) {
            return (
              (e[t.$id + sf] = function () {
                return t(this.$pinia);
              }),
              e
            );
          }, {})
        );
      },
      mapWritableState: function (e, t) {
        return Array.isArray(t)
          ? t.reduce(function (t, n) {
              return (
                (t[n] = {
                  get: function () {
                    return e(this.$pinia)[n];
                  },
                  set: function (t) {
                    return (e(this.$pinia)[n] = t);
                  },
                }),
                t
              );
            }, {})
          : Object.keys(t).reduce(function (n, r) {
              return (
                (n[r] = {
                  get: function () {
                    return e(this.$pinia)[t[r]];
                  },
                  set: function (n) {
                    return (e(this.$pinia)[t[r]] = n);
                  },
                }),
                n
              );
            }, {});
      },
      setActivePinia: ju,
      setMapStoreSuffix: function (e) {
        sf = e;
      },
      skipHydrate: function (e) {
        return Object.defineProperty(e, Zu, {});
      },
      storeToRefs: function (e) {
        e = Ho(e);
        var t = {};
        for (var n in e) {
          var r = e[n];
          (Qo(r) || No(r)) && (t[n] = ii(e, n));
        }
        return t;
      },
    },
    Symbol.toStringTag,
    { value: "Module" }
  )
);
"undefined" != typeof globalThis
  ? globalThis
  : "undefined" != typeof window
  ? window
  : "undefined" != typeof global
  ? global
  : "undefined" != typeof self && self;
function lf(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default")
    ? e.default
    : e;
}
var pf = { exports: {} },
  hf = lf(
    (pf.exports = (function () {
      var e = "millisecond",
        t = "second",
        n = "minute",
        r = "hour",
        o = "day",
        i = "week",
        a = "month",
        s = "quarter",
        c = "year",
        u = "date",
        f = "Invalid Date",
        l =
          /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/,
        p =
          /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g,
        h = {
          name: "en",
          weekdays:
            "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split(
              "_"
            ),
          months:
            "January_February_March_April_May_June_July_August_September_October_November_December".split(
              "_"
            ),
          ordinal: function (e) {
            var t = ["th", "st", "nd", "rd"],
              n = e % 100;
            return "[" + e + (t[(n - 20) % 10] || t[n] || t[0]) + "]";
          },
        },
        v = function (e, t, n) {
          var r = String(e);
          return !r || r.length >= t
            ? e
            : "" + Array(t + 1 - r.length).join(n) + e;
        },
        g = {
          s: v,
          z: function (e) {
            var t = -e.utcOffset(),
              n = Math.abs(t),
              r = Math.floor(n / 60),
              o = n % 60;
            return (t <= 0 ? "+" : "-") + v(r, 2, "0") + ":" + v(o, 2, "0");
          },
          m: function e(t, n) {
            if (t.date() < n.date()) return -e(n, t);
            var r = 12 * (n.year() - t.year()) + (n.month() - t.month()),
              o = t.clone().add(r, a),
              i = n - o < 0,
              s = t.clone().add(r + (i ? -1 : 1), a);
            return +(-(r + (n - o) / (i ? o - s : s - o)) || 0);
          },
          a: function (e) {
            return e < 0 ? Math.ceil(e) || 0 : Math.floor(e);
          },
          p: function (f) {
            return (
              { M: a, y: c, w: i, d: o, D: u, h: r, m: n, s: t, ms: e, Q: s }[
                f
              ] ||
              String(f || "")
                .toLowerCase()
                .replace(/s$/, "")
            );
          },
          u: function (e) {
            return void 0 === e;
          },
        },
        m = "en",
        y = {};
      y[m] = h;
      var _ = "$isDayjsObject",
        b = function (e) {
          return e instanceof S || !(!e || !e[_]);
        },
        w = function e(t, n, r) {
          var o;
          if (!t) return m;
          if ("string" == typeof t) {
            var i = t.toLowerCase();
            y[i] && (o = i), n && ((y[i] = n), (o = i));
            var a = t.split("-");
            if (!o && a.length > 1) return e(a[0]);
          } else {
            var s = t.name;
            (y[s] = t), (o = s);
          }
          return !r && o && (m = o), o || (!r && m);
        },
        k = function (e, t) {
          if (b(e)) return e.clone();
          var n = "object" == d(t) ? t : {};
          return (n.date = e), (n.args = arguments), new S(n);
        },
        x = g;
      (x.l = w),
        (x.i = b),
        (x.w = function (e, t) {
          return k(e, { locale: t.$L, utc: t.$u, x: t.$x, $offset: t.$offset });
        });
      var S = (function () {
          function h(e) {
            (this.$L = w(e.locale, null, !0)),
              this.parse(e),
              (this.$x = this.$x || e.x || {}),
              (this[_] = !0);
          }
          var d = h.prototype;
          return (
            (d.parse = function (e) {
              (this.$d = (function (e) {
                var t = e.date,
                  n = e.utc;
                if (null === t) return new Date(NaN);
                if (x.u(t)) return new Date();
                if (t instanceof Date) return new Date(t);
                if ("string" == typeof t && !/Z$/i.test(t)) {
                  var r = t.match(l);
                  if (r) {
                    var o = r[2] - 1 || 0,
                      i = (r[7] || "0").substring(0, 3);
                    return n
                      ? new Date(
                          Date.UTC(
                            r[1],
                            o,
                            r[3] || 1,
                            r[4] || 0,
                            r[5] || 0,
                            r[6] || 0,
                            i
                          )
                        )
                      : new Date(
                          r[1],
                          o,
                          r[3] || 1,
                          r[4] || 0,
                          r[5] || 0,
                          r[6] || 0,
                          i
                        );
                  }
                }
                return new Date(t);
              })(e)),
                this.init();
            }),
            (d.init = function () {
              var e = this.$d;
              (this.$y = e.getFullYear()),
                (this.$M = e.getMonth()),
                (this.$D = e.getDate()),
                (this.$W = e.getDay()),
                (this.$H = e.getHours()),
                (this.$m = e.getMinutes()),
                (this.$s = e.getSeconds()),
                (this.$ms = e.getMilliseconds());
            }),
            (d.$utils = function () {
              return x;
            }),
            (d.isValid = function () {
              return !(this.$d.toString() === f);
            }),
            (d.isSame = function (e, t) {
              var n = k(e);
              return this.startOf(t) <= n && n <= this.endOf(t);
            }),
            (d.isAfter = function (e, t) {
              return k(e) < this.startOf(t);
            }),
            (d.isBefore = function (e, t) {
              return this.endOf(t) < k(e);
            }),
            (d.$g = function (e, t, n) {
              return x.u(e) ? this[t] : this.set(n, e);
            }),
            (d.unix = function () {
              return Math.floor(this.valueOf() / 1e3);
            }),
            (d.valueOf = function () {
              return this.$d.getTime();
            }),
            (d.startOf = function (e, s) {
              var f = this,
                l = !!x.u(s) || s,
                p = x.p(e),
                h = function (e, t) {
                  var n = x.w(
                    f.$u ? Date.UTC(f.$y, t, e) : new Date(f.$y, t, e),
                    f
                  );
                  return l ? n : n.endOf(o);
                },
                d = function (e, t) {
                  return x.w(
                    f
                      .toDate()
                      [e].apply(
                        f.toDate("s"),
                        (l ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(t)
                      ),
                    f
                  );
                },
                v = this.$W,
                g = this.$M,
                m = this.$D,
                y = "set" + (this.$u ? "UTC" : "");
              switch (p) {
                case c:
                  return l ? h(1, 0) : h(31, 11);
                case a:
                  return l ? h(1, g) : h(0, g + 1);
                case i:
                  var _ = this.$locale().weekStart || 0,
                    b = (v < _ ? v + 7 : v) - _;
                  return h(l ? m - b : m + (6 - b), g);
                case o:
                case u:
                  return d(y + "Hours", 0);
                case r:
                  return d(y + "Minutes", 1);
                case n:
                  return d(y + "Seconds", 2);
                case t:
                  return d(y + "Milliseconds", 3);
                default:
                  return this.clone();
              }
            }),
            (d.endOf = function (e) {
              return this.startOf(e, !1);
            }),
            (d.$set = function (i, s) {
              var f,
                l = x.p(i),
                p = "set" + (this.$u ? "UTC" : ""),
                h = ((f = {}),
                (f[o] = p + "Date"),
                (f[u] = p + "Date"),
                (f[a] = p + "Month"),
                (f[c] = p + "FullYear"),
                (f[r] = p + "Hours"),
                (f[n] = p + "Minutes"),
                (f[t] = p + "Seconds"),
                (f[e] = p + "Milliseconds"),
                f)[l],
                d = l === o ? this.$D + (s - this.$W) : s;
              if (l === a || l === c) {
                var v = this.clone().set(u, 1);
                v.$d[h](d),
                  v.init(),
                  (this.$d = v.set(u, Math.min(this.$D, v.daysInMonth())).$d);
              } else h && this.$d[h](d);
              return this.init(), this;
            }),
            (d.set = function (e, t) {
              return this.clone().$set(e, t);
            }),
            (d.get = function (e) {
              return this[x.p(e)]();
            }),
            (d.add = function (e, s) {
              var u,
                f = this;
              e = Number(e);
              var l = x.p(s),
                p = function (t) {
                  var n = k(f);
                  return x.w(n.date(n.date() + Math.round(t * e)), f);
                };
              if (l === a) return this.set(a, this.$M + e);
              if (l === c) return this.set(c, this.$y + e);
              if (l === o) return p(1);
              if (l === i) return p(7);
              var h =
                  ((u = {}), (u[n] = 6e4), (u[r] = 36e5), (u[t] = 1e3), u)[l] ||
                  1,
                d = this.$d.getTime() + e * h;
              return x.w(d, this);
            }),
            (d.subtract = function (e, t) {
              return this.add(-1 * e, t);
            }),
            (d.format = function (e) {
              var t = this,
                n = this.$locale();
              if (!this.isValid()) return n.invalidDate || f;
              var r = e || "YYYY-MM-DDTHH:mm:ssZ",
                o = x.z(this),
                i = this.$H,
                a = this.$m,
                s = this.$M,
                c = n.weekdays,
                u = n.months,
                l = n.meridiem,
                h = function (e, n, o, i) {
                  return (e && (e[n] || e(t, r))) || o[n].slice(0, i);
                },
                d = function (e) {
                  return x.s(i % 12 || 12, e, "0");
                },
                v =
                  l ||
                  function (e, t, n) {
                    var r = e < 12 ? "AM" : "PM";
                    return n ? r.toLowerCase() : r;
                  };
              return r.replace(p, function (e, r) {
                return (
                  r ||
                  (function (e) {
                    switch (e) {
                      case "YY":
                        return String(t.$y).slice(-2);
                      case "YYYY":
                        return x.s(t.$y, 4, "0");
                      case "M":
                        return s + 1;
                      case "MM":
                        return x.s(s + 1, 2, "0");
                      case "MMM":
                        return h(n.monthsShort, s, u, 3);
                      case "MMMM":
                        return h(u, s);
                      case "D":
                        return t.$D;
                      case "DD":
                        return x.s(t.$D, 2, "0");
                      case "d":
                        return String(t.$W);
                      case "dd":
                        return h(n.weekdaysMin, t.$W, c, 2);
                      case "ddd":
                        return h(n.weekdaysShort, t.$W, c, 3);
                      case "dddd":
                        return c[t.$W];
                      case "H":
                        return String(i);
                      case "HH":
                        return x.s(i, 2, "0");
                      case "h":
                        return d(1);
                      case "hh":
                        return d(2);
                      case "a":
                        return v(i, a, !0);
                      case "A":
                        return v(i, a, !1);
                      case "m":
                        return String(a);
                      case "mm":
                        return x.s(a, 2, "0");
                      case "s":
                        return String(t.$s);
                      case "ss":
                        return x.s(t.$s, 2, "0");
                      case "SSS":
                        return x.s(t.$ms, 3, "0");
                      case "Z":
                        return o;
                    }
                    return null;
                  })(e) ||
                  o.replace(":", "")
                );
              });
            }),
            (d.utcOffset = function () {
              return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
            }),
            (d.diff = function (e, u, f) {
              var l,
                p = this,
                h = x.p(u),
                d = k(e),
                v = 6e4 * (d.utcOffset() - this.utcOffset()),
                g = this - d,
                m = function () {
                  return x.m(p, d);
                };
              switch (h) {
                case c:
                  l = m() / 12;
                  break;
                case a:
                  l = m();
                  break;
                case s:
                  l = m() / 3;
                  break;
                case i:
                  l = (g - v) / 6048e5;
                  break;
                case o:
                  l = (g - v) / 864e5;
                  break;
                case r:
                  l = g / 36e5;
                  break;
                case n:
                  l = g / 6e4;
                  break;
                case t:
                  l = g / 1e3;
                  break;
                default:
                  l = g;
              }
              return f ? l : x.a(l);
            }),
            (d.daysInMonth = function () {
              return this.endOf(a).$D;
            }),
            (d.$locale = function () {
              return y[this.$L];
            }),
            (d.locale = function (e, t) {
              if (!e) return this.$L;
              var n = this.clone(),
                r = w(e, t, !0);
              return r && (n.$L = r), n;
            }),
            (d.clone = function () {
              return x.w(this.$d, this);
            }),
            (d.toDate = function () {
              return new Date(this.valueOf());
            }),
            (d.toJSON = function () {
              return this.isValid() ? this.toISOString() : null;
            }),
            (d.toISOString = function () {
              return this.$d.toISOString();
            }),
            (d.toString = function () {
              return this.$d.toUTCString();
            }),
            h
          );
        })(),
        P = S.prototype;
      return (
        (k.prototype = P),
        [
          ["$ms", e],
          ["$s", t],
          ["$m", n],
          ["$H", r],
          ["$W", o],
          ["$M", a],
          ["$y", c],
          ["$D", u],
        ].forEach(function (e) {
          P[e[1]] = function (t) {
            return this.$g(t, e[0], e[1]);
          };
        }),
        (k.extend = function (e, t) {
          return e.$i || (e(t, S, k), (e.$i = !0)), k;
        }),
        (k.locale = w),
        (k.isDayjs = b),
        (k.unix = function (e) {
          return k(1e3 * e);
        }),
        (k.en = y[m]),
        (k.Ls = y),
        (k.p = {}),
        k
      );
    })())
  ),
  df = {
    pages: [
      {
        path: "pages/index/index",
        style: {
          navigationBarTitleText: "成长互动日志",
          enablePullDownRefresh: !1,
          disableScroll: !0,
          navigationStyle: "custom",
        },
      },
      {
        path: "pages/personal/index",
        style: { navigationBarTitleText: "我的", navigationStyle: "custom" },
      },
      {
        path: "pages/history/index",
        style: {
          navigationBarTitleText: "互动会话记录",
          navigationStyle: "custom",
        },
      },
      {
        path: "pages/chat/chat",
        style: {
          navigationBarTitleText: "家长咨询",
          navigationStyle: "custom",
        },
      },
      {
        path: "pages/personalEdit/index",
        style: { navigationBarTitleText: "基本信息" },
      },
      {
        path: "pages/device/device",
        style: {
          navigationBarTitleText: "设备绑定",
          enablePullDownRefresh: !1,
          disableScroll: !0,
          navigationStyle: "custom",
        },
      },
      {
        path: "pages/login/index",
        style: {
          navigationBarTitleText: "登录/注册",
          navigationStyle: "custom",
        },
      },
      {
        path: "pages/register/index",
        style: { navigationBarTitleText: "登录", navigationStyle: "custom" },
      },
      {
        path: "pages/explain/index",
        style: {
          navigationBarTitleText: "使用说明",
          navigationStyle: "custom",
        },
      },
      {
        path: "pages/secretCharacter/index",
        style: { navigationBarTitleText: "角色设置" },
      },
      {
        path: "pages/characterDetail/index",
        style: { navigationBarTitleText: "" },
      },
      {
        path: "pages/switchingToy/switchingToy",
        style: { navigationBarTitleText: "我的玩具" },
      },
      { path: "pages/toyDetail/index", style: { navigationBarTitleText: "" } },
      {
        path: "pages/setting/setting",
        style: { navigationBarTitleText: "设置" },
      },
      {
        path: "pages/versionUpdating/versionUpdating",
        style: { navigationBarTitleText: "版本列表" },
      },
      {
        path: "pages/versionDetail/versionDetail",
        style: {
          navigationBarTitleText: "版本更新说明详情",
          navigationStyle: "custom",
        },
      },
      {
        path: "pages/memberPage/memberPage",
        style: {
          navigationBarTitleText: "会员权益",
          navigationStyle: "custom",
        },
      },
      {
        path: "pages/notFindPage/index",
        style: { navigationBarTitleText: "配网帮助" },
      },
      {
        path: "pages/mobileWifiHelp/index",
        style: { navigationBarTitleText: "热点配网帮助" },
      },
      {
        path: "pages/familyAccount/index",
        style: { navigationBarTitleText: "家庭账号" },
      },
      { path: "pages/member/index", style: { navigationBarTitleText: "成员" } },
      {
        path: "pages/joinFamily/index",
        style: { navigationBarTitleText: "加入家庭" },
      },
      {
        path: "pages/prohibitUseTimes/index",
        style: { navigationBarTitleText: "禁用时段" },
      },
      {
        path: "pages/prohibitUseTimesAdd/index",
        style: { navigationBarTitleText: "添加禁用时段" },
      },
      {
        path: "pages/prohibitUseRepeat/index",
        style: { navigationBarTitleText: "重复" },
      },
      {
        path: "pages/userFeedback/index",
        style: { navigationBarTitleText: "用户反馈" },
      },
      {
        path: "pages/modifyToyName/index",
        style: { navigationBarTitleText: "修改昵称" },
      },
      {
        path: "pages/AIHelp/index",
        style: { navigationBarTitleText: "AI帮你说" },
      },
      {
        path: "pages/activityDetails/index",
        style: { navigationBarTitleText: "" },
      },
      { path: "pages/webContent/index", style: { navigationBarTitleText: "" } },
      {
        path: "pages/activityDetailsBC/index",
        style: { navigationBarTitleText: "", navigationStyle: "custom" },
      },
      {
        path: "pages/directiveList/index",
        style: { navigationBarTitleText: "全部指令" },
      },
      {
        path: "pages/letterList/index",
        style: { navigationBarTitleText: "消息列表" },
      },
      {
        path: "pages/letterDetail/index",
        style: {
          navigationBarTitleText: "来信详情",
          navigationStyle: "custom",
        },
      },
      {
        path: "pages/commands/index",
        style: {
          navigationBarTitleText: "动作组合loading",
          navigationStyle: "custom",
        },
      },
      {
        path: "pages/commandsPage/index",
        style: {
          navigationBarTitleText: "动作组合",
          navigationStyle: "custom",
          pageOrientation: "landscape",
        },
      },
      {
        path: "pages/selectCommand/index",
        style: {
          navigationBarTitleText: "有趣指令翻翻乐",
          navigationStyle: "custom",
        },
      },
    ],
    globalStyle: {
      navigationBarTextStyle: "black",
      navigationBarTitleText: "",
      navigationBarBackgroundColor: "#f7f7f7",
      backgroundColor: "#f7f7f7",
    },
    tabBar: {
      selectedColor: "#3ada77",
      color: "#999999",
      list: [
        {
          pagePath: "pages/index/index",
          text: "主页",
          iconPath: "static/images/app/tabs/home-inactive.png",
          selectedIconPath: "static/images/app/tabs/home-active.png",
        },
        {
          pagePath: "pages/history/index",
          text: "记录",
          iconPath: "static/images/app/tabs/records-inactive.png",
          selectedIconPath: "static/images/app/tabs/records-active.png",
        },
        {
          pagePath: "pages/personal/index",
          text: "我的",
          iconPath: "static/images/app/tabs/account-inactive.png",
          selectedIconPath: "static/images/app/tabs/account-active.png",
        },
      ],
    },
  };
function vf(e, t, n) {
  return (
    e(
      (n = {
        path: t,
        exports: {},
        require: function (e, t) {
          return (function () {
            throw new Error(
              "Dynamic requires are not currently supported by @rollup/plugin-commonjs"
            );
          })(null == t && n.path);
        },
      }),
      n.exports
    ),
    n.exports
  );
}
var gf = vf(function (e, t) {
    var n;
    e.exports = n =
      n ||
      (function (e, t) {
        var n =
            Object.create ||
            (function () {
              function e() {}
              return function (t) {
                var n;
                return (
                  (e.prototype = t), (n = new e()), (e.prototype = null), n
                );
              };
            })(),
          r = {},
          o = (r.lib = {}),
          i = (o.Base = {
            extend: function (e) {
              var t = n(this);
              return (
                e && t.mixIn(e),
                (t.hasOwnProperty("init") && this.init !== t.init) ||
                  (t.init = function () {
                    t.$super.init.apply(this, arguments);
                  }),
                (t.init.prototype = t),
                (t.$super = this),
                t
              );
            },
            create: function () {
              var e = this.extend();
              return e.init.apply(e, arguments), e;
            },
            init: function () {},
            mixIn: function (e) {
              for (var t in e) e.hasOwnProperty(t) && (this[t] = e[t]);
              e.hasOwnProperty("toString") && (this.toString = e.toString);
            },
            clone: function () {
              return this.init.prototype.extend(this);
            },
          }),
          a = (o.WordArray = i.extend({
            init: function (e, t) {
              (e = this.words = e || []),
                (this.sigBytes = null != t ? t : 4 * e.length);
            },
            toString: function (e) {
              return (e || c).stringify(this);
            },
            concat: function (e) {
              var t = this.words,
                n = e.words,
                r = this.sigBytes,
                o = e.sigBytes;
              if ((this.clamp(), r % 4))
                for (var i = 0; i < o; i++) {
                  var a = (n[i >>> 2] >>> (24 - (i % 4) * 8)) & 255;
                  t[(r + i) >>> 2] |= a << (24 - ((r + i) % 4) * 8);
                }
              else for (i = 0; i < o; i += 4) t[(r + i) >>> 2] = n[i >>> 2];
              return (this.sigBytes += o), this;
            },
            clamp: function () {
              var t = this.words,
                n = this.sigBytes;
              (t[n >>> 2] &= 4294967295 << (32 - (n % 4) * 8)),
                (t.length = e.ceil(n / 4));
            },
            clone: function () {
              var e = i.clone.call(this);
              return (e.words = this.words.slice(0)), e;
            },
            random: function (t) {
              for (
                var n,
                  r = [],
                  o = function (t) {
                    t = t;
                    var n = 987654321,
                      r = 4294967295;
                    return function () {
                      var o =
                        (((n = (36969 * (65535 & n) + (n >> 16)) & r) << 16) +
                          (t = (18e3 * (65535 & t) + (t >> 16)) & r)) &
                        r;
                      return (
                        (o /= 4294967296),
                        (o += 0.5) * (e.random() > 0.5 ? 1 : -1)
                      );
                    };
                  },
                  i = 0;
                i < t;
                i += 4
              ) {
                var s = o(4294967296 * (n || e.random()));
                (n = 987654071 * s()), r.push((4294967296 * s()) | 0);
              }
              return new a.init(r, t);
            },
          })),
          s = (r.enc = {}),
          c = (s.Hex = {
            stringify: function (e) {
              for (var t = e.words, n = e.sigBytes, r = [], o = 0; o < n; o++) {
                var i = (t[o >>> 2] >>> (24 - (o % 4) * 8)) & 255;
                r.push((i >>> 4).toString(16)), r.push((15 & i).toString(16));
              }
              return r.join("");
            },
            parse: function (e) {
              for (var t = e.length, n = [], r = 0; r < t; r += 2)
                n[r >>> 3] |=
                  parseInt(e.substr(r, 2), 16) << (24 - (r % 8) * 4);
              return new a.init(n, t / 2);
            },
          }),
          u = (s.Latin1 = {
            stringify: function (e) {
              for (var t = e.words, n = e.sigBytes, r = [], o = 0; o < n; o++) {
                var i = (t[o >>> 2] >>> (24 - (o % 4) * 8)) & 255;
                r.push(String.fromCharCode(i));
              }
              return r.join("");
            },
            parse: function (e) {
              for (var t = e.length, n = [], r = 0; r < t; r++)
                n[r >>> 2] |= (255 & e.charCodeAt(r)) << (24 - (r % 4) * 8);
              return new a.init(n, t);
            },
          }),
          f = (s.Utf8 = {
            stringify: function (e) {
              try {
                return decodeURIComponent(escape(u.stringify(e)));
              } catch (e) {
                throw new Error("Malformed UTF-8 data");
              }
            },
            parse: function (e) {
              return u.parse(unescape(encodeURIComponent(e)));
            },
          }),
          l = (o.BufferedBlockAlgorithm = i.extend({
            reset: function () {
              (this._data = new a.init()), (this._nDataBytes = 0);
            },
            _append: function (e) {
              "string" == typeof e && (e = f.parse(e)),
                this._data.concat(e),
                (this._nDataBytes += e.sigBytes);
            },
            _process: function (t) {
              var n = this._data,
                r = n.words,
                o = n.sigBytes,
                i = this.blockSize,
                s = o / (4 * i),
                c =
                  (s = t
                    ? e.ceil(s)
                    : e.max((0 | s) - this._minBufferSize, 0)) * i,
                u = e.min(4 * c, o);
              if (c) {
                for (var f = 0; f < c; f += i) this._doProcessBlock(r, f);
                var l = r.splice(0, c);
                n.sigBytes -= u;
              }
              return new a.init(l, u);
            },
            clone: function () {
              var e = i.clone.call(this);
              return (e._data = this._data.clone()), e;
            },
            _minBufferSize: 0,
          }));
        o.Hasher = l.extend({
          cfg: i.extend(),
          init: function (e) {
            (this.cfg = this.cfg.extend(e)), this.reset();
          },
          reset: function () {
            l.reset.call(this), this._doReset();
          },
          update: function (e) {
            return this._append(e), this._process(), this;
          },
          finalize: function (e) {
            return e && this._append(e), this._doFinalize();
          },
          blockSize: 16,
          _createHelper: function (e) {
            return function (t, n) {
              return new e.init(n).finalize(t);
            };
          },
          _createHmacHelper: function (e) {
            return function (t, n) {
              return new p.HMAC.init(e, n).finalize(t);
            };
          },
        });
        var p = (r.algo = {});
        return r;
      })(Math);
  }),
  mf =
    (vf(function (e, t) {
      var n;
      e.exports =
        ((n = gf),
        (function (e) {
          var t = n,
            r = t.lib,
            o = r.WordArray,
            i = r.Hasher,
            a = t.algo,
            s = [];
          !(function () {
            for (var t = 0; t < 64; t++)
              s[t] = (4294967296 * e.abs(e.sin(t + 1))) | 0;
          })();
          var c = (a.MD5 = i.extend({
            _doReset: function () {
              this._hash = new o.init([
                1732584193, 4023233417, 2562383102, 271733878,
              ]);
            },
            _doProcessBlock: function (e, t) {
              for (var n = 0; n < 16; n++) {
                var r = t + n,
                  o = e[r];
                e[r] =
                  (16711935 & ((o << 8) | (o >>> 24))) |
                  (4278255360 & ((o << 24) | (o >>> 8)));
              }
              var i = this._hash.words,
                a = e[t + 0],
                c = e[t + 1],
                h = e[t + 2],
                d = e[t + 3],
                v = e[t + 4],
                g = e[t + 5],
                m = e[t + 6],
                y = e[t + 7],
                _ = e[t + 8],
                b = e[t + 9],
                w = e[t + 10],
                k = e[t + 11],
                x = e[t + 12],
                S = e[t + 13],
                P = e[t + 14],
                T = e[t + 15],
                O = i[0],
                A = i[1],
                I = i[2],
                C = i[3];
              (O = u(O, A, I, C, a, 7, s[0])),
                (C = u(C, O, A, I, c, 12, s[1])),
                (I = u(I, C, O, A, h, 17, s[2])),
                (A = u(A, I, C, O, d, 22, s[3])),
                (O = u(O, A, I, C, v, 7, s[4])),
                (C = u(C, O, A, I, g, 12, s[5])),
                (I = u(I, C, O, A, m, 17, s[6])),
                (A = u(A, I, C, O, y, 22, s[7])),
                (O = u(O, A, I, C, _, 7, s[8])),
                (C = u(C, O, A, I, b, 12, s[9])),
                (I = u(I, C, O, A, w, 17, s[10])),
                (A = u(A, I, C, O, k, 22, s[11])),
                (O = u(O, A, I, C, x, 7, s[12])),
                (C = u(C, O, A, I, S, 12, s[13])),
                (I = u(I, C, O, A, P, 17, s[14])),
                (O = f(
                  O,
                  (A = u(A, I, C, O, T, 22, s[15])),
                  I,
                  C,
                  c,
                  5,
                  s[16]
                )),
                (C = f(C, O, A, I, m, 9, s[17])),
                (I = f(I, C, O, A, k, 14, s[18])),
                (A = f(A, I, C, O, a, 20, s[19])),
                (O = f(O, A, I, C, g, 5, s[20])),
                (C = f(C, O, A, I, w, 9, s[21])),
                (I = f(I, C, O, A, T, 14, s[22])),
                (A = f(A, I, C, O, v, 20, s[23])),
                (O = f(O, A, I, C, b, 5, s[24])),
                (C = f(C, O, A, I, P, 9, s[25])),
                (I = f(I, C, O, A, d, 14, s[26])),
                (A = f(A, I, C, O, _, 20, s[27])),
                (O = f(O, A, I, C, S, 5, s[28])),
                (C = f(C, O, A, I, h, 9, s[29])),
                (I = f(I, C, O, A, y, 14, s[30])),
                (O = l(
                  O,
                  (A = f(A, I, C, O, x, 20, s[31])),
                  I,
                  C,
                  g,
                  4,
                  s[32]
                )),
                (C = l(C, O, A, I, _, 11, s[33])),
                (I = l(I, C, O, A, k, 16, s[34])),
                (A = l(A, I, C, O, P, 23, s[35])),
                (O = l(O, A, I, C, c, 4, s[36])),
                (C = l(C, O, A, I, v, 11, s[37])),
                (I = l(I, C, O, A, y, 16, s[38])),
                (A = l(A, I, C, O, w, 23, s[39])),
                (O = l(O, A, I, C, S, 4, s[40])),
                (C = l(C, O, A, I, a, 11, s[41])),
                (I = l(I, C, O, A, d, 16, s[42])),
                (A = l(A, I, C, O, m, 23, s[43])),
                (O = l(O, A, I, C, b, 4, s[44])),
                (C = l(C, O, A, I, x, 11, s[45])),
                (I = l(I, C, O, A, T, 16, s[46])),
                (O = p(
                  O,
                  (A = l(A, I, C, O, h, 23, s[47])),
                  I,
                  C,
                  a,
                  6,
                  s[48]
                )),
                (C = p(C, O, A, I, y, 10, s[49])),
                (I = p(I, C, O, A, P, 15, s[50])),
                (A = p(A, I, C, O, g, 21, s[51])),
                (O = p(O, A, I, C, x, 6, s[52])),
                (C = p(C, O, A, I, d, 10, s[53])),
                (I = p(I, C, O, A, w, 15, s[54])),
                (A = p(A, I, C, O, c, 21, s[55])),
                (O = p(O, A, I, C, _, 6, s[56])),
                (C = p(C, O, A, I, T, 10, s[57])),
                (I = p(I, C, O, A, m, 15, s[58])),
                (A = p(A, I, C, O, S, 21, s[59])),
                (O = p(O, A, I, C, v, 6, s[60])),
                (C = p(C, O, A, I, k, 10, s[61])),
                (I = p(I, C, O, A, h, 15, s[62])),
                (A = p(A, I, C, O, b, 21, s[63])),
                (i[0] = (i[0] + O) | 0),
                (i[1] = (i[1] + A) | 0),
                (i[2] = (i[2] + I) | 0),
                (i[3] = (i[3] + C) | 0);
            },
            _doFinalize: function () {
              var t = this._data,
                n = t.words,
                r = 8 * this._nDataBytes,
                o = 8 * t.sigBytes;
              n[o >>> 5] |= 128 << (24 - (o % 32));
              var i = e.floor(r / 4294967296),
                a = r;
              (n[15 + (((o + 64) >>> 9) << 4)] =
                (16711935 & ((i << 8) | (i >>> 24))) |
                (4278255360 & ((i << 24) | (i >>> 8)))),
                (n[14 + (((o + 64) >>> 9) << 4)] =
                  (16711935 & ((a << 8) | (a >>> 24))) |
                  (4278255360 & ((a << 24) | (a >>> 8)))),
                (t.sigBytes = 4 * (n.length + 1)),
                this._process();
              for (var s = this._hash, c = s.words, u = 0; u < 4; u++) {
                var f = c[u];
                c[u] =
                  (16711935 & ((f << 8) | (f >>> 24))) |
                  (4278255360 & ((f << 24) | (f >>> 8)));
              }
              return s;
            },
            clone: function () {
              var e = i.clone.call(this);
              return (e._hash = this._hash.clone()), e;
            },
          }));
          function u(e, t, n, r, o, i, a) {
            var s = e + ((t & n) | (~t & r)) + o + a;
            return ((s << i) | (s >>> (32 - i))) + t;
          }
          function f(e, t, n, r, o, i, a) {
            var s = e + ((t & r) | (n & ~r)) + o + a;
            return ((s << i) | (s >>> (32 - i))) + t;
          }
          function l(e, t, n, r, o, i, a) {
            var s = e + (t ^ n ^ r) + o + a;
            return ((s << i) | (s >>> (32 - i))) + t;
          }
          function p(e, t, n, r, o, i, a) {
            var s = e + (n ^ (t | ~r)) + o + a;
            return ((s << i) | (s >>> (32 - i))) + t;
          }
          (t.MD5 = i._createHelper(c)), (t.HmacMD5 = i._createHmacHelper(c));
        })(Math),
        n.MD5);
    }),
    vf(function (e, t) {
      var n, r, o;
      e.exports =
        ((r = (n = gf).lib.Base),
        (o = n.enc.Utf8),
        void (n.algo.HMAC = r.extend({
          init: function (e, t) {
            (e = this._hasher = new e.init()),
              "string" == typeof t && (t = o.parse(t));
            var n = e.blockSize,
              r = 4 * n;
            t.sigBytes > r && (t = e.finalize(t)), t.clamp();
            for (
              var i = (this._oKey = t.clone()),
                a = (this._iKey = t.clone()),
                s = i.words,
                c = a.words,
                u = 0;
              u < n;
              u++
            )
              (s[u] ^= 1549556828), (c[u] ^= 909522486);
            (i.sigBytes = a.sigBytes = r), this.reset();
          },
          reset: function () {
            var e = this._hasher;
            e.reset(), e.update(this._iKey);
          },
          update: function (e) {
            return this._hasher.update(e), this;
          },
          finalize: function (e) {
            var t = this._hasher,
              n = t.finalize(e);
            return t.reset(), t.finalize(this._oKey.clone().concat(n));
          },
        })));
    }),
    vf(function (e, t) {
      e.exports = gf.HmacMD5;
    })),
  yf = vf(function (e, t) {
    e.exports = gf.enc.Utf8;
  }),
  _f = vf(function (e, t) {
    var n, r, o;
    e.exports =
      ((o = (r = n = gf).lib.WordArray),
      (r.enc.Base64 = {
        stringify: function (e) {
          var t = e.words,
            n = e.sigBytes,
            r = this._map;
          e.clamp();
          for (var o = [], i = 0; i < n; i += 3)
            for (
              var a =
                  (((t[i >>> 2] >>> (24 - (i % 4) * 8)) & 255) << 16) |
                  (((t[(i + 1) >>> 2] >>> (24 - ((i + 1) % 4) * 8)) & 255) <<
                    8) |
                  ((t[(i + 2) >>> 2] >>> (24 - ((i + 2) % 4) * 8)) & 255),
                s = 0;
              s < 4 && i + 0.75 * s < n;
              s++
            )
              o.push(r.charAt((a >>> (6 * (3 - s))) & 63));
          var c = r.charAt(64);
          if (c) for (; o.length % 4; ) o.push(c);
          return o.join("");
        },
        parse: function (e) {
          var t = e.length,
            n = this._map,
            r = this._reverseMap;
          if (!r) {
            r = this._reverseMap = [];
            for (var i = 0; i < n.length; i++) r[n.charCodeAt(i)] = i;
          }
          var a = n.charAt(64);
          if (a) {
            var s = e.indexOf(a);
            -1 !== s && (t = s);
          }
          return (function (e, t, n) {
            for (var r = [], i = 0, a = 0; a < t; a++)
              if (a % 4) {
                var s = n[e.charCodeAt(a - 1)] << ((a % 4) * 2),
                  c = n[e.charCodeAt(a)] >>> (6 - (a % 4) * 2);
                (r[i >>> 2] |= (s | c) << (24 - (i % 4) * 8)), i++;
              }
            return o.create(r, i);
          })(e, t, r);
        },
        _map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
      }),
      n.enc.Base64);
  }),
  bf = "FUNCTION",
  wf = "OBJECT",
  kf = "pending",
  xf = "rejected";
function Sf(e) {
  return Object.prototype.toString.call(e).slice(8, -1).toLowerCase();
}
function Pf(e) {
  return "object" === Sf(e);
}
function Tf(e) {
  return "function" == typeof e;
}
function Of(e) {
  return function () {
    try {
      return e.apply(e, arguments);
    } catch (e) {
      console.error(e);
    }
  };
}
var Af = "REJECTED",
  If = "NOT_PENDING",
  Cf = (function () {
    return l(
      function e() {
        var t =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          n = t.createPromise,
          r = t.retryRule,
          o = void 0 === r ? Af : r;
        f(this, e),
          (this.createPromise = n),
          (this.status = null),
          (this.promise = null),
          (this.retryRule = o);
      },
      [
        {
          key: "needRetry",
          get: function () {
            if (!this.status) return !0;
            switch (this.retryRule) {
              case Af:
                return this.status === xf;
              case If:
                return this.status !== kf;
            }
          },
        },
        {
          key: "exec",
          value: function () {
            var e = this;
            return this.needRetry
              ? ((this.status = kf),
                (this.promise = this.createPromise().then(
                  function (t) {
                    return (e.status = "fulfilled"), Promise.resolve(t);
                  },
                  function (t) {
                    return (e.status = xf), Promise.reject(t);
                  }
                )),
                this.promise)
              : this.promise;
          },
        },
      ]
    );
  })();
function Ef(e) {
  return e && "string" == typeof e ? JSON.parse(e) : e;
}
var Lf = Ef([]),
  $f = "mp-weixin",
  Rf = Ef(""),
  jf = Ef("[]") || [];
try {
  ("__UNI__1281306");
} catch (gl) {}
var Mf = {};
function Df(e) {
  var t,
    n,
    r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
  return (
    (t = Mf),
    (n = e),
    Object.prototype.hasOwnProperty.call(t, n) || (Mf[e] = r),
    Mf[e]
  );
}
var Uf = ["invoke", "success", "fail", "complete"],
  Nf = Df("_globalUniCloudInterceptor");
function qf(e, t) {
  Nf[e] || (Nf[e] = {}),
    Pf(t) &&
      Object.keys(t).forEach(function (n) {
        var r, o, i, a;
        Uf.indexOf(n) > -1 &&
          ((r = e),
          (o = n),
          (i = t[n]),
          (a = Nf[r][o]) || (a = Nf[r][o] = []),
          -1 === a.indexOf(i) && Tf(i) && a.push(i));
      });
}
function Bf(e, t) {
  Nf[e] || (Nf[e] = {}),
    Pf(t)
      ? Object.keys(t).forEach(function (n) {
          Uf.indexOf(n) > -1 &&
            (function (e, t, n) {
              var r = Nf[e][t];
              if (r) {
                var o = r.indexOf(n);
                o > -1 && r.splice(o, 1);
              }
            })(e, n, t[n]);
        })
      : delete Nf[e];
}
function Ff(e, t) {
  return e && 0 !== e.length
    ? e.reduce(function (e, n) {
        return e.then(function () {
          return n(t);
        });
      }, Promise.resolve())
    : Promise.resolve();
}
function Hf(e, t) {
  return (Nf[e] && Nf[e][t]) || [];
}
function Vf(e) {
  qf("callObject", e);
}
var Kf = Df("_globalUniCloudListener"),
  Wf = "response",
  zf = "needLogin",
  Jf = "refreshToken",
  Yf = "clientdb",
  Qf = "cloudfunction",
  Gf = "cloudobject";
function Xf(e) {
  return Kf[e] || (Kf[e] = []), Kf[e];
}
function Zf(e, t) {
  var n = Xf(e);
  n.includes(t) || n.push(t);
}
function el(e, t) {
  var n = Xf(e),
    r = n.indexOf(t);
  -1 !== r && n.splice(r, 1);
}
function tl(e, t) {
  for (var n = Xf(e), r = 0; r < n.length; r++) (0, n[r])(t);
}
var nl,
  rl = !1;
function ol() {
  return (
    nl ||
    (nl = new Promise(function (e) {
      rl && e(),
        (function t() {
          if ("function" == typeof getCurrentPages) {
            var n = getCurrentPages();
            n && n[0] && ((rl = !0), e());
          }
          rl ||
            setTimeout(function () {
              t();
            }, 30);
        })();
    }))
  );
}
function il(e) {
  var t = {};
  for (var n in e) {
    var r = e[n];
    Tf(r) && (t[n] = Of(r));
  }
  return t;
}
var al,
  sl,
  cl = (function (e) {
    function t(e) {
      var n;
      return (
        f(this, t),
        ((n = m(this, t, [e.message])).errMsg =
          e.message || e.errMsg || "unknown system error"),
        (n.code = n.errCode = e.code || e.errCode || "SYSTEM_ERROR"),
        (n.errSubject = n.subject = e.subject || e.errSubject),
        (n.cause = e.cause),
        (n.requestId = e.requestId),
        n
      );
    }
    return (
      u(t, e),
      l(t, [
        {
          key: "toJson",
          value: function () {
            var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : 0;
            if (!(e >= 10))
              return (
                e++,
                {
                  errCode: this.errCode,
                  errMsg: this.errMsg,
                  errSubject: this.errSubject,
                  cause:
                    this.cause && this.cause.toJson
                      ? this.cause.toJson(e)
                      : this.cause,
                }
              );
          },
        },
      ])
    );
  })(a(Error)),
  ul = {
    request: function (e) {
      return Dn.request(e);
    },
    uploadFile: function (e) {
      return Dn.uploadFile(e);
    },
    setStorageSync: function (e, t) {
      return Dn.setStorageSync(e, t);
    },
    getStorageSync: function (e) {
      return Dn.getStorageSync(e);
    },
    removeStorageSync: function (e) {
      return Dn.removeStorageSync(e);
    },
    clearStorageSync: function () {
      return Dn.clearStorageSync();
    },
    connectSocket: function (e) {
      return Dn.connectSocket(e);
    },
  };
function fl() {
  return {
    token: ul.getStorageSync("uni_id_token") || ul.getStorageSync("uniIdToken"),
    tokenExpired: ul.getStorageSync("uni_id_token_expired"),
  };
}
function ll() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
    t = e.token,
    n = e.tokenExpired;
  t && ul.setStorageSync("uni_id_token", t),
    n && ul.setStorageSync("uni_id_token_expired", n);
}
function pl() {
  return al || (al = Dn.getSystemInfoSync()), al;
}
var hl = {};
function dl() {
  var e = (Dn.getLocale && Dn.getLocale()) || "en";
  if (sl) return i(i(i({}, hl), sl), {}, { locale: e, LOCALE: e });
  var t = pl(),
    n = t.deviceId,
    r = t.osName,
    o = t.uniPlatform,
    a = t.appId,
    s = [
      "appId",
      "appLanguage",
      "appName",
      "appVersion",
      "appVersionCode",
      "appWgtVersion",
      "browserName",
      "browserVersion",
      "deviceBrand",
      "deviceId",
      "deviceModel",
      "deviceType",
      "osName",
      "osVersion",
      "romName",
      "romVersion",
      "ua",
      "hostName",
      "hostVersion",
      "uniPlatform",
      "uniRuntimeVersion",
      "uniRuntimeVersionCode",
      "uniCompilerVersion",
      "uniCompilerVersionCode",
    ];
  for (var c in t)
    Object.hasOwnProperty.call(t, c) && -1 === s.indexOf(c) && delete t[c];
  return (
    (sl = i(
      i(
        { PLATFORM: o, OS: r, APPID: a, DEVICEID: n },
        (function () {
          var e, t;
          try {
            if (Dn.getLaunchOptionsSync) {
              if (
                Dn.getLaunchOptionsSync
                  .toString()
                  .indexOf("not yet implemented") > -1
              )
                return;
              var n = Dn.getLaunchOptionsSync(),
                r = n.scene;
              (e = n.channel), (t = r);
            }
          } catch (e) {}
          return { channel: e, scene: t };
        })()
      ),
      t
    )),
    i(i(i({}, hl), sl), {}, { locale: e, LOCALE: e })
  );
}
var vl,
  gl,
  ml = function (e, t) {
    var n = "";
    return (
      Object.keys(e)
        .sort()
        .forEach(function (t) {
          e[t] && (n = n + "&" + t + "=" + e[t]);
        }),
      (n = n.slice(1)),
      mf(n, t).toString()
    );
  },
  yl = function (e, t) {
    return new Promise(function (n, r) {
      t(
        Object.assign(e, {
          complete: function (e) {
            e || (e = {});
            var t =
              (e.data &&
                e.data.header &&
                e.data.header["x-serverless-request-id"]) ||
              (e.header && e.header["request-id"]);
            if (!e.statusCode || e.statusCode >= 400) {
              var o =
                  (e.data && e.data.error && e.data.error.code) || "SYS_ERR",
                i =
                  (e.data && e.data.error && e.data.error.message) ||
                  e.errMsg ||
                  "request:fail";
              return r(new cl({ code: o, message: i, requestId: t }));
            }
            var a = e.data;
            if (a.error)
              return r(
                new cl({
                  code: a.error.code,
                  message: a.error.message,
                  requestId: t,
                })
              );
            (a.result = a.data), (a.requestId = t), delete a.data, n(a);
          },
        })
      );
    });
  },
  _l = function (e) {
    return _f.stringify(yf.parse(e));
  },
  bl = (function () {
    return l(
      function e(t) {
        var n = this;
        f(this, e),
          ["spaceId", "clientSecret"].forEach(function (e) {
            if (!Object.prototype.hasOwnProperty.call(t, e))
              throw new Error("".concat(e, " required"));
          }),
          (this.config = Object.assign(
            {},
            {
              endpoint:
                0 === t.spaceId.indexOf("mp-")
                  ? "https://api.next.bspapp.com"
                  : "https://api.bspapp.com",
            },
            t
          )),
          (this.config.provider = "aliyun"),
          (this.config.requestUrl = this.config.endpoint + "/client"),
          (this.config.envType = this.config.envType || "public"),
          (this.config.accessTokenKey = "access_token_" + this.config.spaceId),
          (this.adapter = ul),
          (this._getAccessTokenPromiseHub = new Cf({
            createPromise: function () {
              return n
                .requestAuth(
                  n.setupRequest(
                    {
                      method: "serverless.auth.user.anonymousAuthorize",
                      params: "{}",
                    },
                    "auth"
                  )
                )
                .then(function (e) {
                  if (!e.result || !e.result.accessToken)
                    throw new cl({
                      code: "AUTH_FAILED",
                      message: "获取accessToken失败",
                    });
                  n.setAccessToken(e.result.accessToken);
                });
            },
            retryRule: If,
          }));
      },
      [
        {
          key: "hasAccessToken",
          get: function () {
            return !!this.accessToken;
          },
        },
        {
          key: "setAccessToken",
          value: function (e) {
            this.accessToken = e;
          },
        },
        {
          key: "requestWrapped",
          value: function (e) {
            return yl(e, this.adapter.request);
          },
        },
        {
          key: "requestAuth",
          value: function (e) {
            return this.requestWrapped(e);
          },
        },
        {
          key: "request",
          value: function (e, t) {
            var n = this;
            return Promise.resolve().then(function () {
              return n.hasAccessToken
                ? t
                  ? n.requestWrapped(e)
                  : n.requestWrapped(e).catch(function (t) {
                      return new Promise(function (e, n) {
                        !t ||
                        ("GATEWAY_INVALID_TOKEN" !== t.code &&
                          "InvalidParameter.InvalidToken" !== t.code)
                          ? n(t)
                          : e();
                      })
                        .then(function () {
                          return n.getAccessToken();
                        })
                        .then(function () {
                          var t = n.rebuildRequest(e);
                          return n.request(t, !0);
                        });
                    })
                : n.getAccessToken().then(function () {
                    var t = n.rebuildRequest(e);
                    return n.request(t, !0);
                  });
            });
          },
        },
        {
          key: "rebuildRequest",
          value: function (e) {
            var t = Object.assign({}, e);
            return (
              (t.data.token = this.accessToken),
              (t.header["x-basement-token"] = this.accessToken),
              (t.header["x-serverless-sign"] = ml(
                t.data,
                this.config.clientSecret
              )),
              t
            );
          },
        },
        {
          key: "setupRequest",
          value: function (e, t) {
            var n = Object.assign({}, e, {
                spaceId: this.config.spaceId,
                timestamp: Date.now(),
              }),
              r = { "Content-Type": "application/json" };
            return (
              "auth" !== t &&
                ((n.token = this.accessToken),
                (r["x-basement-token"] = this.accessToken)),
              (r["x-serverless-sign"] = ml(n, this.config.clientSecret)),
              {
                url: this.config.requestUrl,
                method: "POST",
                data: n,
                dataType: "json",
                header: r,
              }
            );
          },
        },
        {
          key: "getAccessToken",
          value: function () {
            return this._getAccessTokenPromiseHub.exec();
          },
        },
        {
          key: "authorize",
          value:
            ((n = o(
              r().mark(function e() {
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (e.next = 2), this.getAccessToken();
                        case 2:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function () {
              return n.apply(this, arguments);
            }),
        },
        {
          key: "callFunction",
          value: function (e) {
            var t = {
              method: "serverless.function.runtime.invoke",
              params: JSON.stringify({
                functionTarget: e.name,
                functionArgs: e.data || {},
              }),
            };
            return this.request(this.setupRequest(t));
          },
        },
        {
          key: "getOSSUploadOptionsFromPath",
          value: function (e) {
            var t = {
              method: "serverless.file.resource.generateProximalSign",
              params: JSON.stringify(e),
            };
            return this.request(this.setupRequest(t));
          },
        },
        {
          key: "uploadFileToOSS",
          value: function (e) {
            var t = this,
              n = e.url,
              r = e.formData,
              o = e.name,
              i = e.filePath,
              a = e.fileType,
              s = e.onUploadProgress;
            return new Promise(function (e, c) {
              var u = t.adapter.uploadFile({
                url: n,
                formData: r,
                name: o,
                filePath: i,
                fileType: a,
                header: { "X-OSS-server-side-encrpytion": "AES256" },
                success: function (t) {
                  t && t.statusCode < 400
                    ? e(t)
                    : c(
                        new cl({
                          code: "UPLOAD_FAILED",
                          message: "文件上传失败",
                        })
                      );
                },
                fail: function (e) {
                  c(
                    new cl({
                      code: e.code || "UPLOAD_FAILED",
                      message: e.message || e.errMsg || "文件上传失败",
                    })
                  );
                },
              });
              "function" == typeof s &&
                u &&
                "function" == typeof u.onProgressUpdate &&
                u.onProgressUpdate(function (e) {
                  s({
                    loaded: e.totalBytesSent,
                    total: e.totalBytesExpectedToSend,
                  });
                });
            });
          },
        },
        {
          key: "reportOSSUpload",
          value: function (e) {
            var t = {
              method: "serverless.file.resource.report",
              params: JSON.stringify(e),
            };
            return this.request(this.setupRequest(t));
          },
        },
        {
          key: "uploadFile",
          value:
            ((t = o(
              r().mark(function e(t) {
                var n,
                  o,
                  i,
                  a,
                  s,
                  c,
                  u,
                  f,
                  l,
                  p,
                  h,
                  d,
                  v,
                  g,
                  m,
                  y,
                  _,
                  b,
                  w,
                  k,
                  x,
                  S;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (
                            ((n = t.filePath),
                            (o = t.cloudPath),
                            (i = t.fileType),
                            (a = void 0 === i ? "image" : i),
                            (s = t.cloudPathAsRealPath),
                            (c = void 0 !== s && s),
                            (u = t.onUploadProgress),
                            (f = t.config),
                            "string" === Sf(o))
                          ) {
                            e.next = 3;
                            break;
                          }
                          throw new cl({
                            code: "INVALID_PARAM",
                            message: "cloudPath必须为字符串类型",
                          });
                        case 3:
                          if ((o = o.trim())) {
                            e.next = 5;
                            break;
                          }
                          throw new cl({
                            code: "INVALID_PARAM",
                            message: "cloudPath不可为空",
                          });
                        case 5:
                          if (!/:\/\//.test(o)) {
                            e.next = 7;
                            break;
                          }
                          throw new cl({
                            code: "INVALID_PARAM",
                            message: "cloudPath不合法",
                          });
                        case 7:
                          if (
                            ((l = (f && f.envType) || this.config.envType),
                            !(
                              c &&
                              ("/" !== o[0] && (o = "/" + o),
                              o.indexOf("\\") > -1)
                            ))
                          ) {
                            e.next = 10;
                            break;
                          }
                          throw new cl({
                            code: "INVALID_PARAM",
                            message:
                              "使用cloudPath作为路径时，cloudPath不可包含“\\”",
                          });
                        case 10:
                          return (
                            (e.next = 12),
                            this.getOSSUploadOptionsFromPath({
                              env: l,
                              filename: c ? o.split("/").pop() : o,
                              fileId: c ? o : void 0,
                            })
                          );
                        case 12:
                          return (
                            (p = e.sent.result),
                            (h = "https://" + p.cdnDomain + "/" + p.ossPath),
                            (d = p.securityToken),
                            (v = p.accessKeyId),
                            (g = p.signature),
                            (m = p.host),
                            (y = p.ossPath),
                            (_ = p.id),
                            (b = p.policy),
                            (w = p.ossCallbackUrl),
                            (k = {
                              "Cache-Control": "max-age=2592000",
                              "Content-Disposition": "attachment",
                              OSSAccessKeyId: v,
                              Signature: g,
                              host: m,
                              id: _,
                              key: y,
                              policy: b,
                              success_action_status: 200,
                            }),
                            d && (k["x-oss-security-token"] = d),
                            w &&
                              ((x = JSON.stringify({
                                callbackUrl: w,
                                callbackBody: JSON.stringify({
                                  fileId: _,
                                  spaceId: this.config.spaceId,
                                }),
                                callbackBodyType: "application/json",
                              })),
                              (k.callback = _l(x))),
                            (S = {
                              url: "https://" + p.host,
                              formData: k,
                              fileName: "file",
                              name: "file",
                              filePath: n,
                              fileType: a,
                            }),
                            (e.next = 27),
                            this.uploadFileToOSS(
                              Object.assign({}, S, { onUploadProgress: u })
                            )
                          );
                        case 27:
                          if (!w) {
                            e.next = 29;
                            break;
                          }
                          return e.abrupt("return", {
                            success: !0,
                            filePath: n,
                            fileID: h,
                          });
                        case 29:
                          return (e.next = 31), this.reportOSSUpload({ id: _ });
                        case 31:
                          if (!e.sent.success) {
                            e.next = 33;
                            break;
                          }
                          return e.abrupt("return", {
                            success: !0,
                            filePath: n,
                            fileID: h,
                          });
                        case 33:
                          throw new cl({
                            code: "UPLOAD_FAILED",
                            message: "文件上传失败",
                          });
                        case 34:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e) {
              return t.apply(this, arguments);
            }),
        },
        {
          key: "getTempFileURL",
          value: function () {
            var e =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : {},
              t = e.fileList;
            return new Promise(function (e, n) {
              (Array.isArray(t) && 0 !== t.length) ||
                n(
                  new cl({
                    code: "INVALID_PARAM",
                    message: "fileList的元素必须是非空的字符串",
                  })
                ),
                e({
                  fileList: t.map(function (e) {
                    return { fileID: e, tempFileURL: e };
                  }),
                });
            });
          },
        },
        {
          key: "getFileInfo",
          value:
            ((e = o(
              r().mark(function e() {
                var t,
                  n,
                  o,
                  i = arguments;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (
                            ((t = i.length > 0 && void 0 !== i[0] ? i[0] : {}),
                            (n = t.fileList),
                            Array.isArray(n) && 0 !== n.length)
                          ) {
                            e.next = 3;
                            break;
                          }
                          throw new cl({
                            code: "INVALID_PARAM",
                            message: "fileList的元素必须是非空的字符串",
                          });
                        case 3:
                          return (
                            (o = {
                              method: "serverless.file.resource.info",
                              params: JSON.stringify({
                                id: n
                                  .map(function (e) {
                                    return e.split("?")[0];
                                  })
                                  .join(","),
                              }),
                            }),
                            (e.next = 6),
                            this.request(this.setupRequest(o))
                          );
                        case 6:
                          return (
                            (e.t0 = e.sent.result),
                            e.abrupt("return", { fileList: e.t0 })
                          );
                        case 8:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function () {
              return e.apply(this, arguments);
            }),
        },
      ]
    );
    var e, t, n;
  })(),
  wl = {
    init: function (e) {
      var t = new bl(e),
        n = {
          signInAnonymously: function () {
            return t.authorize();
          },
          getLoginState: function () {
            return Promise.resolve(!1);
          },
        };
      return (
        (t.auth = function () {
          return n;
        }),
        (t.customAuth = t.auth),
        t
      );
    },
  },
  kl =
    "undefined" != typeof location && "http:" === location.protocol
      ? "http:"
      : "https:";
((gl = vl || (vl = {})).local = "local"),
  (gl.none = "none"),
  (gl.session = "session");
var xl,
  Sl = function () {},
  Pl = vf(function (e, t) {
    var n;
    e.exports =
      ((n = gf),
      (function (e) {
        var t = n,
          r = t.lib,
          o = r.WordArray,
          i = r.Hasher,
          a = t.algo,
          s = [],
          c = [];
        !(function () {
          function t(t) {
            for (var n = e.sqrt(t), r = 2; r <= n; r++) if (!(t % r)) return !1;
            return !0;
          }
          function n(e) {
            return (4294967296 * (e - (0 | e))) | 0;
          }
          for (var r = 2, o = 0; o < 64; )
            t(r) &&
              (o < 8 && (s[o] = n(e.pow(r, 0.5))),
              (c[o] = n(e.pow(r, 1 / 3))),
              o++),
              r++;
        })();
        var u = [],
          f = (a.SHA256 = i.extend({
            _doReset: function () {
              this._hash = new o.init(s.slice(0));
            },
            _doProcessBlock: function (e, t) {
              for (
                var n = this._hash.words,
                  r = n[0],
                  o = n[1],
                  i = n[2],
                  a = n[3],
                  s = n[4],
                  f = n[5],
                  l = n[6],
                  p = n[7],
                  h = 0;
                h < 64;
                h++
              ) {
                if (h < 16) u[h] = 0 | e[t + h];
                else {
                  var d = u[h - 15],
                    v =
                      ((d << 25) | (d >>> 7)) ^
                      ((d << 14) | (d >>> 18)) ^
                      (d >>> 3),
                    g = u[h - 2],
                    m =
                      ((g << 15) | (g >>> 17)) ^
                      ((g << 13) | (g >>> 19)) ^
                      (g >>> 10);
                  u[h] = v + u[h - 7] + m + u[h - 16];
                }
                var y = (r & o) ^ (r & i) ^ (o & i),
                  _ =
                    ((r << 30) | (r >>> 2)) ^
                    ((r << 19) | (r >>> 13)) ^
                    ((r << 10) | (r >>> 22)),
                  b =
                    p +
                    (((s << 26) | (s >>> 6)) ^
                      ((s << 21) | (s >>> 11)) ^
                      ((s << 7) | (s >>> 25))) +
                    ((s & f) ^ (~s & l)) +
                    c[h] +
                    u[h];
                (p = l),
                  (l = f),
                  (f = s),
                  (s = (a + b) | 0),
                  (a = i),
                  (i = o),
                  (o = r),
                  (r = (b + (_ + y)) | 0);
              }
              (n[0] = (n[0] + r) | 0),
                (n[1] = (n[1] + o) | 0),
                (n[2] = (n[2] + i) | 0),
                (n[3] = (n[3] + a) | 0),
                (n[4] = (n[4] + s) | 0),
                (n[5] = (n[5] + f) | 0),
                (n[6] = (n[6] + l) | 0),
                (n[7] = (n[7] + p) | 0);
            },
            _doFinalize: function () {
              var t = this._data,
                n = t.words,
                r = 8 * this._nDataBytes,
                o = 8 * t.sigBytes;
              return (
                (n[o >>> 5] |= 128 << (24 - (o % 32))),
                (n[14 + (((o + 64) >>> 9) << 4)] = e.floor(r / 4294967296)),
                (n[15 + (((o + 64) >>> 9) << 4)] = r),
                (t.sigBytes = 4 * n.length),
                this._process(),
                this._hash
              );
            },
            clone: function () {
              var e = i.clone.call(this);
              return (e._hash = this._hash.clone()), e;
            },
          }));
        (t.SHA256 = i._createHelper(f)),
          (t.HmacSHA256 = i._createHmacHelper(f));
      })(Math),
      n.SHA256);
  }),
  Tl = vf(function (e, t) {
    e.exports = gf.HmacSHA256;
  }),
  Ol = function () {
    var e;
    if (!Promise) {
      (e = function () {}).promise = {};
      var t = function () {
        throw new cl({
          message:
            'Your Node runtime does support ES6 Promises. Set "global.Promise" to your preferred implementation of promises.',
        });
      };
      return (
        Object.defineProperty(e.promise, "then", { get: t }),
        Object.defineProperty(e.promise, "catch", { get: t }),
        e
      );
    }
    var n = new Promise(function (t, n) {
      e = function (e, r) {
        return e ? n(e) : t(r);
      };
    });
    return (e.promise = n), e;
  };
function Al(e) {
  return void 0 === e;
}
function Il(e) {
  return "[object Null]" === Object.prototype.toString.call(e);
}
!(function (e) {
  (e.WEB = "web"), (e.WX_MP = "wx_mp");
})(xl || (xl = {}));
var Cl = { adapter: null, runtime: void 0 },
  El = ["anonymousUuidKey"],
  Ll = (function (e) {
    function t() {
      var e;
      return (
        f(this, t),
        (e = m(this, t)),
        Cl.adapter.root.tcbObject || (Cl.adapter.root.tcbObject = {}),
        e
      );
    }
    return (
      u(t, Sl),
      l(t, [
        {
          key: "setItem",
          value: function (e, t) {
            Cl.adapter.root.tcbObject[e] = t;
          },
        },
        {
          key: "getItem",
          value: function (e) {
            return Cl.adapter.root.tcbObject[e];
          },
        },
        {
          key: "removeItem",
          value: function (e) {
            delete Cl.adapter.root.tcbObject[e];
          },
        },
        {
          key: "clear",
          value: function () {
            delete Cl.adapter.root.tcbObject;
          },
        },
      ])
    );
  })();
function $l(e, t) {
  switch (e) {
    case "local":
      return t.localStorage || new Ll();
    case "none":
      return new Ll();
    default:
      return t.sessionStorage || new Ll();
  }
}
var Rl = (function () {
    return l(
      function e(t) {
        if ((f(this, e), !this._storage)) {
          (this._persistence = Cl.adapter.primaryStorage || t.persistence),
            (this._storage = $l(this._persistence, Cl.adapter));
          var n = "access_token_".concat(t.env),
            r = "access_token_expire_".concat(t.env),
            o = "refresh_token_".concat(t.env),
            i = "anonymous_uuid_".concat(t.env),
            a = "login_type_".concat(t.env),
            s = "user_info_".concat(t.env);
          this.keys = {
            accessTokenKey: n,
            accessTokenExpireKey: r,
            refreshTokenKey: o,
            anonymousUuidKey: i,
            loginTypeKey: a,
            userInfoKey: s,
          };
        }
      },
      [
        {
          key: "updatePersistence",
          value: function (e) {
            if (e !== this._persistence) {
              var t = "local" === this._persistence;
              this._persistence = e;
              var n = $l(e, Cl.adapter);
              for (var r in this.keys) {
                var o = this.keys[r];
                if (!t || !El.includes(r)) {
                  var i = this._storage.getItem(o);
                  Al(i) ||
                    Il(i) ||
                    (n.setItem(o, i), this._storage.removeItem(o));
                }
              }
              this._storage = n;
            }
          },
        },
        {
          key: "setStore",
          value: function (e, t, n) {
            if (this._storage) {
              var r = { version: n || "localCachev1", content: t },
                o = JSON.stringify(r);
              try {
                this._storage.setItem(e, o);
              } catch (e) {
                throw e;
              }
            }
          },
        },
        {
          key: "getStore",
          value: function (e, t) {
            try {
              if (!this._storage) return;
            } catch (e) {
              return "";
            }
            t = t || "localCachev1";
            var n = this._storage.getItem(e);
            return n && n.indexOf(t) >= 0 ? JSON.parse(n).content : "";
          },
        },
        {
          key: "removeStore",
          value: function (e) {
            this._storage.removeItem(e);
          },
        },
      ]
    );
  })(),
  jl = {},
  Ml = {};
function Dl(e) {
  return jl[e];
}
var Ul = l(function e(t, n) {
    f(this, e), (this.data = n || null), (this.name = t);
  }),
  Nl = (function (e) {
    function t(e, n) {
      var r;
      return (
        f(this, t),
        ((r = m(this, t, ["error", { error: e, data: n }])).error = e),
        r
      );
    }
    return u(t, Ul), l(t);
  })(),
  ql = new ((function () {
    return l(
      function e() {
        f(this, e), (this._listeners = {});
      },
      [
        {
          key: "on",
          value: function (e, t) {
            return (
              (n = e),
              (r = t),
              ((o = this._listeners)[n] = o[n] || []),
              o[n].push(r),
              this
            );
            var n, r, o;
          },
        },
        {
          key: "off",
          value: function (e, t) {
            return (
              (function (e, t, n) {
                if (n && n[e]) {
                  var r = n[e].indexOf(t);
                  -1 !== r && n[e].splice(r, 1);
                }
              })(e, t, this._listeners),
              this
            );
          },
        },
        {
          key: "fire",
          value: function (e, t) {
            if (e instanceof Nl) return console.error(e.error), this;
            var n = "string" == typeof e ? new Ul(e, t || {}) : e,
              r = n.name;
            if (this._listens(r)) {
              n.target = this;
              var o,
                i = this._listeners[r] ? h(this._listeners[r]) : [],
                a = g(i);
              try {
                for (a.s(); !(o = a.n()).done; ) {
                  o.value.call(this, n);
                }
              } catch (e) {
                a.e(e);
              } finally {
                a.f();
              }
            }
            return this;
          },
        },
        {
          key: "_listens",
          value: function (e) {
            return this._listeners[e] && this._listeners[e].length > 0;
          },
        },
      ]
    );
  })())();
function Bl(e, t) {
  ql.on(e, t);
}
function Fl(e) {
  var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
  ql.fire(e, t);
}
function Hl(e, t) {
  ql.off(e, t);
}
var Vl,
  Kl = "loginStateChanged",
  Wl = "loginStateExpire",
  zl = "loginTypeChanged",
  Jl = "anonymousConverted",
  Yl = "refreshAccessToken";
!(function (e) {
  (e.ANONYMOUS = "ANONYMOUS"),
    (e.WECHAT = "WECHAT"),
    (e.WECHAT_PUBLIC = "WECHAT-PUBLIC"),
    (e.WECHAT_OPEN = "WECHAT-OPEN"),
    (e.CUSTOM = "CUSTOM"),
    (e.EMAIL = "EMAIL"),
    (e.USERNAME = "USERNAME"),
    (e.NULL = "NULL");
})(Vl || (Vl = {}));
var Ql = [
    "auth.getJwt",
    "auth.logout",
    "auth.signInWithTicket",
    "auth.signInAnonymously",
    "auth.signIn",
    "auth.fetchAccessTokenWithRefreshToken",
    "auth.signUpWithEmailAndPassword",
    "auth.activateEndUserMail",
    "auth.sendPasswordResetEmail",
    "auth.resetPasswordWithToken",
    "auth.isUsernameRegistered",
  ],
  Gl = { "X-SDK-Version": "1.3.5" };
function Xl(e, t, n) {
  var r = e[t];
  e[t] = function (t) {
    var o = {},
      a = {};
    n.forEach(function (n) {
      var r = n.call(e, t),
        i = r.data,
        s = r.headers;
      Object.assign(o, i), Object.assign(a, s);
    });
    var s = t.data;
    return (
      s &&
        (function () {
          var e;
          if (
            ((e = s), "[object FormData]" !== Object.prototype.toString.call(e))
          )
            t.data = i(i({}, s), o);
          else for (var n in o) s.append(n, o[n]);
        })(),
      (t.headers = i(i({}, t.headers || {}), a)),
      r.call(e, t)
    );
  };
}
function Zl() {
  var e = Math.random().toString(16).slice(2);
  return { data: { seqId: e }, headers: i(i({}, Gl), {}, { "x-seqid": e }) };
}
var ep = (function () {
    return l(
      function e() {
        var t,
          n =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        f(this, e),
          (this.config = n),
          (this._reqClass = new Cl.adapter.reqClass({
            timeout: this.config.timeout,
            timeoutMsg: "请求在".concat(
              this.config.timeout / 1e3,
              "s内未完成，已中断"
            ),
            restrictedMethods: ["post"],
          })),
          (this._cache = Dl(this.config.env)),
          (this._localCache = ((t = this.config.env), Ml[t])),
          Xl(this._reqClass, "post", [Zl]),
          Xl(this._reqClass, "upload", [Zl]),
          Xl(this._reqClass, "download", [Zl]);
      },
      [
        {
          key: "post",
          value:
            ((p = o(
              r().mark(function e(t) {
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (e.next = 2), this._reqClass.post(t);
                        case 2:
                          return e.abrupt("return", e.sent);
                        case 3:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e) {
              return p.apply(this, arguments);
            }),
        },
        {
          key: "upload",
          value:
            ((u = o(
              r().mark(function e(t) {
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (e.next = 2), this._reqClass.upload(t);
                        case 2:
                          return e.abrupt("return", e.sent);
                        case 3:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e) {
              return u.apply(this, arguments);
            }),
        },
        {
          key: "download",
          value:
            ((c = o(
              r().mark(function e(t) {
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (e.next = 2), this._reqClass.download(t);
                        case 2:
                          return e.abrupt("return", e.sent);
                        case 3:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e) {
              return c.apply(this, arguments);
            }),
        },
        {
          key: "refreshAccessToken",
          value:
            ((s = o(
              r().mark(function e() {
                var t, n;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            this._refreshAccessTokenPromise ||
                              (this._refreshAccessTokenPromise =
                                this._refreshAccessToken()),
                            (e.prev = 1),
                            (e.next = 4),
                            this._refreshAccessTokenPromise
                          );
                        case 4:
                          (t = e.sent), (e.next = 10);
                          break;
                        case 7:
                          (e.prev = 7), (e.t0 = e.catch(1)), (n = e.t0);
                        case 10:
                          if (
                            ((this._refreshAccessTokenPromise = null),
                            (this._shouldRefreshAccessTokenHook = null),
                            !n)
                          ) {
                            e.next = 12;
                            break;
                          }
                          throw n;
                        case 12:
                          return e.abrupt("return", t);
                        case 13:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this,
                  [[1, 7]]
                );
              })
            )),
            function () {
              return s.apply(this, arguments);
            }),
        },
        {
          key: "_refreshAccessToken",
          value:
            ((a = o(
              r().mark(function e() {
                var t, n, o, i, a, s, c, u, f, l, p, h, d;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (
                            ((t = this._cache.keys),
                            (n = t.accessTokenKey),
                            (o = t.accessTokenExpireKey),
                            (i = t.refreshTokenKey),
                            (a = t.loginTypeKey),
                            (s = t.anonymousUuidKey),
                            this._cache.removeStore(n),
                            this._cache.removeStore(o),
                            (c = this._cache.getStore(i)))
                          ) {
                            e.next = 5;
                            break;
                          }
                          throw new cl({ message: "未登录CloudBase" });
                        case 5:
                          return (
                            (u = { refresh_token: c }),
                            (e.next = 8),
                            this.request(
                              "auth.fetchAccessTokenWithRefreshToken",
                              u
                            )
                          );
                        case 8:
                          if (!(f = e.sent).data.code) {
                            e.next = 21;
                            break;
                          }
                          if (
                            "SIGN_PARAM_INVALID" !== (l = f.data.code) &&
                            "REFRESH_TOKEN_EXPIRED" !== l &&
                            "INVALID_REFRESH_TOKEN" !== l
                          ) {
                            e.next = 20;
                            break;
                          }
                          if (
                            this._cache.getStore(a) !== Vl.ANONYMOUS ||
                            "INVALID_REFRESH_TOKEN" !== l
                          ) {
                            e.next = 19;
                            break;
                          }
                          return (
                            (p = this._cache.getStore(s)),
                            (h = this._cache.getStore(i)),
                            (e.next = 17),
                            this.send("auth.signInAnonymously", {
                              anonymous_uuid: p,
                              refresh_token: h,
                            })
                          );
                        case 17:
                          return (
                            (d = e.sent),
                            e.abrupt(
                              "return",
                              (this.setRefreshToken(d.refresh_token),
                              this._refreshAccessToken())
                            )
                          );
                        case 19:
                          Fl(Wl), this._cache.removeStore(i);
                        case 20:
                          throw new cl({
                            code: f.data.code,
                            message: "刷新access token失败：".concat(
                              f.data.code
                            ),
                          });
                        case 21:
                          if (!f.data.access_token) {
                            e.next = 23;
                            break;
                          }
                          return e.abrupt(
                            "return",
                            (Fl(Yl),
                            this._cache.setStore(n, f.data.access_token),
                            this._cache.setStore(
                              o,
                              f.data.access_token_expire + Date.now()
                            ),
                            {
                              accessToken: f.data.access_token,
                              accessTokenExpire: f.data.access_token_expire,
                            })
                          );
                        case 23:
                          f.data.refresh_token &&
                            (this._cache.removeStore(i),
                            this._cache.setStore(i, f.data.refresh_token),
                            this._refreshAccessToken());
                        case 24:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function () {
              return a.apply(this, arguments);
            }),
        },
        {
          key: "getAccessToken",
          value:
            ((n = o(
              r().mark(function e() {
                var t, n, o, i, a, s, c;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (
                            ((t = this._cache.keys),
                            (n = t.accessTokenKey),
                            (o = t.accessTokenExpireKey),
                            (i = t.refreshTokenKey),
                            this._cache.getStore(i))
                          ) {
                            e.next = 3;
                            break;
                          }
                          throw new cl({
                            message: "refresh token不存在，登录状态异常",
                          });
                        case 3:
                          if (
                            ((a = this._cache.getStore(n)),
                            (s = this._cache.getStore(o)),
                            (c = !0),
                            (e.t0 = this._shouldRefreshAccessTokenHook),
                            !e.t0)
                          ) {
                            e.next = 9;
                            break;
                          }
                          return (
                            (e.next = 8),
                            this._shouldRefreshAccessTokenHook(a, s)
                          );
                        case 8:
                          e.t0 = !e.sent;
                        case 9:
                          if (((e.t1 = e.t0), !e.t1)) {
                            e.next = 12;
                            break;
                          }
                          c = !1;
                        case 12:
                          return e.abrupt(
                            "return",
                            (!a || !s || s < Date.now()) && c
                              ? this.refreshAccessToken()
                              : { accessToken: a, accessTokenExpire: s }
                          );
                        case 13:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function () {
              return n.apply(this, arguments);
            }),
        },
        {
          key: "request",
          value:
            ((t = o(
              r().mark(function e(t, n, o) {
                var a, s, c, u, f, l, p, h, d, v, g, m, y, _, b, w;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (
                            ((a = "x-tcb-trace_".concat(this.config.env)),
                            (s = "application/x-www-form-urlencoded"),
                            (c = i(
                              {
                                action: t,
                                env: this.config.env,
                                dataVersion: "2019-08-16",
                              },
                              n
                            )),
                            -1 !== Ql.indexOf(t))
                          ) {
                            e.next = 10;
                            break;
                          }
                          if (
                            ((u = this._cache.keys.refreshTokenKey),
                            (e.t0 = this._cache.getStore(u)),
                            !e.t0)
                          ) {
                            e.next = 10;
                            break;
                          }
                          return (e.next = 9), this.getAccessToken();
                        case 9:
                          c.access_token = e.sent.accessToken;
                        case 10:
                          if ("storage.uploadFile" === t) {
                            for (l in (f = new FormData()))
                              f.hasOwnProperty(l) &&
                                void 0 !== f[l] &&
                                f.append(l, c[l]);
                            s = "multipart/form-data";
                          } else
                            for (p in ((s = "application/json"), (f = {}), c))
                              void 0 !== c[p] && (f[p] = c[p]);
                          return (
                            (h = { headers: { "content-type": s } }),
                            o &&
                              o.onUploadProgress &&
                              (h.onUploadProgress = o.onUploadProgress),
                            (d = this._localCache.getStore(a)) &&
                              (h.headers["X-TCB-Trace"] = d),
                            (v = n.parse),
                            (g = n.inQuery),
                            (m = n.search),
                            (y = { env: this.config.env }),
                            v && (y.parse = !0),
                            g && (y = i(i({}, g), y)),
                            (_ = (function (e, t) {
                              var n =
                                  arguments.length > 2 &&
                                  void 0 !== arguments[2]
                                    ? arguments[2]
                                    : {},
                                r = /\?/.test(t),
                                o = "";
                              for (var i in n)
                                "" === o ? !r && (t += "?") : (o += "&"),
                                  (o += ""
                                    .concat(i, "=")
                                    .concat(encodeURIComponent(n[i])));
                              return /^http(s)?\:\/\//.test((t += o))
                                ? t
                                : "".concat(e).concat(t);
                            })(kl, "//tcb-api.tencentcloudapi.com/web", y)),
                            m && (_ += m),
                            (e.next = 22),
                            this.post(i({ url: _, data: f }, h))
                          );
                        case 22:
                          if (
                            ((b = e.sent),
                            (w = b.header && b.header["x-tcb-trace"]) &&
                              this._localCache.setStore(a, w),
                            (200 === Number(b.status) ||
                              200 === Number(b.statusCode)) &&
                              b.data)
                          ) {
                            e.next = 26;
                            break;
                          }
                          throw new cl({
                            code: "NETWORK_ERROR",
                            message: "network request error",
                          });
                        case 26:
                          return e.abrupt("return", b);
                        case 27:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e, n, r) {
              return t.apply(this, arguments);
            }),
        },
        {
          key: "send",
          value:
            ((e = o(
              r().mark(function e(t) {
                var n,
                  o,
                  i,
                  a = arguments;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (n = a.length > 1 && void 0 !== a[1] ? a[1] : {}),
                            (e.next = 3),
                            this.request(t, n, {
                              onUploadProgress: n.onUploadProgress,
                            })
                          );
                        case 3:
                          if (
                            "ACCESS_TOKEN_EXPIRED" !== (o = e.sent).data.code ||
                            -1 !== Ql.indexOf(t)
                          ) {
                            e.next = 13;
                            break;
                          }
                          return (e.next = 7), this.refreshAccessToken();
                        case 7:
                          return (
                            (e.next = 9),
                            this.request(t, n, {
                              onUploadProgress: n.onUploadProgress,
                            })
                          );
                        case 9:
                          if (!(i = e.sent).data.code) {
                            e.next = 12;
                            break;
                          }
                          throw new cl({
                            code: i.data.code,
                            message: i.data.message,
                          });
                        case 12:
                          return e.abrupt("return", i.data);
                        case 13:
                          if (!o.data.code) {
                            e.next = 15;
                            break;
                          }
                          throw new cl({
                            code: o.data.code,
                            message: o.data.message,
                          });
                        case 15:
                          return e.abrupt("return", o.data);
                        case 16:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (t) {
              return e.apply(this, arguments);
            }),
        },
        {
          key: "setRefreshToken",
          value: function (e) {
            var t = this._cache.keys,
              n = t.accessTokenKey,
              r = t.accessTokenExpireKey,
              o = t.refreshTokenKey;
            this._cache.removeStore(n),
              this._cache.removeStore(r),
              this._cache.setStore(o, e);
          },
        },
      ]
    );
    var e, t, n, a, s, c, u, p;
  })(),
  tp = {};
function np(e) {
  return tp[e];
}
var rp = (function () {
    return l(
      function e(t) {
        f(this, e),
          (this.config = t),
          (this._cache = Dl(t.env)),
          (this._request = np(t.env));
      },
      [
        {
          key: "setRefreshToken",
          value: function (e) {
            var t = this._cache.keys,
              n = t.accessTokenKey,
              r = t.accessTokenExpireKey,
              o = t.refreshTokenKey;
            this._cache.removeStore(n),
              this._cache.removeStore(r),
              this._cache.setStore(o, e);
          },
        },
        {
          key: "setAccessToken",
          value: function (e, t) {
            var n = this._cache.keys,
              r = n.accessTokenKey,
              o = n.accessTokenExpireKey;
            this._cache.setStore(r, e), this._cache.setStore(o, t);
          },
        },
        {
          key: "refreshUserInfo",
          value:
            ((e = o(
              r().mark(function e() {
                var t, n;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (e.next = 2),
                            this._request.send("auth.getUserInfo", {})
                          );
                        case 2:
                          return (
                            (t = e.sent),
                            (n = t.data),
                            e.abrupt("return", (this.setLocalUserInfo(n), n))
                          );
                        case 5:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function () {
              return e.apply(this, arguments);
            }),
        },
        {
          key: "setLocalUserInfo",
          value: function (e) {
            var t = this._cache.keys.userInfoKey;
            this._cache.setStore(t, e);
          },
        },
      ]
    );
    var e;
  })(),
  op = (function () {
    return l(
      function e(t) {
        if ((f(this, e), !t))
          throw new cl({
            code: "PARAM_ERROR",
            message: "envId is not defined",
          });
        (this._envId = t),
          (this._cache = Dl(this._envId)),
          (this._request = np(this._envId)),
          this.setUserInfo();
      },
      [
        {
          key: "linkWithTicket",
          value: function (e) {
            if ("string" != typeof e)
              throw new cl({
                code: "PARAM_ERROR",
                message: "ticket must be string",
              });
            return this._request.send("auth.linkWithTicket", { ticket: e });
          },
        },
        {
          key: "linkWithRedirect",
          value: function (e) {
            e.signInWithRedirect();
          },
        },
        {
          key: "updatePassword",
          value: function (e, t) {
            return this._request.send("auth.updatePassword", {
              oldPassword: t,
              newPassword: e,
            });
          },
        },
        {
          key: "updateEmail",
          value: function (e) {
            return this._request.send("auth.updateEmail", { newEmail: e });
          },
        },
        {
          key: "updateUsername",
          value: function (e) {
            if ("string" != typeof e)
              throw new cl({
                code: "PARAM_ERROR",
                message: "username must be a string",
              });
            return this._request.send("auth.updateUsername", { username: e });
          },
        },
        {
          key: "getLinkedUidList",
          value:
            ((n = o(
              r().mark(function e() {
                var t, n, o, i;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (e.next = 2),
                            this._request.send("auth.getLinkedUidList", {})
                          );
                        case 2:
                          return (
                            (t = e.sent),
                            (n = t.data),
                            (o = !1),
                            (i = n.users),
                            e.abrupt(
                              "return",
                              (i.forEach(function (e) {
                                e.wxOpenId && e.wxPublicId && (o = !0);
                              }),
                              { users: i, hasPrimaryUid: o })
                            )
                          );
                        case 7:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function () {
              return n.apply(this, arguments);
            }),
        },
        {
          key: "setPrimaryUid",
          value: function (e) {
            return this._request.send("auth.setPrimaryUid", { uid: e });
          },
        },
        {
          key: "unlink",
          value: function (e) {
            return this._request.send("auth.unlink", { platform: e });
          },
        },
        {
          key: "update",
          value:
            ((t = o(
              r().mark(function e(t) {
                var n, o, i, a, s, c, u, f;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (n = t.nickName),
                            (o = t.gender),
                            (i = t.avatarUrl),
                            (a = t.province),
                            (s = t.country),
                            (c = t.city),
                            (e.next = 8),
                            this._request.send("auth.updateUserInfo", {
                              nickName: n,
                              gender: o,
                              avatarUrl: i,
                              province: a,
                              country: s,
                              city: c,
                            })
                          );
                        case 8:
                          (u = e.sent), (f = u.data), this.setLocalUserInfo(f);
                        case 11:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e) {
              return t.apply(this, arguments);
            }),
        },
        {
          key: "refresh",
          value:
            ((e = o(
              r().mark(function e() {
                var t, n;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (e.next = 2),
                            this._request.send("auth.getUserInfo", {})
                          );
                        case 2:
                          return (
                            (t = e.sent),
                            (n = t.data),
                            e.abrupt("return", (this.setLocalUserInfo(n), n))
                          );
                        case 5:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function () {
              return e.apply(this, arguments);
            }),
        },
        {
          key: "setUserInfo",
          value: function () {
            var e = this,
              t = this._cache.keys.userInfoKey,
              n = this._cache.getStore(t);
            [
              "uid",
              "loginType",
              "openid",
              "wxOpenId",
              "wxPublicId",
              "unionId",
              "qqMiniOpenId",
              "email",
              "hasPassword",
              "customUserId",
              "nickName",
              "gender",
              "avatarUrl",
            ].forEach(function (t) {
              e[t] = n[t];
            }),
              (this.location = {
                country: n.country,
                province: n.province,
                city: n.city,
              });
          },
        },
        {
          key: "setLocalUserInfo",
          value: function (e) {
            var t = this._cache.keys.userInfoKey;
            this._cache.setStore(t, e), this.setUserInfo();
          },
        },
      ]
    );
    var e, t, n;
  })(),
  ip = (function () {
    return l(
      function e(t) {
        if ((f(this, e), !t))
          throw new cl({
            code: "PARAM_ERROR",
            message: "envId is not defined",
          });
        this._cache = Dl(t);
        var n = this._cache.keys,
          r = n.refreshTokenKey,
          o = n.accessTokenKey,
          i = n.accessTokenExpireKey,
          a = this._cache.getStore(r),
          s = this._cache.getStore(o),
          c = this._cache.getStore(i);
        (this.credential = {
          refreshToken: a,
          accessToken: s,
          accessTokenExpire: c,
        }),
          (this.user = new op(t));
      },
      [
        {
          key: "isAnonymousAuth",
          get: function () {
            return this.loginType === Vl.ANONYMOUS;
          },
        },
        {
          key: "isCustomAuth",
          get: function () {
            return this.loginType === Vl.CUSTOM;
          },
        },
        {
          key: "isWeixinAuth",
          get: function () {
            return (
              this.loginType === Vl.WECHAT ||
              this.loginType === Vl.WECHAT_OPEN ||
              this.loginType === Vl.WECHAT_PUBLIC
            );
          },
        },
        {
          key: "loginType",
          get: function () {
            return this._cache.getStore(this._cache.keys.loginTypeKey);
          },
        },
      ]
    );
  })(),
  ap = (function (e) {
    function t() {
      return f(this, t), m(this, t, arguments);
    }
    return (
      u(t, rp),
      l(t, [
        {
          key: "signIn",
          value:
            ((i = o(
              r().mark(function e() {
                var t, n, o, i, a, s, c;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            this._cache.updatePersistence("local"),
                            (t = this._cache.keys),
                            (n = t.anonymousUuidKey),
                            (o = t.refreshTokenKey),
                            (i = this._cache.getStore(n) || void 0),
                            (a = this._cache.getStore(o) || void 0),
                            (e.next = 8),
                            this._request.send("auth.signInAnonymously", {
                              anonymous_uuid: i,
                              refresh_token: a,
                            })
                          );
                        case 8:
                          if (!(s = e.sent).uuid || !s.refresh_token) {
                            e.next = 20;
                            break;
                          }
                          return (
                            this._setAnonymousUUID(s.uuid),
                            this.setRefreshToken(s.refresh_token),
                            (e.next = 14),
                            this._request.refreshAccessToken()
                          );
                        case 14:
                          return (
                            Fl(Kl),
                            Fl(zl, {
                              env: this.config.env,
                              loginType: Vl.ANONYMOUS,
                              persistence: "local",
                            }),
                            (c = new ip(this.config.env)),
                            (e.next = 19),
                            c.user.refresh()
                          );
                        case 19:
                          return e.abrupt("return", c);
                        case 20:
                          throw new cl({ message: "匿名登录失败" });
                        case 21:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function () {
              return i.apply(this, arguments);
            }),
        },
        {
          key: "linkAndRetrieveDataWithTicket",
          value:
            ((n = o(
              r().mark(function e(t) {
                var n, o, i, a, s, c;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (n = this._cache.keys),
                            (o = n.anonymousUuidKey),
                            (i = n.refreshTokenKey),
                            (a = this._cache.getStore(o)),
                            (s = this._cache.getStore(i)),
                            (e.next = 7),
                            this._request.send(
                              "auth.linkAndRetrieveDataWithTicket",
                              { anonymous_uuid: a, refresh_token: s, ticket: t }
                            )
                          );
                        case 7:
                          if (!(c = e.sent).refresh_token) {
                            e.next = 16;
                            break;
                          }
                          return (
                            this._clearAnonymousUUID(),
                            this.setRefreshToken(c.refresh_token),
                            (e.next = 13),
                            this._request.refreshAccessToken()
                          );
                        case 13:
                          return (
                            Fl(Jl, { env: this.config.env }),
                            Fl(zl, {
                              loginType: Vl.CUSTOM,
                              persistence: "local",
                            }),
                            e.abrupt("return", {
                              credential: { refreshToken: c.refresh_token },
                            })
                          );
                        case 16:
                          throw new cl({ message: "匿名转化失败" });
                        case 17:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e) {
              return n.apply(this, arguments);
            }),
        },
        {
          key: "_setAnonymousUUID",
          value: function (e) {
            var t = this._cache.keys,
              n = t.anonymousUuidKey,
              r = t.loginTypeKey;
            this._cache.removeStore(n),
              this._cache.setStore(n, e),
              this._cache.setStore(r, Vl.ANONYMOUS);
          },
        },
        {
          key: "_clearAnonymousUUID",
          value: function () {
            this._cache.removeStore(this._cache.keys.anonymousUuidKey);
          },
        },
      ])
    );
    var n, i;
  })(),
  sp = (function (e) {
    function t() {
      return f(this, t), m(this, t, arguments);
    }
    return (
      u(t, rp),
      l(t, [
        {
          key: "signIn",
          value:
            ((n = o(
              r().mark(function e(t) {
                var n, o;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if ("string" == typeof t) {
                            e.next = 2;
                            break;
                          }
                          throw new cl({
                            code: "PARAM_ERROR",
                            message: "ticket must be a string",
                          });
                        case 2:
                          return (
                            (n = this._cache.keys.refreshTokenKey),
                            (e.next = 5),
                            this._request.send("auth.signInWithTicket", {
                              ticket: t,
                              refresh_token: this._cache.getStore(n) || "",
                            })
                          );
                        case 5:
                          if (!(o = e.sent).refresh_token) {
                            e.next = 15;
                            break;
                          }
                          return (
                            this.setRefreshToken(o.refresh_token),
                            (e.next = 10),
                            this._request.refreshAccessToken()
                          );
                        case 10:
                          return (
                            Fl(Kl),
                            Fl(zl, {
                              env: this.config.env,
                              loginType: Vl.CUSTOM,
                              persistence: this.config.persistence,
                            }),
                            (e.next = 14),
                            this.refreshUserInfo()
                          );
                        case 14:
                          return e.abrupt("return", new ip(this.config.env));
                        case 15:
                          throw new cl({ message: "自定义登录失败" });
                        case 16:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e) {
              return n.apply(this, arguments);
            }),
        },
      ])
    );
    var n;
  })(),
  cp = (function (e) {
    function t() {
      return f(this, t), m(this, t, arguments);
    }
    return (
      u(t, rp),
      l(t, [
        {
          key: "signIn",
          value:
            ((a = o(
              r().mark(function e(t, n) {
                var o, i, a, s, c;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if ("string" == typeof t) {
                            e.next = 2;
                            break;
                          }
                          throw new cl({
                            code: "PARAM_ERROR",
                            message: "email must be a string",
                          });
                        case 2:
                          return (
                            (o = this._cache.keys.refreshTokenKey),
                            (e.next = 5),
                            this._request.send("auth.signIn", {
                              loginType: "EMAIL",
                              email: t,
                              password: n,
                              refresh_token: this._cache.getStore(o) || "",
                            })
                          );
                        case 5:
                          if (
                            ((i = e.sent),
                            (a = i.refresh_token),
                            (s = i.access_token),
                            (c = i.access_token_expire),
                            !a)
                          ) {
                            e.next = 22;
                            break;
                          }
                          if ((this.setRefreshToken(a), !s || !c)) {
                            e.next = 15;
                            break;
                          }
                          this.setAccessToken(s, c), (e.next = 17);
                          break;
                        case 15:
                          return (
                            (e.next = 17), this._request.refreshAccessToken()
                          );
                        case 17:
                          return (e.next = 19), this.refreshUserInfo();
                        case 19:
                          return (
                            Fl(Kl),
                            Fl(zl, {
                              env: this.config.env,
                              loginType: Vl.EMAIL,
                              persistence: this.config.persistence,
                            }),
                            e.abrupt("return", new ip(this.config.env))
                          );
                        case 22:
                          throw i.code
                            ? new cl({
                                code: i.code,
                                message: "邮箱登录失败: ".concat(i.message),
                              })
                            : new cl({ message: "邮箱登录失败" });
                        case 23:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e, t) {
              return a.apply(this, arguments);
            }),
        },
        {
          key: "activate",
          value:
            ((i = o(
              r().mark(function e(t) {
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return e.abrupt(
                            "return",
                            this._request.send("auth.activateEndUserMail", {
                              token: t,
                            })
                          );
                        case 1:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e) {
              return i.apply(this, arguments);
            }),
        },
        {
          key: "resetPasswordWithToken",
          value:
            ((n = o(
              r().mark(function e(t, n) {
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return e.abrupt(
                            "return",
                            this._request.send("auth.resetPasswordWithToken", {
                              token: t,
                              newPassword: n,
                            })
                          );
                        case 1:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e, t) {
              return n.apply(this, arguments);
            }),
        },
      ])
    );
    var n, i, a;
  })(),
  up = (function (e) {
    function t() {
      return f(this, t), m(this, t, arguments);
    }
    return (
      u(t, rp),
      l(t, [
        {
          key: "signIn",
          value:
            ((n = o(
              r().mark(function e(t, n) {
                var o, i, a, s, c;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if ("string" == typeof t) {
                            e.next = 2;
                            break;
                          }
                          throw new cl({
                            code: "PARAM_ERROR",
                            message: "username must be a string",
                          });
                        case 2:
                          return (
                            "string" != typeof n &&
                              ((n = ""), console.warn("password is empty")),
                            (o = this._cache.keys.refreshTokenKey),
                            (e.next = 6),
                            this._request.send("auth.signIn", {
                              loginType: Vl.USERNAME,
                              username: t,
                              password: n,
                              refresh_token: this._cache.getStore(o) || "",
                            })
                          );
                        case 6:
                          if (
                            ((i = e.sent),
                            (a = i.refresh_token),
                            (s = i.access_token_expire),
                            (c = i.access_token),
                            !a)
                          ) {
                            e.next = 23;
                            break;
                          }
                          if ((this.setRefreshToken(a), !c || !s)) {
                            e.next = 16;
                            break;
                          }
                          this.setAccessToken(c, s), (e.next = 18);
                          break;
                        case 16:
                          return (
                            (e.next = 18), this._request.refreshAccessToken()
                          );
                        case 18:
                          return (e.next = 20), this.refreshUserInfo();
                        case 20:
                          return (
                            Fl(Kl),
                            Fl(zl, {
                              env: this.config.env,
                              loginType: Vl.USERNAME,
                              persistence: this.config.persistence,
                            }),
                            e.abrupt("return", new ip(this.config.env))
                          );
                        case 23:
                          throw i.code
                            ? new cl({
                                code: i.code,
                                message: "用户名密码登录失败: ".concat(
                                  i.message
                                ),
                              })
                            : new cl({ message: "用户名密码登录失败" });
                        case 24:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e, t) {
              return n.apply(this, arguments);
            }),
        },
      ])
    );
    var n;
  })(),
  fp = (function () {
    return l(
      function e(t) {
        f(this, e),
          (this.config = t),
          (this._cache = Dl(t.env)),
          (this._request = np(t.env)),
          (this._onAnonymousConverted = this._onAnonymousConverted.bind(this)),
          (this._onLoginTypeChanged = this._onLoginTypeChanged.bind(this)),
          Bl(zl, this._onLoginTypeChanged);
      },
      [
        {
          key: "currentUser",
          get: function () {
            var e = this.hasLoginState();
            return (e && e.user) || null;
          },
        },
        {
          key: "loginType",
          get: function () {
            return this._cache.getStore(this._cache.keys.loginTypeKey);
          },
        },
        {
          key: "anonymousAuthProvider",
          value: function () {
            return new ap(this.config);
          },
        },
        {
          key: "customAuthProvider",
          value: function () {
            return new sp(this.config);
          },
        },
        {
          key: "emailAuthProvider",
          value: function () {
            return new cp(this.config);
          },
        },
        {
          key: "usernameAuthProvider",
          value: function () {
            return new up(this.config);
          },
        },
        {
          key: "signInAnonymously",
          value:
            ((h = o(
              r().mark(function e() {
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return e.abrupt(
                            "return",
                            new ap(this.config).signIn()
                          );
                        case 1:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function () {
              return h.apply(this, arguments);
            }),
        },
        {
          key: "signInWithEmailAndPassword",
          value:
            ((p = o(
              r().mark(function e(t, n) {
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return e.abrupt(
                            "return",
                            new cp(this.config).signIn(t, n)
                          );
                        case 1:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e, t) {
              return p.apply(this, arguments);
            }),
        },
        {
          key: "signInWithUsernameAndPassword",
          value: function (e, t) {
            return new up(this.config).signIn(e, t);
          },
        },
        {
          key: "linkAndRetrieveDataWithTicket",
          value:
            ((u = o(
              r().mark(function e(t) {
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            this._anonymousAuthProvider ||
                              (this._anonymousAuthProvider = new ap(
                                this.config
                              )),
                            Bl(Jl, this._onAnonymousConverted),
                            (e.next = 3),
                            this._anonymousAuthProvider.linkAndRetrieveDataWithTicket(
                              t
                            )
                          );
                        case 3:
                          return e.abrupt("return", e.sent);
                        case 4:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e) {
              return u.apply(this, arguments);
            }),
        },
        {
          key: "signOut",
          value:
            ((c = o(
              r().mark(function e() {
                var t, n, o, i, a, s;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (this.loginType !== Vl.ANONYMOUS) {
                            e.next = 2;
                            break;
                          }
                          throw new cl({ message: "匿名用户不支持登出操作" });
                        case 2:
                          if (
                            ((t = this._cache.keys),
                            (n = t.refreshTokenKey),
                            (o = t.accessTokenKey),
                            (i = t.accessTokenExpireKey),
                            (a = this._cache.getStore(n)))
                          ) {
                            e.next = 5;
                            break;
                          }
                          return e.abrupt("return");
                        case 5:
                          return (
                            (e.next = 7),
                            this._request.send("auth.logout", {
                              refresh_token: a,
                            })
                          );
                        case 7:
                          return (
                            (s = e.sent),
                            e.abrupt(
                              "return",
                              (this._cache.removeStore(n),
                              this._cache.removeStore(o),
                              this._cache.removeStore(i),
                              Fl(Kl),
                              Fl(zl, {
                                env: this.config.env,
                                loginType: Vl.NULL,
                                persistence: this.config.persistence,
                              }),
                              s)
                            )
                          );
                        case 9:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function () {
              return c.apply(this, arguments);
            }),
        },
        {
          key: "signUpWithEmailAndPassword",
          value:
            ((s = o(
              r().mark(function e(t, n) {
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return e.abrupt(
                            "return",
                            this._request.send(
                              "auth.signUpWithEmailAndPassword",
                              { email: t, password: n }
                            )
                          );
                        case 1:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e, t) {
              return s.apply(this, arguments);
            }),
        },
        {
          key: "sendPasswordResetEmail",
          value:
            ((a = o(
              r().mark(function e(t) {
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return e.abrupt(
                            "return",
                            this._request.send("auth.sendPasswordResetEmail", {
                              email: t,
                            })
                          );
                        case 1:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e) {
              return a.apply(this, arguments);
            }),
        },
        {
          key: "onLoginStateChanged",
          value: function (e) {
            var t = this;
            Bl(Kl, function () {
              var n = t.hasLoginState();
              e.call(t, n);
            });
            var n = this.hasLoginState();
            e.call(this, n);
          },
        },
        {
          key: "onLoginStateExpired",
          value: function (e) {
            Bl(Wl, e.bind(this));
          },
        },
        {
          key: "onAccessTokenRefreshed",
          value: function (e) {
            Bl(Yl, e.bind(this));
          },
        },
        {
          key: "onAnonymousConverted",
          value: function (e) {
            Bl(Jl, e.bind(this));
          },
        },
        {
          key: "onLoginTypeChanged",
          value: function (e) {
            var t = this;
            Bl(zl, function () {
              var n = t.hasLoginState();
              e.call(t, n);
            });
          },
        },
        {
          key: "getAccessToken",
          value:
            ((n = o(
              r().mark(function e() {
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (e.next = 2), this._request.getAccessToken();
                        case 2:
                          return (
                            (e.t0 = e.sent.accessToken),
                            (e.t1 = this.config.env),
                            e.abrupt("return", { accessToken: e.t0, env: e.t1 })
                          );
                        case 5:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function () {
              return n.apply(this, arguments);
            }),
        },
        {
          key: "hasLoginState",
          value: function () {
            var e = this._cache.keys.refreshTokenKey;
            return this._cache.getStore(e) ? new ip(this.config.env) : null;
          },
        },
        {
          key: "isUsernameRegistered",
          value:
            ((t = o(
              r().mark(function e(t) {
                var n, o;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if ("string" == typeof t) {
                            e.next = 2;
                            break;
                          }
                          throw new cl({
                            code: "PARAM_ERROR",
                            message: "username must be a string",
                          });
                        case 2:
                          return (
                            (e.next = 4),
                            this._request.send("auth.isUsernameRegistered", {
                              username: t,
                            })
                          );
                        case 4:
                          return (
                            (n = e.sent),
                            (o = n.data),
                            e.abrupt("return", o && o.isRegistered)
                          );
                        case 7:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e) {
              return t.apply(this, arguments);
            }),
        },
        {
          key: "getLoginState",
          value: function () {
            return Promise.resolve(this.hasLoginState());
          },
        },
        {
          key: "signInWithTicket",
          value:
            ((e = o(
              r().mark(function e(t) {
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return e.abrupt(
                            "return",
                            new sp(this.config).signIn(t)
                          );
                        case 1:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (t) {
              return e.apply(this, arguments);
            }),
        },
        {
          key: "shouldRefreshAccessToken",
          value: function (e) {
            this._request._shouldRefreshAccessTokenHook = e.bind(this);
          },
        },
        {
          key: "getUserInfo",
          value: function () {
            return this._request
              .send("auth.getUserInfo", {})
              .then(function (e) {
                return e.code
                  ? e
                  : i(i({}, e.data), {}, { requestId: e.seqId });
              });
          },
        },
        {
          key: "getAuthHeader",
          value: function () {
            var e = this._cache.keys,
              t = e.refreshTokenKey,
              n = e.accessTokenKey,
              r = this._cache.getStore(t);
            return {
              "x-cloudbase-credentials": this._cache.getStore(n) + "/@@/" + r,
            };
          },
        },
        {
          key: "_onAnonymousConverted",
          value: function (e) {
            e.data.env === this.config.env &&
              this._cache.updatePersistence(this.config.persistence);
          },
        },
        {
          key: "_onLoginTypeChanged",
          value: function (e) {
            var t = e.data,
              n = t.loginType,
              r = t.persistence;
            t.env === this.config.env &&
              (this._cache.updatePersistence(r),
              this._cache.setStore(this._cache.keys.loginTypeKey, n));
          },
        },
      ]
    );
    var e, t, n, a, s, c, u, p, h;
  })(),
  lp = function (e, t) {
    t = t || Ol();
    var n = np(this.config.env),
      r = e.cloudPath,
      o = e.filePath,
      i = e.onUploadProgress,
      a = e.fileType,
      s = void 0 === a ? "image" : a;
    return (
      n
        .send("storage.getUploadMetadata", { path: r })
        .then(function (e) {
          var a = e.data,
            c = a.url,
            u = a.authorization,
            f = a.token,
            l = a.fileId,
            p = a.cosFileId,
            h = e.requestId,
            d = {
              key: r,
              signature: u,
              "x-cos-meta-fileid": p,
              success_action_status: "201",
              "x-cos-security-token": f,
            };
          n.upload({
            url: c,
            data: d,
            file: o,
            name: r,
            fileType: s,
            onUploadProgress: i,
          })
            .then(function (e) {
              201 === e.statusCode
                ? t(null, { fileID: l, requestId: h })
                : t(
                    new cl({
                      code: "STORAGE_REQUEST_FAIL",
                      message: "STORAGE_REQUEST_FAIL: ".concat(e.data),
                    })
                  );
            })
            .catch(function (e) {
              t(e);
            });
        })
        .catch(function (e) {
          t(e);
        }),
      t.promise
    );
  },
  pp = function (e, t) {
    t = t || Ol();
    var n = np(this.config.env),
      r = e.cloudPath;
    return (
      n
        .send("storage.getUploadMetadata", { path: r })
        .then(function (e) {
          t(null, e);
        })
        .catch(function (e) {
          t(e);
        }),
      t.promise
    );
  },
  hp = function (e, t) {
    var n = e.fileList;
    if (((t = t || Ol()), !n || !Array.isArray(n)))
      return { code: "INVALID_PARAM", message: "fileList必须是非空的数组" };
    var r,
      o = g(n);
    try {
      for (o.s(); !(r = o.n()).done; ) {
        var i = r.value;
        if (!i || "string" != typeof i)
          return {
            code: "INVALID_PARAM",
            message: "fileList的元素必须是非空的字符串",
          };
      }
    } catch (e) {
      o.e(e);
    } finally {
      o.f();
    }
    var a = { fileid_list: n };
    return (
      np(this.config.env)
        .send("storage.batchDeleteFile", a)
        .then(function (e) {
          e.code
            ? t(null, e)
            : t(null, { fileList: e.data.delete_list, requestId: e.requestId });
        })
        .catch(function (e) {
          t(e);
        }),
      t.promise
    );
  },
  dp = function (e, t) {
    var n = e.fileList;
    (t = t || Ol()),
      (n && Array.isArray(n)) ||
        t(null, { code: "INVALID_PARAM", message: "fileList必须是非空的数组" });
    var r,
      o = [],
      i = g(n);
    try {
      for (i.s(); !(r = i.n()).done; ) {
        var a = r.value;
        "object" == d(a)
          ? ((a.hasOwnProperty("fileID") && a.hasOwnProperty("maxAge")) ||
              t(null, {
                code: "INVALID_PARAM",
                message: "fileList的元素必须是包含fileID和maxAge的对象",
              }),
            o.push({ fileid: a.fileID, max_age: a.maxAge }))
          : "string" == typeof a
          ? o.push({ fileid: a })
          : t(null, {
              code: "INVALID_PARAM",
              message: "fileList的元素必须是字符串",
            });
      }
    } catch (e) {
      i.e(e);
    } finally {
      i.f();
    }
    var s = { file_list: o };
    return (
      np(this.config.env)
        .send("storage.batchGetDownloadUrl", s)
        .then(function (e) {
          e.code
            ? t(null, e)
            : t(null, {
                fileList: e.data.download_list,
                requestId: e.requestId,
              });
        })
        .catch(function (e) {
          t(e);
        }),
      t.promise
    );
  },
  vp = (function () {
    var e = o(
      r().mark(function e(t, n) {
        var o, i, a, s;
        return r().wrap(
          function (e) {
            for (;;)
              switch ((e.prev = e.next)) {
                case 0:
                  return (
                    (o = t.fileID),
                    (e.next = 3),
                    dp.call(this, { fileList: [{ fileID: o, maxAge: 600 }] })
                  );
                case 3:
                  if ("SUCCESS" === (i = e.sent.fileList[0]).code) {
                    e.next = 6;
                    break;
                  }
                  return e.abrupt(
                    "return",
                    n
                      ? n(i)
                      : new Promise(function (e) {
                          e(i);
                        })
                  );
                case 6:
                  if (
                    ((a = np(this.config.env)),
                    (s = i.download_url),
                    (s = encodeURI(s)),
                    n)
                  ) {
                    e.next = 10;
                    break;
                  }
                  return e.abrupt("return", a.download({ url: s }));
                case 10:
                  return (e.t0 = n), (e.next = 13), a.download({ url: s });
                case 13:
                  (e.t1 = e.sent), (0, e.t0)(e.t1);
                case 15:
                case "end":
                  return e.stop();
              }
          },
          e,
          this
        );
      })
    );
    return function (t, n) {
      return e.apply(this, arguments);
    };
  })(),
  gp = function (e, t) {
    var n,
      r = e.name,
      o = e.data,
      i = e.query,
      a = e.parse,
      s = e.search,
      c = t || Ol();
    try {
      n = o ? JSON.stringify(o) : "";
    } catch (e) {
      return Promise.reject(e);
    }
    if (!r)
      return Promise.reject(
        new cl({ code: "PARAM_ERROR", message: "函数名不能为空" })
      );
    var u = {
      inQuery: i,
      parse: a,
      search: s,
      function_name: r,
      request_data: n,
    };
    return (
      np(this.config.env)
        .send("functions.invokeFunction", u)
        .then(function (e) {
          if (e.code) c(null, e);
          else {
            var t = e.data.response_data;
            if (a) c(null, { result: t, requestId: e.requestId });
            else
              try {
                (t = JSON.parse(e.data.response_data)),
                  c(null, { result: t, requestId: e.requestId });
              } catch (e) {
                c(new cl({ message: "response data must be json" }));
              }
          }
          return c.promise;
        })
        .catch(function (e) {
          c(e);
        }),
      c.promise
    );
  },
  mp = { timeout: 15e3, persistence: "session" },
  yp = {},
  _p = new ((function () {
    function e(t) {
      f(this, e), (this.config = t || this.config), (this.authObj = void 0);
    }
    return l(e, [
      {
        key: "init",
        value: function (t) {
          switch (
            (Cl.adapter ||
              (this.requestClient = new Cl.adapter.reqClass({
                timeout: t.timeout || 5e3,
                timeoutMsg: "请求在".concat(
                  (t.timeout || 5e3) / 1e3,
                  "s内未完成，已中断"
                ),
              })),
            (this.config = i(i({}, mp), t)),
            !0)
          ) {
            case this.config.timeout > 6e5:
              console.warn("timeout大于可配置上限[10分钟]，已重置为上限数值"),
                (this.config.timeout = 6e5);
              break;
            case this.config.timeout < 100:
              console.warn("timeout小于可配置下限[100ms]，已重置为下限数值"),
                (this.config.timeout = 100);
          }
          return new e(this.config);
        },
      },
      {
        key: "auth",
        value: function () {
          var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : {},
            t = e.persistence;
          if (this.authObj) return this.authObj;
          var n,
            r,
            o,
            a = t || Cl.adapter.primaryStorage || mp.persistence;
          return (
            a !== this.config.persistence && (this.config.persistence = a),
            (r = this.config),
            (o = r.env),
            (jl[o] = new Rl(r)),
            (Ml[o] = new Rl(i(i({}, r), {}, { persistence: "local" }))),
            (n = this.config),
            (tp[n.env] = new ep(n)),
            (this.authObj = new fp(this.config)),
            this.authObj
          );
        },
      },
      {
        key: "on",
        value: function (e, t) {
          return Bl.apply(this, [e, t]);
        },
      },
      {
        key: "off",
        value: function (e, t) {
          return Hl.apply(this, [e, t]);
        },
      },
      {
        key: "callFunction",
        value: function (e, t) {
          return gp.apply(this, [e, t]);
        },
      },
      {
        key: "deleteFile",
        value: function (e, t) {
          return hp.apply(this, [e, t]);
        },
      },
      {
        key: "getTempFileURL",
        value: function (e, t) {
          return dp.apply(this, [e, t]);
        },
      },
      {
        key: "downloadFile",
        value: function (e, t) {
          return vp.apply(this, [e, t]);
        },
      },
      {
        key: "uploadFile",
        value: function (e, t) {
          return lp.apply(this, [e, t]);
        },
      },
      {
        key: "getUploadMetadata",
        value: function (e, t) {
          return pp.apply(this, [e, t]);
        },
      },
      {
        key: "registerExtension",
        value: function (e) {
          yp[e.name] = e;
        },
      },
      {
        key: "invokeExtension",
        value:
          ((t = o(
            r().mark(function e(t, n) {
              var o;
              return r().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if ((o = yp[t])) {
                          e.next = 3;
                          break;
                        }
                        throw new cl({
                          message: "扩展".concat(t, " 必须先注册"),
                        });
                      case 3:
                        return (e.next = 5), o.invoke(n, this);
                      case 5:
                        return e.abrupt("return", e.sent);
                      case 6:
                      case "end":
                        return e.stop();
                    }
                },
                e,
                this
              );
            })
          )),
          function (e, n) {
            return t.apply(this, arguments);
          }),
      },
      {
        key: "useAdapters",
        value: function (e) {
          var t =
              (function (e) {
                var t,
                  n,
                  r =
                    ((t = e),
                    "[object Array]" === Object.prototype.toString.call(t)
                      ? e
                      : [e]),
                  o = g(r);
                try {
                  for (o.s(); !(n = o.n()).done; ) {
                    var i = n.value,
                      a = i.isMatch,
                      s = i.genAdapter,
                      c = i.runtime;
                    if (a()) return { adapter: s(), runtime: c };
                  }
                } catch (e) {
                  o.e(e);
                } finally {
                  o.f();
                }
              })(e) || {},
            n = t.adapter,
            r = t.runtime;
          n && (Cl.adapter = n), r && (Cl.runtime = r);
        },
      },
    ]);
    var t;
  })())();
function bp(e, t, n) {
  void 0 === n && (n = {});
  var r = /\?/.test(t),
    o = "";
  for (var i in n)
    "" === o ? !r && (t += "?") : (o += "&"),
      (o += i + "=" + encodeURIComponent(n[i]));
  return /^http(s)?:\/\//.test((t += o)) ? t : "" + e + t;
}
var wp = (function () {
    return l(
      function e() {
        f(this, e);
      },
      [
        {
          key: "post",
          value: function (e) {
            var t = e.url,
              n = e.data,
              r = e.headers;
            return new Promise(function (e, o) {
              ul.request({
                url: bp("https:", t),
                data: n,
                method: "POST",
                header: r,
                success: function (t) {
                  e(t);
                },
                fail: function (e) {
                  o(e);
                },
              });
            });
          },
        },
        {
          key: "upload",
          value: function (e) {
            return new Promise(function (t, n) {
              var r = e.url,
                o = e.file,
                i = e.data,
                a = e.headers,
                s = e.fileType,
                c = ul.uploadFile({
                  url: bp("https:", r),
                  name: "file",
                  formData: Object.assign({}, i),
                  filePath: o,
                  fileType: s,
                  header: a,
                  success: function (e) {
                    var n = { statusCode: e.statusCode, data: e.data || {} };
                    200 === e.statusCode &&
                      i.success_action_status &&
                      (n.statusCode = parseInt(i.success_action_status, 10)),
                      t(n);
                  },
                  fail: function (e) {
                    n(new Error(e.errMsg || "uploadFile:fail"));
                  },
                });
              "function" == typeof e.onUploadProgress &&
                c &&
                "function" == typeof c.onProgressUpdate &&
                c.onProgressUpdate(function (t) {
                  e.onUploadProgress({
                    loaded: t.totalBytesSent,
                    total: t.totalBytesExpectedToSend,
                  });
                });
            });
          },
        },
      ]
    );
  })(),
  kp = {
    setItem: function (e, t) {
      ul.setStorageSync(e, t);
    },
    getItem: function (e) {
      return ul.getStorageSync(e);
    },
    removeItem: function (e) {
      ul.removeStorageSync(e);
    },
    clear: function () {
      ul.clearStorageSync();
    },
  },
  xp = {
    genAdapter: function () {
      return {
        root: {},
        reqClass: wp,
        localStorage: kp,
        primaryStorage: "local",
      };
    },
    isMatch: function () {
      return !0;
    },
    runtime: "uni_app",
  };
_p.useAdapters(xp);
var Sp = _p,
  Pp = Sp.init;
Sp.init = function (e) {
  e.env = e.spaceId;
  var t = Pp.call(this, e);
  (t.config.provider = "tencent"), (t.config.spaceId = e.spaceId);
  var n = t.auth;
  return (
    (t.auth = function (e) {
      var t = n.call(this, e);
      return (
        [
          "linkAndRetrieveDataWithTicket",
          "signInAnonymously",
          "signOut",
          "getAccessToken",
          "getLoginState",
          "signInWithTicket",
          "getUserInfo",
        ].forEach(function (e) {
          var n;
          t[e] = ((n = t[e]),
          function (e) {
            var t = il((e = e || {})),
              r = t.success,
              o = t.fail,
              i = t.complete;
            if (!(r || o || i)) return n.call(this, e);
            n.call(this, e).then(
              function (e) {
                r && r(e), i && i(e);
              },
              function (e) {
                o && o(e), i && i(e);
              }
            );
          }).bind(t);
        }),
        t
      );
    }),
    (t.customAuth = t.auth),
    t
  );
};
var Tp = Sp,
  Op = (function (e) {
    function t() {
      return f(this, t), m(this, t, arguments);
    }
    return (
      u(t, bl),
      l(t, [
        {
          key: "getAccessToken",
          value: function () {
            var e = this;
            return new Promise(function (t, n) {
              var r = "Anonymous_Access_token";
              e.setAccessToken(r), t(r);
            });
          },
        },
        {
          key: "setupRequest",
          value: function (e, t) {
            var n = Object.assign({}, e, {
                spaceId: this.config.spaceId,
                timestamp: Date.now(),
              }),
              r = { "Content-Type": "application/json" };
            "auth" !== t &&
              ((n.token = this.accessToken),
              (r["x-basement-token"] = this.accessToken)),
              (r["x-serverless-sign"] = ml(n, this.config.clientSecret));
            var o = dl();
            r["x-client-info"] = encodeURIComponent(JSON.stringify(o));
            var i = fl().token;
            return (
              (r["x-client-token"] = i),
              {
                url: this.config.requestUrl,
                method: "POST",
                data: n,
                dataType: "json",
                header: JSON.parse(JSON.stringify(r)),
              }
            );
          },
        },
        {
          key: "uploadFileToOSS",
          value: function (e) {
            var t = this,
              n = e.url,
              r = e.formData,
              o = e.name,
              i = e.filePath,
              a = e.fileType,
              s = e.onUploadProgress;
            return new Promise(function (e, c) {
              var u = t.adapter.uploadFile({
                url: n,
                formData: r,
                name: o,
                filePath: i,
                fileType: a,
                success: function (t) {
                  t && t.statusCode < 400
                    ? e(t)
                    : c(
                        new cl({
                          code: "UPLOAD_FAILED",
                          message: "文件上传失败",
                        })
                      );
                },
                fail: function (e) {
                  c(
                    new cl({
                      code: e.code || "UPLOAD_FAILED",
                      message: e.message || e.errMsg || "文件上传失败",
                    })
                  );
                },
              });
              "function" == typeof s &&
                u &&
                "function" == typeof u.onProgressUpdate &&
                u.onProgressUpdate(function (e) {
                  s({
                    loaded: e.totalBytesSent,
                    total: e.totalBytesExpectedToSend,
                  });
                });
            });
          },
        },
        {
          key: "uploadFile",
          value: function (e) {
            var t,
              n = this,
              r = e.filePath,
              o = e.cloudPath,
              i = e.fileType,
              a = void 0 === i ? "image" : i,
              s = e.onUploadProgress;
            if (!o)
              throw new cl({
                code: "CLOUDPATH_REQUIRED",
                message: "cloudPath不可为空",
              });
            return this.getOSSUploadOptionsFromPath({ cloudPath: o })
              .then(function (e) {
                var o = e.result,
                  i = o.url,
                  c = o.formData,
                  u = o.name;
                t = e.result.fileUrl;
                var f = {
                  url: i,
                  formData: c,
                  name: u,
                  filePath: r,
                  fileType: a,
                };
                return n.uploadFileToOSS(
                  Object.assign({}, f, { onUploadProgress: s })
                );
              })
              .then(function () {
                return n.reportOSSUpload({ cloudPath: o });
              })
              .then(function (e) {
                return new Promise(function (n, o) {
                  e.success
                    ? n({ success: !0, filePath: r, fileID: t })
                    : o(
                        new cl({
                          code: "UPLOAD_FAILED",
                          message: "文件上传失败",
                        })
                      );
                });
              });
          },
        },
        {
          key: "deleteFile",
          value: function (e) {
            var t = e.fileList,
              n = {
                method: "serverless.file.resource.delete",
                params: JSON.stringify({ fileList: t }),
              };
            return this.request(this.setupRequest(n)).then(function (e) {
              if (e.success) return e.result;
              throw new cl({
                code: "DELETE_FILE_FAILED",
                message: "删除文件失败",
              });
            });
          },
        },
        {
          key: "getTempFileURL",
          value: function () {
            var e =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : {},
              t = e.fileList,
              n = e.maxAge;
            if (!Array.isArray(t) || 0 === t.length)
              throw new cl({
                code: "INVALID_PARAM",
                message: "fileList的元素必须是非空的字符串",
              });
            var r = {
              method: "serverless.file.resource.getTempFileURL",
              params: JSON.stringify({ fileList: t, maxAge: n }),
            };
            return this.request(this.setupRequest(r)).then(function (e) {
              if (e.success)
                return {
                  fileList: e.result.fileList.map(function (e) {
                    return { fileID: e.fileID, tempFileURL: e.tempFileURL };
                  }),
                };
              throw new cl({
                code: "GET_TEMP_FILE_URL_FAILED",
                message: "获取临时文件链接失败",
              });
            });
          },
        },
      ])
    );
  })(),
  Ap = {
    init: function (e) {
      var t = new Op(e),
        n = {
          signInAnonymously: function () {
            return t.authorize();
          },
          getLoginState: function () {
            return Promise.resolve(!1);
          },
        };
      return (
        (t.auth = function () {
          return n;
        }),
        (t.customAuth = t.auth),
        t
      );
    },
  },
  Ip = vf(function (e, t) {
    e.exports = gf.enc.Hex;
  });
function Cp() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (e) {
    var t = (16 * Math.random()) | 0;
    return ("x" === e ? t : (3 & t) | 8).toString(16);
  });
}
function Ep() {
  var e,
    t,
    n,
    r,
    o,
    i,
    a,
    s,
    c = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
    u = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
    f = u.data,
    l = u.functionName,
    p = u.method,
    h = u.headers,
    d = u.signHeaderKeys,
    g = void 0 === d ? [] : d,
    m = u.config,
    y = Date.now(),
    _ = Cp(),
    b = Object.assign({}, h, {
      "x-from-app-id": m.spaceAppId,
      "x-from-env-id": m.spaceId,
      "x-to-env-id": m.spaceId,
      "x-from-instance-id": y,
      "x-from-function-name": l,
      "x-client-timestamp": y,
      "x-alipay-source": "client",
      "x-request-id": _,
      "x-alipay-callid": _,
      "x-trace-id": _,
    }),
    w = [
      "x-from-app-id",
      "x-from-env-id",
      "x-to-env-id",
      "x-from-instance-id",
      "x-from-function-name",
      "x-client-timestamp",
    ].concat(g),
    k = c.split("?") || [],
    x = v(k, 2),
    S = x[0],
    P = void 0 === S ? "" : S,
    T = x[1],
    O = void 0 === T ? "" : T,
    A =
      ((e = {
        path: P,
        query: O,
        method: p,
        headers: b,
        timestamp: y,
        body: JSON.stringify(f),
        secretId: m.accessKey,
        secretKey: m.secretKey,
        signedHeaders: w.sort(),
      }),
      (t = e.signedHeaders.join(";")),
      (n = e.signedHeaders
        .map(function (t) {
          return "".concat(t.toLowerCase(), ":").concat(e.headers[t], "\n");
        })
        .join("")),
      (r = Pl(e.body).toString(Ip)),
      (o = ""
        .concat(e.method.toUpperCase(), "\n")
        .concat(e.path, "\n")
        .concat(e.query, "\n")
        .concat(n, "\n")
        .concat(t, "\n")
        .concat(r, "\n")),
      (i = Pl(o).toString(Ip)),
      (a = "HMAC-SHA256\n".concat(e.timestamp, "\n").concat(i, "\n")),
      (s = Tl(a, e.secretKey).toString(Ip)),
      "HMAC-SHA256 Credential="
        .concat(e.secretId, ", SignedHeaders=")
        .concat(t, ", Signature=")
        .concat(s));
  return {
    url: "".concat(m.endpoint).concat(c),
    headers: Object.assign({}, b, { Authorization: A }),
  };
}
function Lp(e) {
  var t = e.url,
    n = e.data,
    r = e.method,
    o = void 0 === r ? "POST" : r,
    i = e.headers,
    a = void 0 === i ? {} : i;
  return new Promise(function (e, r) {
    ul.request({
      url: t,
      method: o,
      data: "object" == d(n) ? JSON.stringify(n) : n,
      header: a,
      dataType: "json",
      complete: function () {
        var t =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          n = a["x-trace-id"] || "";
        if (!t.statusCode || t.statusCode >= 400) {
          var o = t.data || {},
            i = o.message,
            s = o.errMsg,
            c = o.trace_id;
          return r(
            new cl({
              code: "SYS_ERR",
              message: i || s || "request:fail",
              requestId: c || n,
            })
          );
        }
        e({
          status: t.statusCode,
          data: t.data,
          headers: t.header,
          requestId: n,
        });
      },
    });
  });
}
function $p(e, t) {
  var n = e.path,
    r = e.data,
    o = e.method,
    i = void 0 === o ? "GET" : o,
    a = Ep(n, {
      functionName: "",
      data: r,
      method: i,
      headers: {
        "x-alipay-cloud-mode": "oss",
        "x-data-api-type": "oss",
        "x-expire-timestamp": Date.now() + 6e4,
      },
      signHeaderKeys: ["x-data-api-type", "x-expire-timestamp"],
      config: t,
    });
  return Lp({ url: a.url, data: r, method: i, headers: a.headers })
    .then(function (e) {
      var t = e.data || {};
      if (!t.success)
        throw new cl({
          code: e.errCode,
          message: e.errMsg,
          requestId: e.requestId,
        });
      return t.data || {};
    })
    .catch(function (e) {
      throw new cl({
        code: e.errCode,
        message: e.errMsg,
        requestId: e.requestId,
      });
    });
}
function Rp() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
    t = e.trim().replace(/^cloud:\/\//, ""),
    n = t.indexOf("/");
  if (n <= 0) throw new cl({ code: "INVALID_PARAM", message: "fileID不合法" });
  var r = t.substring(0, n),
    o = t.substring(n + 1);
  return (
    r !== this.config.spaceId &&
      console.warn(
        "file "
          .concat(e, " does not belong to env ")
          .concat(this.config.spaceId)
      ),
    o
  );
}
function jp() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
  return "cloud://"
    .concat(this.config.spaceId, "/")
    .concat(e.replace(/^\/+/, ""));
}
var Mp = (function () {
    return l(
      function e(t) {
        f(this, e), (this.config = t);
      },
      [
        {
          key: "signedURL",
          value: function (e) {
            var t =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : {},
              n = "/ws/function/".concat(e),
              r = this.config.wsEndpoint.replace(/^ws(s)?:\/\//, ""),
              o = Object.assign({}, t, {
                accessKeyId: this.config.accessKey,
                signatureNonce: Cp(),
                timestamp: "" + Date.now(),
              }),
              i = [
                n,
                ["accessKeyId", "authorization", "signatureNonce", "timestamp"]
                  .sort()
                  .map(function (e) {
                    return o[e] ? "".concat(e, "=").concat(o[e]) : null;
                  })
                  .filter(Boolean)
                  .join("&"),
                "host:".concat(r),
              ].join("\n"),
              a = ["HMAC-SHA256", Pl(i).toString(Ip)].join("\n"),
              s = Tl(a, this.config.secretKey).toString(Ip),
              c = Object.keys(o)
                .map(function (e) {
                  return "".concat(e, "=").concat(encodeURIComponent(o[e]));
                })
                .join("&");
            return ""
              .concat(this.config.wsEndpoint)
              .concat(n, "?")
              .concat(c, "&signature=")
              .concat(s);
          },
        },
      ]
    );
  })(),
  Dp = (function () {
    return l(
      function e(t) {
        if (
          (f(this, e),
          ["spaceId", "spaceAppId", "accessKey", "secretKey"].forEach(function (
            e
          ) {
            if (!Object.prototype.hasOwnProperty.call(t, e))
              throw new Error("".concat(e, " required"));
          }),
          t.endpoint)
        ) {
          if ("string" != typeof t.endpoint)
            throw new Error("endpoint must be string");
          if (!/^https:\/\//.test(t.endpoint))
            throw new Error("endpoint must start with https://");
          t.endpoint = t.endpoint.replace(/\/$/, "");
        }
        (this.config = Object.assign({}, t, {
          endpoint:
            t.endpoint ||
            "https://".concat(t.spaceId, ".api-hz.cloudbasefunction.cn"),
          wsEndpoint:
            t.wsEndpoint ||
            "wss://".concat(t.spaceId, ".api-hz.cloudbasefunction.cn"),
        })),
          (this._websocket = new Mp(this.config));
      },
      [
        {
          key: "callFunction",
          value: function (e) {
            return (function (e, t) {
              var n = e.name,
                r = e.data,
                o = e.async,
                i = void 0 !== o && o,
                a = { "x-to-function-name": n };
              i && (a["x-function-invoke-type"] = "async");
              var s = Ep("/functions/invokeFunction", {
                functionName: n,
                data: r,
                method: "POST",
                headers: a,
                signHeaderKeys: ["x-to-function-name"],
                config: t,
              });
              return Lp({
                url: s.url,
                data: r,
                method: "POST",
                headers: s.headers,
              })
                .then(function (e) {
                  var t = 0;
                  if (i) {
                    var n = e.data || {};
                    (t = "200" === n.errCode ? 0 : n.errCode),
                      (e.data = n.data || {}),
                      (e.errMsg = n.errMsg);
                  }
                  if (0 !== t)
                    throw new cl({
                      code: t,
                      message: e.errMsg,
                      requestId: e.requestId,
                    });
                  return {
                    errCode: t,
                    success: 0 === t,
                    requestId: e.requestId,
                    result: e.data,
                  };
                })
                .catch(function (e) {
                  throw new cl({
                    code: e.errCode,
                    message: e.errMsg,
                    requestId: e.requestId,
                  });
                });
            })(e, this.config);
          },
        },
        {
          key: "uploadFileToOSS",
          value: function (e) {
            var t = e.url,
              n = e.filePath,
              r = e.fileType,
              o = e.formData,
              i = e.onUploadProgress;
            return new Promise(function (e, a) {
              var s = ul.uploadFile({
                url: t,
                filePath: n,
                fileType: r,
                formData: o,
                name: "file",
                success: function (t) {
                  t && t.statusCode < 400
                    ? e(t)
                    : a(
                        new cl({
                          code: "UPLOAD_FAILED",
                          message: "文件上传失败",
                        })
                      );
                },
                fail: function (e) {
                  a(
                    new cl({
                      code: e.code || "UPLOAD_FAILED",
                      message: e.message || e.errMsg || "文件上传失败",
                    })
                  );
                },
              });
              "function" == typeof i &&
                s &&
                "function" == typeof s.onProgressUpdate &&
                s.onProgressUpdate(function (e) {
                  i({
                    loaded: e.totalBytesSent,
                    total: e.totalBytesExpectedToSend,
                  });
                });
            });
          },
        },
        {
          key: "uploadFile",
          value:
            ((n = o(
              r().mark(function e(t) {
                var n, o, i, a, s, c, u, f, l, p, h;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (
                            ((n = t.filePath),
                            (o = t.cloudPath),
                            (i = void 0 === o ? "" : o),
                            (a = t.fileType),
                            (s = void 0 === a ? "image" : a),
                            (c = t.onUploadProgress),
                            "string" === Sf(i))
                          ) {
                            e.next = 3;
                            break;
                          }
                          throw new cl({
                            code: "INVALID_PARAM",
                            message: "cloudPath必须为字符串类型",
                          });
                        case 3:
                          if ((i = i.trim())) {
                            e.next = 5;
                            break;
                          }
                          throw new cl({
                            code: "INVALID_PARAM",
                            message: "cloudPath不可为空",
                          });
                        case 5:
                          if (!/:\/\//.test(i)) {
                            e.next = 7;
                            break;
                          }
                          throw new cl({
                            code: "INVALID_PARAM",
                            message: "cloudPath不合法",
                          });
                        case 7:
                          return (
                            (e.next = 9),
                            $p(
                              {
                                path: "/".concat(
                                  i.replace(/^\//, ""),
                                  "?post_url"
                                ),
                              },
                              this.config
                            )
                          );
                        case 9:
                          return (
                            (u = e.sent),
                            (f = u.file_id),
                            (l = u.upload_url),
                            (p = u.form_data),
                            (h =
                              p &&
                              p.reduce(function (e, t) {
                                return (e[t.key] = t.value), e;
                              }, {})),
                            e.abrupt(
                              "return",
                              this.uploadFileToOSS({
                                url: l,
                                filePath: n,
                                fileType: s,
                                formData: h,
                                onUploadProgress: c,
                              }).then(function () {
                                return { fileID: f };
                              })
                            )
                          );
                        case 15:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (e) {
              return n.apply(this, arguments);
            }),
        },
        {
          key: "getTempFileURL",
          value:
            ((t = o(
              r().mark(function e(t) {
                var n,
                  o = this;
                return r().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (n = t.fileList),
                          e.abrupt(
                            "return",
                            new Promise(function (e, t) {
                              (!n || n.length < 0) &&
                                t(
                                  new cl({
                                    errCode: "INVALID_PARAM",
                                    errMsg: "fileList不能为空数组",
                                  })
                                ),
                                n.length > 50 &&
                                  t(
                                    new cl({
                                      errCode: "INVALID_PARAM",
                                      errMsg: "fileList数组长度不能超过50",
                                    })
                                  );
                              var r,
                                i = [],
                                a = g(n);
                              try {
                                for (a.s(); !(r = a.n()).done; ) {
                                  var s = r.value;
                                  "string" !== Sf(s) &&
                                    t(
                                      new cl({
                                        errCode: "INVALID_PARAM",
                                        errMsg:
                                          "fileList的元素必须是非空的字符串",
                                      })
                                    );
                                  var c = Rp.call(o, s);
                                  i.push({ file_id: c, expire: 600 });
                                }
                              } catch (e) {
                                a.e(e);
                              } finally {
                                a.f();
                              }
                              $p(
                                {
                                  path: "/?download_url",
                                  data: { file_list: i },
                                  method: "POST",
                                },
                                o.config
                              )
                                .then(function (t) {
                                  var n = t.file_list;
                                  e({
                                    fileList: (void 0 === n ? [] : n).map(
                                      function (e) {
                                        return {
                                          fileID: jp.call(o, e.file_id),
                                          tempFileURL: e.download_url,
                                        };
                                      }
                                    ),
                                  });
                                })
                                .catch(function (e) {
                                  return t(e);
                                });
                            })
                          )
                        );
                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            )),
            function (e) {
              return t.apply(this, arguments);
            }),
        },
        {
          key: "connectWebSocket",
          value:
            ((e = o(
              r().mark(function e(t) {
                var n, o;
                return r().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (n = t.name),
                            (o = t.query),
                            e.abrupt(
                              "return",
                              ul.connectSocket({
                                url: this._websocket.signedURL(n, o),
                                complete: function () {},
                              })
                            )
                          );
                        case 2:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            )),
            function (t) {
              return e.apply(this, arguments);
            }),
        },
      ]
    );
    var e, t, n;
  })(),
  Up = {
    init: function (e) {
      e.provider = "alipay";
      var t = new Dp(e);
      return (
        (t.auth = function () {
          return {
            signInAnonymously: function () {
              return Promise.resolve();
            },
            getLoginState: function () {
              return Promise.resolve(!0);
            },
          };
        }),
        t
      );
    },
  };
function Np(e) {
  var t,
    n = e.data;
  t = dl();
  var r = JSON.parse(JSON.stringify(n || {}));
  if ((Object.assign(r, { clientInfo: t }), !r.uniIdToken)) {
    var o = fl().token;
    o && (r.uniIdToken = o);
  }
  return r;
}
function qp() {
  return Bp.apply(this, arguments);
}
function Bp() {
  return (Bp = o(
    r().mark(function e() {
      var t,
        n,
        o,
        i,
        a,
        s,
        c,
        u,
        f,
        l,
        p = this,
        h = arguments;
      return r().wrap(
        function (e) {
          for (;;)
            switch ((e.prev = e.next)) {
              case 0:
                return (
                  (t = h.length > 0 && void 0 !== h[0] ? h[0] : {}),
                  (n = t.name),
                  (o = t.data),
                  (e.next = 3),
                  this.__dev__.initLocalNetwork()
                );
              case 3:
                return (
                  (i = this.__dev__),
                  (a = i.localAddress),
                  (s = i.localPort),
                  (c = { aliyun: "aliyun", tencent: "tcb", alipay: "alipay" }[
                    this.config.provider
                  ]),
                  (u = this.config.spaceId),
                  (f = "http://"
                    .concat(a, ":")
                    .concat(s, "/system/check-function")),
                  (l = "http://"
                    .concat(a, ":")
                    .concat(s, "/cloudfunctions/")
                    .concat(n)),
                  e.abrupt(
                    "return",
                    new Promise(function (e, t) {
                      ul.request({
                        method: "POST",
                        url: f,
                        data: {
                          name: n,
                          platform: $f,
                          provider: c,
                          spaceId: u,
                        },
                        timeout: 3e3,
                        success: function (t) {
                          e(t);
                        },
                        fail: function () {
                          e({
                            data: {
                              code: "NETWORK_ERROR",
                              message:
                                "连接本地调试服务失败，请检查客户端是否和主机在同一局域网下，自动切换为已部署的云函数。",
                            },
                          });
                        },
                      });
                    })
                      .then(function () {
                        var e =
                            arguments.length > 0 && void 0 !== arguments[0]
                              ? arguments[0]
                              : {},
                          t = e.data,
                          n = t || {},
                          r = n.code,
                          o = n.message;
                        return {
                          code: 0 === r ? 0 : r || "SYS_ERR",
                          message: o || "SYS_ERR",
                        };
                      })
                      .then(function (e) {
                        var t = e.code,
                          r = e.message;
                        if (0 !== t) {
                          switch (t) {
                            case "MODULE_ENCRYPTED":
                              console.error(
                                "此云函数（".concat(
                                  n,
                                  "）依赖加密公共模块不可本地调试，自动切换为云端已部署的云函数"
                                )
                              );
                              break;
                            case "FUNCTION_ENCRYPTED":
                              console.error(
                                "此云函数（".concat(
                                  n,
                                  "）已加密不可本地调试，自动切换为云端已部署的云函数"
                                )
                              );
                              break;
                            case "ACTION_ENCRYPTED":
                              console.error(
                                r ||
                                  "需要访问加密的uni-clientDB-action，自动切换为云端环境"
                              );
                              break;
                            case "NETWORK_ERROR":
                              console.error(
                                r ||
                                  "连接本地调试服务失败，请检查客户端是否和主机在同一局域网下"
                              );
                              break;
                            case "SWITCH_TO_CLOUD":
                              break;
                            default:
                              var i = "检测本地调试服务出现错误：".concat(
                                r,
                                "，请检查网络环境或重启客户端再试"
                              );
                              throw (console.error(i), new Error(i));
                          }
                          return p._callCloudFunction({ name: n, data: o });
                        }
                        return new Promise(function (e, t) {
                          var n = Np.call(p, { data: o });
                          ul.request({
                            method: "POST",
                            url: l,
                            data: { provider: c, platform: $f, param: n },
                            success: function () {
                              var n =
                                  arguments.length > 0 &&
                                  void 0 !== arguments[0]
                                    ? arguments[0]
                                    : {},
                                r = n.statusCode,
                                o = n.data;
                              return !r || r >= 400
                                ? t(
                                    new cl({
                                      code: o.code || "SYS_ERR",
                                      message: o.message || "request:fail",
                                    })
                                  )
                                : e({ result: o });
                            },
                            fail: function (e) {
                              t(
                                new cl({
                                  code: e.code || e.errCode || "SYS_ERR",
                                  message:
                                    e.message || e.errMsg || "request:fail",
                                })
                              );
                            },
                          });
                        });
                      })
                  )
                );
              case 5:
              case "end":
                return e.stop();
            }
        },
        e,
        this
      );
    })
  )).apply(this, arguments);
}
var Fp = [
    {
      rule: /fc_function_not_found|FUNCTION_NOT_FOUND/,
      content:
        "，云函数[{functionName}]在云端不存在，请检查此云函数名称是否正确以及该云函数是否已上传到服务空间",
      mode: "append",
    },
  ],
  Hp = /[\\^$.*+?()[\]{}|]/g,
  Vp = RegExp(Hp.source);
function Kp(e, t, n) {
  return e.replace(
    new RegExp((r = t) && Vp.test(r) ? r.replace(Hp, "\\$&") : r, "g"),
    n
  );
  var r;
}
var Wp,
  zp = "request",
  Jp = "response",
  Yp = 2e4,
  Qp = { code: 20101, message: "Invalid client" };
function Gp(e) {
  var t = e || {},
    n = t.errSubject,
    r = t.subject,
    o = t.errCode,
    i = t.errMsg,
    a = t.code,
    s = t.message,
    c = t.cause;
  return new cl({
    subject: n || r || "uni-secure-network",
    code: o || a || Yp,
    message: i || s,
    cause: c,
  });
}
function Xp() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
    t = e.secretType;
  return t === zp || t === Jp || "both" === t;
}
function Zp() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  e.name, e.data;
  return "app" === $f;
}
function eh(e) {
  var t = e.functionName,
    n = e.result,
    r = e.logPvd;
  if (this.__dev__.debugLog && n && n.requestId) {
    var o = JSON.stringify({
      spaceId: this.config.spaceId,
      functionName: t,
      requestId: n.requestId,
    });
    console.log(
      "[".concat(r, "-request]").concat(o, "[/").concat(r, "-request]")
    );
  }
}
function th(e) {
  var t = e.callFunction,
    n = function (n) {
      var r = this,
        o = n.name;
      n.data = Np.call(e, { data: n.data });
      var i = {
          aliyun: "aliyun",
          tencent: "tcb",
          tcb: "tcb",
          alipay: "alipay",
        }[this.config.provider],
        a = Xp(n),
        s = Zp(n),
        c = a || s;
      return t.call(this, n).then(
        function (e) {
          return (
            (e.errCode = 0),
            !c && eh.call(r, { functionName: o, result: e, logPvd: i }),
            Promise.resolve(e)
          );
        },
        function (e) {
          return (
            !c && eh.call(r, { functionName: o, result: e, logPvd: i }),
            e &&
              e.message &&
              (e.message = (function () {
                for (
                  var e =
                      arguments.length > 0 && void 0 !== arguments[0]
                        ? arguments[0]
                        : {},
                    t = e.message,
                    n = void 0 === t ? "" : t,
                    r = e.extraInfo,
                    o = void 0 === r ? {} : r,
                    i = e.formatter,
                    a = void 0 === i ? [] : i,
                    s = 0;
                  s < a.length;
                  s++
                ) {
                  var c = a[s],
                    u = c.rule,
                    f = c.content,
                    l = c.mode,
                    p = n.match(u);
                  if (p) {
                    for (var h = f, d = 1; d < p.length; d++)
                      h = Kp(h, "{$".concat(d, "}"), p[d]);
                    for (var v in o) h = Kp(h, "{".concat(v, "}"), o[v]);
                    return "replace" === l ? h : n + h;
                  }
                }
                return n;
              })({
                message: "[".concat(n.name, "]: ").concat(e.message),
                formatter: Fp,
                extraInfo: { functionName: o },
              })),
            Promise.reject(e)
          );
        }
      );
    };
  e.callFunction = function (t) {
    var r,
      o,
      i,
      a,
      s,
      c = e.config,
      u = c.provider,
      f = c.spaceId,
      l = t.name;
    return (
      (t.data = t.data || {}),
      e.__dev__.debugInfo && !e.__dev__.debugInfo.forceRemote && jf
        ? (e._callCloudFunction ||
            ((e._callCloudFunction = n), (e._callLocalFunction = qp)),
          (r = qp))
        : (r = n),
      (r = r.bind(e)),
      Zp(t) ||
        ((a = (i = t).name),
        (s = i.data),
        (o =
          "uni-id-co" === a &&
          "secureNetworkHandshakeByWeixin" === (void 0 === s ? {} : s).method
            ? r.call(e, t)
            : Xp(t)
            ? new Wp({
                secretType: t.secretType,
                uniCloudIns: e,
              }).wrapEncryptDataCallFunction(n.bind(e))(t)
            : (function () {
                var e =
                    arguments.length > 0 && void 0 !== arguments[0]
                      ? arguments[0]
                      : {},
                  t = e.provider,
                  n = e.spaceId,
                  r = e.functionName,
                  o = pl(),
                  i = o.appId,
                  a = o.uniPlatform,
                  s = o.osName,
                  c = a;
                "app" === a && (c = s);
                var u = (function () {
                  var e =
                      arguments.length > 0 && void 0 !== arguments[0]
                        ? arguments[0]
                        : {},
                    t = e.provider,
                    n = e.spaceId,
                    r = Lf;
                  if (!r) return {};
                  t = (function (e) {
                    return "tencent" === e ? "tcb" : e;
                  })(t);
                  var o = r.find(function (e) {
                    return e.provider === t && e.spaceId === n;
                  });
                  return o && o.config;
                })({ provider: t, spaceId: n });
                if (!u || !u.accessControl || !u.accessControl.enable)
                  return !1;
                var f = u.accessControl.function || {},
                  l = Object.keys(f);
                if (0 === l.length) return !0;
                var p = (function (e, t) {
                  for (var n, r, o, i = 0; i < e.length; i++) {
                    var a = e[i];
                    a !== t
                      ? "*" !== a
                        ? a
                            .split(",")
                            .map(function (e) {
                              return e.trim();
                            })
                            .indexOf(t) > -1 && (r = a)
                        : (o = a)
                      : (n = a);
                  }
                  return n || r || o;
                })(l, r);
                if (!p) return !1;
                if (
                  (f[p] || []).find(function () {
                    var e =
                      arguments.length > 0 && void 0 !== arguments[0]
                        ? arguments[0]
                        : {};
                    return (
                      e.appId === i &&
                      (e.platform || "").toLowerCase() === c.toLowerCase()
                    );
                  })
                )
                  return !0;
                throw (
                  (console.error(
                    "此应用[appId: "
                      .concat(i, ", platform: ")
                      .concat(
                        c,
                        "]不在云端配置的允许访问的应用列表内，参考：https://uniapp.dcloud.net.cn/uniCloud/secure-network.html#verify-client"
                      )
                  ),
                  Gp(Qp))
                );
              })({ provider: u, spaceId: f, functionName: l })
            ? new Wp({
                secretType: t.secretType,
                uniCloudIns: e,
              }).wrapVerifyClientCallFunction(n.bind(e))(t)
            : r(t))),
      Object.defineProperty(o, "result", {
        get: function () {
          return (
            console.warn(
              "当前返回结果为Promise类型，不可直接访问其result属性，详情请参考：https://uniapp.dcloud.net.cn/uniCloud/faq?id=promise"
            ),
            {}
          );
        },
      }),
      o.then(function (e) {
        return (
          "undefined" != typeof UTSJSONObject &&
            (e.result = new UTSJSONObject(e.result)),
          e
        );
      })
    );
  };
}
Wp = l(function e() {
  throw (
    (f(this, e),
    Gp({
      message: "Platform ".concat(
        $f,
        " is not enabled, please check whether secure network module is enabled in your manifest.json"
      ),
    }))
  );
});
var nh = Symbol("CLIENT_DB_INTERNAL");
function rh(e, t) {
  return (
    (e.then = "DoNotReturnProxyWithAFunctionNamedThen"),
    (e._internalType = nh),
    (e.inspect = null),
    (e.__v_raw = void 0),
    new Proxy(e, {
      get: function (e, n, r) {
        if ("_uniClient" === n) return null;
        if ("symbol" == d(n)) return e[n];
        if (n in e || "string" != typeof n) {
          var o = e[n];
          return "function" == typeof o ? o.bind(e) : o;
        }
        return t.get(e, n, r);
      },
    })
  );
}
function oh(e) {
  return {
    on: function (t, n) {
      (e[t] = e[t] || []), e[t].indexOf(n) > -1 || e[t].push(n);
    },
    off: function (t, n) {
      e[t] = e[t] || [];
      var r = e[t].indexOf(n);
      -1 !== r && e[t].splice(r, 1);
    },
  };
}
var ih = ["db.Geo", "db.command", "command.aggregate"];
function ah(e, t) {
  return ih.indexOf("".concat(e, ".").concat(t)) > -1;
}
function sh(e) {
  switch (
    Sf(
      (e = (function e(t) {
        return (t && e(t.__v_raw)) || t;
      })(e))
    )
  ) {
    case "array":
      return e.map(function (e) {
        return sh(e);
      });
    case "object":
      return (
        e._internalType === nh ||
          Object.keys(e).forEach(function (t) {
            e[t] = sh(e[t]);
          }),
        e
      );
    case "regexp":
      return { $regexp: { source: e.source, flags: e.flags } };
    case "date":
      return { $date: e.toISOString() };
    default:
      return e;
  }
}
function ch(e) {
  return e && e.content && e.content.$method;
}
var uh = (function () {
  return l(
    function e(t, n, r) {
      f(this, e),
        (this.content = t),
        (this.prevStage = n || null),
        (this.udb = null),
        (this._database = r);
    },
    [
      {
        key: "toJSON",
        value: function () {
          for (var e = this, t = [e.content]; e.prevStage; )
            (e = e.prevStage), t.push(e.content);
          return {
            $db: t.reverse().map(function (e) {
              return { $method: e.$method, $param: sh(e.$param) };
            }),
          };
        },
      },
      {
        key: "toString",
        value: function () {
          return JSON.stringify(this.toJSON());
        },
      },
      {
        key: "getAction",
        value: function () {
          var e = this.toJSON().$db.find(function (e) {
            return "action" === e.$method;
          });
          return e && e.$param && e.$param[0];
        },
      },
      {
        key: "getCommand",
        value: function () {
          return {
            $db: this.toJSON().$db.filter(function (e) {
              return "action" !== e.$method;
            }),
          };
        },
      },
      {
        key: "isAggregate",
        get: function () {
          for (var e = this; e; ) {
            var t = ch(e),
              n = ch(e.prevStage);
            if (("aggregate" === t && "collection" === n) || "pipeline" === t)
              return !0;
            e = e.prevStage;
          }
          return !1;
        },
      },
      {
        key: "isCommand",
        get: function () {
          for (var e = this; e; ) {
            if ("command" === ch(e)) return !0;
            e = e.prevStage;
          }
          return !1;
        },
      },
      {
        key: "isAggregateCommand",
        get: function () {
          for (var e = this; e; ) {
            var t = ch(e),
              n = ch(e.prevStage);
            if ("aggregate" === t && "command" === n) return !0;
            e = e.prevStage;
          }
          return !1;
        },
      },
      {
        key: "getNextStageFn",
        value: function (e) {
          var t = this;
          return function () {
            return fh(
              { $method: e, $param: sh(Array.from(arguments)) },
              t,
              t._database
            );
          };
        },
      },
      {
        key: "count",
        get: function () {
          return this.isAggregate
            ? this.getNextStageFn("count")
            : function () {
                return this._send("count", Array.from(arguments));
              };
        },
      },
      {
        key: "remove",
        get: function () {
          return this.isCommand
            ? this.getNextStageFn("remove")
            : function () {
                return this._send("remove", Array.from(arguments));
              };
        },
      },
      {
        key: "get",
        value: function () {
          return this._send("get", Array.from(arguments));
        },
      },
      {
        key: "add",
        get: function () {
          return this.isCommand
            ? this.getNextStageFn("add")
            : function () {
                return this._send("add", Array.from(arguments));
              };
        },
      },
      {
        key: "update",
        value: function () {
          return this._send("update", Array.from(arguments));
        },
      },
      {
        key: "end",
        value: function () {
          return this._send("end", Array.from(arguments));
        },
      },
      {
        key: "set",
        get: function () {
          return this.isCommand
            ? this.getNextStageFn("set")
            : function () {
                throw new Error("JQL禁止使用set方法");
              };
        },
      },
      {
        key: "_send",
        value: function (e, t) {
          var n = this.getAction(),
            r = this.getCommand();
          r.$db.push({ $method: e, $param: sh(t) });
          var o = r.$db.find(function (e) {
              return "collection" === e.$method;
            }),
            i = o && o.$param;
          return (
            i &&
              1 === i.length &&
              "string" == typeof o.$param[0] &&
              o.$param[0].indexOf(",") > -1 &&
              console.warn(
                "检测到使用JQL语法联表查询时，未使用getTemp先过滤主表数据，在主表数据量大的情况下可能会查询缓慢。\n- 如何优化请参考此文档：https://uniapp.dcloud.net.cn/uniCloud/jql?id=lookup-with-temp \n- 如果主表数据量很小请忽略此信息，项目发行时不会出现此提示。"
              ),
            this._database._callCloudFunction({ action: n, command: r })
          );
        },
      },
    ]
  );
})();
function fh(e, t, n) {
  return rh(new uh(e, t, n), {
    get: function (e, t) {
      var r = "db";
      return (
        e && e.content && (r = e.content.$method),
        ah(r, t)
          ? fh({ $method: t }, e, n)
          : function () {
              return fh(
                { $method: t, $param: sh(Array.from(arguments)) },
                e,
                n
              );
            }
      );
    },
  });
}
function lh(e) {
  var t = e.path,
    n = e.method;
  return (function () {
    return l(
      function e() {
        f(this, e), (this.param = Array.from(arguments));
      },
      [
        {
          key: "toJSON",
          value: function () {
            return {
              $newDb: [].concat(
                h(
                  t.map(function (e) {
                    return { $method: e };
                  })
                ),
                [{ $method: n, $param: this.param }]
              ),
            };
          },
        },
        {
          key: "toString",
          value: function () {
            return JSON.stringify(this.toJSON());
          },
        },
      ]
    );
  })();
}
function ph(e) {
  var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
  return rh(new e(t), {
    get: function (e, t) {
      return ah("db", t)
        ? fh({ $method: t }, null, e)
        : function () {
            return fh(
              { $method: t, $param: sh(Array.from(arguments)) },
              null,
              e
            );
          };
    },
  });
}
var hh = (function (e) {
    function t() {
      return f(this, t), m(this, t, arguments);
    }
    return (
      u(t, e),
      l(t, [
        {
          key: "_parseResult",
          value: function (e) {
            return this._isJQL ? e.result : e;
          },
        },
        {
          key: "_callCloudFunction",
          value: function (e) {
            var t = this,
              n = e.action,
              r = e.command,
              o = e.multiCommand,
              i = e.queryList;
            function a(e, t) {
              if (o && i)
                for (var n = 0; n < i.length; n++) {
                  var r = i[n];
                  r.udb &&
                    "function" == typeof r.udb.setResult &&
                    (t
                      ? r.udb.setResult(t)
                      : r.udb.setResult(e.result.dataList[n]));
                }
            }
            var s = this,
              c = this._isJQL ? "databaseForJQL" : "database";
            function u(e) {
              return (
                s._callback("error", [e]),
                Ff(Hf(c, "fail"), e)
                  .then(function () {
                    return Ff(Hf(c, "complete"), e);
                  })
                  .then(function () {
                    return (
                      a(null, e),
                      tl(Wf, { type: Yf, content: e }),
                      Promise.reject(e)
                    );
                  })
              );
            }
            var f = Ff(Hf(c, "invoke")),
              l = this._uniClient;
            return f
              .then(function () {
                return l.callFunction({
                  name: "DCloud-clientDB",
                  type: "CLIENT_DB",
                  data: { action: n, command: r, multiCommand: o },
                });
              })
              .then(
                function (e) {
                  var n = e.result,
                    r = n.code,
                    o = n.message,
                    i = n.token,
                    f = n.tokenExpired,
                    l = n.systemInfo,
                    p = void 0 === l ? [] : l;
                  if (p)
                    for (var h = 0; h < p.length; h++) {
                      var d = p[h],
                        v = d.level,
                        g = d.message,
                        m = d.detail,
                        y = console[v] || console.log,
                        _ = "[System Info]" + g;
                      m && (_ = "".concat(_, "\n详细信息：").concat(m)), y(_);
                    }
                  if (r)
                    return u(
                      new cl({ code: r, message: o, requestId: e.requestId })
                    );
                  (e.result.errCode = e.result.errCode || e.result.code),
                    (e.result.errMsg = e.result.errMsg || e.result.message),
                    i &&
                      f &&
                      (ll({ token: i, tokenExpired: f }),
                      t._callbackAuth("refreshToken", [
                        { token: i, tokenExpired: f },
                      ]),
                      t._callback("refreshToken", [
                        { token: i, tokenExpired: f },
                      ]),
                      tl(Jf, { token: i, tokenExpired: f }));
                  for (
                    var b = [
                        {
                          prop: "affectedDocs",
                          tips: "affectedDocs不再推荐使用，请使用inserted/deleted/updated/data.length替代",
                        },
                        {
                          prop: "code",
                          tips: "code不再推荐使用，请使用errCode替代",
                        },
                        {
                          prop: "message",
                          tips: "message不再推荐使用，请使用errMsg替代",
                        },
                      ],
                      w = function () {
                        var t = b[k],
                          n = t.prop,
                          r = t.tips;
                        if ((n in e.result)) {
                          var o = e.result[n];
                          Object.defineProperty(e.result, n, {
                            get: function () {
                              return console.warn(r), o;
                            },
                          });
                        }
                      },
                      k = 0;
                    k < b.length;
                    k++
                  )
                    w();
                  return (function (e) {
                    return Ff(Hf(c, "success"), e)
                      .then(function () {
                        return Ff(Hf(c, "complete"), e);
                      })
                      .then(function () {
                        a(e, null);
                        var t = s._parseResult(e);
                        return (
                          tl(Wf, { type: Yf, content: t }), Promise.resolve(t)
                        );
                      });
                  })(e);
                },
                function (e) {
                  return (
                    /fc_function_not_found|FUNCTION_NOT_FOUND/g.test(
                      e.message
                    ) &&
                      console.warn(
                        "clientDB未初始化，请在web控制台保存一次schema以开启clientDB"
                      ),
                    u(
                      new cl({
                        code: e.code || "SYSTEM_ERROR",
                        message: e.message,
                        requestId: e.requestId,
                      })
                    )
                  );
                }
              );
          },
        },
      ])
    );
  })(
    (function () {
      return l(
        function e() {
          var t =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : {},
            n = t.uniClient,
            r = void 0 === n ? {} : n,
            o = t.isJQL,
            i = void 0 !== o && o;
          f(this, e),
            (this._uniClient = r),
            (this._authCallBacks = {}),
            (this._dbCallBacks = {}),
            r._isDefault &&
              (this._dbCallBacks = Df("_globalUniCloudDatabaseCallback")),
            i || (this.auth = oh(this._authCallBacks)),
            (this._isJQL = i),
            Object.assign(this, oh(this._dbCallBacks)),
            (this.env = rh(
              {},
              {
                get: function (e, t) {
                  return { $env: t };
                },
              }
            )),
            (this.Geo = rh(
              {},
              {
                get: function (e, t) {
                  return lh({ path: ["Geo"], method: t });
                },
              }
            )),
            (this.serverDate = lh({ path: [], method: "serverDate" })),
            (this.RegExp = lh({ path: [], method: "RegExp" }));
        },
        [
          {
            key: "getCloudEnv",
            value: function (e) {
              if ("string" != typeof e || !e.trim())
                throw new Error("getCloudEnv参数错误");
              return { $env: e.replace("$cloudEnv_", "") };
            },
          },
          {
            key: "_callback",
            value: function (e, t) {
              var n = this._dbCallBacks;
              n[e] &&
                n[e].forEach(function (e) {
                  e.apply(void 0, h(t));
                });
            },
          },
          {
            key: "_callbackAuth",
            value: function (e, t) {
              var n = this._authCallBacks;
              n[e] &&
                n[e].forEach(function (e) {
                  e.apply(void 0, h(t));
                });
            },
          },
          {
            key: "multiSend",
            value: function () {
              var e = Array.from(arguments),
                t = e.map(function (e) {
                  var t = e.getAction(),
                    n = e.getCommand();
                  if ("getTemp" !== n.$db[n.$db.length - 1].$method)
                    throw new Error("multiSend只支持子命令内使用getTemp");
                  return { action: t, command: n };
                });
              return this._callCloudFunction({ multiCommand: t, queryList: e });
            },
          },
        ]
      );
    })()
  ),
  dh = "token无效，跳转登录页面",
  vh = "token过期，跳转登录页面",
  gh = {
    TOKEN_INVALID_TOKEN_EXPIRED: vh,
    TOKEN_INVALID_INVALID_CLIENTID: dh,
    TOKEN_INVALID: dh,
    TOKEN_INVALID_WRONG_TOKEN: dh,
    TOKEN_INVALID_ANONYMOUS_USER: dh,
  },
  mh = {
    "uni-id-token-expired": vh,
    "uni-id-check-token-failed": dh,
    "uni-id-token-not-exist": dh,
    "uni-id-check-device-feature-failed": dh,
  };
function yh(e, t) {
  return (e ? "".concat(e, "/").concat(t) : t).replace(/^\//, "");
}
function _h() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
    n = [],
    r = [];
  return (
    e.forEach(function (e) {
      !0 === e.needLogin
        ? n.push(yh(t, e.path))
        : !1 === e.needLogin && r.push(yh(t, e.path));
    }),
    { needLoginPage: n, notNeedLoginPage: r }
  );
}
function bh(e) {
  return e.split("?")[0].replace(/^\//, "");
}
function wh() {
  return (function (e) {
    var t = (e && e.$page && e.$page.fullPath) || "";
    return t ? ("/" !== t.charAt(0) && (t = "/" + t), t) : t;
  })(
    (function () {
      var e = getCurrentPages();
      return e[e.length - 1];
    })()
  );
}
function kh() {
  return bh(wh());
}
function xh() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
  if (!e) return !1;
  if (!(t && t.list && t.list.length)) return !1;
  var n = t.list,
    r = bh(e);
  return n.some(function (e) {
    return e.pagePath === r;
  });
}
var Sh,
  Ph = !!df.uniIdRouter,
  Th = (function () {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : df,
      t = e.pages,
      n = void 0 === t ? [] : t,
      r = e.subPackages,
      o = void 0 === r ? [] : r,
      i = e.uniIdRouter,
      a = void 0 === i ? {} : i,
      s = e.tabBar,
      c = void 0 === s ? {} : s,
      u = a.loginPage,
      f = a.needLogin,
      l = void 0 === f ? [] : f,
      p = a.resToLogin,
      d = void 0 === p || p,
      v = _h(n),
      g = v.needLoginPage,
      m = v.notNeedLoginPage,
      y = (function () {
        var e =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
          t = [],
          n = [];
        return (
          e.forEach(function (e) {
            var r = e.root,
              o = e.pages,
              i = _h(void 0 === o ? [] : o, r),
              a = i.needLoginPage,
              s = i.notNeedLoginPage;
            t.push.apply(t, h(a)), n.push.apply(n, h(s));
          }),
          { needLoginPage: t, notNeedLoginPage: n }
        );
      })(o),
      _ = y.needLoginPage,
      b = y.notNeedLoginPage;
    return {
      loginPage: u,
      routerNeedLogin: l,
      resToLogin: d,
      needLoginPage: [].concat(h(g), h(_)),
      notNeedLoginPage: [].concat(h(m), h(b)),
      loginPageInTabBar: xh(u, c),
    };
  })(),
  Oh = Th.loginPage,
  Ah = Th.routerNeedLogin,
  Ih = Th.resToLogin,
  Ch = Th.needLoginPage,
  Eh = Th.notNeedLoginPage,
  Lh = Th.loginPageInTabBar;
if (Ch.indexOf(Oh) > -1)
  throw new Error(
    "Login page [".concat(
      Oh,
      '] should not be "needLogin", please check your pages.json'
    )
  );
function $h(e) {
  var t = kh();
  if ("/" === e.charAt(0)) return e;
  var n = e.split("?"),
    r = v(n, 2),
    o = r[0],
    i = r[1],
    a = o.replace(/^\//, "").split("/"),
    s = t.split("/");
  s.pop();
  for (var c = 0; c < a.length; c++) {
    var u = a[c];
    ".." === u ? s.pop() : "." !== u && s.push(u);
  }
  return "" === s[0] && s.shift(), "/" + s.join("/") + (i ? "?" + i : "");
}
function Rh(e) {
  var t = bh($h(e));
  return (
    !(Eh.indexOf(t) > -1) &&
    (Ch.indexOf(t) > -1 ||
      Ah.some(function (t) {
        return (n = e), new RegExp(t).test(n);
        var n;
      }))
  );
}
function jh(e) {
  var t = bh(e.redirect),
    n = bh(Oh);
  return kh() !== n && t !== n;
}
function Mh() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
    t = e.api,
    n = e.redirect;
  if (n && jh({ redirect: n })) {
    var r,
      o,
      i =
        ((o = n),
        "/" !== (r = Oh).charAt(0) && (r = "/" + r),
        o
          ? r.indexOf("?") > -1
            ? r + "&uniIdRedirectUrl=".concat(encodeURIComponent(o))
            : r + "?uniIdRedirectUrl=".concat(encodeURIComponent(o))
          : r);
    Lh
      ? ("navigateTo" !== t && "redirectTo" !== t) || (t = "switchTab")
      : "switchTab" === t && (t = "navigateTo");
    var a = {
      navigateTo: Dn.navigateTo,
      redirectTo: Dn.redirectTo,
      switchTab: Dn.switchTab,
      reLaunch: Dn.reLaunch,
    };
    setTimeout(function () {
      a[t]({ url: i });
    }, 0);
  }
}
function Dh() {
  var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
    t = e.url,
    n = { abortLoginPageJump: !1, autoToLoginPage: !1 },
    r = (function () {
      var e,
        t = fl(),
        n = t.token,
        r = t.tokenExpired;
      if (n) {
        if (r < Date.now()) {
          var o = "uni-id-token-expired";
          e = { errCode: o, errMsg: mh[o] };
        }
      } else {
        var i = "uni-id-check-token-failed";
        e = { errCode: i, errMsg: mh[i] };
      }
      return e;
    })();
  if (Rh(t) && r) {
    if (((r.uniIdRedirectUrl = t), Xf(zf).length > 0))
      return (
        setTimeout(function () {
          tl(zf, r);
        }, 0),
        (n.abortLoginPageJump = !0),
        n
      );
    n.autoToLoginPage = !0;
  }
  return n;
}
function Uh() {
  !(function () {
    var e = wh(),
      t = Dh({ url: e }),
      n = t.abortLoginPageJump,
      r = t.autoToLoginPage;
    n || (r && Mh({ api: "redirectTo", redirect: e }));
  })();
  for (
    var e = ["navigateTo", "redirectTo", "reLaunch", "switchTab"],
      t = function () {
        var t = e[n];
        Dn.addInterceptor(t, {
          invoke: function (e) {
            var n = Dh({ url: e.url }),
              r = n.abortLoginPageJump,
              o = n.autoToLoginPage;
            return r ? e : o ? (Mh({ api: t, redirect: $h(e.url) }), !1) : e;
          },
        });
      },
      n = 0;
    n < e.length;
    n++
  )
    t();
}
function Nh() {
  this.onResponse(function (e) {
    var t,
      n = e.type,
      r = e.content,
      o = !1;
    switch (n) {
      case "cloudobject":
        o = "object" == d((t = r)) && (t || {}).errCode in mh;
        break;
      case "clientdb":
        o = (function (e) {
          return "object" == d(e) && (e || {}).errCode in gh;
        })(r);
    }
    o &&
      (function () {
        var e =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          t = Xf(zf);
        ol().then(function () {
          var n = wh();
          if (n && jh({ redirect: n }))
            return t.length > 0
              ? tl(zf, Object.assign({ uniIdRedirectUrl: n }, e))
              : void (Oh && Mh({ api: "navigateTo", redirect: n }));
        });
      })(r);
  });
}
function qh(e) {
  var t;
  ((t = e).onResponse = function (e) {
    Zf(Wf, e);
  }),
    (t.offResponse = function (e) {
      el(Wf, e);
    }),
    (function (e) {
      (e.onNeedLogin = function (e) {
        Zf(zf, e);
      }),
        (e.offNeedLogin = function (e) {
          el(zf, e);
        }),
        Ph &&
          (Df("_globalUniCloudStatus").needLoginInit ||
            ((Df("_globalUniCloudStatus").needLoginInit = !0),
            ol().then(function () {
              Uh.call(e);
            }),
            Ih && Nh.call(e)));
    })(e),
    (function (e) {
      (e.onRefreshToken = function (e) {
        Zf(Jf, e);
      }),
        (e.offRefreshToken = function (e) {
          el(Jf, e);
        });
    })(e);
}
var Bh = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
  Fh = /^(?:[A-Za-z\d+/]{4})*?(?:[A-Za-z\d+/]{2}(?:==)?|[A-Za-z\d+/]{3}=?)?$/;
function Hh() {
  var e,
    t,
    n = fl().token || "",
    r = n.split(".");
  if (!n || 3 !== r.length)
    return { uid: null, role: [], permission: [], tokenExpired: 0 };
  try {
    e = JSON.parse(
      ((t = r[1]),
      decodeURIComponent(
        Sh(t)
          .split("")
          .map(function (e) {
            return "%" + ("00" + e.charCodeAt(0).toString(16)).slice(-2);
          })
          .join("")
      ))
    );
  } catch (e) {
    throw new Error("获取当前用户信息出错，详细错误信息为：" + e.message);
  }
  return (e.tokenExpired = 1e3 * e.exp), delete e.exp, delete e.iat, e;
}
Sh =
  "function" != typeof atob
    ? function (e) {
        if (((e = String(e).replace(/[\t\n\f\r ]+/g, "")), !Fh.test(e)))
          throw new Error(
            "Failed to execute 'atob' on 'Window': The string to be decoded is not correctly encoded."
          );
        var t;
        e += "==".slice(2 - (3 & e.length));
        for (var n, r, o = "", i = 0; i < e.length; )
          (t =
            (Bh.indexOf(e.charAt(i++)) << 18) |
            (Bh.indexOf(e.charAt(i++)) << 12) |
            ((n = Bh.indexOf(e.charAt(i++))) << 6) |
            (r = Bh.indexOf(e.charAt(i++)))),
            (o +=
              64 === n
                ? String.fromCharCode((t >> 16) & 255)
                : 64 === r
                ? String.fromCharCode((t >> 16) & 255, (t >> 8) & 255)
                : String.fromCharCode(
                    (t >> 16) & 255,
                    (t >> 8) & 255,
                    255 & t
                  ));
        return o;
      }
    : atob;
var Vh = (function (e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default")
    ? e.default
    : e;
})(
  vf(function (e, t) {
    Object.defineProperty(t, "__esModule", { value: !0 });
    var n = "chooseAndUploadFile:ok",
      r = "chooseAndUploadFile:fail";
    function o(e, t) {
      return (
        e.tempFiles.forEach(function (e, n) {
          e.name || (e.name = e.path.substring(e.path.lastIndexOf("/") + 1)),
            t && (e.fileType = t),
            (e.cloudPath =
              Date.now() + "_" + n + e.name.substring(e.name.lastIndexOf(".")));
        }),
        e.tempFilePaths ||
          (e.tempFilePaths = e.tempFiles.map(function (e) {
            return e.path;
          })),
        e
      );
    }
    function i(e, t, r) {
      var o = r.onChooseFile,
        i = r.onUploadProgress;
      return t
        .then(function (e) {
          if (o) {
            var t = o(e);
            if (void 0 !== t)
              return Promise.resolve(t).then(function (t) {
                return void 0 === t ? e : t;
              });
          }
          return e;
        })
        .then(function (t) {
          return !1 === t
            ? { errMsg: n, tempFilePaths: [], tempFiles: [] }
            : (function (e, t) {
                var r =
                    arguments.length > 2 && void 0 !== arguments[2]
                      ? arguments[2]
                      : 5,
                  o = arguments.length > 3 ? arguments[3] : void 0;
                (t = Object.assign({}, t)).errMsg = n;
                var i = t.tempFiles,
                  a = i.length,
                  s = 0;
                return new Promise(function (n) {
                  for (; s < r; ) c();
                  function c() {
                    var r = s++;
                    if (r >= a)
                      !i.find(function (e) {
                        return !e.url && !e.errMsg;
                      }) && n(t);
                    else {
                      var u = i[r];
                      e.uploadFile({
                        provider: u.provider,
                        filePath: u.path,
                        cloudPath: u.cloudPath,
                        fileType: u.fileType,
                        cloudPathAsRealPath: u.cloudPathAsRealPath,
                        onUploadProgress: function (e) {
                          (e.index = r),
                            (e.tempFile = u),
                            (e.tempFilePath = u.path),
                            o && o(e);
                        },
                      })
                        .then(function (e) {
                          (u.url = e.fileID), r < a && c();
                        })
                        .catch(function (e) {
                          (u.errMsg = e.errMsg || e.message), r < a && c();
                        });
                    }
                  }
                });
              })(e, t, 5, i);
        });
    }
    t.initChooseAndUploadFile = function (e) {
      return function () {
        var t,
          n,
          a,
          s,
          c,
          u,
          f =
            arguments.length > 0 && void 0 !== arguments[0]
              ? arguments[0]
              : { type: "all" };
        return "image" === f.type
          ? i(
              e,
              ((n = (t = f).count),
              (a = t.sizeType),
              (s = t.sourceType),
              (c = void 0 === s ? ["album", "camera"] : s),
              (u = t.extension),
              new Promise(function (e, t) {
                Dn.chooseImage({
                  count: n,
                  sizeType: a,
                  sourceType: c,
                  extension: u,
                  success: function (t) {
                    e(o(t, "image"));
                  },
                  fail: function (e) {
                    t({ errMsg: e.errMsg.replace("chooseImage:fail", r) });
                  },
                });
              })),
              f
            )
          : "video" === f.type
          ? i(
              e,
              (function (e) {
                var t = e.camera,
                  n = e.compressed,
                  i = e.maxDuration,
                  a = e.sourceType,
                  s = void 0 === a ? ["album", "camera"] : a,
                  c = e.extension;
                return new Promise(function (e, a) {
                  Dn.chooseVideo({
                    camera: t,
                    compressed: n,
                    maxDuration: i,
                    sourceType: s,
                    extension: c,
                    success: function (t) {
                      var n = t.tempFilePath,
                        r = t.duration,
                        i = t.size,
                        a = t.height,
                        s = t.width;
                      e(
                        o(
                          {
                            errMsg: "chooseVideo:ok",
                            tempFilePaths: [n],
                            tempFiles: [
                              {
                                name: (t.tempFile && t.tempFile.name) || "",
                                path: n,
                                size: i,
                                type: (t.tempFile && t.tempFile.type) || "",
                                width: s,
                                height: a,
                                duration: r,
                                fileType: "video",
                                cloudPath: "",
                              },
                            ],
                          },
                          "video"
                        )
                      );
                    },
                    fail: function (e) {
                      a({ errMsg: e.errMsg.replace("chooseVideo:fail", r) });
                    },
                  });
                });
              })(f),
              f
            )
          : i(
              e,
              (function (e) {
                var t = e.count,
                  n = e.extension;
                return new Promise(function (e, i) {
                  var a = Dn.chooseFile;
                  if (
                    (void 0 !== Mn &&
                      "function" == typeof Mn.chooseMessageFile &&
                      (a = Mn.chooseMessageFile),
                    "function" != typeof a)
                  )
                    return i({
                      errMsg:
                        r +
                        " 请指定 type 类型，该平台仅支持选择 image 或 video。",
                    });
                  a({
                    type: "all",
                    count: t,
                    extension: n,
                    success: function (t) {
                      e(o(t));
                    },
                    fail: function (e) {
                      i({ errMsg: e.errMsg.replace("chooseFile:fail", r) });
                    },
                  });
                });
              })(f),
              f
            );
      };
    };
  })
);
function Kh(e) {
  return {
    props: {
      localdata: {
        type: Array,
        default: function () {
          return [];
        },
      },
      options: {
        type: [Object, Array],
        default: function () {
          return {};
        },
      },
      spaceInfo: {
        type: Object,
        default: function () {
          return {};
        },
      },
      collection: { type: [String, Array], default: "" },
      action: { type: String, default: "" },
      field: { type: String, default: "" },
      orderby: { type: String, default: "" },
      where: { type: [String, Object], default: "" },
      pageData: { type: String, default: "add" },
      pageCurrent: { type: Number, default: 1 },
      pageSize: { type: Number, default: 20 },
      getcount: { type: [Boolean, String], default: !1 },
      gettree: { type: [Boolean, String], default: !1 },
      gettreepath: { type: [Boolean, String], default: !1 },
      startwith: { type: String, default: "" },
      limitlevel: { type: Number, default: 10 },
      groupby: { type: String, default: "" },
      groupField: { type: String, default: "" },
      distinct: { type: [Boolean, String], default: !1 },
      foreignKey: { type: String, default: "" },
      loadtime: { type: String, default: "auto" },
      manual: { type: Boolean, default: !1 },
    },
    data: function () {
      return {
        mixinDatacomLoading: !1,
        mixinDatacomHasMore: !1,
        mixinDatacomResData: [],
        mixinDatacomErrorMessage: "",
        mixinDatacomPage: {},
        mixinDatacomError: null,
      };
    },
    created: function () {
      var e = this;
      (this.mixinDatacomPage = {
        current: this.pageCurrent,
        size: this.pageSize,
        count: 0,
      }),
        this.$watch(
          function () {
            var t = [];
            return (
              [
                "pageCurrent",
                "pageSize",
                "localdata",
                "collection",
                "action",
                "field",
                "orderby",
                "where",
                "getont",
                "getcount",
                "gettree",
                "groupby",
                "groupField",
                "distinct",
              ].forEach(function (n) {
                t.push(e[n]);
              }),
              t
            );
          },
          function (t, n) {
            if ("manual" !== e.loadtime) {
              for (var r = !1, o = [], i = 2; i < t.length; i++)
                t[i] !== n[i] && (o.push(t[i]), (r = !0));
              t[0] !== n[0] && (e.mixinDatacomPage.current = e.pageCurrent),
                (e.mixinDatacomPage.size = e.pageSize),
                e.onMixinDatacomPropsChange(r, o);
            }
          }
        );
    },
    methods: {
      onMixinDatacomPropsChange: function (e, t) {},
      mixinDatacomEasyGet: function () {
        var e = this,
          t =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          n = t.getone,
          r = void 0 !== n && n,
          o = t.success,
          i = t.fail;
        this.mixinDatacomLoading ||
          ((this.mixinDatacomLoading = !0),
          (this.mixinDatacomErrorMessage = ""),
          (this.mixinDatacomError = null),
          this.mixinDatacomGet()
            .then(function (t) {
              e.mixinDatacomLoading = !1;
              var n = t.result,
                i = n.data,
                a = n.count;
              e.getcount && (e.mixinDatacomPage.count = a),
                (e.mixinDatacomHasMore = i.length < e.pageSize);
              var s = r ? (i.length ? i[0] : void 0) : i;
              (e.mixinDatacomResData = s), o && o(s);
            })
            .catch(function (t) {
              (e.mixinDatacomLoading = !1),
                (e.mixinDatacomErrorMessage = t),
                (e.mixinDatacomError = t),
                i && i(t);
            }));
      },
      mixinDatacomGet: function () {
        var t,
          n,
          r =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        (r = r || {}),
          (n =
            "undefined" != typeof __uniX && __uniX
              ? e.databaseForJQL(this.spaceInfo)
              : e.database(this.spaceInfo));
        var o = r.action || this.action;
        o && (n = n.action(o));
        var i = r.collection || this.collection;
        n = Array.isArray(i)
          ? (t = n).collection.apply(t, h(i))
          : n.collection(i);
        var a = r.where || this.where;
        a && Object.keys(a).length && (n = n.where(a));
        var s = r.field || this.field;
        s && (n = n.field(s));
        var c = r.foreignKey || this.foreignKey;
        c && (n = n.foreignKey(c));
        var u = r.groupby || this.groupby;
        u && (n = n.groupBy(u));
        var f = r.groupField || this.groupField;
        f && (n = n.groupField(f)),
          !0 === (void 0 !== r.distinct ? r.distinct : this.distinct) &&
            (n = n.distinct());
        var l = r.orderby || this.orderby;
        l && (n = n.orderBy(l));
        var p =
            void 0 !== r.pageCurrent
              ? r.pageCurrent
              : this.mixinDatacomPage.current,
          d = void 0 !== r.pageSize ? r.pageSize : this.mixinDatacomPage.size,
          v = void 0 !== r.getcount ? r.getcount : this.getcount,
          g = void 0 !== r.gettree ? r.gettree : this.gettree,
          m = void 0 !== r.gettreepath ? r.gettreepath : this.gettreepath,
          y = { getCount: v },
          _ = {
            limitLevel:
              void 0 !== r.limitlevel ? r.limitlevel : this.limitlevel,
            startWith: void 0 !== r.startwith ? r.startwith : this.startwith,
          };
        return (
          g && (y.getTree = _),
          m && (y.getTreePath = _),
          (n = n
            .skip(d * (p - 1))
            .limit(d)
            .get(y))
        );
      },
    },
  };
}
function Wh(e) {
  return Df(
    "_globalUniCloudSecureNetworkCache__{spaceId}".replace(
      "{spaceId}",
      e.config.spaceId
    )
  );
}
function zh() {
  return Jh.apply(this, arguments);
}
function Jh() {
  return (Jh = o(
    r().mark(function e() {
      var t,
        n,
        o,
        i,
        a,
        s,
        c,
        u = arguments;
      return r().wrap(
        function (e) {
          for (;;)
            switch ((e.prev = e.next)) {
              case 0:
                if (
                  ((t = u.length > 0 && void 0 !== u[0] ? u[0] : {}),
                  (n = t.openid),
                  (o = t.callLoginByWeixin),
                  (i = void 0 !== o && o),
                  (a = Wh(this)),
                  !n || !i)
                ) {
                  e.next = 4;
                  break;
                }
                throw new Error(
                  "[SecureNetwork] openid and callLoginByWeixin cannot be passed at the same time"
                );
              case 4:
                if (!n) {
                  e.next = 6;
                  break;
                }
                return e.abrupt("return", ((a.mpWeixinOpenid = n), {}));
              case 6:
                return (
                  (e.next = 8),
                  new Promise(function (e, t) {
                    Dn.login({
                      success: function (t) {
                        e(t.code);
                      },
                      fail: function (e) {
                        t(new Error(e.errMsg));
                      },
                    });
                  })
                );
              case 8:
                return (
                  (s = e.sent),
                  (c = this.importObject("uni-id-co", { customUI: !0 })),
                  (e.next = 12),
                  c.secureNetworkHandshakeByWeixin({
                    code: s,
                    callLoginByWeixin: i,
                  })
                );
              case 12:
                return (a.mpWeixinCode = s), e.abrupt("return", { code: s });
              case 14:
              case "end":
                return e.stop();
            }
        },
        e,
        this
      );
    })
  )).apply(this, arguments);
}
function Yh(e) {
  return Qh.apply(this, arguments);
}
function Qh() {
  return (Qh = o(
    r().mark(function e(t) {
      var n;
      return r().wrap(
        function (e) {
          for (;;)
            switch ((e.prev = e.next)) {
              case 0:
                return (
                  (n = Wh(this)),
                  e.abrupt(
                    "return",
                    (n.initPromise ||
                      (n.initPromise = zh
                        .call(this, t)
                        .then(function (e) {
                          return e;
                        })
                        .catch(function (e) {
                          throw (delete n.initPromise, e);
                        })),
                    n.initPromise)
                  )
                );
              case 2:
              case "end":
                return e.stop();
            }
        },
        e,
        this
      );
    })
  )).apply(this, arguments);
}
function Gh(e) {
  hl = e;
}
function Xh(e) {
  var t = {
    getSystemInfo: Dn.getSystemInfo,
    getPushClientId: Dn.getPushClientId,
  };
  return function (n) {
    return new Promise(function (r, o) {
      t[e](
        i(
          i({}, n),
          {},
          {
            success: function (e) {
              r(e);
            },
            fail: function (e) {
              o(e);
            },
          }
        )
      );
    });
  };
}
var Zh = (function (t) {
  function n() {
    var t;
    return (
      f(this, n),
      ((t = m(this, n))._uniPushMessageCallback = t._receivePushMessage.bind(
        e(t)
      )),
      (t._currentMessageId = -1),
      (t._payloadQueue = []),
      t
    );
  }
  return (
    u(n, t),
    l(n, [
      {
        key: "init",
        value: function () {
          var e = this;
          return Promise.all([
            Xh("getSystemInfo")(),
            Xh("getPushClientId")(),
          ]).then(
            function () {
              var t =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : [],
                n = v(t, 2),
                r = n[0],
                o = void 0 === r ? {} : r,
                i = o.appId,
                a = n[1],
                s = void 0 === a ? {} : a,
                c = s.cid;
              if (!i)
                throw new Error(
                  "Invalid appId, please check the manifest.json file"
                );
              if (!c) throw new Error("Invalid push client id");
              (e._appId = i),
                (e._pushClientId = c),
                (e._seqId =
                  Date.now() + "-" + Math.floor(9e5 * Math.random() + 1e5)),
                e.emit("open"),
                e._initMessageListener();
            },
            function (t) {
              throw (e.emit("error", t), e.close(), t);
            }
          );
        },
      },
      {
        key: "open",
        value:
          ((i = o(
            r().mark(function e() {
              return r().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return e.abrupt("return", this.init());
                      case 1:
                      case "end":
                        return e.stop();
                    }
                },
                e,
                this
              );
            })
          )),
          function () {
            return i.apply(this, arguments);
          }),
      },
      {
        key: "_isUniCloudSSE",
        value: function (e) {
          if ("receive" !== e.type) return !1;
          var t = e && e.data && e.data.payload;
          return !(
            !t ||
            "UNI_CLOUD_SSE" !== t.channel ||
            t.seqId !== this._seqId
          );
        },
      },
      {
        key: "_receivePushMessage",
        value: function (e) {
          if (this._isUniCloudSSE(e)) {
            var t = e && e.data && e.data.payload,
              n = t.action,
              r = t.messageId,
              o = t.message;
            this._payloadQueue.push({ action: n, messageId: r, message: o }),
              this._consumMessage();
          }
        },
      },
      {
        key: "_consumMessage",
        value: function () {
          for (var e = this; ; ) {
            var t = this._payloadQueue.find(function (t) {
              return t.messageId === e._currentMessageId + 1;
            });
            if (!t) break;
            this._currentMessageId++, this._parseMessagePayload(t);
          }
        },
      },
      {
        key: "_parseMessagePayload",
        value: function (e) {
          var t = e.action,
            n = e.messageId,
            r = e.message;
          "end" === t
            ? this._end({ messageId: n, message: r })
            : "message" === t &&
              this._appendMessage({ messageId: n, message: r });
        },
      },
      {
        key: "_appendMessage",
        value: function () {
          var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : {},
            t = (e.messageId, e.message);
          this.emit("message", t);
        },
      },
      {
        key: "_end",
        value: function () {
          var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : {},
            t = (e.messageId, e.message);
          this.emit("end", t), this.close();
        },
      },
      {
        key: "_initMessageListener",
        value: function () {
          Dn.onPushMessage(this._uniPushMessageCallback);
        },
      },
      {
        key: "_destroy",
        value: function () {
          Dn.offPushMessage(this._uniPushMessageCallback);
        },
      },
      {
        key: "toJSON",
        value: function () {
          return {
            appId: this._appId,
            pushClientId: this._pushClientId,
            seqId: this._seqId,
          };
        },
      },
      {
        key: "close",
        value: function () {
          this._destroy(), this.emit("close");
        },
      },
    ])
  );
  var i;
})(
  (function () {
    return l(
      function e() {
        f(this, e), (this._callback = {});
      },
      [
        {
          key: "addListener",
          value: function (e, t) {
            this._callback[e] || (this._callback[e] = []),
              this._callback[e].push(t);
          },
        },
        {
          key: "on",
          value: function (e, t) {
            return this.addListener(e, t);
          },
        },
        {
          key: "removeListener",
          value: function (e, t) {
            if (!t)
              throw new Error(
                'The "listener" argument must be of type function. Received undefined'
              );
            var n = this._callback[e];
            if (n) {
              var r = (function (e, t) {
                for (var n = e.length - 1; n >= 0; n--)
                  if (e[n] === t) return n;
                return -1;
              })(n, t);
              n.splice(r, 1);
            }
          },
        },
        {
          key: "off",
          value: function (e, t) {
            return this.removeListener(e, t);
          },
        },
        {
          key: "removeAllListener",
          value: function (e) {
            delete this._callback[e];
          },
        },
        {
          key: "emit",
          value: function (e) {
            for (
              var t = this._callback[e],
                n = arguments.length,
                r = new Array(n > 1 ? n - 1 : 0),
                o = 1;
              o < n;
              o++
            )
              r[o - 1] = arguments[o];
            if (t) for (var i = 0; i < t.length; i++) t[i].apply(t, r);
          },
        },
      ]
    );
  })()
);
function ed(e, t) {
  return td.apply(this, arguments);
}
function td() {
  return (td = o(
    r().mark(function e(t, n) {
      var o, a, s;
      return r().wrap(
        function (e) {
          for (;;)
            switch ((e.prev = e.next)) {
              case 0:
                return (
                  (o = "http://".concat(t, ":").concat(n, "/system/ping")),
                  (e.prev = 1),
                  (e.next = 4),
                  (s = { url: o, timeout: 500 }),
                  new Promise(function (e, t) {
                    ul.request(
                      i(
                        i({}, s),
                        {},
                        {
                          success: function (t) {
                            e(t);
                          },
                          fail: function (e) {
                            t(e);
                          },
                        }
                      )
                    );
                  })
                );
              case 4:
                return (
                  (a = e.sent),
                  e.abrupt("return", !(!a.data || 0 !== a.data.code))
                );
              case 8:
                return (
                  (e.prev = 8), (e.t0 = e.catch(1)), e.abrupt("return", !1)
                );
              case 11:
              case "end":
                return e.stop();
            }
        },
        e,
        null,
        [[1, 8]]
      );
    })
  )).apply(this, arguments);
}
function nd() {
  return (nd = o(
    r().mark(function e(t) {
      var n, i, a, s, c, u, f, l;
      return r().wrap(function (e) {
        for (;;)
          switch ((e.prev = e.next)) {
            case 0:
              if ((n = t.__dev__).debugInfo) {
                e.next = 3;
                break;
              }
              return e.abrupt("return");
            case 3:
              return (
                (i = n.debugInfo),
                (a = i.address),
                (s = i.servePort),
                (e.next = 8),
                (function () {
                  var e = o(
                    r().mark(function e(t, n) {
                      var o, i, a;
                      return r().wrap(function (e) {
                        for (;;)
                          switch ((e.prev = e.next)) {
                            case 0:
                              i = 0;
                            case 1:
                              if (!(i < t.length)) {
                                e.next = 11;
                                break;
                              }
                              return (a = t[i]), (e.next = 5), ed(a, n);
                            case 5:
                              if (!e.sent) {
                                e.next = 8;
                                break;
                              }
                              return (o = a), e.abrupt("break", 11);
                            case 8:
                              i++, (e.next = 1);
                              break;
                            case 11:
                              return e.abrupt("return", {
                                address: o,
                                port: n,
                              });
                            case 12:
                            case "end":
                              return e.stop();
                          }
                      }, e);
                    })
                  );
                  return function (t, n) {
                    return e.apply(this, arguments);
                  };
                })()(a, s)
              );
            case 8:
              if (((c = e.sent), !(u = c.address))) {
                e.next = 12;
                break;
              }
              return e.abrupt(
                "return",
                ((n.localAddress = u), void (n.localPort = s))
              );
            case 12:
              if (
                ((f = console.warn),
                (l = ""),
                "remote" === n.debugInfo.initialLaunchType
                  ? ((n.debugInfo.forceRemote = !0),
                    (l =
                      "当前客户端和HBuilderX不在同一局域网下（或其他网络原因无法连接HBuilderX），uniCloud本地调试服务不对当前客户端生效。\n- 如果不使用uniCloud本地调试服务，请直接忽略此信息。\n- 如需使用uniCloud本地调试服务，请将客户端与主机连接到同一局域网下并重新运行到客户端。"))
                  : (l =
                      "无法连接uniCloud本地调试服务，请检查当前客户端是否与主机在同一局域网下。\n- 如需使用uniCloud本地调试服务，请将客户端与主机连接到同一局域网下并重新运行到客户端。"),
                (l +=
                  "\n- 如果在HBuilderX开启的状态下切换过网络环境，请重启HBuilderX后再试\n- 检查系统防火墙是否拦截了HBuilderX自带的nodejs\n- 检查是否错误的使用拦截器修改uni.request方法的参数"),
                0 === $f.indexOf("mp-") &&
                  (l +=
                    "\n- 小程序中如何使用uniCloud，请参考：https://uniapp.dcloud.net.cn/uniCloud/publish.html#useinmp"),
                n.debugInfo.forceRemote)
              ) {
                e.next = 16;
                break;
              }
              throw new Error(l);
            case 16:
              f(l);
            case 17:
            case "end":
              return e.stop();
          }
      }, e);
    })
  )).apply(this, arguments);
}
var rd = { tcb: Tp, tencent: Tp, aliyun: wl, private: Ap, alipay: Up },
  od = new ((function () {
    return l(
      function e() {
        f(this, e);
      },
      [
        {
          key: "init",
          value: function (e) {
            var t,
              n,
              a = {},
              s = rd[e.provider];
            if (!s) throw new Error("未提供正确的provider参数");
            return (
              (function (e) {
                var t = {};
                (e.__dev__ = t), (t.debugLog = "app" === $f);
                var n = Rf;
                n && !n.code && (t.debugInfo = n);
                var r = new Cf({
                  createPromise: function () {
                    return (function (e) {
                      return nd.apply(this, arguments);
                    })(e);
                  },
                });
                t.initLocalNetwork = function () {
                  return r.exec();
                };
              })((a = s.init(e))),
              (function (e) {
                e._initPromiseHub ||
                  (e._initPromiseHub = new Cf({
                    createPromise: function () {
                      var t = Promise.resolve();
                      t = new Promise(function (e) {
                        setTimeout(function () {
                          e();
                        }, 1);
                      });
                      var n = e.auth();
                      return t
                        .then(function () {
                          return n.getLoginState();
                        })
                        .then(function (e) {
                          return e ? Promise.resolve() : n.signInAnonymously();
                        });
                    },
                  }));
              })(a),
              th(a),
              (n = (t = a).uploadFile),
              (t.uploadFile = function (e) {
                return n.call(this, e);
              }),
              (function (e) {
                (e.database = function (t) {
                  if (t && Object.keys(t).length > 0)
                    return e.init(t).database();
                  if (this._database) return this._database;
                  var n = ph(hh, { uniClient: e });
                  return (this._database = n), n;
                }),
                  (e.databaseForJQL = function (t) {
                    if (t && Object.keys(t).length > 0)
                      return e.init(t).databaseForJQL();
                    if (this._databaseForJQL) return this._databaseForJQL;
                    var n = ph(hh, { uniClient: e, isJQL: !0 });
                    return (this._databaseForJQL = n), n;
                  });
              })(a),
              (function (e) {
                (e.getCurrentUserInfo = Hh),
                  (e.chooseAndUploadFile = Vh.initChooseAndUploadFile(e)),
                  Object.assign(e, {
                    get mixinDatacom() {
                      return Kh(e);
                    },
                  }),
                  (e.SSEChannel = Zh),
                  (e.initSecureNetworkByWeixin = (function (e) {
                    return function () {
                      var t =
                          arguments.length > 0 && void 0 !== arguments[0]
                            ? arguments[0]
                            : {},
                        n = t.openid,
                        r = t.callLoginByWeixin,
                        o = void 0 !== r && r;
                      return Yh.call(e, { openid: n, callLoginByWeixin: o });
                    };
                  })(e)),
                  (e.setCustomClientInfo = Gh),
                  (e.importObject = (function (e) {
                    return function (t) {
                      var n =
                          arguments.length > 1 && void 0 !== arguments[1]
                            ? arguments[1]
                            : {},
                        a = (n = (function (e) {
                          var t =
                            arguments.length > 1 && void 0 !== arguments[1]
                              ? arguments[1]
                              : {};
                          return (
                            (e.customUI = t.customUI || e.customUI),
                            (e.parseSystemError =
                              t.parseSystemError || e.parseSystemError),
                            Object.assign(e.loadingOptions, t.loadingOptions),
                            Object.assign(e.errorOptions, t.errorOptions),
                            "object" == d(t.secretMethods) &&
                              (e.secretMethods = t.secretMethods),
                            e
                          );
                        })(
                          {
                            customUI: !1,
                            loadingOptions: { title: "加载中...", mask: !0 },
                            errorOptions: { type: "modal", retry: !1 },
                          },
                          n
                        )),
                        s = a.customUI,
                        c = a.loadingOptions,
                        u = a.errorOptions,
                        f = a.parseSystemError,
                        l = !s;
                      return new Proxy(
                        {},
                        {
                          get: function (a, s) {
                            switch (s) {
                              case "toString":
                                return "[object UniCloudObject]";
                              case "toJSON":
                                return {};
                            }
                            return (function () {
                              var e =
                                  arguments.length > 0 &&
                                  void 0 !== arguments[0]
                                    ? arguments[0]
                                    : {},
                                t = e.fn,
                                n = e.interceptorName,
                                a = e.getCallbackArgs;
                              return o(
                                r().mark(function e() {
                                  var o,
                                    s,
                                    c,
                                    u,
                                    f,
                                    l,
                                    p = arguments;
                                  return r().wrap(
                                    function (e) {
                                      for (;;)
                                        switch ((e.prev = e.next)) {
                                          case 0:
                                            for (
                                              o = p.length,
                                                s = new Array(o),
                                                c = 0;
                                              c < o;
                                              c++
                                            )
                                              s[c] = p[c];
                                            return (
                                              (u = a ? a({ params: s }) : {}),
                                              (e.prev = 2),
                                              (e.next = 5),
                                              Ff(Hf(n, "invoke"), i({}, u))
                                            );
                                          case 5:
                                            return (
                                              (e.next = 7), t.apply(void 0, s)
                                            );
                                          case 7:
                                            return (
                                              (f = e.sent),
                                              (e.next = 10),
                                              Ff(
                                                Hf(n, "success"),
                                                i(i({}, u), {}, { result: f })
                                              )
                                            );
                                          case 10:
                                            return e.abrupt("return", f);
                                          case 13:
                                            return (
                                              (e.prev = 13),
                                              (e.t0 = e.catch(2)),
                                              (l = e.t0),
                                              (e.next = 18),
                                              Ff(
                                                Hf(n, "fail"),
                                                i(i({}, u), {}, { error: l })
                                              )
                                            );
                                          case 18:
                                            throw l;
                                          case 19:
                                            return (
                                              (e.prev = 19),
                                              (e.next = 22),
                                              Ff(
                                                Hf(n, "complete"),
                                                i(
                                                  i({}, u),
                                                  {},
                                                  l
                                                    ? { error: l }
                                                    : { result: f }
                                                )
                                              )
                                            );
                                          case 22:
                                            return e.finish(19);
                                          case 23:
                                          case "end":
                                            return e.stop();
                                        }
                                    },
                                    e,
                                    null,
                                    [[2, 13, 19, 23]]
                                  );
                                })
                              );
                            })({
                              fn: (function () {
                                var a = o(
                                  r().mark(function a() {
                                    var h,
                                      v,
                                      g,
                                      m,
                                      y,
                                      _,
                                      b,
                                      w,
                                      k,
                                      x,
                                      S,
                                      P,
                                      T,
                                      O,
                                      A,
                                      I = arguments;
                                    return r().wrap(
                                      function (a) {
                                        for (;;)
                                          switch ((a.prev = a.next)) {
                                            case 0:
                                              for (
                                                l &&
                                                  Dn.showLoading({
                                                    title: c.title,
                                                    mask: c.mask,
                                                  }),
                                                  v = I.length,
                                                  g = new Array(v),
                                                  m = 0;
                                                m < v;
                                                m++
                                              )
                                                g[m] = I[m];
                                              return (
                                                (y = {
                                                  name: t,
                                                  type: wf,
                                                  data: {
                                                    method: s,
                                                    params: g,
                                                  },
                                                }),
                                                "object" ==
                                                  d(n.secretMethods) &&
                                                  (function (e, t) {
                                                    var n = t.data.method,
                                                      r = e.secretMethods || {},
                                                      o = r[n] || r["*"];
                                                    o && (t.secretType = o);
                                                  })(n, y),
                                                (_ = !1),
                                                (a.prev = 5),
                                                (a.next = 8),
                                                e.callFunction(y)
                                              );
                                            case 8:
                                              (h = a.sent), (a.next = 14);
                                              break;
                                            case 11:
                                              (a.prev = 11),
                                                (a.t0 = a.catch(5)),
                                                (_ = !0),
                                                (h = { result: new cl(a.t0) });
                                            case 14:
                                              if (
                                                ((b = h.result || {}),
                                                (w = b.errSubject),
                                                (k = b.errCode),
                                                (x = b.errMsg),
                                                (S = b.newToken),
                                                l && Dn.hideLoading(),
                                                S &&
                                                  S.token &&
                                                  S.tokenExpired &&
                                                  (ll(S), tl(Jf, i({}, S))),
                                                !k)
                                              ) {
                                                a.next = 39;
                                                break;
                                              }
                                              if (((P = x), !_ || !f)) {
                                                a.next = 24;
                                                break;
                                              }
                                              return (
                                                (a.next = 20),
                                                f({
                                                  objectName: t,
                                                  methodName: s,
                                                  params: g,
                                                  errSubject: w,
                                                  errCode: k,
                                                  errMsg: x,
                                                })
                                              );
                                            case 20:
                                              if (
                                                ((a.t1 = a.sent.errMsg), a.t1)
                                              ) {
                                                a.next = 23;
                                                break;
                                              }
                                              a.t1 = x;
                                            case 23:
                                              P = a.t1;
                                            case 24:
                                              if (!l) {
                                                a.next = 37;
                                                break;
                                              }
                                              if ("toast" !== u.type) {
                                                a.next = 29;
                                                break;
                                              }
                                              Dn.showToast({
                                                title: P,
                                                icon: "none",
                                              }),
                                                (a.next = 37);
                                              break;
                                            case 29:
                                              if ("modal" === u.type) {
                                                a.next = 31;
                                                break;
                                              }
                                              throw new Error(
                                                "Invalid errorOptions.type: ".concat(
                                                  u.type
                                                )
                                              );
                                            case 31:
                                              return (
                                                (a.next = 33),
                                                o(
                                                  r().mark(function e() {
                                                    var t,
                                                      n,
                                                      o,
                                                      i,
                                                      a,
                                                      s,
                                                      c = arguments;
                                                    return r().wrap(function (
                                                      e
                                                    ) {
                                                      for (;;)
                                                        switch (
                                                          (e.prev = e.next)
                                                        ) {
                                                          case 0:
                                                            return (
                                                              (t =
                                                                c.length > 0 &&
                                                                void 0 !== c[0]
                                                                  ? c[0]
                                                                  : {}),
                                                              (n = t.title),
                                                              (o = t.content),
                                                              (i =
                                                                t.showCancel),
                                                              (a =
                                                                t.cancelText),
                                                              (s =
                                                                t.confirmText),
                                                              e.abrupt(
                                                                "return",
                                                                new Promise(
                                                                  function (
                                                                    e,
                                                                    t
                                                                  ) {
                                                                    Dn.showModal(
                                                                      {
                                                                        title:
                                                                          n,
                                                                        content:
                                                                          o,
                                                                        showCancel:
                                                                          i,
                                                                        cancelText:
                                                                          a,
                                                                        confirmText:
                                                                          s,
                                                                        success:
                                                                          function (
                                                                            t
                                                                          ) {
                                                                            e(
                                                                              t
                                                                            );
                                                                          },
                                                                        fail: function () {
                                                                          e({
                                                                            confirm:
                                                                              !1,
                                                                            cancel:
                                                                              !0,
                                                                          });
                                                                        },
                                                                      }
                                                                    );
                                                                  }
                                                                )
                                                              )
                                                            );
                                                          case 2:
                                                          case "end":
                                                            return e.stop();
                                                        }
                                                    },
                                                    e);
                                                  })
                                                )({
                                                  title: "提示",
                                                  content: P,
                                                  showCancel: u.retry,
                                                  cancelText: "取消",
                                                  confirmText: u.retry
                                                    ? "重试"
                                                    : "确定",
                                                })
                                              );
                                            case 33:
                                              if (
                                                ((T = a.sent),
                                                (O = T.confirm),
                                                !u.retry || !O)
                                              ) {
                                                a.next = 37;
                                                break;
                                              }
                                              return a.abrupt(
                                                "return",
                                                p.apply(void 0, g)
                                              );
                                            case 37:
                                              throw (
                                                (((A = new cl({
                                                  subject: w,
                                                  code: k,
                                                  message: x,
                                                  requestId: h.requestId,
                                                })).detail = h.result),
                                                tl(Wf, {
                                                  type: Gf,
                                                  content: A,
                                                }),
                                                A)
                                              );
                                            case 39:
                                              return a.abrupt(
                                                "return",
                                                (tl(Wf, {
                                                  type: Gf,
                                                  content: h.result,
                                                }),
                                                h.result)
                                              );
                                            case 40:
                                            case "end":
                                              return a.stop();
                                          }
                                      },
                                      a,
                                      null,
                                      [[5, 11]]
                                    );
                                  })
                                );
                                function p() {
                                  return a.apply(this, arguments);
                                }
                                return p;
                              })(),
                              interceptorName: "callObject",
                              getCallbackArgs: function () {
                                var e =
                                    arguments.length > 0 &&
                                    void 0 !== arguments[0]
                                      ? arguments[0]
                                      : {},
                                  n = e.params;
                                return {
                                  objectName: t,
                                  methodName: s,
                                  params: n,
                                };
                              },
                            });
                          },
                        }
                      );
                    };
                  })(e));
              })(a),
              [
                "callFunction",
                "uploadFile",
                "deleteFile",
                "getTempFileURL",
                "downloadFile",
                "chooseAndUploadFile",
              ].forEach(function (e) {
                if (a[e]) {
                  var t = a[e];
                  (a[e] = function () {
                    return t.apply(a, Array.from(arguments));
                  }),
                    (a[e] = (function (e, t) {
                      return function (n) {
                        var r = this,
                          o = !1;
                        if ("callFunction" === t) {
                          var i = (n && n.type) || bf;
                          o = i !== bf;
                        }
                        var a = "callFunction" === t && !o,
                          s = this._initPromiseHub.exec(),
                          c = il((n = n || {})),
                          u = c.success,
                          f = c.fail,
                          l = c.complete,
                          p = s
                            .then(function () {
                              return o
                                ? Promise.resolve()
                                : Ff(Hf(t, "invoke"), n);
                            })
                            .then(function () {
                              return e.call(r, n);
                            })
                            .then(
                              function (e) {
                                return o
                                  ? Promise.resolve(e)
                                  : Ff(Hf(t, "success"), e)
                                      .then(function () {
                                        return Ff(Hf(t, "complete"), e);
                                      })
                                      .then(function () {
                                        return (
                                          a && tl(Wf, { type: Qf, content: e }),
                                          Promise.resolve(e)
                                        );
                                      });
                              },
                              function (e) {
                                return o
                                  ? Promise.reject(e)
                                  : Ff(Hf(t, "fail"), e)
                                      .then(function () {
                                        return Ff(Hf(t, "complete"), e);
                                      })
                                      .then(function () {
                                        return (
                                          tl(Wf, { type: Qf, content: e }),
                                          Promise.reject(e)
                                        );
                                      });
                              }
                            );
                        if (!(u || f || l)) return p;
                        p.then(
                          function (e) {
                            u && u(e),
                              l && l(e),
                              a && tl(Wf, { type: Qf, content: e });
                          },
                          function (e) {
                            f && f(e),
                              l && l(e),
                              a && tl(Wf, { type: Qf, content: e });
                          }
                        );
                      };
                    })(a[e], e).bind(a));
                }
              }),
              (a.init = this.init),
              a
            );
          },
        },
      ]
    );
  })())();
!(function () {
  var e = jf,
    t = {};
  if (e && 1 === e.length) (t = e[0]), ((od = od.init(t))._isDefault = !0);
  else {
    var n;
    (n =
      e && e.length > 0
        ? "应用有多个服务空间，请通过uniCloud.init方法指定要使用的服务空间"
        : "uni-app cli项目内使用uniCloud需要使用HBuilderX的运行菜单运行项目，且需要在uniCloud目录关联服务空间"),
      [
        "auth",
        "callFunction",
        "uploadFile",
        "deleteFile",
        "getTempFileURL",
        "downloadFile",
        "database",
        "getCurrentUSerInfo",
        "importObject",
      ].forEach(function (e) {
        od[e] = function () {
          return (
            console.error(n),
            Promise.reject(new cl({ code: "SYS_ERR", message: n }))
          );
        };
      });
  }
  Object.assign(od, {
    get mixinDatacom() {
      return Kh(od);
    },
  }),
    qh(od),
    (od.addInterceptor = qf),
    (od.removeInterceptor = Bf),
    (od.interceptObject = Vf);
})();
var id = od;
(exports.Pinia = ff),
  (exports.Vs = id),
  (exports._export_sfc = function (e, t) {
    var n,
      r = e.__vccOpts || e,
      o = g(t);
    try {
      for (o.s(); !(n = o.n()).done; ) {
        var i = v(n.value, 2),
          a = i[0],
          s = i[1];
        r[a] = s;
      }
    } catch (e) {
      o.e(e);
    } finally {
      o.f();
    }
    return r;
  }),
  (exports.computed = qs),
  (exports.createPinia = Hu),
  (exports.createSSRApp = $c),
  (exports.dayjs = hf),
  (exports.defineComponent = function (e, t) {
    return $(e)
      ? (function () {
          return T({ name: e.name }, t, { setup: e });
        })()
      : e;
  }),
  (exports.defineStore = af),
  (exports.e = function (e) {
    for (
      var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1;
      r < t;
      r++
    )
      n[r - 1] = arguments[r];
    return T.apply(void 0, [e].concat(n));
  }),
  (exports.f = function (e, t) {
    return (function (e, t) {
      var n;
      if (C(e) || R(e)) {
        n = new Array(e.length);
        for (var r = 0, o = e.length; r < o; r++) n[r] = t(e[r], r, r);
      } else if ("number" == typeof e) {
        if (!Number.isInteger(e))
          return (
            Fs(
              "The v-for range expect an integer value but got ".concat(e, ".")
            ),
            []
          );
        n = new Array(e);
        for (var i = 0; i < e; i++) n[i] = t(i + 1, i, i);
      } else if (M(e))
        if (e[Symbol.iterator])
          n = Array.from(e, function (e, n) {
            return t(e, n, n);
          });
        else {
          var a = Object.keys(e);
          n = new Array(a.length);
          for (var s = 0, c = a.length; s < c; s++) {
            var u = a[s];
            n[s] = t(e[u], u, s);
          }
        }
      else n = [];
      return n;
    })(e, t);
  }),
  (exports.index = Dn),
  (exports.initVueI18n = function (e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
      n = arguments.length > 2 ? arguments[2] : void 0,
      r = arguments.length > 3 ? arguments[3] : void 0;
    if ("string" != typeof e) {
      var o = [t, e];
      (e = o[0]), (t = o[1]);
    }
    "string" != typeof e && (e = Me()),
      "string" != typeof n &&
        (n =
          ("undefined" != typeof __uniConfig && __uniConfig.fallbackLocale) ||
          "en");
    var i = new Re({ locale: e, fallbackLocale: n, messages: t, watcher: r }),
      a = function (e, t) {
        if ("function" != typeof getApp)
          a = function (e, t) {
            return i.t(e, t);
          };
        else {
          var n = !1;
          a = function (e, t) {
            var r = getApp().$vm;
            return r && (r.$locale, n || ((n = !0), je(r, i))), i.t(e, t);
          };
        }
        return a(e, t);
      };
    return {
      i18n: i,
      f: function (e, t, n) {
        return i.f(e, t, n);
      },
      t: function (e, t) {
        return a(e, t);
      },
      add: function (e, t) {
        var n =
          !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        return i.add(e, t, n);
      },
      watch: function (e) {
        return i.watchLocale(e);
      },
      getLocale: function () {
        return i.getLocale();
      },
      setLocale: function (e) {
        return i.setLocale(e);
      },
    };
  }),
  (exports.n = function (e) {
    return (function e(t) {
      var n = "";
      if (R(t)) n = t;
      else if (C(t))
        for (var r = 0; r < t.length; r++) {
          var o = e(t[r]);
          o && (n += o + " ");
        }
      else if (M(t)) for (var i in t) t[i] && (n += i + " ");
      return n.trim();
    })(e);
  }),
  (exports.nextTick$1 = Oi),
  (exports.o = function (e, t) {
    return Cc(e, t);
  }),
  (exports.onBeforeUnmount = Pa),
  (exports.onHide = xu),
  (exports.onLaunch = Su),
  (exports.onLoad = Pu),
  (exports.onMounted = ka),
  (exports.onPageShow = Cu),
  (exports.onShareAppMessage = Iu),
  (exports.onShareTimeline = Au),
  (exports.onShow = ku),
  (exports.onTabItemTap = Ou),
  (exports.onUnload = Tu),
  (exports.onUnmounted = Ta),
  (exports.p = function (e) {
    return Tc(e);
  }),
  (exports.ref = Go),
  (exports.resolveComponent = function (e, t) {
    return (
      (function (e, t) {
        var n =
            !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
          r = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
          o = Zi || Ss;
        if (o) {
          var i = o.type,
            a = Us(i, !1);
          if (a && (a === t || a === z(t) || a === Q(z(t)))) return i;
          var s = ta(o[e] || i[e], t) || ta(o.appContext[e], t);
          if (!s && r) return i;
          if (n && !s) {
            var c =
              "\nIf this is a native custom element, make sure to exclude it from component resolution via compilerOptions.isCustomElement.";
            fi(
              "Failed to resolve "
                .concat(e.slice(0, -1), ": ")
                .concat(t)
                .concat(c)
            );
          }
          return s;
        }
        fi(
          "resolve".concat(
            Q(e.slice(0, -1)),
            " can only be used in render() or setup()."
          )
        );
      })("components", e, !0, t) || e
    );
  }),
  (exports.s = function (e) {
    return Lc(e);
  }),
  (exports.sr = function (e, t, n) {
    return (function (e, t) {
      var n =
          arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
        r = Ps(),
        o = r.$templateRefs;
      o.push({ i: t, r: e, k: n.k, f: n.f });
    })(e, t, n);
  }),
  (exports.t = function (e) {
    return (function (e) {
      return R(e)
        ? e
        : null == e
        ? ""
        : C(e) || (M(e) && (e.toString === U || !$(e.toString)))
        ? JSON.stringify(e, ae, 2)
        : String(e);
    })(e);
  }),
  (exports.unref = Zo),
  (exports.useCssVars = function (e) {
    var t = Ps();
    t
      ? (function (e, t) {
          e.ctx.__cssVars = function () {
            var n = t(e.proxy),
              r = {};
            for (var o in n) r["--".concat(o)] = n[o];
            return r;
          };
        })(t, e)
      : Fs("useCssVars is called without current active component instance.");
  }),
  (exports.watch = ra),
  (exports.wx$1 = Mn);
