var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  t = require("../../@babel/runtime/helpers/asyncToGenerator"),
  n = require("../../common/vendor.js"),
  r = require("../../common/assets.js"),
  a = require("../../api/index.js"),
  u = require("../../store/deviceStore.js"),
  c = n.defineComponent({
    __name: "index",
    setup: function (c) {
      var l = u.useDeviceStore(),
        s = n.ref(""),
        i = n.ref(""),
        o = n.ref([]),
        v = n.ref(-1);
      n.ref([]);
      var p = n.ref(!1),
        f = n.ref(""),
        d = n.ref(0),
        m = function (e) {
          var t, n;
          (b.value = null == (t = l.devices[e.detail.value]) ? void 0 : t.sn),
            (h.value =
              null == (n = l.devices[e.detail.value]) ? void 0 : n.productName);
        },
        h = n.ref(""),
        b = n.ref(""),
        g = n.computed(function () {
          return l.devices.map(function (e) {
            return (e.showDownName = e.productName + " (" + e.sn + ")"), e;
          });
        });
      n.onMounted(function () {
        var e, t;
        x(),
          1 === l.devices.length &&
            ((b.value = null == (e = l.devices[0]) ? void 0 : e.sn),
            (h.value = null == (t = l.devices[0]) ? void 0 : t.productName));
      });
      var x = (function () {
          var n = t(
            e().mark(function t() {
              var n, r;
              return e().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (e.next = 2), a.feedbackTypeList();
                    case 2:
                      (n = e.sent),
                        (r = n.data) &&
                          r.data &&
                          Array.isArray(r.data.list) &&
                          (o.value = r.data.list);
                    case 5:
                    case "end":
                      return e.stop();
                  }
              }, t);
            })
          );
          return function () {
            return n.apply(this, arguments);
          };
        })(),
        y = n.ref([]),
        k = n.ref([]),
        w = function () {
          var r = y.value.filter(function (e) {
              return "image" === e.type;
            }).length,
            u = y.value.filter(function (e) {
              return "video" === e.type;
            }).length,
            c = [],
            l = "all";
          r < 5 && u < 2 && (c = ["选择照片", "拍摄视频"]),
            r >= 5 && ((c = ["拍摄视频"]), (l = "video")),
            u >= 2 && ((c = ["选择照片"]), (l = "image")),
            0 !== c.length
              ? n.index.showActionSheet({
                  itemList: c,
                  success: function (r) {
                    var u, c;
                    "image" ===
                    ("all" === l ? (0 === r.tapIndex ? "image" : "video") : l)
                      ? n.index.chooseImage({
                          count: 1,
                          sizeType: ["original"],
                          success:
                            ((c = t(
                              e().mark(function t(r) {
                                var u, c, l, s;
                                return e().wrap(
                                  function (e) {
                                    for (;;)
                                      switch ((e.prev = e.next)) {
                                        case 0:
                                          if (
                                            ((c = r.tempFiles),
                                            console.log(c, "==========="),
                                            !(
                                              (null == (u = c[0])
                                                ? void 0
                                                : u.size) > 5242880
                                            ))
                                          ) {
                                            e.next = 5;
                                            break;
                                          }
                                          return (
                                            n.index.showToast({
                                              title: "图片不得超过5MB",
                                              icon: "none",
                                            }),
                                            e.abrupt("return")
                                          );
                                        case 5:
                                          if (0 !== c.length) {
                                            e.next = 7;
                                            break;
                                          }
                                          return e.abrupt("return");
                                        case 7:
                                          return (
                                            (f.value = "图片上传中..."),
                                            (p.value = !0),
                                            (e.prev = 9),
                                            (e.next = 12),
                                            a.commonFileUpload(
                                              r.tempFiles[0].path
                                            )
                                          );
                                        case 12:
                                          (l = e.sent),
                                            (s = l.data),
                                            console.log(
                                              s.bucketName,
                                              s.objectKey
                                            ),
                                            k.value.push({
                                              bucketName: s.bucketName,
                                              objectKey: s.objectKey,
                                            }),
                                            (y.value = y.value.concat(
                                              c.map(function (e) {
                                                return {
                                                  type: "image",
                                                  path: e.path,
                                                };
                                              })
                                            )),
                                            (p.value = !1),
                                            (e.next = 24);
                                          break;
                                        case 20:
                                          (e.prev = 20),
                                            (e.t0 = e.catch(9)),
                                            console.log(
                                              e.t0,
                                              "图片上传失败============="
                                            ),
                                            (p.value = !1);
                                        case 24:
                                        case "end":
                                          return e.stop();
                                      }
                                  },
                                  t,
                                  null,
                                  [[9, 20]]
                                );
                              })
                            )),
                            function (e) {
                              return c.apply(this, arguments);
                            }),
                          fail: function (e) {
                            console.log(e, "图片选择失败============="),
                              (p.value = !1);
                          },
                        })
                      : n.index.chooseVideo({
                          sourceType: ["camera", "album"],
                          maxDuration: 60,
                          success:
                            ((u = t(
                              e().mark(function t(r) {
                                var u, c;
                                return e().wrap(
                                  function (e) {
                                    for (;;)
                                      switch ((e.prev = e.next)) {
                                        case 0:
                                          if (!(r.size > 52428800)) {
                                            e.next = 3;
                                            break;
                                          }
                                          return (
                                            n.index.showToast({
                                              title: "视频不得超过50MB",
                                              icon: "none",
                                            }),
                                            e.abrupt("return")
                                          );
                                        case 3:
                                          return (
                                            (f.value = "视频上传中..."),
                                            (p.value = !0),
                                            (e.prev = 5),
                                            (e.next = 8),
                                            a.commonFileUpload(r.tempFilePath)
                                          );
                                        case 8:
                                          (u = e.sent),
                                            (c = u.data),
                                            console.log(
                                              c.bucketName,
                                              c.objectKey
                                            ),
                                            k.value.push({
                                              bucketName: c.bucketName,
                                              objectKey: c.objectKey,
                                            }),
                                            y.value.push({
                                              type: "video",
                                              path: r.tempFilePath,
                                            }),
                                            (p.value = !1),
                                            (e.next = 19);
                                          break;
                                        case 16:
                                          (e.prev = 16),
                                            (e.t0 = e.catch(5)),
                                            (p.value = !1);
                                        case 19:
                                        case "end":
                                          return e.stop();
                                      }
                                  },
                                  t,
                                  null,
                                  [[5, 16]]
                                );
                              })
                            )),
                            function (e) {
                              return u.apply(this, arguments);
                            }),
                        });
                  },
                })
              : n.index.showToast({ title: "已达最大上传数量", icon: "none" });
        },
        _ = n.ref(!1),
        j = n.ref("success"),
        N = function (e) {
          (j.value = e), (_.value = !0);
        },
        q = function () {
          (_.value = !1), "success" === j.value && n.index.navigateBack();
        },
        T = (function () {
          var n = t(
            e().mark(function t() {
              var n, r, u, c;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (!(l.devices.length > 0) || b.value) {
                          e.next = 3;
                          break;
                        }
                        return N("error"), e.abrupt("return");
                      case 3:
                        if (s.value) {
                          e.next = 6;
                          break;
                        }
                        return N("error"), e.abrupt("return");
                      case 6:
                        if (-1 !== v.value) {
                          e.next = 9;
                          break;
                        }
                        return N("error"), e.abrupt("return");
                      case 9:
                        if (i.value) {
                          e.next = 12;
                          break;
                        }
                        return N("error"), e.abrupt("return");
                      case 12:
                        if (
                          ((n = /^1[3-9]\d{9}$/),
                          (r = /^[^\s@]+@[^\s@]+\.[^\s@]+$/),
                          s.value && (n.test(s.value) || r.test(s.value)))
                        ) {
                          e.next = 17;
                          break;
                        }
                        return N("error"), e.abrupt("return");
                      case 17:
                        return (
                          (p.value = !0),
                          (f.value = "提交中..."),
                          (u = {
                            types: [o.value[v.value].type],
                            description: i.value,
                            contactInfo: s.value,
                            attachments: k.value,
                            sn: b.value,
                          }),
                          (e.prev = 20),
                          (e.next = 23),
                          a.feedbackSubmit(u)
                        );
                      case 23:
                        (c = e.sent),
                          "A00000" === c.data.resultCode &&
                            ((p.value = !1), N("success")),
                          (e.next = 31);
                        break;
                      case 28:
                        (e.prev = 28), (e.t0 = e.catch(20)), N("error");
                      case 31:
                        return (e.prev = 31), (p.value = !1), e.finish(31);
                      case 34:
                      case "end":
                        return e.stop();
                    }
                },
                t,
                null,
                [[20, 28, 31, 34]]
              );
            })
          );
          return function () {
            return n.apply(this, arguments);
          };
        })();
      return function (e, t) {
        return n.e(
          { a: n.unref(l).devices.length > 0 },
          (n.unref(l).devices.length, {}),
          {
            b: 0 === n.unref(l).devices.length,
            c: 0 === n.unref(l).devices.length ? "暂无玩具" : "请选择玩具",
            d: h.value,
            e: n.o(function (e) {
              return (h.value = e.detail.value);
            }),
            f: n.unref(l).devices.length > 0,
          },
          n.unref(l).devices.length > 0
            ? { g: d.value, h: g.value, i: n.o(m) }
            : {},
          { j: n.unref(l).devices.length > 0 },
          n.unref(l).devices.length > 0 ? { k: r._imports_0$9 } : {},
          {
            l: s.value,
            m: n.o(function (e) {
              return (s.value = e.detail.value);
            }),
            n: n.f(o.value, function (e, t, r) {
              return {
                a: n.t(e.name),
                b: e.type,
                c: n.n(
                  v.value === t ? "type-btn-selected" : "type-btn-unselected"
                ),
                d: n.o(function (e) {
                  return (v.value = t);
                }, e.type),
              };
            }),
            o: i.value,
            p: n.o(function (e) {
              return (i.value = e.detail.value);
            }),
            q: n.f(y.value, function (e, t, r) {
              return n.e(
                { a: "image" === e.type },
                "image" === e.type ? { b: e.path } : { c: e.path },
                {
                  d: n.o(function (e) {
                    return (function (e) {
                      y.value.splice(e, 1), k.value.splice(e, 1);
                    })(t);
                  }, t),
                  e: t,
                }
              );
            }),
            r: r._imports_1$3,
            s: y.value.length < 7,
          },
          y.value.length < 7 ? { t: r._imports_2$3, v: n.o(w) } : {},
          { w: n.o(T), x: _.value },
          _.value
            ? {
                y: n.t("success" === j.value ? "提交成功" : "完善内容"),
                z: n.t(
                  "success" === j.value
                    ? "感谢您的反馈"
                    : "请完善内容后进行提交"
                ),
                A: n.t("success" === j.value ? "离开" : "确定"),
                B: n.o(q),
                C: n.o(q),
              }
            : {},
          { D: p.value },
          p.value ? { E: n.t(f.value) } : {}
        );
      };
    },
  }),
  l = n._export_sfc(c, [["__scopeId", "data-v-12bd65be"]]);
wx.createPage(l);
