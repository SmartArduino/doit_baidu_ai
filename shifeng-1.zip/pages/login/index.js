var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  a = require("../../common/vendor.js"),
  o = require("../../api/index.js");
Array || a.resolveComponent("privacyModal")();
Math;
var t = a.defineComponent({
  __name: "index",
  setup: function (t) {
    var r = a.ref({ navHeight: "", statusBarHeight: 0, buttonMargin: 0 }),
      i = a.ref({ shareCode: "", nickname: "" });
    a.onLoad(function (e) {
      i.value = e;
      var n = a.index.getMenuButtonBoundingClientRect(),
        o = n.top,
        t = n.height;
      a.index.getSystemInfo({
        success: function (e) {
          var n = e.statusBarHeight,
            a = o - n;
          (r.value.navHeight = t + n + 2 * a),
            (r.value.statusBarHeight = n),
            (r.value.buttonMargin = a);
        },
      });
    }),
      a.ref(!1);
    var c = a.ref(!1),
      u = function (e) {
        console.log(e), (c.value = e.detail.value.includes("cb2"));
      },
      s = a.index.getAccountInfoSync(),
      d = a.ref(s.miniProgram.envVersion),
      l = function (t) {
        var r = t.detail.code;
        a.index.login({
          success: function (t) {
            if (t.code) {
              var c = {
                sessionCode: t.code,
                phoneNumberCode: r,
                appId: a.index.getAccountInfoSync().miniProgram.appId,
                familyShareCode: i.value.shareCode,
              };
              o.login(c)
                .then(
                  (function () {
                    var t = n(
                      e().mark(function n(t) {
                        var r, c, u, s;
                        return e().wrap(function (e) {
                          for (;;)
                            switch ((e.prev = e.next)) {
                              case 0:
                                if (
                                  (console.log(t, "res登录返回数据"),
                                  a.index.setStorageSync(
                                    d.value + "token",
                                    t.data.data.accessToken
                                  ),
                                  a.index.setStorageSync("disagree", !1),
                                  (c = t.data.data.deviceNum),
                                  0 !== t.data.data.isNew || !i.value.shareCode)
                                ) {
                                  e.next = 10;
                                  break;
                                }
                                return (
                                  (e.next = 7),
                                  o.familyUserUseShareCode({
                                    shareCode: i.value.shareCode,
                                  })
                                );
                              case 7:
                                (u = e.sent),
                                  "A00000" === (s = u.data).resultCode &&
                                    (c =
                                      null == (r = null == s ? void 0 : s.data)
                                        ? void 0
                                        : r.deviceNum);
                              case 10:
                                c > 0
                                  ? a.index.reLaunch({
                                      url: "/pages/index/index",
                                    })
                                  : a.index.reLaunch({
                                      url: "/pages/device/device",
                                    });
                              case 11:
                              case "end":
                                return e.stop();
                            }
                        }, n);
                      })
                    );
                    return function (e) {
                      return t.apply(this, arguments);
                    };
                  })()
                )
                .catch(function (e) {
                  console.log(e, "err");
                });
            } else console.log("获取失败！" + t.errMsg);
          },
        });
      },
      v = function () {
        a.wx$1.openPrivacyContract({
          success: function () {},
          fail: function () {},
          complete: function () {},
        });
      },
      g = function (e) {
        console.log(e, "用户是否同意隐私协议"), (c.value = e);
      },
      f = a.ref(),
      h = function () {
        f.value.openPrivacyModel();
      },
      p = function () {
        console.log("goBack"),
          a.index.setStorageSync("disagree", !0),
          a.index.switchTab({ url: "/pages/index/index" });
      };
    return function (e, n) {
      return a.e(
        {
          a: a.o(p),
          b: "".concat(r.value.statusBarHeight + r.value.buttonMargin, "px"),
          c: a.o(l),
          d: !c.value,
        },
        c.value ? {} : { e: a.o(h) },
        {
          f: c.value,
          g: a.o(u),
          h: a.o(v),
          i: "".concat(r.value.navHeight, "px"),
          j: a.sr(f, "4849c5a3-0", { k: "privacyModalRef" }),
          k: a.o(g),
        }
      );
    };
  },
});
wx.createPage(t);
