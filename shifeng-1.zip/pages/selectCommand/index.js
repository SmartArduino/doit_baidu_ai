var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  u = require("../../@babel/runtime/helpers/toConsumableArray"),
  t = require("../../common/vendor.js"),
  a = require("../../common/assets.js"),
  r = require("../../store/deviceStore.js"),
  i = require("../../api/index.js"),
  o = t.defineComponent({
    __name: "index",
    setup: function (o) {
      t.useCssVars(function (e) {
        return { "796e56b8": h.value + "px" };
      });
      var l = r.useDeviceStore(),
        v = t.ref([]),
        s = t.ref(-1),
        c = t.ref(!1),
        f = t.ref(!1),
        m = t.ref(!1),
        d = t.ref(!1),
        g = t.ref(null),
        p = t.ref(!1),
        h = t.ref(0),
        b = t.ref({ navHeight: 0, statusBarHeight: 0, buttonMargin: 0 }),
        x = function () {
          var e = l.commandList;
          if (0 !== e.length)
            if (e.length <= 9) v.value = u(e);
            else {
              var n = u(e).sort(function () {
                return Math.random() - 0.5;
              });
              v.value = n.slice(0, 9);
            }
          else v.value = [];
        },
        _ = t.ref(!1),
        q = function () {
          (f.value = !0),
            (d.value = !1),
            (_.value = !0),
            setTimeout(function () {
              (m.value = !0), (d.value = !0), B();
            }, 500);
        },
        B = (function () {
          var u = n(
            e().mark(function n() {
              var u, a;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (g.value) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return");
                      case 2:
                        if (
                          ((e.prev = 2),
                          (a = null == (u = l.device) ? void 0 : u.sn))
                        ) {
                          e.next = 7;
                          break;
                        }
                        return (
                          t.index.showToast({
                            title: "设备信息获取失败",
                            icon: "none",
                          }),
                          e.abrupt("return")
                        );
                      case 7:
                        return (
                          (e.next = 9),
                          i.deviceCommandSend({
                            sn: a,
                            command: g.value.command,
                          })
                        );
                      case 9:
                        (_.value = !1), x(), (e.next = 17);
                        break;
                      case 13:
                        (e.prev = 13),
                          (e.t0 = e.catch(2)),
                          console.error("发送指令失败:", e.t0),
                          (_.value = !1);
                      case 17:
                      case "end":
                        return e.stop();
                    }
                },
                n,
                null,
                [[2, 13]]
              );
            })
          );
          return function () {
            return u.apply(this, arguments);
          };
        })(),
        H = function () {
          m.value &&
            ((c.value = !1),
            (f.value = !1),
            (m.value = !1),
            (g.value = null),
            (p.value = !1));
        },
        k = function () {
          t.index.navigateTo({ url: "/pages/directiveList/index" });
        },
        M = function () {
          var e = t.index.getMenuButtonBoundingClientRect();
          if (e) {
            h.value = e.bottom + 16;
            var n = e.top,
              u = e.height;
            t.index.getSystemInfo({
              success: function (e) {
                var t = e.statusBarHeight,
                  a = n - t;
                (b.value.navHeight = u + 2 * a),
                  (b.value.statusBarHeight = t),
                  (b.value.buttonMargin = a);
              },
            });
          }
        },
        T = function () {
          t.index.navigateBack();
        };
      return (
        t.onMounted(function () {
          x(), M();
        }),
        t.onLoad(function (e) {
          console.log("页面参数:", e), M();
        }),
        function (e, n) {
          var u, r, i, o, l, h;
          return t.e(
            {
              a: a._imports_0$4,
              b: 2 * b.value.buttonMargin + "px",
              c: t.o(T),
              d: b.value.navHeight + "px",
              e: b.value.statusBarHeight + "px",
              f: a._imports_1,
              g: t.o(k),
              h: t.f(v.value, function (e, n, u) {
                return {
                  a: n,
                  b: s.value === n ? 1 : "",
                  c: t.o(function (u) {
                    return (function (e, n) {
                      p.value ||
                        ((p.value = !0),
                        (s.value = n),
                        (g.value = e),
                        setTimeout(function () {
                          (c.value = !0),
                            (s.value = -1),
                            setTimeout(function () {
                              q();
                            }, 100);
                        }, 200));
                    })(e, n);
                  }, n),
                };
              }),
              i: c.value,
            },
            c.value
              ? t.e(
                  {
                    j: f.value ? 1 : "",
                    k: null == (u = g.value) ? void 0 : u.img,
                  },
                  (null == (r = g.value) ? void 0 : r.img)
                    ? { l: null == (i = g.value) ? void 0 : i.img }
                    : {
                        m: t.t(null == (o = g.value) ? void 0 : o.name),
                        n:
                          ((null ==
                          (h = null == (l = g.value) ? void 0 : l.name)
                            ? void 0
                            : h.length) || 0) > 2
                            ? 1
                            : "",
                      },
                  { o: d.value && m.value },
                  d.value && m.value ? { p: a._imports_2$6, q: t.o(H) } : {},
                  {
                    r: f.value ? 1 : "",
                    s: m.value ? 1 : "",
                    t: t.o(function () {}),
                    v: t.o(H),
                  }
                )
              : {},
            { w: _.value },
            (_.value, {}),
            { x: t.s(e.__cssVars()) }
          );
        }
      );
    },
  }),
  l = t._export_sfc(o, [["__scopeId", "data-v-37b0c8ce"]]);
wx.createPage(l);
