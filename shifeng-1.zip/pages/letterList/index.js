var e = require("../../@babel/runtime/helpers/objectSpread2"),
  n = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  r = require("../../@babel/runtime/helpers/toConsumableArray"),
  t = require("../../@babel/runtime/helpers/asyncToGenerator"),
  a = require("../../common/vendor.js"),
  u = require("../../store/deviceStore.js"),
  s = require("../../api/index.js"),
  o = a.defineComponent({
    __name: "index",
    setup: function (o) {
      var i = u.useDeviceStore(),
        l = a.ref([]),
        c = a.ref(1),
        v = a.ref(20),
        f = a.ref(!1),
        p = a.ref(!1),
        d = a.ref(!1),
        h = a.computed(function () {
          return l.value.some(function (e) {
            return 0 === e.status;
          });
        }),
        m = (function () {
          var e = t(
            n().mark(function e() {
              var t,
                a,
                u,
                o,
                h,
                m,
                g,
                x = arguments;
              return n().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (
                          ((t = x.length > 0 && void 0 !== x[0] ? x[0] : 1),
                          (a = x.length > 1 && void 0 !== x[1] && x[1]),
                          !f.value && (null == (u = i.device) ? void 0 : u.sn))
                        ) {
                          e.next = 4;
                          break;
                        }
                        return e.abrupt("return");
                      case 4:
                        return (
                          (f.value = !0),
                          (e.prev = 5),
                          (e.next = 8),
                          s.messageList({
                            sn: i.device.sn,
                            pageNum: t,
                            pageSize: v.value,
                          })
                        );
                      case 8:
                        (h = e.sent),
                          "A00000" === (m = h.data).resultCode &&
                            ((g =
                              (null == (o = m.data) ? void 0 : o.list) || []),
                            (l.value = a ? [].concat(r(l.value), r(g)) : g),
                            g.length < v.value
                              ? (p.value = !0)
                              : (p.value = !1),
                            (c.value = t)),
                          (e.next = 16);
                        break;
                      case 13:
                        (e.prev = 13),
                          (e.t0 = e.catch(5)),
                          console.error("获取信件列表失败:", e.t0);
                      case 16:
                        return (
                          (e.prev = 16),
                          (f.value = !1),
                          (d.value = !1),
                          e.finish(16)
                        );
                      case 20:
                      case "end":
                        return e.stop();
                    }
                },
                e,
                null,
                [[5, 13, 16, 20]]
              );
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })(),
        g = (function () {
          var e = t(
            n().mark(function e() {
              return n().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (
                        console.log("开始下拉刷新"),
                        (d.value = !0),
                        (c.value = 1),
                        (p.value = !1),
                        (e.next = 6),
                        m(1, !1)
                      );
                    case 6:
                    case "end":
                      return e.stop();
                  }
              }, e);
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })(),
        x = function () {
          f.value || p.value || m(c.value + 1, !0);
        },
        b = (function () {
          var r = t(
            n().mark(function r() {
              var u;
              return n().wrap(function (r) {
                for (;;)
                  switch ((r.prev = r.next)) {
                    case 0:
                      if (null == (u = i.device) ? void 0 : u.sn) {
                        r.next = 2;
                        break;
                      }
                      return r.abrupt("return");
                    case 2:
                      a.index.showModal({
                        title: "提示",
                        content: "确定要将所有消息标记为已读吗？",
                        success: (function () {
                          var r = t(
                            n().mark(function r(t) {
                              var u;
                              return n().wrap(
                                function (n) {
                                  for (;;)
                                    switch ((n.prev = n.next)) {
                                      case 0:
                                        if (!t.confirm) {
                                          n.next = 15;
                                          break;
                                        }
                                        return (
                                          a.index.showLoading({
                                            title: "标记中...",
                                            mask: !0,
                                          }),
                                          (n.prev = 2),
                                          (n.next = 5),
                                          s.readAllMessage({ sn: i.device.sn })
                                        );
                                      case 5:
                                        (u = n.sent),
                                          "A00000" === u.data.resultCode &&
                                            ((l.value = l.value.map(function (
                                              n
                                            ) {
                                              return e(
                                                e({}, n),
                                                {},
                                                { status: 1 }
                                              );
                                            })),
                                            a.index.showToast({
                                              title: "标记成功",
                                              icon: "none",
                                            })),
                                          (n.next = 13);
                                        break;
                                      case 10:
                                        (n.prev = 10),
                                          (n.t0 = n.catch(2)),
                                          console.error("标记已读失败:", n.t0);
                                      case 13:
                                        return (n.prev = 13), n.finish(13);
                                      case 15:
                                      case "end":
                                        return n.stop();
                                    }
                                },
                                r,
                                null,
                                [[2, 10, 13, 15]]
                              );
                            })
                          );
                          return function (e) {
                            return r.apply(this, arguments);
                          };
                        })(),
                      });
                    case 3:
                    case "end":
                      return r.stop();
                  }
              }, r);
            })
          );
          return function () {
            return r.apply(this, arguments);
          };
        })();
      return (
        a.onShow(function () {
          (c.value = 1), (p.value = !1), m(1, !1);
        }),
        function (e, n) {
          return a.e(
            {
              a: a.f(l.value, function (e, n, r) {
                var t;
                return {
                  a: 0 === e.status ? 1 : "",
                  b: a.t(e.title),
                  c: a.t(null == (t = e.messageTime) ? void 0 : t.slice(0, 10)),
                  d: e.messageId,
                  e: a.o(function (n) {
                    return (function (e) {
                      console.log("点击了信件:", e),
                        a.index.navigateTo({
                          url: "/pages/letterDetail/index?messageId=".concat(
                            e.messageId
                          ),
                        });
                    })(e);
                  }, e.messageId),
                };
              }),
              b: l.value.length > 0,
            },
            l.value.length > 0
              ? a.e({ c: f.value }, (f.value || p.value, {}), { d: p.value })
              : {},
            { e: 0 === l.value.length && !f.value },
            (0 !== l.value.length || f.value, {}),
            {
              f: h.value ? 1 : "",
              g: a.o(x),
              h: d.value,
              i: a.o(g),
              j: h.value,
            },
            h.value ? { k: a.o(b) } : {}
          );
        }
      );
    },
  }),
  i = a._export_sfc(o, [["__scopeId", "data-v-b046ff49"]]);
wx.createPage(i);
