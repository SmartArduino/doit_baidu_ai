var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  r = require("../../common/vendor.js"),
  t = require("../../store/deviceStore.js"),
  a = require("../../api/index.js"),
  u = r.defineComponent({
    __name: "index",
    setup: function (u) {
      var o = r.ref(!1),
        i = t.useDeviceStore();
      r.onLoad(function () {});
      var c = r.ref(-1),
        s = (function () {
          var t = n(
            e().mark(function n() {
              var t, u, s;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (-1 !== c.value) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return");
                      case 2:
                        return (
                          (u = i.commandList[c.value]),
                          console.log("deviceStore", i),
                          (e.prev = 4),
                          (e.next = 7),
                          a.deviceCommandSend({
                            sn: null == (t = i.device) ? void 0 : t.sn,
                            command: u.command,
                          })
                        );
                      case 7:
                        (s = e.sent),
                          "A00000" == s.data.resultCode &&
                            r.index.showToast({
                              title: "已发送指令",
                              icon: "none",
                            }),
                          (e.next = 15);
                        break;
                      case 12:
                        (e.prev = 12), (e.t0 = e.catch(4)), console.log(e.t0);
                      case 15:
                        return (
                          (e.prev = 15),
                          (o.value = !1),
                          (c.value = -1),
                          e.finish(15)
                        );
                      case 19:
                      case "end":
                        return e.stop();
                    }
                },
                n,
                null,
                [[4, 12, 15, 19]]
              );
            })
          );
          return function () {
            return t.apply(this, arguments);
          };
        })(),
        v = function () {
          (o.value = !1), (c.value = -1);
        };
      return function (e, n) {
        return r.e(
          {
            a: r.f(r.unref(i).commandList, function (e, n, t) {
              return r.e(
                { a: e.img },
                e.img ? { b: e.img } : { c: r.t(e.name) },
                { d: c.value === n },
                (c.value, {}),
                {
                  e: n,
                  f: c.value === n ? 1 : "",
                  g: r.o(function (e) {
                    return (function (e) {
                      (c.value = e), (o.value = !0);
                    })(n);
                  }, n),
                }
              );
            }),
            b: o.value,
          },
          o.value ? { c: r.o(v), d: r.o(s) } : {}
        );
      };
    },
  }),
  o = r._export_sfc(u, [["__scopeId", "data-v-b6e75921"]]);
wx.createPage(o);
