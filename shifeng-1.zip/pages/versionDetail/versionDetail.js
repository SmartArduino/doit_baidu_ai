var e = require("../../common/vendor.js"),
  n = require("../../common/assets.js"),
  t = require("../../api/index.js"),
  a = e.defineComponent({
    __name: "versionDetail",
    setup: function (a) {
      var o = e.ref({ navHeight: "", statusBarHeight: 0, buttonMargin: 0 });
      e.onLoad(function (n) {
        var a,
          i,
          u = e.index.getMenuButtonBoundingClientRect(),
          s = u.top,
          c = u.height;
        console.log(n, "option"),
          e.index.getSystemInfo({
            success: function (e) {
              var n = e.statusBarHeight,
                t = s - n;
              (o.value.navHeight = c + n + 2 * t),
                (o.value.statusBarHeight = n),
                (o.value.buttonMargin = t);
            },
          }),
          (a = n.versionId),
          (i = n.version),
          t
            .versionInfo({ versionId: a, version: i })
            .then(function (e) {
              r.value = e.data.data;
            })
            .catch(function (e) {
              console.log(e);
            });
      });
      var i = function () {
          e.index.navigateBack();
        },
        r = e.ref();
      return (
        e.onShareAppMessage(function () {
          return {};
        }),
        e.onShareTimeline(function () {
          return {};
        }),
        function (t, a) {
          var u, s;
          return {
            a: n._imports_0$2,
            b: "".concat(o.value.statusBarHeight, "px"),
            c: e.o(i),
            d: "".concat(o.value.statusBarHeight, "px"),
            e: "".concat(o.value.navHeight, "px"),
            f: e.t(null == (u = r.value) ? void 0 : u.version),
            g: e.t(null == (s = r.value) ? void 0 : s.description),
            h: "".concat(o.value.navHeight, "px"),
            i: "34rpx",
            j: "calc(100vh - ".concat(o.value.navHeight, "px)"),
          };
        }
      );
    },
  });
a.__runtimeHooks = 6;
var o = e._export_sfc(a, [["__scopeId", "data-v-0031c1a5"]]);
wx.createPage(o);
