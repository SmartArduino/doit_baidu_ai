var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  r = require("../../common/vendor.js"),
  t = require("../../common/assets.js"),
  u = require("../../store/useAuthStore.js"),
  o = require("../../api/index.js"),
  a = r.defineComponent({
    __name: "setting",
    setup: function (a) {
      var i = u.useAuthStore(),
        s = r.ref(!1),
        c = r.ref(!1),
        l = (function () {
          var r = n(
            e().mark(function n() {
              return e().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                    case "end":
                      return e.stop();
                  }
              }, n);
            })
          );
          return function () {
            return r.apply(this, arguments);
          };
        })(),
        f = r.index.getAccountInfoSync(),
        v = r.ref(f.miniProgram.envVersion),
        p = (function () {
          var t = n(
            e().mark(function n() {
              var t;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (e.prev = 0), (e.next = 3), o.logout();
                      case 3:
                        (t = e.sent),
                          "A00000" === t.data.resultCode &&
                            r.index.showModal({
                              title: "提示",
                              content: "你的账号已成功退出",
                              showCancel: !1,
                              success: function () {
                                i.clearAuth(),
                                  r.index.setStorageSync(v.value + "token", ""),
                                  r.index.reLaunch({
                                    url: "/pages/login/index",
                                  });
                              },
                            }),
                          (e.next = 11);
                        break;
                      case 8:
                        (e.prev = 8),
                          (e.t0 = e.catch(0)),
                          r.index.showToast({
                            title: "退出失败",
                            icon: "none",
                          });
                      case 11:
                        return (e.prev = 11), (c.value = !1), e.finish(11);
                      case 14:
                      case "end":
                        return e.stop();
                    }
                },
                n,
                null,
                [[0, 8, 11, 14]]
              );
            })
          );
          return function () {
            return t.apply(this, arguments);
          };
        })();
      return function (e, n) {
        return r.e(
          {
            a: t._imports_1,
            b: r.o(function (e) {
              return (
                (n = "/pages/memberPage/memberPage"),
                void r.index.navigateTo({ url: n })
              );
              var n;
            }),
            c: t._imports_1,
            d: r.o(function (e) {
              return (c.value = !0);
            }),
            e: s.value,
          },
          s.value
            ? {
                f: r.o(function (e) {
                  return (s.value = !1);
                }),
                g: r.o(l),
              }
            : {},
          { h: c.value },
          c.value
            ? {
                i: r.o(function (e) {
                  return (c.value = !1);
                }),
                j: r.o(p),
              }
            : {}
        );
      };
    },
  }),
  i = r._export_sfc(a, [["__scopeId", "data-v-7a487483"]]);
wx.createPage(i);
