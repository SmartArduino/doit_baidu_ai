var r = require("../../common/assets.js"),
  e = {};
var s = require("../../common/vendor.js")._export_sfc(e, [
  [
    "render",
    function (e, s) {
      return {
        a: r._imports_0$6,
        b: r._imports_0$6,
        c: r._imports_0$6,
        d: r._imports_0$6,
        e: r._imports_0$6,
      };
    },
  ],
  ["__scopeId", "data-v-c1ecca8f"],
]);
wx.createPage(s);
