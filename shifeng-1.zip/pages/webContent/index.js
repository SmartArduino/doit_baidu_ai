require("../../@babel/runtime/helpers/Arrayincludes");
var e = require("../../common/vendor.js"),
  n = e.defineComponent({
    __name: "index",
    setup: function (n) {
      var t = e.ref(""),
        r = e.ref(""),
        o = e.index.getAccountInfoSync().miniProgram.envVersion;
      return (
        e.onLoad(function (n) {
          var a = decodeURIComponent(n.url);
          e.index.getStorageSync(o + "token");
          var i = new Date().getTime(),
            c = a.includes("?") ? "&" : "?";
          (t.value = ""
            .concat(a)
            .concat(c, "timestamp=")
            .concat(i, "&source=miniprogram")),
            (r.value = n.title);
        }),
        e.onShow(function () {
          e.index.setNavigationBarTitle({ title: r.value });
        }),
        function (e, n) {
          return { a: t.value };
        }
      );
    },
  }),
  t = e._export_sfc(n, [["__scopeId", "data-v-ceea1792"]]);
wx.createPage(t);
