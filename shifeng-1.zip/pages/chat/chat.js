require("../../@babel/runtime/helpers/Arrayincludes");
var e = require("../../@babel/runtime/helpers/toConsumableArray"),
  a = require("../../common/vendor.js"),
  t = require("../../common/assets.js"),
  n = require("../../tools/hexHandle.js"),
  o = require("../../config/config.js"),
  s = require("../../tools/authorize.js"),
  u = require("../../api/index.js");
Array ||
  (a.resolveComponent("zero-markdown-view") + a.resolveComponent("recorder"))();
Math ||
  (
    function () {
      return "../../uni_modules/zero-markdown-view/components/zero-markdown-view/zero-markdown-view.js";
    } +
    function () {
      return "../../components/recorder/recorder.js";
    }
  )();
var r = a.defineComponent({
    __name: "chat",
    setup: function (r) {
      var i = o.getConfig(),
        l = a.ref(10),
        c = a.ref(!1),
        v = a.ref([]),
        d = a.ref(""),
        g = "",
        m = a.ref(""),
        f = function (a) {
          (c.value = !0),
            u
              .messageQuestionList(a)
              .then(function (t) {
                if ((console.log(t), 200 == t.statusCode)) {
                  if (
                    ((v.value = [].concat(e(t.data.data.list), e(v.value))),
                    (d.value = t.data.data.nextCursorId),
                    0 === t.data.data.list.length)
                  )
                    return (_.value = !1), void (c.value = !1);
                  a
                    ? ((_.value = !1),
                      setTimeout(function () {
                        (m.value = "c" + g),
                          (g = t.data.data.list[0].messageId),
                          (c.value = !1),
                          !d.value || t.data.data.list.length < 10
                            ? (_.value = !1)
                            : (_.value = !0);
                      }, 200))
                    : (A(),
                      (c.value = !1),
                      (g = t.data.data.list[0].messageId));
                }
              })
              .catch(function (e) {
                (c.value = !1), console.log(e);
              });
        };
      f();
      var p = function (e) {
          l.value = e.detail.height;
        },
        y = function () {
          l.value = 10;
        };
      a.index.createInnerAudioContext().autoplay = !0;
      var h = a.ref("text"),
        x = a.ref(""),
        T = a.ref(""),
        w = a.ref(9999999999),
        _ = a.ref(!0),
        k = function (e) {
          _.value && f(d.value);
        },
        C = function (e) {},
        H = a.ref(!1),
        S = function () {
          "text" == h.value
            ? ((H.value = !0),
              s
                .impower()
                .then(function () {
                  console.log(123123),
                    a.index.getRecorderManager()
                      ? (h.value = "voice")
                      : a.wx$1.showToast({
                          title: "您当前设备不支持语音输入",
                          icon: "none",
                          duration: 1e3,
                        });
                })
                .catch(function () {
                  console.log(456456), (h.value = "text");
                }))
            : ((H.value = !1), (h.value = "text"));
        };
      a.onShow(function () {
        H.value &&
          s.impower().then(function () {
            h.value = "voice";
          });
      });
      var b = a.index.getAccountInfoSync(),
        I = a.ref(b.miniProgram.envVersion),
        P = function (e) {
          "text" == h.value && x.value.trim()
            ? (v.value.push({
                senderType: 1,
                taskId: new Date().getTime().toString(),
                messageId: new Date().getTime().toString(),
                messageTime: a.dayjs().format("YYYY-MM-DD HH:mm:ss"),
                messageType: 1,
                message: x.value,
              }),
              q({ messageType: 1, message: x.value }))
            : "voice" == h.value &&
              a.index.uploadFile({
                url:
                  i.apiUrl +
                  "/api/v1/toystory/wechat/message/question/audioFile",
                filePath: e,
                name: "audio",
                header: {
                  accessToken: a.index.getStorageSync(I.value + "token"),
                },
                success: function (e) {
                  var t = JSON.parse(e.data);
                  if (401 == e.statusCode || "A00002" == t.resultCode)
                    return (
                      a.index.showToast({
                        icon: "none",
                        title: "出错了，请尝试重新登录！",
                      }),
                      void a.index.reLaunch({ url: "/pages/login/index" })
                    );
                  "A00000" == t.resultCode
                    ? ((T.value = t.data.audioUrl),
                      v.value.push({
                        senderType: 1,
                        taskId: new Date().getTime().toString(),
                        messageId: new Date().getTime().toString(),
                        messageTime: a.dayjs().format("YYYY-MM-DD HH:mm:ss"),
                        messageType: 2,
                        message: T.value,
                      }),
                      q({ messageType: 2, message: t.data.audioUrl }))
                    : a.index.showToast({
                        icon: "none",
                        title: e.data.resultMsg,
                        duration: 2e3,
                      });
                },
                fail: function (e) {
                  console.error("上传失败", e);
                },
              });
        },
        j = a.ref(!1),
        q = function (e) {
          var t = a.wx$1.request({
            url: i.apiUrl + "/api/v1/toystory/wechat/message/question/send",
            method: "POST",
            header: {
              "Content-Type": "application/json",
              accessToken: a.index.getStorageSync(I.value + "token"),
            },
            data: e,
            responseType: "ArrayBuffer",
            enableChunked: !0,
            success: function (e) {
              if (((j.value = !1), A(), 401 == e.statusCode))
                return (
                  a.index.showToast({
                    icon: "none",
                    title: "出错了，请尝试重新登录！",
                  }),
                  void a.index.reLaunch({ url: "/pages/login/index" })
                );
            },
            fail: function () {
              (j.value = !1), A();
            },
          });
          (w.value = w.value + 1),
            (x.value = ""),
            (j.value = !0),
            t.onHeadersReceived(function (e) {
              console.log("开始收到数据", e),
                v.value.push({
                  senderType: 2,
                  taskId: new Date().getTime().toString(),
                  messageId: new Date().getTime().toString(),
                  messageTime: a.dayjs().format("YYYY-MM-DD HH:mm:ss"),
                  messageType: 1,
                  message: "",
                });
            });
          var o = "";
          t.onChunkReceived(function (e) {
            console.log("收到数据", e);
            var a = n.buf2hex(e.data),
              t = n.hexToStr(a);
            (o += t), console.log("收到数据str", o);
            var s = o.split("\n\n");
            console.log(s, "arr======="),
              (function (e) {
                for (var a = "", t = 0; t < e.length; t++)
                  if (e[t].includes("data:{")) {
                    var n = e[t].replace("data:", "");
                    try {
                      var o = JSON.parse(n);
                      "message" === o.event && (a += o.answer);
                    } catch (e) {
                      console.log(e, t);
                    }
                  }
                console.log(a, "str======="),
                  (v.value[v.value.length - 1].message = a),
                  e.find(function (e) {
                    return e.includes("tts_message_end");
                  }) && (j.value = !1);
                w.value = w.value + 1;
              })(s);
          });
        };
      function A() {
        setTimeout(function () {
          m.value = "bottom";
        }, 500);
      }
      var D,
        M = function () {
          a.index.navigateBack();
        },
        Y = function (e, t) {
          D && (D.stop(), D.destroy()),
            ((D = a.index.createInnerAudioContext()).autoplay = !1),
            (D.loop = !1),
            (D.src = e),
            D.play(),
            v.value.forEach(function (e) {
              e.isPlay = !1;
            }),
            (v.value[t].isPlay = !0),
            D.onEnded(function () {
              v.value[t].isPlay = !1;
            });
        };
      a.onHide(function () {
        D.stop();
      }),
        a.onUnload(function () {
          D.stop(), D.destroy();
        });
      var B = a.ref({ navHeight: "", statusBarHeight: 0, buttonMargin: 0 });
      return (
        a.onLoad(function () {
          var e = a.index.getMenuButtonBoundingClientRect(),
            t = e.top,
            n = e.height;
          a.index.getSystemInfo({
            success: function (e) {
              var a = e.statusBarHeight,
                o = t - a;
              (B.value.navHeight = n + a + 2 * o),
                (B.value.statusBarHeight = a),
                (B.value.buttonMargin = o);
            },
          });
        }),
        function (e, n) {
          return a.e(
            {
              a: t._imports_0$2,
              b: a.o(M),
              c: "".concat(B.value.statusBarHeight, "px"),
              d: "".concat(B.value.statusBarHeight + 7, "px"),
              e: "".concat(B.value.statusBarHeight - 35, "px"),
              f: a.f(v.value, function (e, n, o) {
                return a.e(
                  { a: 1 == e.senderType },
                  1 == e.senderType
                    ? a.e(
                        { b: 1 == e.messageType },
                        1 == e.messageType
                          ? {
                              c: "a041b13f-0-" + o,
                              d: a.p({
                                markdown: e.message.replaceAll("~", "~ "),
                              }),
                            }
                          : {},
                        { e: 2 == e.messageType },
                        2 == e.messageType
                          ? a.e(
                              { f: !e.isPlay },
                              e.isPlay ? {} : { g: t._imports_1$2 },
                              { h: e.isPlay },
                              e.isPlay ? { i: t._imports_2$2 } : {},
                              {
                                j: a.o(function (a) {
                                  return Y(e.message, n);
                                }, n),
                              }
                            )
                          : {}
                      )
                    : {},
                  { k: 2 == e.senderType },
                  2 == e.senderType
                    ? a.e(
                        { l: 1 == e.messageType },
                        1 == e.messageType
                          ? {
                              m: "a041b13f-1-" + o,
                              n: a.p({
                                markdown: e.message.replaceAll("~", "~ "),
                              }),
                            }
                          : {},
                        { o: 2 == e.messageType },
                        2 == e.messageType
                          ? a.e(
                              { p: !e.isPlay },
                              e.isPlay ? {} : { q: t._imports_1$2 },
                              { r: e.isPlay },
                              e.isPlay ? { s: t._imports_2$2 } : {},
                              {
                                t: a.o(function (a) {
                                  return Y(e.message, n);
                                }, n),
                              }
                            )
                          : {}
                      )
                    : {},
                  { v: "c" + e.messageId, w: n }
                );
              }),
              g: a.o(k),
              h: a.o(C),
              i: w.value,
              j: m.value,
              k: "text" == h.value,
            },
            "text" == h.value
              ? a.e(
                  { l: !j.value },
                  j.value
                    ? {}
                    : {
                        m: a.o(P),
                        n: a.o(P),
                        o: a.o(p),
                        p: a.o(y),
                        q: x.value,
                        r: a.o(function (e) {
                          return (x.value = e.detail.value);
                        }),
                      }
                )
              : {},
            { s: "voice" == h.value },
            "voice" == h.value ? { t: a.o(P) } : {},
            { v: "text" == h.value },
            "text" == h.value ? { w: t._imports_3$2 } : {},
            { x: "voice" == h.value },
            "voice" == h.value ? { y: t._imports_4$2 } : {},
            { z: a.o(S), A: a.s("bottom: ".concat(l.value, "px")), B: j.value },
            (j.value, {}),
            { C: 10 == l.value },
            (l.value, {})
          );
        }
      );
    },
  }),
  i = a._export_sfc(r, [["__scopeId", "data-v-a041b13f"]]);
wx.createPage(i);
