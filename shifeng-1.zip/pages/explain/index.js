var e = require("../../common/vendor.js"),
  n = require("../../common/assets.js"),
  t = e.defineComponent({
    __name: "index",
    setup: function (t) {
      var a = this;
      e.onShow(function () {});
      var o = e.ref({ navHeight: "", statusBarHeight: 0, buttonMargin: 0 });
      e.onLoad(function () {
        var n = e.index.getMenuButtonBoundingClientRect(),
          t = n.top,
          a = n.height;
        e.index.getSystemInfo({
          success: function (e) {
            var n = e.statusBarHeight,
              u = t - n;
            (o.value.navHeight = a + n + 2 * u),
              (o.value.statusBarHeight = n),
              (o.value.buttonMargin = u);
          },
        });
      });
      var u = function (e) {
          console.log(e);
        },
        i = function () {
          e.index.navigateBack();
        },
        c = e.ref(null),
        r = function (n) {
          (console.log(n, c.value, "handlePlay"),
          null !== c.value && c.value !== n)
            ? e.index.createVideoContext("myVideo".concat(c.value), a).pause()
            : e.index.createVideoContext("myVideo".concat(n)).play();
          c.value = n;
        };
      return function (t, a) {
        return {
          a: n._imports_0$2,
          b: "".concat(o.value.statusBarHeight, "px"),
          c: e.o(i),
          d: "".concat(o.value.statusBarHeight, "px"),
          e: "".concat(o.value.navHeight, "px"),
          f: e.o(function (e) {
            return r(0);
          }),
          g: e.o(u),
          h: e.o(function (e) {
            return r(1);
          }),
          i: e.o(u),
          j: e.o(function (e) {
            return r(2);
          }),
          k: e.o(u),
          l: e.o(function (e) {
            return r(3);
          }),
          m: e.o(u),
          n: "".concat(o.value.navHeight, "px"),
          o: "40px",
          p: "calc(100vh - ".concat(o.value.navHeight, "px)"),
        };
      };
    },
  }),
  a = e._export_sfc(t, [["__scopeId", "data-v-237211ef"]]);
wx.createPage(a);
