var e = require("../../@babel/runtime/helpers/defineProperty"),
  n = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  t = require("../../@babel/runtime/helpers/asyncToGenerator"),
  a = require("../../common/vendor.js"),
  r = require("../../api/index.js");
Math || u();
var u = function () {
    return "../../components/MyButton/MyButton.js";
  },
  o = a.defineComponent({
    __name: "index",
    setup: function (u) {
      var o = a.ref(!1),
        l = a.ref(!0),
        c = a.ref({ id: -1, name: "", sn: "", dataSource: "" });
      a.onLoad(function (e) {
        (c.value = e),
          console.log("页面加载完成"),
          a.index.setNavigationBarTitle({
            title: (null == e ? void 0 : e.name) || "活动详情",
          }),
          -1 == (null == e ? void 0 : e.id)
            ? ((i.value.detailImg =
                "https://vseed-toystory.cdn.bcebos.com/2025/08/07/8355cd4c-daf2-42ae-ab62-704afa0530ea.png"),
              (i.value.introduce =
                "🎵 欢迎来到「音乐小舞台」！  \n\n这是专为宝贝们打造的“语音点歌台”～想听歌时，只要直接对飞飞兔下指令：\n\n👉  想随机听儿歌？试试对飞飞兔说： “唱首儿歌吧” ，耳朵扇动，就能让欢快旋律随时响起~\n\n👉  想点播歌曲？试试对飞飞兔说： “播放《虫儿飞》（或任意儿歌名）” ，专属BGM立刻安排！  \n\n\n🎧  听歌小提示：  \n\n为了提供一个 沉浸式享受音乐 的环境，播放音乐时麦克风会变得不灵敏噢~（外界声音不干扰听歌啦～）；如果享受完美美的音乐，只要 短按1次右脚按键 ，就能秒切回“聊天对话状态”，听歌聊天自由切换超丝滑！\n\n\n功能亮点\n\n✔️ 儿歌库超“有料” ：经典儿歌（《数鸭子》《小星星》）、热门新儿歌全覆盖，从“童年回忆”听到“流行旋律”，承包宝贝的欢乐歌单！  \n\n✔️ 互动像“唠嗑”一样简单 ：不用点屏幕、不用找按钮，说句话就能听歌/切歌，3岁宝宝也能轻松“掌控”音乐节奏～  \n\n✔️ 沉浸式听歌体验 ：关闭拾音+清晰音质，让宝贝像在“私人小剧场”，跟着旋律拍手、摇摆，边听边玩更开心！  \n\n✔️ 模式灵活切换 ：听歌时专心听，想互动也可以一键切回对话，既保护“音乐沉浸感”，又能随时喊飞飞兔玩问答，两不误～  \n"),
              (l.value = !1))
            : -2 == (null == e ? void 0 : e.id)
            ? ((i.value.detailImg =
                "https://vseed-toystory.cdn.bcebos.com/2025/08/07/38d53cdc-6903-43db-8301-0ce55c9a0700.png"),
              (i.value.introduce =
                "🌼 欢迎解锁「天气小百科」！ \n\n这是陪宝贝探索“大自然秘密”的生活小助手～想查天气时，可以和飞飞兔唠唠呀：  \n\n👉 查今天天气？可以问它： “今天天气怎么样” ，听温度、晴天/雨天全播报！  \n\n👉 查未来天气？可以问它：“明天会下雨吗”“上海周末热不热” ，提前准备小伞、小外套超方便～  \n\n\n功能亮点\n\n✔️ 查询像“聊天”一样自然 ：不管问“今天热不热”还是“周末下雨吗”，飞飞兔都能秒懂，用“宝贝能听懂的话”讲天气～  \n\n✔️ 知识藏在“生活里” ：把“25度、晴天”变成 “穿衣小贴士” （“今天穿短袖正好！”）、 “出行小提醒” （“明天下雨，要带小雨伞哦～”），学常识超轻松！\n\n✔️ 语音超清晰好理解 ：不用看复杂天气预报，飞飞兔用简单句子讲天气，数字、天气现象都变“小朋友的话”，一听就懂～  \n\n✔️ 出门更“安心” ：提前知道天气，帮爸爸妈妈和宝贝准备小装备（雨天带伞、晴天戴帽），让每天出门都更有序、更有趣！  "),
              (l.value = !1))
            : ((14 != (null == e ? void 0 : e.id) &&
                15 != (null == e ? void 0 : e.id)) ||
                (l.value = !1),
              v());
      });
      var i = a.ref({
          id: 0,
          name: "",
          functionType: 0,
          img: "",
          introduce: "",
          detailImg: "",
          hasSceneButton: 0,
        }),
        d = a.ref(!1),
        v = (function () {
          var e = t(
            n().mark(function e() {
              var t, a, u, o, l;
              return n().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.prev = 0),
                          (d.value = !0),
                          (e.next = 4),
                          r.sceneInfo({
                            id: null == (t = c.value) ? void 0 : t.id,
                          })
                        );
                      case 4:
                        (o = e.sent),
                          "A00000" === (l = o.data).resultCode &&
                            (l.data.introduce &&
                              (console.log(l.data.introduce, "122122121122"),
                              (l.data.introduce =
                                null ==
                                (u =
                                  null == (a = l.data) ? void 0 : a.introduce)
                                  ? void 0
                                  : u.replaceAll("\\n", function () {
                                      return "\n";
                                    })),
                              console.log(l.data.introduce, "33333")),
                            (i.value = l.data)),
                          (e.next = 12);
                        break;
                      case 9:
                        (e.prev = 9),
                          (e.t0 = e.catch(0)),
                          console.error("获取场景失败:", e.t0);
                      case 12:
                        return (e.prev = 12), (d.value = !1), e.finish(12);
                      case 15:
                      case "end":
                        return e.stop();
                    }
                },
                e,
                null,
                [[0, 9, 12, 15]]
              );
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })(),
        s = a.ref(!1),
        p = (function () {
          var e = t(
            n().mark(function e() {
              var t, a, u;
              return n().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (!s.value) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return");
                      case 2:
                        return (
                          (e.prev = 2),
                          (s.value = !0),
                          (e.next = 6),
                          r.functionOpen({
                            sn: null == (t = c.value) ? void 0 : t.sn,
                            functionType: i.value.functionType,
                            dataSource:
                              null == (a = c.value) ? void 0 : a.dataSource,
                          })
                        );
                      case 6:
                        (u = e.sent),
                          "A00000" === u.data.resultCode && (o.value = !0),
                          (e.next = 14);
                        break;
                      case 11:
                        (e.prev = 11),
                          (e.t0 = e.catch(2)),
                          console.error("进入游戏失败:", e.t0);
                      case 14:
                        return (e.prev = 14), (s.value = !1), e.finish(14);
                      case 17:
                      case "end":
                        return e.stop();
                    }
                },
                e,
                null,
                [[2, 11, 14, 17]]
              );
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })();
      return function (n, t) {
        var r;
        return a.e(
          {
            a: i.value.detailImg,
            b: a.t(i.value.introduce || ""),
            c: l.value ? "calc(100vh - 192rpx)" : "calc(100vh - 120rpx)",
            d: i.value.hasSceneButton,
          },
          i.value.hasSceneButton
            ? {
                e: a.o(function (e) {
                  return p();
                }),
                f: a.p(
                  e(
                    e(
                      e(
                        e(
                          { label: "进入" },
                          "bg-color",
                          s.value ? "#E5E5E5" : "#00D550"
                        ),
                        "button-width",
                        343
                      ),
                      "button-height",
                      44
                    ),
                    "border-radius",
                    10
                  )
                ),
              }
            : {},
          { g: o.value },
          o.value
            ? {
                h: a.t(null == (r = c.value) ? void 0 : r.name),
                i: a.o(function (e) {
                  o.value = !1;
                }),
              }
            : {},
          { j: s.value },
          s.value ? { k: a.t("正在进入") } : {}
        );
      };
    },
  }),
  l = a._export_sfc(o, [["__scopeId", "data-v-c767af12"]]);
wx.createPage(l);
