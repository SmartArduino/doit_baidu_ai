var e = require("../../@babel/runtime/helpers/defineProperty"),
  n = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  t = require("../../@babel/runtime/helpers/asyncToGenerator"),
  a = require("../../common/vendor.js"),
  r = require("../../common/assets.js"),
  u = require("../../api/index.js");
Math || o();
var o = function () {
    return "../../components/MyButton/MyButton.js";
  },
  i = a.defineComponent({
    __name: "index",
    setup: function (o) {
      var i = a.ref(!1),
        l = a.ref({ navHeight: 0, statusBarHeight: 0, buttonMargin: 0 }),
        c = a.ref({ id: -1, name: "", sn: "", dataSource: "" });
      a.onLoad(function (e) {
        (c.value = e), console.log("页面加载完成", e), d();
        var n = a.index.getMenuButtonBoundingClientRect(),
          t = n.top,
          r = n.height;
        a.index.getSystemInfo({
          success: function (e) {
            var n = e.statusBarHeight,
              a = t - n;
            (l.value.navHeight = r + 2 * a),
              (l.value.statusBarHeight = n),
              (l.value.buttonMargin = a);
          },
        });
      });
      var s = a.ref({
          id: 0,
          name: "",
          functionType: 0,
          img: "",
          introduce: "",
          detailImg: "",
          hasSceneButton: 0,
        }),
        v = a.ref(!1),
        d = (function () {
          var e = t(
            n().mark(function e() {
              var t, a, r, o, i;
              return n().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.prev = 0),
                          (v.value = !0),
                          (e.next = 4),
                          u.sceneInfo({
                            id: null == (t = c.value) ? void 0 : t.id,
                          })
                        );
                      case 4:
                        (o = e.sent),
                          "A00000" === (i = o.data).resultCode &&
                            (i.data.introduce &&
                              (console.log(i.data.introduce, "122122121122"),
                              (i.data.introduce =
                                null ==
                                (r =
                                  null == (a = i.data) ? void 0 : a.introduce)
                                  ? void 0
                                  : r.replaceAll("\\n", function () {
                                      return "\n";
                                    })),
                              console.log(i.data.introduce, "33333")),
                            (s.value = i.data)),
                          (e.next = 12);
                        break;
                      case 9:
                        (e.prev = 9),
                          (e.t0 = e.catch(0)),
                          console.error("获取场景失败:", e.t0);
                      case 12:
                        return (e.prev = 12), (v.value = !1), e.finish(12);
                      case 15:
                      case "end":
                        return e.stop();
                    }
                },
                e,
                null,
                [[0, 9, 12, 15]]
              );
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })(),
        f = function () {
          a.index.navigateBack();
        },
        p = a.ref(!1),
        h = (function () {
          var e = t(
            n().mark(function e() {
              var t, a, r, o, l;
              return n().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (!p.value) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return");
                      case 2:
                        return (
                          (e.prev = 2),
                          (p.value = !0),
                          (e.next = 6),
                          u.functionOpen({
                            sn: null == (t = c.value) ? void 0 : t.sn,
                            functionType: s.value.functionType,
                            dataSource:
                              null == (a = c.value) ? void 0 : a.dataSource,
                            id: null == (r = c.value) ? void 0 : r.id,
                            name: null == (o = c.value) ? void 0 : o.name,
                          })
                        );
                      case 6:
                        (l = e.sent),
                          "A00000" === l.data.resultCode && (i.value = !0),
                          (e.next = 14);
                        break;
                      case 11:
                        (e.prev = 11),
                          (e.t0 = e.catch(2)),
                          console.error("进入游戏失败:", e.t0);
                      case 14:
                        return (e.prev = 14), (p.value = !1), e.finish(14);
                      case 17:
                      case "end":
                        return e.stop();
                    }
                },
                e,
                null,
                [[2, 11, 14, 17]]
              );
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })();
      return function (n, t) {
        var u;
        return a.e(
          {
            a: r._imports_0$4,
            b: 2 * l.value.buttonMargin + "px",
            c: a.o(f),
            d: l.value.navHeight + "px",
            e: l.value.statusBarHeight + "px",
            f: s.value.detailImg,
            g: s.value.hasSceneButton,
          },
          s.value.hasSceneButton
            ? {
                h: a.o(function (e) {
                  return h();
                }),
                i: a.p(
                  e(
                    e(
                      e(
                        e(
                          { label: "开始播放" },
                          "bg-color",
                          p.value ? "#E5E5E5" : "#00D550"
                        ),
                        "button-width",
                        343
                      ),
                      "button-height",
                      44
                    ),
                    "border-radius",
                    10
                  )
                ),
              }
            : {},
          { j: i.value },
          i.value
            ? {
                k: a.t(null == (u = c.value) ? void 0 : u.name),
                l: a.o(function (e) {
                  i.value = !1;
                }),
              }
            : {},
          { m: p.value },
          p.value ? { n: a.t("正在进入") } : {}
        );
      };
    },
  }),
  l = a._export_sfc(i, [["__scopeId", "data-v-76998f2a"]]);
wx.createPage(l);
