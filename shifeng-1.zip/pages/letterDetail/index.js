var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  t = require("../../@babel/runtime/helpers/asyncToGenerator"),
  n = require("../../common/vendor.js"),
  a = require("../../common/assets.js"),
  r = require("../../store/deviceStore.js"),
  s = require("../../api/index.js"),
  u = n.defineComponent({
    __name: "index",
    setup: function (u) {
      var o = r.useDeviceStore(),
        i = n.ref({ messageId: "", productName: "魔法星", content: "" }),
        c = n.ref({ navHeight: 0, statusBarHeight: 0, buttonMargin: 0 });
      n.onLoad(function (e) {
        e.messageId && ((i.value.messageId = e.messageId), d(e.messageId));
        var t = n.index.getMenuButtonBoundingClientRect(),
          a = t.top,
          r = t.height;
        n.index.getSystemInfo({
          success: function (e) {
            var t = e.statusBarHeight,
              n = a - t;
            (c.value.navHeight = r + 2 * n),
              (c.value.statusBarHeight = t),
              (c.value.buttonMargin = n);
          },
        });
      });
      var v = function () {
          n.index.navigateBack();
        },
        d = (function () {
          var n = t(
            e().mark(function t(n) {
              var a, r, u;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.prev = 0),
                          (e.next = 3),
                          s.messageInfo({
                            sn: null == (a = o.device) ? void 0 : a.sn,
                            messageId: n,
                          })
                        );
                      case 3:
                        (r = e.sent),
                          "A00000" == (u = r.data).resultCode &&
                            (console.log("res", u.data), (i.value = u.data)),
                          (e.next = 11);
                        break;
                      case 8:
                        (e.prev = 8),
                          (e.t0 = e.catch(0)),
                          console.error("获取信件详情失败:", e.t0);
                      case 11:
                      case "end":
                        return e.stop();
                    }
                },
                t,
                null,
                [[0, 8]]
              );
            })
          );
          return function (e) {
            return n.apply(this, arguments);
          };
        })();
      return function (e, t) {
        return {
          a: a._imports_0$4,
          b: 2 * c.value.buttonMargin + "px",
          c: n.o(v),
          d: c.value.navHeight + "px",
          e: c.value.statusBarHeight + "px",
          f: n.t(i.value.content),
          g: n.t(i.value.productName),
        };
      };
    },
  }),
  o = n._export_sfc(u, [["__scopeId", "data-v-0afd8f6b"]]);
wx.createPage(o);
