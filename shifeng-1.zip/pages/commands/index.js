var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  r = require("../../common/vendor.js"),
  t = require("../../api/index.js"),
  o = r.defineComponent({
    __name: "index",
    setup: function (o) {
      var i = r.ref(""),
        u = r.ref(!1);
      r.onLoad(function (e) {
        console.log(e), (i.value = e.code);
      });
      var a = (function () {
        var o = n(
          e().mark(function n() {
            var o, a, c, s;
            return e().wrap(
              function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      if (!u.value) {
                        e.next = 3;
                        break;
                      }
                      return (
                        console.log("正在跳转，跳过重复请求"),
                        e.abrupt("return")
                      );
                    case 3:
                      return (
                        (e.prev = 3),
                        (e.next = 6),
                        t.isBindDevice({
                          code: i.value,
                          date: new Date().toISOString(),
                        })
                      );
                    case 6:
                      if (((c = e.sent), "A00000" != (s = c.data).resultCode)) {
                        e.next = 15;
                        break;
                      }
                      return (
                        console.log(s.data),
                        0 ===
                        (
                          (null == (o = s.data) ? void 0 : o.deviceInfoList) ||
                          []
                        ).length
                          ? ((u.value = !0),
                            setTimeout(function () {
                              r.index.reLaunch({ url: "/pages/device/device" });
                            }, 100))
                          : ((u.value = !0),
                            setTimeout(function () {
                              r.index.navigateTo({
                                url:
                                  "/pages/commandsPage/index?source=nfc&code=" +
                                  i.value,
                              });
                            }, 100)),
                        e.abrupt("return", !0)
                      );
                    case 15:
                      "A00000" !== s.resultCode &&
                        "A00002" !== s.resultCode &&
                        (console.log("请求成功的错误码:", s.resultCode),
                        (u.value = !0),
                        setTimeout(function () {
                          r.index.reLaunch({ url: "/pages/index/index" });
                        }, 100));
                    case 16:
                      e.next = 27;
                      break;
                    case 18:
                      if (
                        ((e.prev = 18),
                        (e.t0 = e.catch(3)),
                        console.log("getIsBindDevice error", e.t0),
                        401 != e.t0.statusCode &&
                          "A00002" !=
                            (null == (a = e.t0.data) ? void 0 : a.resultCode))
                      ) {
                        e.next = 25;
                        break;
                      }
                      return (
                        (u.value = !0),
                        setTimeout(function () {
                          r.index.reLaunch({ url: "/pages/login/index" });
                        }, 100),
                        e.abrupt("return", !1)
                      );
                    case 25:
                      (u.value = !0),
                        setTimeout(function () {
                          r.index.reLaunch({ url: "/pages/index/index" });
                        }, 100);
                    case 27:
                    case "end":
                      return e.stop();
                  }
              },
              n,
              null,
              [[3, 18]]
            );
          })
        );
        return function () {
          return o.apply(this, arguments);
        };
      })();
      r.onShow(function () {
        (u.value = !1),
          r.index.showLoading({ title: "加载中...", mask: !0 }),
          c() ? a() : r.index.hideLoading();
      });
      var c = function () {
        if (u.value) return console.log("正在跳转，跳过 token 检查"), !1;
        console.log("checkTokenIsExpired");
        var e = r.index.getAccountInfoSync().miniProgram.envVersion;
        return (
          !!r.index.getStorageSync(e + "token") ||
          ((u.value = !0),
          setTimeout(function () {
            r.index.reLaunch({ url: "/pages/login/index" });
          }, 100),
          !1)
        );
      };
      return (
        r.onHide(function () {
          r.index.hideLoading();
        }),
        function (e, n) {
          return {};
        }
      );
    },
  });
wx.createPage(o);
