var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  t = require("../../common/vendor.js"),
  r = require("../../common/assets.js"),
  u = require("../../api/index.js"),
  a = require("../../store/deviceStore.js");
Array ||
  (
    t.resolveComponent("uni-swipe-action-item") +
    t.resolveComponent("uni-swipe-action")
  )();
Math ||
  (
    function () {
      return "../../uni_modules/uni-swipe-action/components/uni-swipe-action-item/uni-swipe-action-item.js";
    } +
    function () {
      return "../../uni_modules/uni-swipe-action/components/uni-swipe-action/uni-swipe-action.js";
    }
  )();
var o = t.defineComponent({
    __name: "index",
    setup: function (o) {
      var i = t.ref(!1),
        s = a.useDeviceStore(),
        l = t.ref({ navHeight: "", statusBarHeight: 0, buttonMargin: 0 }),
        c = t.ref();
      t.onLoad(function () {
        var e = t.index.getMenuButtonBoundingClientRect(),
          n = e.top,
          r = e.height;
        t.index.getSystemInfo({
          success: function (e) {
            var t = e.statusBarHeight,
              u = n - t;
            (l.value.navHeight = r + t),
              (l.value.statusBarHeight = t),
              (l.value.buttonMargin = u);
          },
        });
      });
      var v = function () {
          t.nextTick$1(function () {
            c.value
              ? c.value.closeAll()
              : (console.warn("uniSwipeActionRef 尚未就绪"),
                console.log(c.value, "================~~============"));
          });
        },
        f = t.ref([]),
        p = (function () {
          var t = n(
            e().mark(function n() {
              var t, r, a, o;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.prev = 0),
                          (e.next = 3),
                          u.promptListAPI({
                            sn:
                              (null == (t = null == s ? void 0 : s.device)
                                ? void 0
                                : t.sn) || "",
                          })
                        );
                      case 3:
                        (a = e.sent),
                          (o = a.data),
                          console.log(o, "res promptListAPI"),
                          "A00000" === o.resultCode &&
                            (f.value =
                              (null == (r = null == o ? void 0 : o.data)
                                ? void 0
                                : r.list) || []),
                          (e.next = 12);
                        break;
                      case 9:
                        (e.prev = 9),
                          (e.t0 = e.catch(0)),
                          console.error("获取列表失败:", e.t0);
                      case 12:
                      case "end":
                        return e.stop();
                    }
                },
                n,
                null,
                [[0, 9]]
              );
            })
          );
          return function () {
            return t.apply(this, arguments);
          };
        })();
      t.onShow(function () {
        p();
      });
      var d = t.ref(!1),
        h = t.ref(""),
        g = t.ref(!t.index.getStorageSync("readFinish")),
        m = t.ref(),
        x = t.ref(!1),
        w = t.computed(function () {
          var e;
          return null ==
            (e = f.value.filter(function (e) {
              return 1 === e.status;
            }))
            ? void 0
            : e.length;
        }),
        b = t.ref(null),
        k = (function () {
          var r = n(
            e().mark(function n(r, u) {
              return e().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      if (1 !== u.type) {
                        e.next = 3;
                        break;
                      }
                      return (
                        t.index.showToast({
                          title: "系统预设关键词无法删除",
                          icon: "none",
                        }),
                        e.abrupt("return")
                      );
                    case 3:
                      (i.value = !0), (b.value = r);
                    case 5:
                    case "end":
                      return e.stop();
                  }
              }, n);
            })
          );
          return function (e, n) {
            return r.apply(this, arguments);
          };
        })(),
        y = (function () {
          var t = n(
            e().mark(function n() {
              var t, r;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (t = f.value[b.value]),
                          (e.prev = 1),
                          (e.next = 4),
                          u.promptDeleteAPI(t.id)
                        );
                      case 4:
                        (r = e.sent),
                          "A00000" === r.data.resultCode &&
                            ((i.value = !1), p()),
                          (e.next = 12);
                        break;
                      case 9:
                        (e.prev = 9),
                          (e.t0 = e.catch(1)),
                          console.error("删除关键词失败:", e.t0);
                      case 12:
                      case "end":
                        return e.stop();
                    }
                },
                n,
                null,
                [[1, 9]]
              );
            })
          );
          return function () {
            return t.apply(this, arguments);
          };
        })(),
        A = function () {
          (d.value = !1), (h.value = ""), (H.value = 0), (x.value = !1);
        };
      t.index.onKeyboardHeightChange(function (e) {
        console.log(e.height, "高度高度高度高度");
      });
      var C = function (e) {
          var n = e.target.value.replace(/\s*/g, "");
          t.nextTick$1(function () {
            h.value = n;
          });
        },
        _ = (function () {
          var r = n(
            e().mark(function n() {
              var r, a, o;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (h.value.trim()) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return");
                      case 2:
                        return (
                          (x.value = !0),
                          (e.prev = 3),
                          (e.next = 6),
                          u.promptAddAPI({
                            sn:
                              (null == (r = null == s ? void 0 : s.device)
                                ? void 0
                                : r.sn) || "",
                            content: h.value,
                          })
                        );
                      case 6:
                        if (
                          ((a = e.sent), "A00000" !== (o = a.data).resultCode)
                        ) {
                          e.next = 15;
                          break;
                        }
                        return (
                          t.index.showToast({
                            title: "添加成功",
                            icon: "none",
                          }),
                          (e.next = 12),
                          p()
                        );
                      case 12:
                        A(), (e.next = 17);
                        break;
                      case 15:
                        t.index.showToast({
                          title: o.resultMsg || "添加失败",
                          icon: "none",
                        }),
                          (x.value = !1);
                      case 17:
                        e.next = 24;
                        break;
                      case 19:
                        (e.prev = 19),
                          (e.t0 = e.catch(3)),
                          console.error("添加自定义关键词失败:", e.t0),
                          t.index.showToast({
                            title: "添加失败",
                            icon: "none",
                          }),
                          (x.value = !1);
                      case 24:
                      case "end":
                        return e.stop();
                    }
                },
                n,
                null,
                [[3, 19]]
              );
            })
          );
          return function () {
            return r.apply(this, arguments);
          };
        })(),
        S = t.ref(!1),
        T = (function () {
          var t = n(
            e().mark(function n() {
              var t, r, a;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (
                          ((t = f.value.filter(function (e) {
                            return 1 === e.status;
                          })),
                          console.log(t, "selectedKeywords"),
                          0 !== t.length)
                        ) {
                          e.next = 4;
                          break;
                        }
                        return e.abrupt("return");
                      case 4:
                        return (
                          (r = f.value.map(function (e) {
                            return { id: e.id, status: e.status };
                          })),
                          console.log(t, "selectedKeywords", r),
                          (e.prev = 6),
                          (e.next = 9),
                          u.promptUpdateStatusAPI({ list: r })
                        );
                      case 9:
                        (a = e.sent),
                          "A00000" === a.data.resultCode &&
                            ((S.value = !0), p()),
                          (e.next = 17);
                        break;
                      case 14:
                        (e.prev = 14),
                          (e.t0 = e.catch(6)),
                          console.error("更新关键词失败:", e.t0);
                      case 17:
                      case "end":
                        return e.stop();
                    }
                },
                n,
                null,
                [[6, 14]]
              );
            })
          );
          return function () {
            return t.apply(this, arguments);
          };
        })();
      t.nextTick$1(function () {
        d.value && m.value && m.value.focus();
      });
      var j = function (e) {
          console.log(e);
        },
        H = t.ref(0),
        q = function (e) {
          console.log(e), (H.value = e.detail.height);
        },
        I = function () {
          setTimeout(function () {
            0 !== H.value || x.value || A();
          }, 200);
        };
      t.onMounted(function () {
        t.index.onKeyboardHeightChange(function (e) {
          console.log("键盘高度变化:", e.height),
            (H.value = e.height),
            e.height > 0 && (x.value = !1),
            0 === e.height &&
              d.value &&
              !x.value &&
              setTimeout(function () {
                A();
              }, 200);
        });
      }),
        t.onUnmounted(function () {
          t.index.offKeyboardHeightChange();
        });
      return function (e, n) {
        return t.e(
          {
            a: t.f(f.value, function (e, n, u) {
              return t.e(
                { a: t.t(e.content), b: 1 === e.status },
                1 === e.status ? { c: r._imports_0$11 } : {},
                { d: 0 === e.status },
                0 === e.status ? { e: r._imports_1$4 } : {},
                {
                  f: t.o(function (e) {
                    return (function (e) {
                      f.value[e].status = 0 === f.value[e].status ? 1 : 0;
                    })(n);
                  }, e.id),
                  g: n === f.value.length - 1 ? 0 : "24rpx",
                  h: 1 === e.status ? "#F9F0C6" : "#fff",
                  i: 1 !== e.type,
                },
                1 !== e.type
                  ? {
                      j: r._imports_2$4,
                      k: t.o(function (t) {
                        return k(n, e);
                      }, e.id),
                    }
                  : {},
                {
                  l: e.id,
                  m: t.o(j, e.id),
                  n: "2384df43-1-" + u + ",2384df43-0",
                }
              );
            }),
            b: t.p({ autoClose: !0 }),
            c: t.sr(c, "2384df43-0", { k: "uniSwipeActionRef" }),
            d: f.value.length >= 10 ? 1 : "",
            e: t.o(function () {
              f.value.length >= 10 || ((d.value = !0), (x.value = !0));
            }),
            f: t.o(T),
            g: t.n(0 === f.value.length || 0 === w.value ? "disabled" : ""),
            h: d.value,
          },
          d.value ? { i: t.o(I) } : {},
          { j: d.value },
          d.value
            ? t.e(
                {
                  k: t.o([
                    function (e) {
                      return (h.value = e.detail.value);
                    },
                    C,
                  ]),
                  l: t.o(_),
                  m: t.o(q),
                  n: t.o(I),
                  o: h.value,
                  p: h.value,
                },
                h.value ? { q: h.value ? "" : 1, r: !h.value, s: t.o(_) } : {},
                { t: H.value + "px" }
              )
            : {},
          { v: g.value },
          g.value
            ? {
                w: t.o(function (e) {
                  return (
                    (g.value = !1),
                    void t.index.setStorageSync("readFinish", !0)
                  );
                }),
              }
            : {},
          { x: i.value },
          i.value
            ? {
                y: t.o(y),
                z: t.o(function (e) {
                  return (i.value = !1);
                }),
              }
            : {},
          { A: S.value },
          S.value
            ? {
                B: t.o(function (e) {
                  return (S.value = !1);
                }),
              }
            : {},
          { C: t.o(v) }
        );
      };
    },
  }),
  i = t._export_sfc(o, [["__scopeId", "data-v-2384df43"]]);
wx.createPage(i);
