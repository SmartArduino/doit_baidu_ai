var e = require("../../common/vendor.js"),
  n = require("../../common/assets.js"),
  u = e.defineComponent({
    __name: "index",
    setup: function (u) {
      var a = [
          { label: "每天", value: "everyday" },
          { label: "星期一", value: 1 },
          { label: "星期二", value: 2 },
          { label: "星期三", value: 3 },
          { label: "星期四", value: 4 },
          { label: "星期五", value: 5 },
          { label: "星期六", value: 6 },
          { label: "星期日", value: 0 },
        ],
        r = e.ref([]);
      e.onMounted(function () {
        var n = e.index.getStorageSync("prohibitUseRepeatSelected");
        Array.isArray(n) && n.length > 0
          ? (r.value = n
              .map(function (e) {
                return a.findIndex(function (n) {
                  return n.value === e;
                });
              })
              .filter(function (e) {
                return -1 !== e;
              }))
          : (r.value = [0]);
      });
      var t = function () {
        var n = r.value
          .map(function (e) {
            return a[e].value;
          })
          .filter(function (e) {
            return "number" == typeof e;
          })
          .sort(function (e, n) {
            return 0 === e ? 1 : 0 === n ? -1 : e - n;
          });
        r.value.includes(0) && n.unshift("everyday"),
          e.index.setStorageSync("prohibitUseRepeatSelected", n),
          e.index.navigateBack();
      };
      return function (u, l) {
        return {
          a: e.f(a, function (u, t, l) {
            return e.e(
              { a: e.t(u.label), b: r.value.includes(t) },
              r.value.includes(t) ? { c: n._imports_0$8 } : {},
              {
                d: u.value,
                e: e.o(function (e) {
                  return (function (e) {
                    if ("everyday" === a[e].value)
                      r.value.includes(e) ? (r.value = []) : (r.value = [e]);
                    else {
                      var n = a.findIndex(function (e) {
                        return "everyday" === e.value;
                      });
                      r.value = r.value.filter(function (e) {
                        return e !== n;
                      });
                      var u = r.value.indexOf(e);
                      u > -1 ? r.value.splice(u, 1) : r.value.push(e),
                        a
                          .map(function (e, n) {
                            return "number" == typeof e.value ? n : -1;
                          })
                          .filter(function (e) {
                            return -1 !== e;
                          })
                          .every(function (e) {
                            return r.value.includes(e);
                          }) && (r.value = [n]);
                    }
                  })(t);
                }, u.value),
              }
            );
          }),
          b: e.o(t),
        };
      };
    },
  }),
  a = e._export_sfc(u, [["__scopeId", "data-v-46e0576c"]]);
wx.createPage(a);
