var e = require("../../common/vendor.js"),
  a = require("../../common/assets.js");
Array || e.resolveComponent("uni-easyinput")();
Math;
var t = e.defineComponent({
    __name: "index",
    setup: function (t) {
      var n = e.ref({ navHeight: "", statusBarHeight: 0, buttonMargin: 0 }),
        u = e.ref({ name: "", code: 1 });
      e.onLoad(function () {
        var a = e.index.getMenuButtonBoundingClientRect(),
          t = a.top,
          u = a.height;
        e.index.getSystemInfo({
          success: function (e) {
            var a = e.statusBarHeight,
              o = t - a;
            (n.value.navHeight = u + a + 2 * o),
              (n.value.statusBarHeight = a),
              (n.value.buttonMargin = o);
          },
        });
      });
      var o = function () {
        e.index.navigateBack();
      };
      return function (t, r) {
        return {
          a: a._imports_0$2,
          b: e.o(o),
          c: "".concat(n.value.statusBarHeight, "px"),
          d: "".concat(n.value.statusBarHeight, "px"),
          e: "".concat(n.value.navHeight, "px"),
          f: e.o(function (e) {
            return (u.value.name = e);
          }),
          g: e.p({
            maxlength: "11",
            type: "number",
            clearable: !1,
            placeholder: "输入手机号",
            modelValue: u.value.name,
          }),
          h: e.o(function (e) {
            return (u.value.code = e);
          }),
          i: e.p({
            maxlength: "6",
            type: "number",
            clearable: !1,
            placeholder: "输入验证码",
            modelValue: u.value.code,
          }),
          j: "".concat(n.value.navHeight, "px"),
        };
      };
    },
  }),
  n = e._export_sfc(t, [["__scopeId", "data-v-c5d9c666"]]);
wx.createPage(n);
