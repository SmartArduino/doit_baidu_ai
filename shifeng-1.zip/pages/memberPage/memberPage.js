var e = require("../../common/vendor.js"),
  t = require("../../common/assets.js"),
  n = require("../../api/index.js"),
  a = e.defineComponent({
    __name: "memberPage",
    setup: function (a) {
      var i = e.ref({ navHeight: "", statusBarHeight: 0, buttonMargin: 0 });
      e.onLoad(function () {
        var t = e.index.getMenuButtonBoundingClientRect(),
          n = t.top,
          a = t.height;
        e.index.getSystemInfo({
          success: function (e) {
            var t = e.statusBarHeight,
              o = n - t;
            (i.value.navHeight = a + t + 2 * o),
              (i.value.statusBarHeight = t),
              (i.value.buttonMargin = o);
          },
        });
      }),
        e.onShow(function () {
          u();
        });
      var o = e.ref([]),
        u = function () {
          n.userDeviceList()
            .then(function (e) {
              o.value = e.data.data.list;
            })
            .catch(function (e) {
              console.log(e);
            });
        },
        r = function () {
          e.index.navigateBack();
        };
      return (
        e.onShareAppMessage(function () {
          return {};
        }),
        e.onShareTimeline(function () {
          return {};
        }),
        function (n, a) {
          return e.e(
            {
              a: t._imports_0$2,
              b: "".concat(i.value.statusBarHeight, "px"),
              c: e.o(r),
              d: "".concat(i.value.statusBarHeight, "px"),
              e: "".concat(i.value.navHeight, "px"),
              f: o.value.length > 0,
            },
            (o.value.length, {}),
            {
              g: "".concat(i.value.navHeight, "px"),
              h: "34rpx",
              i: "calc(100vh - ".concat(i.value.navHeight, "px)"),
            }
          );
        }
      );
    },
  });
a.__runtimeHooks = 6;
var i = e._export_sfc(a, [["__scopeId", "data-v-2389659c"]]);
wx.createPage(i);
