var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  t = require("../../@babel/runtime/helpers/asyncToGenerator"),
  n = require("../../common/vendor.js"),
  a = require("../../common/assets.js"),
  r = require("../../store/useRoleStore.js"),
  o = require("../../api/index.js"),
  i = n.defineComponent({
    __name: "index",
    setup: function (i) {
      var u = r.useRoleStore(),
        s = n.ref([]),
        c = n.ref(""),
        l = n.ref({ navHeight: "", statusBarHeight: 0, buttonMargin: 0 });
      n.onLoad(function (e) {
        (null == e ? void 0 : e.sn) && (c.value = e.sn);
        var t = n.index.getMenuButtonBoundingClientRect(),
          a = t.top,
          r = t.height;
        n.index.getSystemInfo({
          success: function (e) {
            var t = e.statusBarHeight,
              n = a - t;
            (l.value.navHeight = r + t),
              (l.value.statusBarHeight = t),
              (l.value.buttonMargin = n);
          },
        });
      }),
        n.onShow(function () {
          d();
        });
      var d = (function () {
        var n = t(
          e().mark(function t() {
            var n, a, r, i, l;
            return e().wrap(
              function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (
                        console.log("sn:", c.value),
                        (e.prev = 1),
                        (e.next = 4),
                        o.characterList({ sn: c.value })
                      );
                    case 4:
                      (r = e.sent),
                        "A00000" ===
                          (null == (i = r.data) ? void 0 : i.resultCode) &&
                          (null ==
                          (a =
                            null == (n = null == i ? void 0 : i.data)
                              ? void 0
                              : n.list)
                            ? void 0
                            : a.length) &&
                          ((s.value = i.data.list),
                          u.setRoleList(i.data.list),
                          (l = i.data.list.find(function (e) {
                            return 1 === e.bindStatus;
                          })) && u.setRole(l)),
                        (e.next = 12);
                      break;
                    case 9:
                      (e.prev = 9),
                        (e.t0 = e.catch(1)),
                        console.error("Failed to fetch character list:", e.t0);
                    case 12:
                    case "end":
                      return e.stop();
                  }
              },
              t,
              null,
              [[1, 9]]
            );
          })
        );
        return function () {
          return n.apply(this, arguments);
        };
      })();
      return function (e, t) {
        return {
          a: n.f(s.value, function (e, t, a) {
            return n.e(
              { a: e.thumbnailImg, b: n.t(e.name), c: 1 === e.bindStatus },
              (e.bindStatus, {}),
              {
                d: n.t(e.introduce),
                e: e.code,
                f: n.o(function (t) {
                  return (
                    (a = e),
                    u.setRoleDetailPageHeader(a.name || "Role setting"),
                    void n.index.navigateTo({
                      url: "/pages/characterDetail/index?sn="
                        .concat(c.value, "&code=")
                        .concat(a.code),
                    })
                  );
                  var a;
                }, e.code),
              }
            );
          }),
          b: a._imports_0$5,
        };
      };
    },
  }),
  u = n._export_sfc(i, [["__scopeId", "data-v-dcc1b6a1"]]);
wx.createPage(u);
