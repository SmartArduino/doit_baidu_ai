var e = require("../../common/vendor.js"),
  n = require("../../common/assets.js");
Math || t();
var t = function () {
    return "../../components/Account/Account.js";
  },
  i = e.defineComponent({
    __name: "index",
    setup: function (t) {
      var i = e.ref(null),
        o = function (n) {
          var t = e.index.getAccountInfoSync(),
            o = e.ref(t.miniProgram.envVersion);
          if (!e.index.getStorageSync(o.value + "token"))
            return (
              e.index.showToast({
                title: "用户未登录",
                icon: "none",
                duration: 2e3,
              }),
              clearTimeout(i.value),
              void (i.value = setTimeout(function () {
                e.index.navigateTo({ url: "/pages/login/index" });
              }, 1e3))
            );
          e.index.navigateTo({ url: n });
        },
        r = e.ref({ navHeight: "", statusBarHeight: 0, buttonMargin: 0 });
      return (
        e.onLoad(function () {
          var n = e.index.getMenuButtonBoundingClientRect(),
            t = n.top,
            i = n.height;
          e.index.getSystemInfo({
            success: function (e) {
              var n = e.statusBarHeight,
                o = t - n;
              (r.value.navHeight = i + n),
                (r.value.statusBarHeight = n),
                (r.value.buttonMargin = o);
            },
          });
        }),
        function (t, i) {
          return {
            a: r.value.navHeight + 16 + "px",
            b: n._imports_0,
            c: n._imports_1,
            d: e.o(function (e) {
              return o("/pages/switchingToy/switchingToy");
            }),
            e: n._imports_2,
            f: n._imports_1,
            g: e.o(function (e) {
              return o("/pages/familyAccount/index");
            }),
            h: n._imports_3,
            i: n._imports_1,
            j: e.o(function (e) {
              return o("/pages/userFeedback/index");
            }),
            k: n._imports_4,
            l: n._imports_1,
            m: e.o(function (e) {
              return o("/pages/setting/setting");
            }),
          };
        }
      );
    },
  }),
  o = e._export_sfc(i, [["__scopeId", "data-v-b1f18929"]]);
wx.createPage(o);
