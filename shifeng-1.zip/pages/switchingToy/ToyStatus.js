var t = require("../../common/vendor.js"),
  e = t.defineComponent({
    __name: "ToyStatus",
    props: { networkStatus: {}, switchStatus: {}, rebindStatus: {} },
    setup: function (e) {
      return function (e, o) {
        return t.e(
          { a: void 0 !== e.networkStatus },
          void 0 !== e.networkStatus
            ? {
                b: t.t(e.networkStatus ? "在线" : "离线"),
                c: t.n(e.networkStatus ? "online" : "offline"),
              }
            : {},
          { d: void 0 !== e.switchStatus },
          void 0 !== e.switchStatus
            ? {
                e: t.t(e.switchStatus ? "开启" : "关闭"),
                f: t.n(e.switchStatus ? "toggle-on" : "toggle-off"),
              }
            : {}
        );
      };
    },
  }),
  o = t._export_sfc(e, [["__scopeId", "data-v-c702c013"]]);
wx.createComponent(o);
