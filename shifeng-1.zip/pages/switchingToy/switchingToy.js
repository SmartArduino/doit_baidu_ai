var e = require("../../@babel/runtime/helpers/defineProperty"),
  t = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  r = require("../../common/vendor.js"),
  a = require("../../common/assets.js"),
  o = require("../../store/deviceStore.js"),
  c = require("../../api/index.js");
Math || (i + u)();
var i = function () {
    return "./ToyStatus.js";
  },
  u = function () {
    return "../../components/Device/NotFound.js";
  },
  s = r.defineComponent({
    __name: "switchingToy",
    setup: function (i) {
      var u = o.useDeviceStore(),
        s = r.ref([]),
        l = (function () {
          var e = n(
            t().mark(function e() {
              var n, r;
              return t().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (e.prev = 0), (e.next = 3), c.userDeviceList();
                      case 3:
                        (n = e.sent),
                          "A00000" === (r = n.data).resultCode &&
                            ((s.value = r.data.list),
                            u.setDevices(r.data.list)),
                          (e.next = 11);
                        break;
                      case 8:
                        (e.prev = 8),
                          (e.t0 = e.catch(0)),
                          console.error("获取设备列表失败:", e.t0);
                      case 11:
                      case "end":
                        return e.stop();
                    }
                },
                e,
                null,
                [[0, 8]]
              );
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })();
      r.onShow(function () {
        l();
      });
      var v = function () {
        r.index.navigateTo({ url: "/pages/device/device" });
      };
      return function (t, n) {
        return r.e(
          { a: s.value.length > 0 },
          s.value.length > 0
            ? {
                b: r.f(s.value, function (t, n, a) {
                  return {
                    a:
                      t.thumbnailImg ||
                      "https://vseed-toystory.bj.bcebos.com/2025/05/22/0c52c11f-19c8-4e77-843c-fdad91c7314e.png",
                    b: r.t(t.nickname || t.productName),
                    c: "cec72690-0-" + a,
                    d: r.p(e({}, "network-status", t.networkStatus)),
                    e: r.t(t.sn),
                    f: t.sn,
                    g: r.o(function (e) {
                      return (function (e) {
                        u.setDeviceDetail(e),
                          r.index.navigateTo({
                            url: "/pages/toyDetail/index?id=".concat(e.id),
                          });
                      })(t);
                    }, t.sn),
                  };
                }),
                c: a._imports_1,
              }
            : {},
          { d: s.value.length > 0 },
          s.value.length > 0 ? { e: r.o(v) } : {}
        );
      };
    },
  }),
  l = r._export_sfc(s, [["__scopeId", "data-v-cec72690"]]);
wx.createPage(l);
