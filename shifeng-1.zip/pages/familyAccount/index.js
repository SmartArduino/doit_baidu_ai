var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  r = require("../../common/vendor.js"),
  a = require("../../common/assets.js"),
  t = require("../../api/index.js"),
  u = r.defineComponent({
    __name: "index",
    setup: function (u) {
      var i = function (e, n) {
          c.value &&
            r.index.navigateTo({
              url:
                e +
                "?id=" +
                n.id +
                "&nickname=" +
                (n.nickname || "") +
                "&phoneNumber=" +
                (n.phoneNumber || "") +
                "&isOwner=" +
                (n.isOwner || ""),
            });
        },
        o = r.ref({
          id: -1,
          isOwner: 1,
          isUser: 1,
          nickname: "",
          phoneNumber: "",
        }),
        s = r.ref([]),
        l = r.ref({
          id: -1,
          isOwner: 0,
          isUser: 1,
          nickname: "",
          phoneNumber: "",
        }),
        c = r.ref(!1);
      return (
        r.onShow(function () {
          t.familyUserList()
            .then(function (e) {
              if ((console.log(e), 200 == e.statusCode)) {
                var n = e.data;
                if (
                  "A00000" == n.resultCode &&
                  (console.log(n.data.list, "~~~~~~~~~resp.data.list"),
                  n.data.list.length > 0)
                ) {
                  var r = n.data.list.findIndex(function (e) {
                    return 1 == e.isOwner;
                  });
                  (l.value = n.data.list.find(function (e) {
                    return 1 == e.isOwner;
                  })),
                    (o.value = n.data.list[r]),
                    (s.value = n.data.list.filter(function (e) {
                      return 0 == e.isOwner;
                    })),
                    (c.value = 1 == o.value.isOwner && 1 == o.value.isUser),
                    console.log(s.value),
                    console.log(r, o.value);
                }
              }
            })
            .catch(function (e) {
              console.log(e);
            });
        }),
        r.onShareAppMessage(
          n(
            e().mark(function n() {
              var r, a;
              return e().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (e.next = 2), t.familyUserShareCode();
                    case 2:
                      return (
                        (r = e.sent),
                        (a = r.data),
                        e.abrupt("return", {
                          title: "点开链接，加入家庭",
                          path:
                            "/pages/joinFamily/index?shareCode=" +
                            a.data.shareCode +
                            "&phoneNumber=" +
                            l.value.phoneNumber,
                          imageUrl:
                            "https://vseed-toystory.cdn.bcebos.com/2025/05/19/effd20a8-35f0-47ac-b57f-4c4289b42e7c.png",
                        })
                      );
                    case 5:
                    case "end":
                      return e.stop();
                  }
              }, n);
            })
          )
        ),
        r.onLoad(function () {}),
        function (e, n) {
          return r.e(
            {
              a: r.t(o.value.nickname || o.value.phoneNumber || "暂无昵称"),
              b: o.value.phoneNumber,
            },
            o.value.phoneNumber ? { c: r.t(o.value.phoneNumber) } : {},
            { d: c.value },
            c.value ? { e: a._imports_1 } : {},
            {
              f: r.o(function (e) {
                return i("/pages/member/index", o.value);
              }),
              g: s.value.length > 0,
            },
            s.value.length > 0
              ? {
                  h: r.f(s.value, function (e, n, t) {
                    return r.e(
                      {
                        a: r.t(e.nickname || e.phoneNumber || "暂无昵称"),
                        b: e.phoneNumber,
                      },
                      e.phoneNumber ? { c: r.t(e.phoneNumber) } : {},
                      c.value ? { d: a._imports_1 } : {},
                      {
                        e: e.id,
                        f: r.o(function (n) {
                          return i("/pages/member/index", e);
                        }, e.id),
                      }
                    );
                  }),
                  i: c.value,
                }
              : {},
            { j: c.value },
            (c.value, {})
          );
        }
      );
    },
  });
u.__runtimeHooks = 2;
var i = r._export_sfc(u, [["__scopeId", "data-v-29fc1682"]]);
wx.createPage(i);
