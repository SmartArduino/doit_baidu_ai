require("../../@babel/runtime/helpers/Arrayincludes");
var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  r = require("../../common/vendor.js"),
  t = require("../../common/assets.js"),
  u = require("../../api/index.js"),
  a = require("../../store/deviceStore.js"),
  i = r.defineComponent({
    __name: "index",
    setup: function (i) {
      var o = a.useDeviceStore(),
        c = Array.from({ length: 24 }, function (e, n) {
          return n < 10 ? "0" + n : "" + n;
        }),
        l = Array.from({ length: 6 }, function (e, n) {
          var r = 10 * n;
          return r < 10 ? "0".concat(r) : "".concat(r);
        }),
        s = r.ref([0, 0]),
        v = r.ref([0, 0]),
        f = function (e) {
          s.value = e.detail.value;
          var n = (Number(c[s.value[0]]) + 1) % 24,
            r = c.findIndex(function (e) {
              return Number(e) === n;
            });
          v.value = [r, 0];
        },
        d = function (e) {
          v.value = e.detail.value;
        },
        p = r.ref([]),
        m = {
          1: "周一",
          2: "周二",
          3: "周三",
          4: "周四",
          5: "周五",
          6: "周六",
          0: "周日",
        },
        b = r.computed(function () {
          return p.value && 0 !== p.value.length
            ? p.value
                .filter(function (e) {
                  return "number" == typeof e && m[e];
                })
                .map(function (e) {
                  return m[e];
                })
                .join("、")
            : "每天";
        }),
        x = (function () {
          var t = n(
            e().mark(function n() {
              var t, a, i, f, d, m, b, x;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (
                          ((a = Number(c[s.value[0]])),
                          (i = Number(l[s.value[1]])),
                          (f = Number(c[v.value[0]])),
                          (d = Number(l[v.value[1]])),
                          (m = {
                            sn:
                              (null == (t = null == o ? void 0 : o.device)
                                ? void 0
                                : t.sn) || "",
                            startHour: a,
                            startMinute: i,
                            endHour: f,
                            endMinute: d,
                            days: p.value,
                          }),
                          console.log(m, "reqData"),
                          (b = new Date(0, 0, 0, a, i)),
                          !(new Date(0, 0, 0, f, d) <= b))
                        ) {
                          e.next = 11;
                          break;
                        }
                        return (
                          r.index.showToast({
                            title: "结束时间必须晚于开始时间",
                            icon: "none",
                            duration: 2e3,
                          }),
                          e.abrupt("return")
                        );
                      case 11:
                        return (
                          (e.prev = 11), (e.next = 14), u.disableConfigSave(m)
                        );
                      case 14:
                        (x = e.sent),
                          "A00000" === x.data.resultCode &&
                            (r.index.showToast({
                              title: "保存成功",
                              icon: "none",
                              duration: 2e3,
                            }),
                            setTimeout(function () {
                              r.index.navigateBack();
                            }, 1e3)),
                          (e.next = 22);
                        break;
                      case 19:
                        (e.prev = 19), (e.t0 = e.catch(11)), console.log(e.t0);
                      case 22:
                      case "end":
                        return e.stop();
                    }
                },
                n,
                null,
                [[11, 19]]
              );
            })
          );
          return function () {
            return t.apply(this, arguments);
          };
        })();
      r.onLoad(function () {
        r.nextTick$1(function () {
          (s.value = [16, 0]), (v.value = [17, 0]);
        });
      }),
        r.onShow(function () {
          var e = r.index.getStorageSync("prohibitUseRepeatSelected");
          if (e) {
            if (e.includes("everyday")) return void (p.value = []);
            p.value = e;
          } else p.value = [];
        });
      var h = function () {
        r.index.navigateTo({ url: "/pages/prohibitUseRepeat/index" });
      };
      return function (e, n) {
        return {
          a: r.f(r.unref(c), function (e, n, t) {
            return {
              a: r.t(e),
              b: n,
              c: r.n(s.value[0] === n ? "picker-item-select-start" : ""),
            };
          }),
          b: r.f(r.unref(l), function (e, n, t) {
            return {
              a: r.t(e),
              b: n,
              c: r.n(s.value[1] === n ? "picker-item-select-end" : ""),
            };
          }),
          c: s.value,
          d: r.o(f),
          e: r.f(r.unref(c), function (e, n, t) {
            return {
              a: r.t(e),
              b: n,
              c: r.n(v.value[0] === n ? "picker-item-select-start" : ""),
            };
          }),
          f: r.f(r.unref(l), function (e, n, t) {
            return {
              a: r.t(e),
              b: n,
              c: r.n(v.value[1] === n ? "picker-item-select-end" : ""),
            };
          }),
          g: v.value,
          h: r.o(d),
          i: r.t(b.value),
          j: t._imports_1,
          k: r.o(h),
          l: r.o(x),
        };
      };
    },
  }),
  o = r._export_sfc(i, [["__scopeId", "data-v-f7ce4b06"]]);
wx.createPage(o);
