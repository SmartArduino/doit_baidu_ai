var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  t = require("../../common/vendor.js"),
  r = require("../../api/index.js"),
  a = t.defineComponent({
    __name: "index",
    setup: function (a) {
      var o = t.ref({});
      t.onLoad(function (e) {
        (o.value = e), (l.value = null == e ? void 0 : e.nickname);
      });
      var u = function () {
          var a;
          t.index.showModal({
            title: "提示",
            content: "确定删除该账号吗？",
            success:
              ((a = n(
                e().mark(function n(a) {
                  var u, i;
                  return e().wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            if (!a.confirm) {
                              e.next = 13;
                              break;
                            }
                            return (
                              (e.prev = 1),
                              (e.next = 4),
                              r.familyUserRemove({ userId: o.value.id })
                            );
                          case 4:
                            (u = e.sent),
                              (i = u.data),
                              console.log(i, "res delete"),
                              "A00000" === i.resultCode &&
                                (t.index.showToast({
                                  title: "删除成功",
                                  icon: "none",
                                  duration: 1e3,
                                }),
                                setTimeout(function () {
                                  t.index.navigateBack();
                                })),
                              (e.next = 13);
                            break;
                          case 10:
                            (e.prev = 10),
                              (e.t0 = e.catch(1)),
                              console.log(e.t0, "error");
                          case 13:
                          case "end":
                            return e.stop();
                        }
                    },
                    n,
                    null,
                    [[1, 10]]
                  );
                })
              )),
              function (e) {
                return a.apply(this, arguments);
              }),
          });
        },
        i = function () {
          var a;
          t.index.showModal({
            title: "提示",
            content: "确定提升为管理员吗？",
            success:
              ((a = n(
                e().mark(function n(a) {
                  var u, i;
                  return e().wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            if (!a.confirm) {
                              e.next = 13;
                              break;
                            }
                            return (
                              (e.prev = 1),
                              (e.next = 4),
                              r.familyUserOwner({ userId: o.value.id })
                            );
                          case 4:
                            (u = e.sent),
                              (i = u.data),
                              console.log(i, "确定提升为管理员吗？"),
                              "A00000" === i.resultCode &&
                                (t.index.showToast({
                                  title: "操作成功",
                                  icon: "none",
                                  duration: 1e3,
                                }),
                                setTimeout(function () {
                                  t.index.navigateBack();
                                })),
                              (e.next = 13);
                            break;
                          case 10:
                            (e.prev = 10),
                              (e.t0 = e.catch(1)),
                              console.log(e.t0, "error");
                          case 13:
                          case "end":
                            return e.stop();
                        }
                    },
                    n,
                    null,
                    [[1, 10]]
                  );
                })
              )),
              function (e) {
                return a.apply(this, arguments);
              }),
          });
        },
        s = t.ref(!1),
        c = t.ref(""),
        l = t.ref("");
      function v() {
        (c.value = l.value || ""), (s.value = !0);
      }
      function d() {
        return f.apply(this, arguments);
      }
      function f() {
        return (f = n(
          e().mark(function n() {
            var a;
            return e().wrap(
              function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (
                        (e.prev = 0),
                        (e.next = 3),
                        r.familyUserUpdate({
                          userId: o.value.id,
                          nickname: c.value,
                        })
                      );
                    case 3:
                      (a = e.sent),
                        "A00000" === a.data.resultCode &&
                          ((l.value = c.value),
                          t.index.showToast({
                            title: "修改成功",
                            icon: "none",
                          }),
                          (s.value = !1)),
                        (e.next = 11);
                      break;
                    case 8:
                      (e.prev = 8), (e.t0 = e.catch(0)), console.log(e.t0);
                    case 11:
                    case "end":
                      return e.stop();
                  }
              },
              n,
              null,
              [[0, 8]]
            );
          })
        )).apply(this, arguments);
      }
      return function (e, n) {
        return t.e(
          {
            a: t.t(o.value.phoneNumber),
            b: t.t(l.value || "暂无昵称"),
            c: t.o(v),
            d: 0 == o.value.isOwner,
          },
          0 == o.value.isOwner ? { e: t.o(i) } : {},
          { f: 0 == o.value.isOwner },
          0 == o.value.isOwner ? { g: t.o(u) } : {},
          { h: s.value },
          s.value
            ? {
                i: c.value,
                j: t.o(function (e) {
                  return (c.value = e.detail.value);
                }),
                k: t.o(function (e) {
                  return (s.value = !1);
                }),
                l: t.o(d),
              }
            : {}
        );
      };
    },
  }),
  o = t._export_sfc(a, [["__scopeId", "data-v-97d9768f"]]);
wx.createPage(o);
