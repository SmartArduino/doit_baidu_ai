var e = require("../../@babel/runtime/helpers/defineProperty"),
  a = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  t = require("../../@babel/runtime/helpers/asyncToGenerator"),
  u = require("../../common/vendor.js"),
  n = require("../../common/assets.js"),
  r = require("../../api/index.js"),
  s = require("../../store/deviceStore.js");
Array ||
  (u.resolveComponent("uni-calendar") + u.resolveComponent("uni-popup"))();
Math ||
  (
    l +
    function () {
      return "../../uni_modules/uni-calendar/components/uni-calendar/uni-calendar.js";
    } +
    function () {
      return "../../uni_modules/uni-popup/components/uni-popup/uni-popup.js";
    }
  )();
var l = function () {
    return "../report/index.js";
  },
  o = u.defineComponent({
    __name: "index",
    setup: function (l) {
      var o = s.useDeviceStore(),
        v = u.ref("history"),
        i = u.ref(null);
      u.ref();
      var c = u.ref(!1),
        d = function () {
          console.log("clearRefreshTimer", i.value),
            null !== i.value && (clearInterval(i.value), (i.value = null));
        };
      function f(e) {
        return g.apply(this, arguments);
      }
      function g() {
        return (g = t(
          a().mark(function e(t) {
            return a().wrap(function (e) {
              for (;;)
                switch ((e.prev = e.next)) {
                  case 0:
                    if (((v.value = t), "history" !== t)) {
                      e.next = 9;
                      break;
                    }
                    return (
                      (_.value = !0),
                      (h.value = u.index.getStorageSync("selectDateStore")),
                      (e.next = 6),
                      D()
                    );
                  case 6:
                    u.dayjs().format("YYYY-MM-DD") === h.value
                      ? (d(), (i.value = setInterval(D, 5e3)))
                      : d(),
                      (e.next = 13);
                    break;
                  case 9:
                    u.index.setStorageSync("selectDateStore", h.value),
                      (k.value = !0),
                      h.value === u.dayjs().format("YYYY-MM-DD") &&
                        (h.value = u
                          .dayjs()
                          .subtract(1, "day")
                          .format("YYYY-MM-DD")),
                      d();
                  case 13:
                  case "end":
                    return e.stop();
                }
            }, e);
          })
        )).apply(this, arguments);
      }
      var m,
        p = u.ref(),
        h = u.ref(u.dayjs().format("YYYY-MM-DD")),
        y = u.ref(u.dayjs().format("YYYY-MM-DD HH:mm:ss"));
      u.index.setStorageSync("selectDateStore", h.value);
      var x = u.ref({ msgId: "", multi: !1, audioIdx: 0 }),
        b = u.ref([]),
        I = u.ref({ navHeight: "", statusBarHeight: 0, buttonMargin: 0 }),
        S = u.ref(1e7),
        Y = u.ref(!1),
        _ = u.ref(!0),
        D = function () {
          var e;
          console.log(h.value, "===========================");
          var a = {
            messageDate: h.value,
            sn:
              F.value ||
              (null == (e = null == o ? void 0 : o.device) ? void 0 : e.sn) ||
              "",
          };
          return (
            (Y.value = !0),
            r
              .wechatMessageList(a)
              .then(function (e) {
                if (((Y.value = !1), 200 == e.statusCode)) {
                  var a = e.data;
                  if ("A00000" == a.resultCode) {
                    var t = JSON.parse(JSON.stringify(b.value)),
                      u = JSON.parse(JSON.stringify(a.data.messageList));
                    if (JSON.stringify(t) == JSON.stringify(u)) return;
                    (b.value = a.data.messageList),
                      setTimeout(function () {
                        A();
                      }, 500),
                      (b.value = a.data.messageList);
                  }
                }
                _.value &&
                  (setTimeout(function () {
                    A();
                  }, 500),
                  (_.value = !1));
              })
              .catch(function (e) {
                console.log(e), (b.value = []), (Y.value = !1);
              })
          );
        },
        M = function () {
          p.value.close(), (k.value = !0), (j.value = !1);
        };
      u.onLoad(function () {
        var e = u.index.getMenuButtonBoundingClientRect(),
          a = e.top,
          t = e.height;
        u.index.getSystemInfo({
          success: function (e) {
            var u = e.statusBarHeight,
              n = a - u;
            (I.value.navHeight = t + u + 2 * n),
              (I.value.statusBarHeight = u),
              (I.value.buttonMargin = n);
          },
        });
      }),
        u.onTabItemTap(
          (function () {
            var e = t(
              a().mark(function e(t) {
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        1 === t.index &&
                          ((h.value = u.dayjs().format("YYYY-MM-DD")),
                          u.index.setStorageSync("selectDateStore", h.value),
                          (G.value = ""),
                          (F.value = ""),
                          (v.value = "history"));
                      case 1:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            );
            return function (a) {
              return e.apply(this, arguments);
            };
          })()
        ),
        u.onShow(
          t(
            a().mark(function e() {
              return a().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (
                        (c.value = !0),
                        (h.value =
                          u.index.getStorageSync("selectDateStore") ||
                          u.dayjs().format("YYYY-MM-DD")),
                        (G.value =
                          u.index.getStorageSync("selectedSnStore") || ""),
                        (F.value =
                          u.index.getStorageSync("selectedSnStore") || ""),
                        (e.next = 6),
                        q()
                      );
                    case 6:
                      if (c.value) {
                        e.next = 8;
                        break;
                      }
                      return e.abrupt("return");
                    case 8:
                      return (e.next = 10), D();
                    case 10:
                      if (c.value) {
                        e.next = 12;
                        break;
                      }
                      return e.abrupt("return");
                    case 12:
                      "history" === v.value &&
                      u.dayjs(y.value).format("YYYY-MM-DD") === h.value
                        ? (d(), (i.value = setInterval(D, 5e3)), (_.value = !0))
                        : d();
                    case 13:
                    case "end":
                      return e.stop();
                  }
              }, e);
            })
          )
        ),
        u.onBeforeUnmount(function () {
          d();
        }),
        u.onHide(function () {
          console.log("onHide 页面隐藏了"),
            (c.value = !1),
            d(),
            C(),
            z(),
            (G.value = ""),
            (F.value = ""),
            (N.value = []),
            (O.value = 0),
            (P.value = !1);
        }),
        u.onUnload(function () {
          console.log("onUnload 页面退出了"),
            d(),
            (G.value = ""),
            (F.value = ""),
            (N.value = []),
            (O.value = 0),
            z(),
            (P.value = !1);
        });
      var j = u.ref(!1),
        k = u.ref(!0),
        w = function () {
          p.value.open(),
            (y.value = u.dayjs().format("YYYY-MM-DD HH:mm:ss")),
            (k.value = !1),
            (j.value = !0);
        },
        L = function (e) {
          (h.value = e.fulldate),
            u.index.setStorageSync("selectDateStore", h.value),
            (j.value = !1),
            p.value.close(),
            (_.value = !0),
            (k.value = !0),
            D(),
            "history" === v.value && u.dayjs().format("YYYY-MM-DD") === h.value
              ? (d(), (i.value = setInterval(D, 5e3)))
              : d();
        };
      u.ref("");
      var T = u.ref(0),
        A = function () {
          if (b.value.length > 0) {
            var e = b.value[b.value.length - 1];
            console.log("scrollToBottom", "msg-" + e.messageId),
              (S.value = T.value),
              u.nextTick$1(function () {
                S.value = 1e7;
              });
          }
        },
        H = function (e) {
          T.value = e.detail.scrollTop;
        };
      function $(e) {
        if (x.value.msgId != e) {
          m && C(),
            ((m = u.index.createInnerAudioContext()).autoplay = !1),
            (m.loop = !1),
            m.onEnded(function () {
              !(function () {
                var e = b.value.find(function (e) {
                  return e.messageId == x.value.msgId;
                });
                e && x.value.audioIdx < e.messageAudioList.length - 1
                  ? (x.value.audioIdx++,
                    (a = e.messageAudioList[x.value.audioIdx]) &&
                      ((m.src = a), m.play()))
                  : C();
                var a;
              })();
            }),
            (x.value.msgId = e);
          var a = b.value.find(function (a) {
            return a.messageId == e;
          });
          (null == a ? void 0 : a.messageAudioList) &&
            a.messageAudioList.length > 0 &&
            ((x.value.msgId = a.messageId),
            (m.src = a.messageAudioList[0]),
            m.play());
        } else C();
      }
      function C() {
        m && m.stop(),
          (x.value.audioIdx = 0),
          (x.value.msgId = ""),
          (x.value.multi = !1);
      }
      var N = u.ref([]),
        B = u.ref(!1);
      function q() {
        return J.apply(this, arguments);
      }
      function J() {
        return (J = t(
          a().mark(function e() {
            var t, u, n, s, l;
            return a().wrap(
              function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (
                        (e.prev = 0),
                        (B.value = !0),
                        (e.next = 4),
                        r.userDeviceList()
                      );
                    case 4:
                      if (
                        ((n = e.sent),
                        "A00000" !==
                          (null == (s = n.data) ? void 0 : s.resultCode))
                      ) {
                        e.next = 14;
                        break;
                      }
                      if (((l = s.data.list || []), (N.value = l), !G.value)) {
                        e.next = 11;
                        break;
                      }
                      return e.abrupt("return");
                    case 11:
                      (F.value = G.value =
                        (null ==
                        (t = l.find(function (e) {
                          return 1 === e.switchStatus;
                        }))
                          ? void 0
                          : t.sn) || ""),
                        (E.value =
                          (null ==
                          (u = l.find(function (e) {
                            return 1 === e.switchStatus;
                          }))
                            ? void 0
                            : u.productName) || ""),
                        !G.value &&
                          l.length > 0 &&
                          ((G.value = l[0].sn),
                          (F.value = l[0].sn),
                          (E.value = l[0].productName));
                    case 14:
                      e.next = 20;
                      break;
                    case 16:
                      (e.prev = 16),
                        (e.t0 = e.catch(0)),
                        (b.value = []),
                        console.error(e.t0);
                    case 20:
                      return (e.prev = 20), (B.value = !1), e.finish(20);
                    case 23:
                    case "end":
                      return e.stop();
                  }
              },
              e,
              null,
              [[0, 16, 20, 23]]
            );
          })
        )).apply(this, arguments);
      }
      var O = u.ref(0),
        R = u.ref(),
        P = u.ref(!1);
      function U() {
        (P.value = !0),
          (k.value = !1),
          setTimeout(function () {
            R.value.open();
          }, 500);
      }
      function z() {
        P.value && ((k.value = !0), (P.value = !1), R.value.close());
      }
      var E = u.ref("");
      var G = u.ref(""),
        F = u.ref("");
      function K() {
        (F.value = G.value),
          u.index.setStorageSync("selectedSnStore", F.value),
          (_.value = !0),
          (k.value = !0),
          "history" === v.value && D(),
          z();
      }
      return function (a, t) {
        return u.e(
          { a: "history" === v.value },
          (v.value, {}),
          {
            b: "history" === v.value ? 1 : "",
            c: u.o(function (e) {
              return f("history");
            }),
            d: "report" === v.value,
          },
          (v.value, {}),
          {
            e: "report" === v.value ? 1 : "",
            f: u.o(function (e) {
              return f("report");
            }),
            g: "".concat(I.value.statusBarHeight, "px"),
            h: u.t(h.value),
            i: u.o(w),
            j: !!j.value,
          },
          !j.value ? {} : { k: n._imports_0$1 },
          { l: !j.value },
          j.value ? {} : { m: n._imports_1$1 },
          { n: N.value.length > 0 && 0 == B.value },
          N.value.length > 0 && 0 == B.value
            ? u.e(
                { o: u.t(E.value), p: !!j.value },
                !j.value ? {} : { q: n._imports_0$1 },
                { r: !j.value },
                j.value ? {} : { s: n._imports_1$1 },
                { t: u.o(U) }
              )
            : {},
          { v: "history" === v.value },
          "history" === v.value
            ? u.e(
                { w: 0 == b.value.length },
                0 == b.value.length ? { x: n._imports_2$1 } : {},
                { y: b.value.length > 0 },
                b.value.length > 0
                  ? {
                      z: u.f(b.value, function (e, a, t) {
                        var r, s, l, o;
                        return u.e(
                          { a: 1 == e.senderType },
                          1 == e.senderType
                            ? u.e(
                                {
                                  b:
                                    (null == (r = e.messageAudioList)
                                      ? void 0
                                      : r.length) > 0,
                                },
                                (null == (s = e.messageAudioList)
                                  ? void 0
                                  : s.length) > 0
                                  ? u.e(
                                      { c: e.message.length >= 18 },
                                      e.message.length >= 18
                                        ? { d: n._imports_3$1 }
                                        : {},
                                      { e: e.message.length < 18 },
                                      e.message.length < 18
                                        ? { f: n._imports_4$1 }
                                        : {},
                                      { g: u.unref(x).msgId != e.messageId },
                                      u.unref(x).msgId != e.messageId
                                        ? { h: n._imports_1$2 }
                                        : {},
                                      { i: u.unref(x).msgId == e.messageId },
                                      u.unref(x).msgId == e.messageId
                                        ? { j: n._imports_2$2 }
                                        : {},
                                      {
                                        k: u.o(function (a) {
                                          return $(e.messageId);
                                        }, e.messageId),
                                      }
                                    )
                                  : {},
                                {
                                  l: u.t(e.message),
                                  m:
                                    e.avatar ||
                                    "https://vseed-toystory.bj.bcebos.com/2025/07/25/20c07b76-f3b0-4669-bdca-19bf6bb6da61.png",
                                }
                              )
                            : {},
                          { n: 2 == e.senderType },
                          2 == e.senderType
                            ? u.e(
                                {
                                  o:
                                    e.avatar ||
                                    "https://vseed-toystory.bj.bcebos.com/2025/07/25/20c07b76-f3b0-4669-bdca-19bf6bb6da61.png",
                                  p:
                                    (null == (l = e.messageAudioList)
                                      ? void 0
                                      : l.length) > 0,
                                },
                                (null == (o = e.messageAudioList)
                                  ? void 0
                                  : o.length) > 0
                                  ? u.e(
                                      { q: u.unref(x).msgId != e.messageId },
                                      u.unref(x).msgId != e.messageId
                                        ? { r: n._imports_1$2 }
                                        : {},
                                      { s: u.unref(x).msgId == e.messageId },
                                      u.unref(x).msgId == e.messageId
                                        ? { t: n._imports_2$2 }
                                        : {},
                                      { v: e.message.length >= 18 },
                                      e.message.length >= 18
                                        ? { w: n._imports_3$1 }
                                        : {},
                                      { x: e.message.length < 18 },
                                      e.message.length < 18
                                        ? { y: n._imports_4$1 }
                                        : {},
                                      {
                                        z: u.o(function (a) {
                                          return $(e.messageId);
                                        }, e.messageId),
                                      }
                                    )
                                  : {},
                                { A: u.t(e.message) }
                              )
                            : {},
                          {
                            B: "msg-" + e.messageId,
                            C: e.messageId,
                            D: a === b.value.length - 1 ? "32rpx" : "16rpx",
                          }
                        );
                      }),
                      A: !j.value,
                      B: u.s(
                        j.value
                          ? {
                              height: "calc(100vh - 238rpx)",
                              overflow: "hidden",
                            }
                          : { height: "calc(100vh - 238rpx)" }
                      ),
                      C: S.value,
                      D: u.o(H),
                    }
                  : {}
              )
            : {},
          {
            E: "report" === v.value,
            F: u.p({
              activeTab: v.value,
              date: h.value,
              selectedSn: F.value,
              showChart: k.value,
            }),
            G: u.o(L),
            H: u.p({ insert: !0, lunar: !1, date: h.value, endDate: y.value }),
            I: u.sr(p, "530ef1ab-1", { k: "popup" }),
            J: u.o(M),
            K: u.o(M),
            L: u.p(
              e(
                e({ type: "top" }, "background-color", "#fff"),
                "border-radius",
                "20px 20px 20px 20px"
              )
            ),
            M: P.value,
          },
          P.value
            ? {
                N: u.f(N.value, function (e, a, t) {
                  return u.e(
                    {
                      a: u.t(e.productName),
                      b: u.t(e.sn),
                      c: e.sn === G.value,
                    },
                    e.sn === G.value ? { d: n._imports_7 } : {},
                    {
                      e: e.sn,
                      f: u.o(function (e) {
                        return (function (e) {
                          O.value = e;
                          var a = N.value[O.value];
                          console.log(a, "===================="),
                            (G.value = a.sn),
                            (E.value = a.productName);
                        })(a);
                      }, e.sn),
                    }
                  );
                }),
                O: u.o(K),
                P: I.value.navHeight + "px",
                Q: u.sr(R, "530ef1ab-3", { k: "snPopupRef" }),
                R: u.o(z),
                S: u.o(z),
                T: u.p(
                  e(
                    e({ type: "top" }, "background-color", "#fff"),
                    "border-radius",
                    "20px"
                  )
                ),
              }
            : {}
        );
      };
    },
  }),
  v = u._export_sfc(o, [["__scopeId", "data-v-530ef1ab"]]);
wx.createPage(v);
