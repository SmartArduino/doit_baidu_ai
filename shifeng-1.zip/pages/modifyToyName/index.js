var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/objectSpread2"),
  r = require("../../@babel/runtime/helpers/asyncToGenerator"),
  t = require("../../common/vendor.js"),
  a = require("../../common/assets.js"),
  i = require("../../api/index.js"),
  u = require("../../store/deviceStore.js"),
  o = t.defineComponent({
    __name: "index",
    setup: function (o) {
      var c = t.ref(""),
        s = function () {
          c.value = "";
        },
        l = function (e) {
          console.log(e);
          var n = e.detail.value;
          c.value = n;
        },
        v = t.ref("");
      t.onLoad(function (e) {
        (v.value = null == e ? void 0 : e.sn),
          (c.value = null == e ? void 0 : e.nickname);
      });
      var d = (function () {
        var a = r(
          e().mark(function r() {
            var a, o, s;
            return e().wrap(
              function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      if (
                        !(a = c.value || "") ||
                        !/[^\u4e00-\u9fa5a-zA-Z0-9]/g.test(a)
                      ) {
                        e.next = 4;
                        break;
                      }
                      return (
                        t.index.showToast({
                          title: "昵称只能包含数字、字母和中文",
                          icon: "none",
                        }),
                        e.abrupt("return")
                      );
                    case 4:
                      return (
                        (e.prev = 4),
                        (e.next = 7),
                        i.settingNickname({ nickname: c.value, sn: v.value })
                      );
                    case 7:
                      (o = e.sent),
                        "A00000" === o.data.resultCode &&
                          (t.index.showToast({
                            title: "保存成功",
                            icon: "none",
                          }),
                          (s = u.useDeviceStore()).deviceDetail &&
                            s.setDeviceDetail(
                              n(
                                n({}, s.deviceDetail),
                                {},
                                { nickname: c.value }
                              )
                            ),
                          setTimeout(function () {
                            t.index.navigateBack();
                          }, 1e3)),
                        (e.next = 15);
                      break;
                    case 12:
                      (e.prev = 12),
                        (e.t0 = e.catch(4)),
                        console.error("获取设备列表失败:", e.t0);
                    case 15:
                    case "end":
                      return e.stop();
                  }
              },
              r,
              null,
              [[4, 12]]
            );
          })
        );
        return function () {
          return a.apply(this, arguments);
        };
      })();
      return function (e, n) {
        return t.e(
          { a: c.value, b: t.o(l), c: c.value },
          c.value ? { d: a._imports_0$10, e: t.o(s) } : {},
          { f: t.o(d) }
        );
      };
    },
  }),
  c = t._export_sfc(o, [["__scopeId", "data-v-c0f1d647"]]);
wx.createPage(c);
