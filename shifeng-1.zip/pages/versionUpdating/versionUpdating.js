var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  r = require("../../common/vendor.js"),
  t = require("../../store/deviceStore.js"),
  a = require("../../api/index.js"),
  i = r.defineComponent({
    __name: "versionUpdating",
    setup: function (i) {
      var o = t.useDeviceStore(),
        s = r.ref([]),
        u = r.ref("");
      r.onLoad(function (e) {
        (u.value = (null == e ? void 0 : e.sn) || ""), c();
      });
      var c = (function () {
        var t = n(
          e().mark(function n() {
            var t, i, c, l;
            return e().wrap(
              function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (
                        (e.prev = 0),
                        (e.next = 3),
                        a.versionList({ sn: u.value })
                      );
                    case 3:
                      (c = e.sent),
                        "A00000" === (l = c.data).resultCode &&
                          (null == (i = null == (t = l.data) ? void 0 : t.list)
                            ? void 0
                            : i.length) &&
                          ((s.value = l.data.list), o.setVersions(l.data.list)),
                        (e.next = 12);
                      break;
                    case 8:
                      (e.prev = 8),
                        (e.t0 = e.catch(0)),
                        console.log(e.t0, "===================="),
                        r.index.showToast({
                          title: "获取版本列表失败",
                          icon: "none",
                        });
                    case 12:
                    case "end":
                      return e.stop();
                  }
              },
              n,
              null,
              [[0, 8]]
            );
          })
        );
        return function () {
          return t.apply(this, arguments);
        };
      })();
      return function (e, n) {
        return r.e(
          {
            a: r.f(s.value, function (e, n, t) {
              return r.e(
                { a: 0 !== n },
                {},
                { b: r.t(e.name), c: e.description },
                e.description ? { d: r.t(e.description) } : {},
                { e: e.id }
              );
            }),
            b: 0 === s.value.length,
          },
          (s.value.length, {})
        );
      };
    },
  }),
  o = r._export_sfc(i, [["__scopeId", "data-v-90439c1f"]]);
wx.createPage(o);
