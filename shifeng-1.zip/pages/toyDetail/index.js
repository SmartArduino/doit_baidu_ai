var e = require("../../@babel/runtime/helpers/defineProperty"),
  n = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  t = require("../../@babel/runtime/helpers/asyncToGenerator"),
  i = require("../../common/vendor.js"),
  r = require("../../common/assets.js"),
  o = require("../../store/deviceStore.js"),
  a = require("../../api/index.js");
Math || u();
var u = function () {
    return "../switchingToy/ToyStatus.js";
  },
  c = i.defineComponent({
    __name: "index",
    setup: function (u) {
      var c = o.useDeviceStore(),
        s = i.ref(!1),
        l = i.ref(!1);
      i.onMounted(function () {
        var e;
        c.deviceDetail ||
          (i.index.showToast({ title: "设备信息获取失败", icon: "none" }), v()),
          (null == (e = c.deviceDetail) ? void 0 : e.productName) &&
            i.index.setNavigationBarTitle({
              title: c.deviceDetail.productName,
            });
      });
      var v = function () {
          i.index.navigateBack();
        },
        d = function () {
          c.deviceDetail &&
            i.index.navigateTo({
              url: "/pages/device/device?sn=".concat(c.deviceDetail.sn),
            });
        },
        f = function () {
          var e;
          i.index.navigateTo({
            url: "/pages/versionUpdating/versionUpdating?sn=".concat(
              null == (e = c.deviceDetail) ? void 0 : e.sn
            ),
          });
        },
        p = function () {
          var e = c.devices,
            n = e.findIndex(function (e) {
              var n;
              return e.sn === (null == (n = c.deviceDetail) ? void 0 : n.sn);
            });
          console.log(n, "==========");
          var t = e.some(function (e) {
            return 1 === e.switchStatus;
          });
          console.log(t, "==========");
          var i = 1 === e[n].switchStatus;
          (i || (!t && 0 === n)) && c.setDevice(null),
            -1 !== n && (e.splice(n, 1), console.log(e), c.setDevices(e)),
            console.log(e),
            e.length > 0 && i && c.setDevice(e[0]),
            e.length > 0 && !t && c.setDevice(e[0]),
            c.setDeviceDetail({});
        },
        m = (function () {
          var e = t(
            n().mark(function e() {
              var t, r;
              return n().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          console.log("deviceStore", c),
                          (e.prev = 1),
                          (e.next = 4),
                          a.userDeviceUnbind({
                            sn:
                              (null == (t = c.deviceDetail) ? void 0 : t.sn) ||
                              "",
                          })
                        );
                      case 4:
                        (r = e.sent),
                          "A00000" === r.data.resultCode &&
                            (i.index.showToast({ title: "解绑成功" }),
                            p(),
                            v()),
                          (e.next = 11);
                        break;
                      case 9:
                        (e.prev = 9), (e.t0 = e.catch(1));
                      case 11:
                        return (e.prev = 11), (s.value = !1), e.finish(11);
                      case 14:
                      case "end":
                        return e.stop();
                    }
                },
                e,
                null,
                [[1, 9, 11, 14]]
              );
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })(),
        h = (function () {
          var e = t(
            n().mark(function e() {
              var t, r;
              return n().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.prev = 0),
                          (e.next = 3),
                          a.deviceReset({
                            sn:
                              (null == (t = c.deviceDetail) ? void 0 : t.sn) ||
                              "",
                          })
                        );
                      case 3:
                        (r = e.sent),
                          "A00000" === r.data.resultCode &&
                            (i.index.showToast({ title: "恢复成功" }),
                            p(),
                            v()),
                          (e.next = 11);
                        break;
                      case 8:
                        (e.prev = 8), (e.t0 = e.catch(0)), console.log(e.t0);
                      case 11:
                        return (e.prev = 11), (l.value = !1), e.finish(11);
                      case 14:
                      case "end":
                        return e.stop();
                    }
                },
                e,
                null,
                [[0, 8, 11, 14]]
              );
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })();
      return function (n, t) {
        var o, a, u, v, p, g, D, x, b, w;
        return i.e(
          {
            a:
              (null == (a = null == (o = i.unref(c)) ? void 0 : o.deviceDetail)
                ? void 0
                : a.thumbnailImg) ||
              "https://vseed-toystory.bj.bcebos.com/2025/05/22/0c52c11f-19c8-4e77-843c-fdad91c7314e.png",
            b: i.t(
              (null == (v = null == (u = i.unref(c)) ? void 0 : u.deviceDetail)
                ? void 0
                : v.nickname) ||
                (null ==
                (g = null == (p = i.unref(c)) ? void 0 : p.deviceDetail)
                  ? void 0
                  : g.productName)
            ),
            c: i.p(
              e(
                {},
                "network-status",
                null == (x = null == (D = i.unref(c)) ? void 0 : D.deviceDetail)
                  ? void 0
                  : x.networkStatus
              )
            ),
            d: i.t(
              null == (w = null == (b = i.unref(c)) ? void 0 : b.deviceDetail)
                ? void 0
                : w.sn
            ),
            e: i.o(d),
            f: r._imports_1,
            g: i.o(function (e) {
              return (s.value = !0);
            }),
            h: r._imports_1,
            i: i.o(function (e) {
              return (l.value = !0);
            }),
            j: r._imports_1,
            k: i.o(f),
            l: s.value,
          },
          s.value
            ? {
                m: i.o(function (e) {
                  return (s.value = !1);
                }),
                n: i.o(m),
              }
            : {},
          { o: l.value },
          l.value
            ? {
                p: i.o(function (e) {
                  return (l.value = !1);
                }),
                q: i.o(h),
              }
            : {}
        );
      };
    },
  }),
  s = i._export_sfc(c, [["__scopeId", "data-v-6c35c913"]]);
wx.createPage(s);
