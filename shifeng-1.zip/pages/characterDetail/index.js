var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  t = require("../../common/vendor.js"),
  r = require("../../api/index.js");
Math || o();
var o = function () {
    return "../../components/MyButton/MyButton.js";
  },
  a = t.defineComponent({
    __name: "index",
    setup: function (o) {
      var a,
        u =
          (null == (a = t.index.getSystemInfoSync().safeAreaInsets)
            ? void 0
            : a.bottom) || 0,
        c = t.ref(""),
        l = t.ref("");
      t.onLoad(function (e) {
        console.log("路由参数:", e), (c.value = e.sn), (l.value = e.code);
      });
      var i = t.ref({ code: "", introduce: "", name: "", thumbnailImg: "" }),
        s = (function () {
          var o = n(
            e().mark(function n() {
              var o, a, u, s;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.prev = 0),
                          (e.next = 3),
                          r.characterInfo({ code: l.value, sn: c.value })
                        );
                      case 3:
                        (u = e.sent),
                          (s = u.data),
                          console.log("getCharacterDetail", s),
                          (i.value = s.data),
                          (i.value.introduce =
                            null ==
                            (a = null == (o = s.data) ? void 0 : o.introduce)
                              ? void 0
                              : a.replaceAll("\\n", function () {
                                  return "\n";
                                })),
                          t.index.setNavigationBarTitle({ title: s.data.name }),
                          (e.next = 14);
                        break;
                      case 11:
                        (e.prev = 11),
                          (e.t0 = e.catch(0)),
                          console.error("getCharacterDetail error", e.t0);
                      case 14:
                      case "end":
                        return e.stop();
                    }
                },
                n,
                null,
                [[0, 11]]
              );
            })
          );
          return function () {
            return o.apply(this, arguments);
          };
        })(),
        d = (function () {
          var o = n(
            e().mark(function n() {
              var o, a;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          console.log("toggleRole"),
                          (e.prev = 1),
                          (e.next = 4),
                          r.characterBind({
                            sn: c.value,
                            characterCode: l.value,
                          })
                        );
                      case 4:
                        (o = e.sent),
                          (a = o.data),
                          console.log("toggleRole", a),
                          "A00000" === a.resultCode &&
                            (t.index.showToast({
                              title: "角色切换成功",
                              icon: "none",
                            }),
                            setTimeout(function () {
                              v();
                            }, 1e3)),
                          (e.next = 13);
                        break;
                      case 10:
                        (e.prev = 10),
                          (e.t0 = e.catch(1)),
                          console.error("toggleRole error", e.t0);
                      case 13:
                      case "end":
                        return e.stop();
                    }
                },
                n,
                null,
                [[1, 10]]
              );
            })
          );
          return function () {
            return o.apply(this, arguments);
          };
        })(),
        v = function () {
          t.index.navigateBack();
        };
      return (
        t.onMounted(function () {
          console.log("sn:", c), console.log("code:", l);
        }),
        t.onShow(function () {
          s();
        }),
        function (e, n) {
          var r, o, a;
          return {
            a: null == (r = i.value) ? void 0 : r.thumbnailImg,
            b: t.t(null == (o = i.value) ? void 0 : o.name),
            c: t.t(null == (a = i.value) ? void 0 : a.introduce),
            d: t.o(d),
            e: t.p({
              label: "切换角色",
              buttonWidth: 343,
              buttonHeight: 44,
              borderRadius: 10,
            }),
            f: t.unref(u) + "px",
          };
        }
      );
    },
  }),
  u = t._export_sfc(a, [["__scopeId", "data-v-0fcd5c8b"]]);
wx.createPage(u);
