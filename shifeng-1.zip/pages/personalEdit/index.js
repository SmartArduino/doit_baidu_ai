var e = require("../../@babel/runtime/helpers/createForOfIteratorHelper"),
  a = require("../../common/vendor.js"),
  t = require("../../store/profile.js"),
  n = require("../../api/modules/user.js"),
  r = require("../../api/index.js");
Array || a.resolveComponent("uni-popup")();
Math;
var u = a.defineComponent({
    __name: "index",
    setup: function (u) {
      var i = a.ref({ name: "", gender: 1, birthdate: "", avatar: "" }),
        l = a.computed(function () {
          return [
            {
              label: "男",
              value: n.Gender.Male,
              select:
                i.value.gender === n.Gender.Male
                  ? "/static/images/app/checked.png"
                  : "/static/images/app/unchecked.png",
              icon:
                i.value.gender === n.Gender.Male
                  ? "/static/images/app/male.png"
                  : "/static/images/app/male_unchecked.png",
            },
            {
              label: "女",
              value: n.Gender.Female,
              select:
                i.value.gender === n.Gender.Female
                  ? "/static/images/app/checked.png"
                  : "/static/images/app/unchecked.png",
              icon:
                i.value.gender === n.Gender.Female
                  ? "/static/images/app/female.png"
                  : "/static/images/app/female_unchecked.png",
            },
          ];
        }),
        o = a.ref(a.dayjs().format("YYYY-MM-DD")),
        c = function (e) {
          console.log("picker发送选择改变,携带值为", e.target.value),
            (i.value.birthdate = e.detail.value);
        },
        v = {
          name: { rules: [{ required: !0, errorMessage: "请输入姓名" }] },
          birthdate: { rules: [{ required: !0, errorMessage: "请选择生日" }] },
          gender: { rules: [{ required: !0, errorMessage: "请选择性别" }] },
        },
        d = a.ref(),
        s = t.useProfileStore(),
        g = function () {
          r.wechatUserInfo()
            .then(function (e) {
              if (200 == e.statusCode) {
                var a = e.data;
                s.changeChild({
                  nickname: a.data.nickname,
                  gender: a.data.gender,
                  birthdate: a.data.birthdate,
                  avatar: a.data.avatar,
                }),
                  (i.value.name = a.data.nickname || ""),
                  (i.value.gender = a.data.gender),
                  (i.value.birthdate = a.data.birthdate || ""),
                  (i.value.avatar = a.data.avatar || ""),
                  s.changeLang(a.data.language),
                  k();
              }
            })
            .catch(function (e) {
              console.log(e);
            });
        },
        f = a.ref(!1);
      a.onLoad(function () {
        g();
      });
      function h(e, t) {
        e && a.index.showToast({ icon: "none", title: e, duration: 2e3 });
      }
      function p() {
        if (
          (function () {
            var a;
            for (a in v) {
              var t = v[a];
              console.log(a, t);
              var n,
                r = e(t.rules);
              try {
                for (r.s(); !(n = r.n()).done; ) {
                  var u = n.value;
                  if ((console.log(u), u.required)) {
                    if (!i.value[a] || !String(i.value[a]).trim())
                      return h(u.errorMessage), !1;
                  } else if (u.minLength || u.maxLength) {
                    if (
                      i.value[a].trim().length < u.minLength ||
                      i.value[a].trim().length > u.maxLength
                    )
                      return (
                        h(
                          u.errorMessage
                            .replace("{minLength}", u.minLength)
                            .replace("{maxLength}", u.maxLength)
                        ),
                        !1
                      );
                  }
                }
              } catch (e) {
                r.e(e);
              } finally {
                r.f();
              }
            }
            return !0;
          })()
        ) {
          var t = i.value,
            n = {
              nickname: t.name,
              gender: t.gender,
              birthdate: t.birthdate,
              avatar: i.value.avatar,
            };
          s.changeChild(n),
            (function (e) {
              (f.value = !0),
                r
                  .wechatUserInfoUpdate(e)
                  .then(function (e) {
                    200 == e.statusCode
                      ? "A00000" == e.data.resultCode
                        ? (h("更新成功"),
                          g(),
                          (f.value = !0),
                          setTimeout(function () {
                            a.index.navigateBack();
                          }, 1500))
                        : (f.value = !1)
                      : (f.value = !1);
                  })
                  .catch(function (e) {
                    f.value = !1;
                  });
            })(n);
        }
      }
      var m = a.ref({ navHeight: "", statusBarHeight: 0, buttonMargin: 0 });
      a.onLoad(function () {
        var e = a.index.getMenuButtonBoundingClientRect(),
          t = e.top,
          n = e.height;
        a.index.getSystemInfo({
          success: function (e) {
            var a = e.statusBarHeight,
              r = t - a;
            (m.value.navHeight = n + a + 2 * r),
              (m.value.statusBarHeight = a),
              (m.value.buttonMargin = r);
          },
        });
      });
      var b = function (e) {
          console.log("当前模式：" + e.type + ",状态：" + e.show);
        },
        k = function () {
          r.wechatConfigBasic()
            .then(function (e) {
              if (200 == e.statusCode) {
                var a = e.data;
                if ("A00000" == a.resultCode) {
                  M.value = a.data.headPortraitList;
                  var t = M.value.indexOf(i.value.avatar);
                  (C.value = t),
                    M.value.length > 0 &&
                      (i.value.avatar =
                        -1 == t
                          ? "https://vseed-toystory.bj.bcebos.com/2025/07/25/20c07b76-f3b0-4669-bdca-19bf6bb6da61.png"
                          : M.value[C.value]);
                }
              }
            })
            .catch(function (e) {
              console.log(e);
            });
        },
        M = a.ref([]),
        x = function () {
          d.value.open();
        },
        L = function () {
          -1 != C.value &&
            ((i.value.avatar = M.value[C.value]), d.value.close());
        },
        C = a.ref(0);
      return function (e, t) {
        return a.e(
          { a: a.unref(s).child },
          a.unref(s).child
            ? a.e(
                { b: i.value.avatar },
                i.value.avatar ? { c: a.o(x), d: i.value.avatar } : {},
                {
                  e: i.value.name,
                  f: a.o(function (e) {
                    return (i.value.name = e.detail.value);
                  }),
                  g: i.value.birthdate,
                  h: a.o(function (e) {
                    return (i.value.birthdate = e.detail.value);
                  }),
                  i: i.value.birthdate,
                  j: "",
                  k: o.value,
                  l: a.o(c),
                  m: a.f(l.value, function (e, t, n) {
                    return {
                      a: e.select,
                      b: a.t(e.label),
                      c: a.n(i.value.gender === e.value && "active"),
                      d: e.icon,
                      e: e.value,
                      f: a.o(function (a) {
                        return (i.value.gender = e.value);
                      }, e.value),
                    };
                  }),
                }
              )
            : {},
          { n: !f.value },
          f.value ? {} : { o: a.o(p) },
          {
            p: a.f(M.value, function (e, t, n) {
              return {
                a: e,
                b: a.n(C.value === t ? "avatar-active" : ""),
                c: a.o(function (e) {
                  return (function (e) {
                    C.value = e;
                  })(t);
                }, t),
                d: t,
              };
            }),
            q: -1 !== C.value,
          },
          -1 !== C.value ? { r: a.o(L) } : { s: a.o(L) },
          {
            t: a.sr(d, "42e4a62f-0", { k: "popup" }),
            v: a.o(b),
            w: a.p({ type: "top" }),
          }
        );
      };
    },
  }),
  i = a._export_sfc(u, [["__scopeId", "data-v-42e4a62f"]]);
wx.createPage(i);
