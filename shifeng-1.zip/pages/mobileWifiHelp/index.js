var e = require("../../common/assets.js"),
  r = {};
var s = require("../../common/vendor.js")._export_sfc(r, [
  [
    "render",
    function (r, s) {
      return { a: e._imports_0$6, b: e._imports_0$6, c: e._imports_0$6 };
    },
  ],
  ["__scopeId", "data-v-cbee7b29"],
]);
wx.createPage(s);
