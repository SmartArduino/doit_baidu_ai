var e = require("../../@babel/runtime/helpers/defineProperty"),
  n = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  r = require("../../@babel/runtime/helpers/asyncToGenerator"),
  t = require("../../common/vendor.js"),
  o = require("../../api/index.js");
Math || a();
var a = function () {
    return "../../components/MyButton/MyButton.js";
  },
  u = t.defineComponent({
    __name: "index",
    setup: function (a) {
      var u = (function () {
          var e = r(
            n().mark(function e() {
              var r, a;
              return n().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.prev = 0),
                          (e.next = 3),
                          o.familyUserUseShareCode({
                            shareCode: i.value.shareCode,
                          })
                        );
                      case 3:
                        (r = e.sent),
                          "A00000" === (a = r.data).resultCode &&
                            (t.index.showToast({
                              title: "加入成功",
                              icon: "success",
                              duration: 2e3,
                            }),
                            setTimeout(function () {
                              t.index.switchTab({ url: "/pages/index/index" });
                            }, 1e3)),
                          console.log(a),
                          (e.next = 11);
                        break;
                      case 9:
                        (e.prev = 9), (e.t0 = e.catch(0));
                      case 11:
                      case "end":
                        return e.stop();
                    }
                },
                e,
                null,
                [[0, 9]]
              );
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })(),
        i = t.ref({ shareCode: "", phoneNumber: "" });
      return (
        t.onLoad(function (e) {
          console.log(e),
            (i.value = {
              shareCode: null == e ? void 0 : e.shareCode,
              phoneNumber: null == e ? void 0 : e.phoneNumber,
            });
          var n = t.index.getAccountInfoSync(),
            r = t.ref(n.miniProgram.envVersion);
          t.index.getStorageSync(r.value + "token") ||
            setTimeout(function () {
              t.index.navigateTo({
                url:
                  "/pages/login/index?shareCode=" +
                  i.value.shareCode +
                  "&phoneNumber=" +
                  i.value.phoneNumber,
              });
            }, 500);
        }),
        function (n, r) {
          return {
            a: t.t(i.value.phoneNumber),
            b: t.o(u),
            c: t.p(
              e(
                e(
                  e({ label: "加入" }, "button-width", 191.5),
                  "button-height",
                  44
                ),
                "border-radius",
                10
              )
            ),
          };
        }
      );
    },
  }),
  i = t._export_sfc(u, [["__scopeId", "data-v-3bc22380"]]);
wx.createPage(i);
