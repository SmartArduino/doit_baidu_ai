var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  t = require("../../common/vendor.js"),
  r = require("../../store/deviceStore.js"),
  o = require("../../api/index.js");
Math || (a + u)();
var a = function () {
    return "../../components/Device/BoundPage.js";
  },
  u = function () {
    return "../../components/showLetterModal/index.js";
  },
  i = t.defineComponent({
    __name: "index",
    setup: function (a) {
      var u = r.useDeviceStore();
      t.onShareAppMessage(function () {
        return {};
      }),
        t.onShareTimeline(function () {
          return {};
        });
      var i = t.ref(!0);
      t.onShow(function () {
        t.index.getNetworkType({
          success: function (e) {
            "none" === e.networkType ? (i.value = !1) : (i.value = !0);
          },
          fail: function (e) {
            (i.value = !1), console.error("获取网络状态失败：", e);
          },
        }),
          t.index.onNetworkStatusChange(function (e) {
            e.isConnected
              ? ((i.value = !0),
                console.log("网络已恢复，类型：", e.networkType))
              : (console.log("网络已断开"), (i.value = !1));
          });
        try {
          t.index.setPageOrientation &&
            t.index.setPageOrientation({ orientation: "portrait" });
        } catch (e) {
          console.log("恢复竖屏失败", e);
        }
      });
      var c = t.ref(),
        s = t.ref(""),
        l = t.ref(""),
        v = (function () {
          var r = n(
            e().mark(function n() {
              var r, o;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.prev = 0),
                          (e.next = 3),
                          null == (r = c.value) ? void 0 : r.open()
                        );
                      case 3:
                        (null == (o = e.sent) ? void 0 : o.confirm) &&
                          (console.log("用户要查看信件"),
                          t.index.navigateTo({
                            url: "/pages/letterDetail/index?messageId=".concat(
                              l.value
                            ),
                          })),
                          (e.next = 11);
                        break;
                      case 7:
                        (e.prev = 7),
                          (e.t0 = e.catch(0)),
                          console.error("打开弹窗失败:", e.t0),
                          console.log("用户关闭了弹窗");
                      case 11:
                      case "end":
                        return e.stop();
                    }
                },
                n,
                null,
                [[0, 7]]
              );
            })
          );
          return function () {
            return r.apply(this, arguments);
          };
        })(),
        f = t.ref(!1),
        d = (function () {
          var r = n(
            e().mark(function n(r) {
              var a, u;
              return e().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (e.next = 2), o.messagePopup({ sn: r });
                    case 2:
                      (a = e.sent),
                        "A00000" == (u = a.data).resultCode &&
                          (console.log("result", u.data),
                          null !== u.data &&
                            ((s.value = u.data.title),
                            (l.value = u.data.messageId),
                            (f.value = !0),
                            t.nextTick$1(function () {
                              setTimeout(function () {
                                v();
                              }, 200);
                            })));
                    case 5:
                    case "end":
                      return e.stop();
                  }
              }, n);
            })
          );
          return function (e) {
            return r.apply(this, arguments);
          };
        })(),
        p = t.ref(!1);
      return (
        t.watch(
          function () {
            var e;
            return null == (e = u.device) ? void 0 : e.sn;
          },
          function (e) {
            console.log(1111, e, !p.value),
              e && !p.value && (d(e), (p.value = !0));
          },
          { immediate: !0 }
        ),
        t.onLoad(function () {}),
        t.onMounted(
          n(
            e().mark(function n() {
              return e().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                    case "end":
                      return e.stop();
                  }
              }, n);
            })
          )
        ),
        function (e, n) {
          return t.e(
            { a: i.value, b: !i.value, c: f.value },
            f.value
              ? {
                  d: t.sr(c, "83a5a03c-1", { k: "letterModalRef" }),
                  e: t.p({ title: s.value, messageId: l.value }),
                }
              : {}
          );
        }
      );
    },
  });
i.__runtimeHooks = 6;
var c = t._export_sfc(i, [["__scopeId", "data-v-83a5a03c"]]);
wx.createPage(c);
