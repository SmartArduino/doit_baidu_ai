var e = require("../../common/vendor.js"),
  a = require("../../common/assets.js"),
  t = require("../../api/index.js"),
  o = require("../../store/home.js"),
  n = require("../../store/deviceStore.js");
Array || e.resolveComponent("report")();
Math ||
  (
    r +
    function () {
      return "../../components/report/report.js";
    }
  )();
var r = function () {
    return "../../uni_modules/qiun-data-charts/components/qiun-data-charts/qiun-data-charts.js";
  },
  i = e.defineComponent({
    __name: "index",
    props: {
      activeTab: { type: String, default: "" },
      showChart: { type: Boolean, default: !0 },
      selectedSn: { type: String, default: "" },
      date: { type: String, default: "" },
    },
    setup: function (r) {
      var i = n.useDeviceStore(),
        s = r,
        c = e.ref(!0);
      e.watch(
        function () {
          return [s.activeTab, s.date, s.selectedSn];
        },
        function (a, o) {
          console.log(a[0]),
            "report" === a[0] && a[2]
              ? ((c.value = !0),
                e.nextTick$1(function () {
                  var a;
                  p(),
                    (g.value = !0),
                    t
                      .reportWeekly({
                        sn:
                          s.selectedSn ||
                          (null == (a = null == i ? void 0 : i.device)
                            ? void 0
                            : a.sn) ||
                          "",
                      })
                      .then(function (a) {
                        c.value = !0;
                        for (
                          var t = a.data.data.dailyList, o = [], n = [], r = 0;
                          r < t.length;
                          r++
                        )
                          o.push(t[r].dayName), n.push(t[r].duration);
                        var i = n.map(function (e) {
                          return e >= 40
                            ? { value: 40, labelText: "".concat(e) }
                            : { value: e, labelText: "".concat(e) };
                        });
                        console.log(o),
                          (v.value = {
                            categories: o,
                            series: [
                              {
                                name: "",
                                linearColor: [
                                  [0, "#feea39"],
                                  [0.2, "#edeb42"],
                                  [0.4, "#c7ef5b"],
                                  [0.6, "#9cf377"],
                                  [0.8, "#71f791"],
                                  [1, "#37fdb6"],
                                ],
                                setShadow: [2, 4, 14, "rgba(253, 233, 56, 1)"],
                                data: i,
                              },
                            ],
                          }),
                          (g.value = !1),
                          u.value.fetchData(
                            s.date ||
                              e.dayjs().subtract(1, "day").format("YYYY-MM-DD"),
                            s.selectedSn
                          );
                      })
                      .catch(function (e) {
                        (c.value = !1),
                          console.log(e, "err===========================");
                      });
                }))
              : (c.value = !1);
        },
        { deep: !0, immediate: !0 }
      ),
        o.useHomeStore();
      var u = e.ref(),
        l = e.ref(!1),
        d = function (e) {
          l.value = e;
        },
        f = e.ref({
          color: [
            "#00D550",
            "#EE6666",
            "#73C0DE",
            "#3CA272",
            "#FC8452",
            "#9A60B4",
            "#ea7ccc",
          ],
          padding: [10, 30, 4, 0],
          dataLabel: !1,
          dataPointShape: !0,
          forceUseOldCanvas: !0,
          enableScroll: !1,
          legend: { show: !1 },
          xAxis: { disableGrid: !0 },
          yAxis: {
            gridType: "dash",
            dashLength: 2,
            splitNumber: 4,
            data: [
              {
                axisLineColor: "#ffffff",
                min: 0,
                max: 40,
                formatter: function (e, a, t) {
                  return e >= 40 ? "更多" : "".concat(e);
                },
              },
            ],
          },
          extra: {
            tooltip: {
              bgColor: "#00D550",
              borderRadius: 20,
              showArrow: !1,
              legendShow: !1,
            },
            area: {
              type: "curve",
              opacity: 0.6,
              addLine: !0,
              width: 3,
              gradient: !0,
              activeType: "hollow",
            },
          },
        }),
        v = e.ref({
          categories: ["", "", "", "", "", "", ""],
          series: [
            {
              name: "",
              linearColor: [
                [0, "#feea39"],
                [0.2, "#edeb42"],
                [0.4, "#c7ef5b"],
                [0.6, "#9cf377"],
                [0.8, "#71f791"],
                [1, "#37fdb6"],
              ],
              setShadow: [2, 4, 14, "rgba(253, 233, 56, 1)"],
              data: [0, 0, 0, 0, 0, 0, 0],
            },
          ],
        }),
        h = e.ref({ navHeight: "", statusBarHeight: 0, buttonMargin: 0 }),
        p = function () {
          console.log(0x2bbdfb99bd83a4);
          var a = e.index.getMenuButtonBoundingClientRect(),
            t = a.top,
            o = a.height;
          e.index.getSystemInfo({
            success: function (e) {
              var a = e.statusBarHeight,
                n = t - a;
              (h.value.navHeight = o + a + 2 * n),
                (h.value.statusBarHeight = a),
                (h.value.buttonMargin = n);
            },
          }),
            (v.value = {
              categories: ["", "", "", "", "", "", ""],
              series: [
                {
                  name: "",
                  linearColor: [
                    [0, "#feea39"],
                    [0.2, "#edeb42"],
                    [0.4, "#c7ef5b"],
                    [0.6, "#9cf377"],
                    [0.8, "#71f791"],
                    [1, "#37fdb6"],
                  ],
                  setShadow: [2, 4, 14, "rgba(253, 233, 56, 1)"],
                  data: [0, 0, 0, 0, 0, 0, 0],
                },
              ],
            });
        };
      e.onLoad(function () {}),
        e.onShow(function () {
          console.log("onShow");
        });
      var g = e.ref(!1);
      var b = function () {
        l.value = !1;
      };
      return (
        e.onShareAppMessage(function () {
          return {};
        }),
        e.onShareTimeline(function () {
          return {};
        }),
        function (t, o) {
          return {
            a: e.p({
              type: "area",
              reshow: r.showChart,
              reload: r.showChart,
              canvasId: "canvasLineA",
              canvas2d: !0,
              loadingType: 0,
              tooltipFormat: "tooltipLXC",
              opts: f.value,
              animation: !1,
              chartData: v.value,
            }),
            b: r.showChart && c.value,
            c: a._imports_2$1,
            d: !c.value,
            e: e.sr(u, "804f1809-1", { k: "reportRef" }),
            f: e.o(b),
            g: e.o(d),
            h: e.p({
              date: r.date,
              selectedSn: r.selectedSn,
              activeTab: r.activeTab,
            }),
            i: "overflow:" + (l.value ? "hidden" : "visible"),
          };
        }
      );
    },
  });
i.__runtimeHooks = 6;
var s = e._export_sfc(i, [["__scopeId", "data-v-804f1809"]]);
wx.createComponent(s);
