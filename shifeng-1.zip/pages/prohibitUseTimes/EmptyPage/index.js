var e = require("../../../common/vendor.js"),
  n = require("../../../common/assets.js"),
  o = e.defineComponent({
    __name: "index",
    setup: function (o) {
      var t = function () {
        e.index.removeStorageSync("prohibitUseRepeatSelected"),
          e.index.navigateTo({ url: "/pages/prohibitUseTimesAdd/index" });
      };
      return function (o, r) {
        return { a: n._imports_2$1, b: e.o(t) };
      };
    },
  }),
  t = e._export_sfc(o, [["__scopeId", "data-v-d42575be"]]);
wx.createComponent(t);
