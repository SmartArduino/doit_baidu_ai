var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/asyncToGenerator"),
  t = require("../../common/vendor.js"),
  r = require("../../common/assets.js"),
  o = require("../../api/index.js"),
  a = require("../../store/deviceStore.js");
Math || i();
var i = function () {
    return "./EmptyPage/index.js";
  },
  u = t.defineComponent({
    __name: "index",
    setup: function (i) {
      var u = a.useDeviceStore(),
        s = t.ref([]),
        c = (function () {
          var t = n(
            e().mark(function n() {
              var t, r, a;
              return e().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          console.log("snValue", u),
                          (e.prev = 1),
                          (e.next = 4),
                          o.disableConfigList({
                            sn:
                              (null == (t = null == u ? void 0 : u.device)
                                ? void 0
                                : t.sn) || "",
                          })
                        );
                      case 4:
                        (r = e.sent),
                          "A00000" === (a = r.data).resultCode &&
                            (s.value = a.data.list),
                          (e.next = 12);
                        break;
                      case 9:
                        (e.prev = 9), (e.t0 = e.catch(1)), console.log(e.t0);
                      case 12:
                      case "end":
                        return e.stop();
                    }
                },
                n,
                null,
                [[1, 9]]
              );
            })
          );
          return function () {
            return t.apply(this, arguments);
          };
        })(),
        l = t.ref("");
      t.onLoad(function (e) {
        l.value = null == e ? void 0 : e.sn;
      }),
        t.onShow(function () {
          c();
        });
      var d = function () {
          console.log("添加按钮被点击"),
            t.index.removeStorageSync("prohibitUseRepeatSelected"),
            t.index.navigateTo({ url: "/pages/prohibitUseTimesAdd/index" });
        },
        p = {
          1: "周一",
          2: "周二",
          3: "周三",
          4: "周四",
          5: "周五",
          6: "周六",
          0: "周日",
        },
        f = (function () {
          var r = n(
            e().mark(function r(a) {
              return e().wrap(function (r) {
                for (;;)
                  switch ((r.prev = r.next)) {
                    case 0:
                      t.index.showModal({
                        title: "提示",
                        content: "确定要删除该时段吗？",
                        success: (function () {
                          var r = n(
                            e().mark(function n(r) {
                              var i, s, l;
                              return e().wrap(
                                function (e) {
                                  for (;;)
                                    switch ((e.prev = e.next)) {
                                      case 0:
                                        if (!r.confirm) {
                                          e.next = 12;
                                          break;
                                        }
                                        return (
                                          (e.prev = 1),
                                          (e.next = 4),
                                          o.disableConfigDelete({
                                            sn:
                                              (null ==
                                              (i =
                                                null == u ? void 0 : u.device)
                                                ? void 0
                                                : i.sn) || "",
                                            configId: a.id,
                                          })
                                        );
                                      case 4:
                                        (s = e.sent),
                                          "A00000" === (l = s.data).resultCode
                                            ? (t.index.showToast({
                                                title: "删除成功",
                                                icon: "none",
                                              }),
                                              c())
                                            : t.index.showToast({
                                                title:
                                                  l.resultMsg || "删除失败",
                                                icon: "none",
                                              }),
                                          (e.next = 12);
                                        break;
                                      case 9:
                                        (e.prev = 9),
                                          (e.t0 = e.catch(1)),
                                          t.index.showToast({
                                            title: "网络异常",
                                            icon: "none",
                                          });
                                      case 12:
                                      case "end":
                                        return e.stop();
                                    }
                                },
                                n,
                                null,
                                [[1, 9]]
                              );
                            })
                          );
                          return function (e) {
                            return r.apply(this, arguments);
                          };
                        })(),
                      });
                    case 1:
                    case "end":
                      return r.stop();
                  }
              }, r);
            })
          );
          return function (e) {
            return r.apply(this, arguments);
          };
        })();
      return function (e, n) {
        return t.e(
          { a: s.value.length > 0 },
          s.value.length > 0
            ? {
                b: t.f(s.value, function (e, n, r) {
                  return {
                    a: t.t(
                      String(e.startHour).padStart(2, "0") +
                        ":" +
                        String(e.startMinute).padStart(2, "0")
                    ),
                    b: t.t(
                      String(e.endHour).padStart(2, "0") +
                        ":" +
                        String(e.endMinute).padStart(2, "0")
                    ),
                    c: t.o(function (n) {
                      return f(e);
                    }, n),
                    d: t.t(
                      ((o = e.days),
                      o && 0 !== o.length
                        ? o
                            .filter(function (e) {
                              return "number" == typeof e && p[e];
                            })
                            .map(function (e) {
                              return p[e];
                            })
                            .join("、")
                        : "每天")
                    ),
                    e: n,
                  };
                  var o;
                }),
                c: r._imports_0$7,
                d: t.o(d),
              }
            : {},
          { e: 0 === s.value.length },
          (s.value.length, {})
        );
      };
    },
  }),
  s = t._export_sfc(u, [["__scopeId", "data-v-a8de187d"]]);
wx.createPage(s);
