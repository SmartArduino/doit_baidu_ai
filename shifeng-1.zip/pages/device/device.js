var e = require("../../@babel/runtime/helpers/objectSpread2"),
  n = require("../../@babel/runtime/helpers/defineProperty");
require("../../@babel/runtime/helpers/Arrayincludes");
var t = require("../../@babel/runtime/helpers/toConsumableArray"),
  o = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  a = require("../../@babel/runtime/helpers/asyncToGenerator"),
  r = require("../../common/vendor.js"),
  c = require("../../common/assets.js"),
  i = require("../../tools/authorizeBle.js"),
  u = require("../../tools/authorizeLocation.js"),
  l = require("../../api/index.js"),
  s = require("../../tools/base64.js"),
  v = require("../../tools/tools.js");
Math || (x + d + f + g + p + h + I)();
var d = function () {
    return "../../components/Connect/NofoundPage.js";
  },
  f = function () {
    return "../../components/Connect/BlueToothConnected.js";
  },
  g = function () {
    return "../../components/Connect/InputNetwork.js";
  },
  p = function () {
    return "../../components/Connect/ConnectSuccess.js";
  },
  h = function () {
    return "../../components/Connect/Failure.js";
  },
  x = function () {
    return "../../components/Connect/LoadingSearch.js";
  },
  I = function () {
    return "../../components/Connect/StartConnect.js";
  },
  m = r.defineComponent({
    __name: "device",
    setup: function (d) {
      var f = r.ref({ navHeight: 0, statusBarHeight: 0, buttonMargin: 0 }),
        g = r.ref(""),
        p = r.ref("");
      r.onLoad(function (e) {
        var n = r.index.getMenuButtonBoundingClientRect(),
          t = n.top,
          o = n.height;
        (g.value = null == e ? void 0 : e.pageSource),
          (p.value = (null == e ? void 0 : e.sn) || ""),
          console.log("option", e),
          r.index.getSystemInfo({
            success: function (e) {
              var n = e.statusBarHeight,
                a = t - n;
              (f.value.navHeight = o + 2 * a),
                (f.value.statusBarHeight = n),
                (f.value.buttonMargin = a);
            },
          });
      });
      var h = r.ref(0),
        x = r.ref(0),
        I = r.ref({
          deviceId: "",
          deviceName: "guoguoble",
          serviceId: "24c2eee8-61d6-4639-929d-79ee9ced8193",
          characteristicId: "e283f597-9286-402d-9339-2f27fb290445",
          ssid: "",
          password: "",
        }),
        m = r.index.getDeviceInfo().platform,
        w = r.ref(102),
        b = r.ref(!1);
      console.log("platform", m);
      var y = function (e) {
          console.log("setStepFn", e), (h.value = e), 9 === e && M();
        },
        C = r.ref(""),
        B = function (e) {
          console.log("bindTraceIdHandler", e);
          var n = {
            eventType: e,
            traceId: "",
            sn: S.value || "",
            deviceVersion: _.value || "",
          };
          return l
            .bindTraceId(n)
            .then(function (e) {
              if ((console.log("bindTraceIdHandler", e), 200 == e.statusCode)) {
                var n = e.data;
                "A00000" == n.resultCode && (C.value = n.data.traceId);
              }
            })
            .catch(function (e) {
              console.log(e);
            });
        },
        L = (function () {
          var e = a(
            o().mark(function e(n, t) {
              var a;
              return o().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (
                        console.log(t, "埋点字符串"),
                        (a = {
                          eventType: n,
                          traceId: C.value || "",
                          sn: S.value || "",
                          deviceVersion: _.value || "",
                          customFields: t || "",
                        }),
                        e.abrupt(
                          "return",
                          l
                            .putDataTracking(a)
                            .then(function (e) {
                              if (
                                (console.log("bindTraceIdHandler", e),
                                200 == e.statusCode)
                              ) {
                                var n = e.data;
                                "A00000" == n.resultCode &&
                                  console.log("putDataTrackingFn", n);
                              }
                            })
                            .catch(function (e) {
                              console.log(e);
                            })
                        )
                      );
                    case 3:
                    case "end":
                      return e.stop();
                  }
              }, e);
            })
          );
          return function (n, t) {
            return e.apply(this, arguments);
          };
        })();
      function E() {
        return (E = a(
          o().mark(function e(n) {
            return o().wrap(function (e) {
              for (;;)
                switch ((e.prev = e.next)) {
                  case 0:
                    k(n);
                  case 1:
                  case "end":
                    return e.stop();
                }
            }, e);
          })
        )).apply(this, arguments);
      }
      function k(e) {
        return T.apply(this, arguments);
      }
      function T() {
        return (T = a(
          o().mark(function e(n) {
            var t, c, i, u, v;
            return o().wrap(
              function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (
                        console.log("wifiSendData", n),
                        (t = {
                          base64ssid: n.ssid,
                          pass: n.password,
                          submit: "Submie",
                          accessToken: n.accessToken,
                          traceId: C.value,
                          ssid: s.BASE64.decrypt(n.ssid),
                        }),
                        r.index.showLoading({ title: "发送中" }),
                        (e.prev = 3),
                        (e.next = 6),
                        l.deviceConnect(t)
                      );
                    case 6:
                      (c = e.sent),
                        console.log("res=========wifi", c),
                        (i = c.data),
                        (u = i.sn),
                        (v = i.version),
                        console.log(u),
                        (S.value = u),
                        (le.value.sn = u),
                        (le.value.version = v),
                        (e.next = 18);
                      break;
                    case 15:
                      (e.prev = 15),
                        (e.t0 = e.catch(3)),
                        console.log("deviceConnect error", e.t0);
                    case 18:
                      return (
                        (e.prev = 18),
                        (D.value = setInterval(
                          a(
                            o().mark(function e() {
                              return o().wrap(function (e) {
                                for (;;)
                                  switch ((e.prev = e.next)) {
                                    case 0:
                                      if ((A.value--, !(A.value <= 0))) {
                                        e.next = 7;
                                        break;
                                      }
                                      return (
                                        clearInterval(D.value),
                                        (h.value = 5),
                                        r.index.hideLoading(),
                                        (A.value = 40),
                                        e.abrupt("return")
                                      );
                                    case 7:
                                      console.log(
                                        A.value,
                                        "timerRequestIndex, 请求倒计时"
                                      ),
                                        oe();
                                    case 9:
                                    case "end":
                                      return e.stop();
                                  }
                              }, e);
                            })
                          ),
                          1e3
                        )),
                        e.finish(18)
                      );
                    case 21:
                    case "end":
                      return e.stop();
                  }
              },
              e,
              null,
              [[3, 15, 18, 21]]
            );
          })
        )).apply(this, arguments);
      }
      r.ref(0), r.ref(null);
      var S = r.ref(""),
        _ = r.ref(""),
        D = r.ref(null),
        A = r.ref(40),
        N = null,
        V = r.ref(0),
        j = r.ref(!1);
      function M() {
        (V.value = 0), q();
      }
      function q(e) {
        return O.apply(this, arguments);
      }
      function O() {
        return (O = a(
          o().mark(function e(n) {
            var t;
            return o().wrap(function (e) {
              for (;;)
                switch ((e.prev = e.next)) {
                  case 0:
                    return (e.next = 2), B("DEVICE_NETWORK_CONFIG_START");
                  case 2:
                    if (
                      ((t = r.index.getSystemSetting()),
                      (x.value = 0),
                      0 === V.value && ((h.value = 0), (b.value = !0)),
                      t.locationEnabled)
                    ) {
                      e.next = 11;
                      break;
                    }
                    return (
                      r.nextTick$1(function () {
                        r.index.showToast({
                          title: "请开启定位",
                          icon: "error",
                          duration: 2e3,
                        });
                      }),
                      (h.value = 2),
                      r.index.hideLoading(),
                      clearInterval(N),
                      e.abrupt("return")
                    );
                  case 11:
                    r.index.getLocation({
                      type: "gcj02",
                      success: function (e) {
                        return a(
                          o().mark(function e() {
                            return o().wrap(function (e) {
                              for (;;)
                                switch ((e.prev = e.next)) {
                                  case 0:
                                    if (t.bluetoothEnabled) {
                                      e.next = 6;
                                      break;
                                    }
                                    return (
                                      r.nextTick$1(function () {
                                        r.index.showModal({
                                          title: "注意",
                                          content:
                                            "请前往【手机设置—微信—打开蓝牙授权】，再开启手机蓝牙",
                                          icon: "none",
                                          showCancel: !1,
                                          success: function (e) {
                                            e.confirm &&
                                              console.log("用户点击确定");
                                          },
                                        });
                                      }),
                                      (h.value = 2),
                                      clearInterval(N),
                                      r.index.hideLoading(),
                                      e.abrupt("return")
                                    );
                                  case 6:
                                    console.log("蓝牙连接状态", X.value),
                                      X.value && Z(),
                                      r.index.openBluetoothAdapter({
                                        success: (function () {
                                          var e = a(
                                            o().mark(function e(n) {
                                              return o().wrap(function (e) {
                                                for (;;)
                                                  switch ((e.prev = e.next)) {
                                                    case 0:
                                                      console.log(
                                                        "Bluetooth adapter initialized:",
                                                        n
                                                      ),
                                                        H(),
                                                        P();
                                                    case 3:
                                                    case "end":
                                                      return e.stop();
                                                  }
                                              }, e);
                                            })
                                          );
                                          return function (n) {
                                            return e.apply(this, arguments);
                                          };
                                        })(),
                                        fail: function (e) {
                                          if (
                                            (console.log(
                                              "Bluetooth adapter initialization failed:",
                                              e
                                            ),
                                            r.index.hideLoading(),
                                            clearInterval(N),
                                            103 !== e.errno)
                                          ) {
                                            if (3 === e.errno) {
                                              var n =
                                                r.index.getAppAuthorizeSetting();
                                              if (
                                                (console.log(
                                                  "appAuthorizeSetting",
                                                  n
                                                ),
                                                "denied" ===
                                                  n.bluetoothAuthorized)
                                              ) {
                                                r.index.hideLoading(),
                                                  (h.value = 2);
                                                try {
                                                  var t =
                                                    r.index.getSystemInfoSync();
                                                  "android" === t.platform
                                                    ? (console.log(
                                                        "Android 版本:",
                                                        t.system
                                                      ),
                                                      r.nextTick$1(function () {
                                                        r.index.showModal({
                                                          title: "注意",
                                                          content:
                                                            "请到【手机设置—微信—其他权限-附近设备】开启权限",
                                                          icon: "none",
                                                          showCancel: !1,
                                                          success: function (
                                                            e
                                                          ) {
                                                            e.confirm &&
                                                              console.log(
                                                                "用户点击确定"
                                                              );
                                                          },
                                                        });
                                                      }),
                                                      clearInterval(N))
                                                    : console.log(
                                                        "当前设备不是 Android 设备"
                                                      );
                                                } catch (e) {
                                                  console.error(
                                                    "获取系统信息失败:",
                                                    e
                                                  );
                                                }
                                              }
                                            }
                                          } else
                                            i.impower()
                                              .then(function () {})
                                              .catch(function (e) {
                                                (h.value = 2),
                                                  console.log(
                                                    e,
                                                    "蓝牙授权失败========="
                                                  );
                                              });
                                        },
                                      });
                                  case 9:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                          })
                        )();
                      },
                      fail: function (e) {
                        if (
                          (clearInterval(N),
                          console.log(e, "d定位服务==============="),
                          e.errMsg.includes("getLocation:fail system"))
                        )
                          return (
                            r.nextTick$1(function () {
                              r.index.showToast({
                                title: "请开启微信定位授权",
                                icon: "error",
                                duration: 2e3,
                              });
                            }),
                            (h.value = 2),
                            void r.index.hideLoading()
                          );
                        103 !== e.errno ||
                          u
                            .impower()
                            .then(function () {})
                            .catch(function (e) {
                              r.index.hideLoading(),
                                (h.value = 2),
                                console.log(e, "=================");
                            });
                      },
                    });
                  case 12:
                  case "end":
                    return e.stop();
                }
            }, e);
          })
        )).apply(this, arguments);
      }
      M(),
        r.watch(
          function () {
            return h.value;
          },
          function (e, n) {
            0 !== e && (console.log("进行下一步了"), (b.value = !1));
          }
        );
      var F = r.ref(0);
      function H() {
        clearInterval(N),
          (N = setInterval(
            a(
              o().mark(function e() {
                return o().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        R.value--,
                          console.log("deviceConnectIndex:", R.value),
                          R.value <= 0 && (0 === h.value || 5 === h.value)
                            ? (clearInterval(N),
                              (R.value = 10),
                              F.value++,
                              F.value > 2
                                ? (Z(),
                                  r.index.hideLoading(),
                                  (h.value = 5),
                                  (j.value = !1))
                                : ((R.value = 5), q()))
                            : 0 !== h.value &&
                              5 !== h.value &&
                              ((R.value = 10),
                              clearInterval(N),
                              r.index.hideLoading());
                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            ),
            1e3
          ));
      }
      function P() {
        (j.value = !0),
          r.index.startBluetoothDevicesDiscovery({
            allowDuplicatesKey: !0,
            success: function (e) {
              console.log("Bluetooth devices discovery started:", e),
                r.index.onBluetoothDeviceFound(function (e) {
                  var n = e.devices[0];
                  n.name &&
                    console.log(
                      "Found device:",
                      n.deviceId,
                      n.name,
                      n.localName
                    ),
                    n &&
                      n.name === I.value.deviceName &&
                      ((I.value.deviceId = n.deviceId),
                      r.index.stopBluetoothDevicesDiscovery({
                        success: function (e) {
                          console.log(
                            "Bluetooth devices discovery stopped==============:",
                            e
                          ),
                            console.log("deviceId:", I.value.deviceId),
                            r.index.createBLEConnection({
                              deviceId: I.value.deviceId,
                              success: function (e) {
                                console.log(
                                  "蓝牙连接成功了:",
                                  e,
                                  new Date().getTime()
                                ),
                                  (h.value = 1),
                                  r.index.setBLEMTU({
                                    deviceId: I.value.deviceId,
                                    mtu: 500,
                                    success: function (e) {
                                      console.log("setBLEMTU成功:", e),
                                        (K.value = 1);
                                    },
                                    fail: function (e) {
                                      console.log("setBLEMTU失败:", e),
                                        (K.value = 0);
                                    },
                                    complete: function (e) {
                                      console.log("setBLEMTU完成:", e),
                                        r.index.getBLEDeviceServices({
                                          deviceId: I.value.deviceId,
                                          success: function (e) {
                                            console.log(
                                              "Bluetooth get serviceId:------",
                                              e
                                            ),
                                              (I.value.serviceId =
                                                e.services.find(function (e) {
                                                  return e.uuid.includes(
                                                    "8193"
                                                  );
                                                }).uuid),
                                              console.log(
                                                "=================================",
                                                e.deviceId
                                              ),
                                              r.index.getBLEDeviceCharacteristics(
                                                {
                                                  deviceId: I.value.deviceId,
                                                  serviceId: I.value.serviceId,
                                                  success: function (e) {
                                                    var n, c, i;
                                                    console.log(
                                                      "Bluetooth get getBLEDeviceCharacteristics:",
                                                      e
                                                    ),
                                                      console.log(
                                                        "Bluetooth get getBLEDeviceCharacteristics: uuid",
                                                        e.characteristics[0]
                                                          .uuid
                                                      ),
                                                      (I.value.characteristicId =
                                                        e.characteristics[0].uuid),
                                                      (j.value = !1),
                                                      r.index.onBLECharacteristicValueChange(
                                                        (function () {
                                                          var e = a(
                                                            o().mark(function e(
                                                              n
                                                            ) {
                                                              var a, r;
                                                              return o().wrap(
                                                                function (e) {
                                                                  for (;;)
                                                                    switch (
                                                                      (e.prev =
                                                                        e.next)
                                                                    ) {
                                                                      case 0:
                                                                        if (
                                                                          ((a =
                                                                            v.arrayBufferToString(
                                                                              n.value
                                                                            )),
                                                                          console.log(
                                                                            "onBLECharacteristicValueChange arrayBufferToString",
                                                                            a
                                                                          ),
                                                                          !(
                                                                            a &&
                                                                            a.length >
                                                                              0
                                                                          ))
                                                                        ) {
                                                                          e.next = 39;
                                                                          break;
                                                                        }
                                                                        z.value ||
                                                                          ((z.value =
                                                                            a.includes(
                                                                              "ping"
                                                                            )
                                                                              ? "old"
                                                                              : "new"),
                                                                          console.log(
                                                                            "old" ===
                                                                              z.value
                                                                              ? "老设备"
                                                                              : "新设备"
                                                                          ),
                                                                          "new" ===
                                                                            z.value &&
                                                                            0 ===
                                                                              x.value &&
                                                                            ("ohos" !==
                                                                            m
                                                                              ? re()
                                                                              : setTimeout(
                                                                                  function () {
                                                                                    re();
                                                                                  },
                                                                                  1e3
                                                                                )));
                                                                        try {
                                                                          r =
                                                                            JSON.parse(
                                                                              a
                                                                            );
                                                                        } catch (e) {
                                                                          console.log(
                                                                            e
                                                                          );
                                                                        }
                                                                        if (
                                                                          void 0 !==
                                                                          r
                                                                        ) {
                                                                          e.next = 7;
                                                                          break;
                                                                        }
                                                                        return e.abrupt(
                                                                          "return"
                                                                        );
                                                                      case 7:
                                                                        if (
                                                                          1 !==
                                                                          r.type
                                                                        ) {
                                                                          e.next = 29;
                                                                          break;
                                                                        }
                                                                        if (
                                                                          (100 ===
                                                                            r.code &&
                                                                            (console.log(
                                                                              "获取wifi，开始扫描",
                                                                              r
                                                                            ),
                                                                            (w.value = 100),
                                                                            (Q.value =
                                                                              [])),
                                                                          101 ===
                                                                            r.code &&
                                                                            ((w.value = 101),
                                                                            console.log(
                                                                              "获取wifi，扫描中",
                                                                              r
                                                                            )),
                                                                          102 !==
                                                                            r.code)
                                                                        ) {
                                                                          e.next = 24;
                                                                          break;
                                                                        }
                                                                        if (
                                                                          (console.log(
                                                                            "获取wifi，扫描完成",
                                                                            r
                                                                          ),
                                                                          (w.value = 102),
                                                                          r.sn &&
                                                                            !S.value &&
                                                                            ((_.value =
                                                                              r.version),
                                                                            (S.value =
                                                                              r.sn),
                                                                            se()),
                                                                          "ohos" !==
                                                                            m ||
                                                                            0 !==
                                                                              K.value)
                                                                        ) {
                                                                          e.next = 21;
                                                                          break;
                                                                        }
                                                                        if (
                                                                          0 !==
                                                                          r.nextIndex
                                                                        ) {
                                                                          e.next = 19;
                                                                          break;
                                                                        }
                                                                        return (
                                                                          (ae.value =
                                                                            !1),
                                                                          (e.next = 19),
                                                                          L(
                                                                            "DEVICE_NETWORK_SCAN_COMPLETE"
                                                                          )
                                                                        );
                                                                      case 19:
                                                                        e.next = 24;
                                                                        break;
                                                                      case 21:
                                                                        return (
                                                                          (ae.value =
                                                                            !1),
                                                                          (e.next = 24),
                                                                          L(
                                                                            "DEVICE_NETWORK_SCAN_COMPLETE"
                                                                          )
                                                                        );
                                                                      case 24:
                                                                        r.data &&
                                                                          (r.data.forEach(
                                                                            function (
                                                                              e
                                                                            ) {
                                                                              e.name =
                                                                                s.BASE64.decrypt(
                                                                                  e.ssid
                                                                                );
                                                                            }
                                                                          ),
                                                                          -1 ===
                                                                            JSON.stringify(
                                                                              Q.value
                                                                            ).indexOf(
                                                                              JSON.stringify(
                                                                                r.data
                                                                              )
                                                                            ) &&
                                                                            (Q.value =
                                                                              [].concat(
                                                                                t(
                                                                                  Q.value
                                                                                ),
                                                                                t(
                                                                                  r.data
                                                                                )
                                                                              ))),
                                                                          console.log(
                                                                            "判断进入条件",
                                                                            " 是否有下一页：",
                                                                            0 !==
                                                                              r.nextIndex,
                                                                            " 是否是鸿蒙：",
                                                                            "ohos" ===
                                                                              m,
                                                                            " 鸿蒙是否可用setMtu：",
                                                                            K.value
                                                                          ),
                                                                          0 !==
                                                                            r.nextIndex &&
                                                                            "ohos" ===
                                                                              m &&
                                                                            0 ===
                                                                              K.value &&
                                                                            (console.log(
                                                                              "鸿蒙进入扫描",
                                                                              r
                                                                            ),
                                                                            100 ===
                                                                              r.code ||
                                                                            101 ===
                                                                              r.code
                                                                              ? (clearTimeout(
                                                                                  ce
                                                                                ),
                                                                                (ce =
                                                                                  setTimeout(
                                                                                    function () {
                                                                                      U(
                                                                                        r.nextIndex
                                                                                      );
                                                                                    },
                                                                                    1e3
                                                                                  )))
                                                                              : U(
                                                                                  r.nextIndex
                                                                                )),
                                                                          (e.next = 39);
                                                                        break;
                                                                      case 29:
                                                                        if (
                                                                          -1 !==
                                                                          r.code
                                                                        ) {
                                                                          e.next = 35;
                                                                          break;
                                                                        }
                                                                        return (
                                                                          (_.value =
                                                                            r.version),
                                                                          (S.value =
                                                                            r.sn),
                                                                          se(),
                                                                          clearInterval(
                                                                            null
                                                                          ),
                                                                          e.abrupt(
                                                                            "return"
                                                                          )
                                                                        );
                                                                      case 35:
                                                                        if (
                                                                          "new" !==
                                                                          z.value
                                                                        ) {
                                                                          e.next = 37;
                                                                          break;
                                                                        }
                                                                        return e.abrupt(
                                                                          "return"
                                                                        );
                                                                      case 37:
                                                                        (S.value =
                                                                          r.sn),
                                                                          ie();
                                                                      case 39:
                                                                      case "end":
                                                                        return e.stop();
                                                                    }
                                                                },
                                                                e
                                                              );
                                                            })
                                                          );
                                                          return function (n) {
                                                            return e.apply(
                                                              this,
                                                              arguments
                                                            );
                                                          };
                                                        })()
                                                      ),
                                                      (n = I.value.deviceId),
                                                      (c = I.value.serviceId),
                                                      (i =
                                                        I.value
                                                          .characteristicId),
                                                      console.log(
                                                        "notifyBLECharacteristicValueChange",
                                                        n,
                                                        c,
                                                        i
                                                      ),
                                                      r.index.notifyBLECharacteristicValueChange(
                                                        {
                                                          state: !0,
                                                          deviceId: n,
                                                          serviceId: c,
                                                          characteristicId: i,
                                                          success: function (
                                                            e
                                                          ) {
                                                            console.log(
                                                              "notifyBLECharacteristicValueChange success=============",
                                                              e
                                                            );
                                                          },
                                                          fail: function (e) {
                                                            console.log(
                                                              "notifyBLECharacteristicValueChange fail",
                                                              e.errMsg
                                                            );
                                                          },
                                                        }
                                                      ),
                                                      $("{ping:12}", "ping"),
                                                      1 === V.value &&
                                                        (j.value = !1);
                                                  },
                                                  fail: function (e) {
                                                    console.log(
                                                      "Bluetooth get getBLEDeviceCharacteristics failed:",
                                                      e
                                                    ),
                                                      (h.value = 2),
                                                      (j.value = !1),
                                                      r.index.hideLoading();
                                                  },
                                                }
                                              );
                                          },
                                        });
                                    },
                                  });
                              },
                              fail: function (e) {
                                console.log("Bluetooth get serviceId:", e),
                                  (j.value = !1),
                                  r.index.hideLoading();
                              },
                            });
                        },
                      }));
                });
            },
            fail: function (e) {
              console.log("Bluetooth devices discovery failed:", e),
                (h.value = 2),
                (j.value = !1),
                r.index.hideLoading();
            },
          });
      }
      var R = r.ref(10);
      var z = r.ref();
      function W() {
        return (W = a(
          o().mark(function n(t) {
            var a;
            return o().wrap(function (n) {
              for (;;)
                switch ((n.prev = n.next)) {
                  case 0:
                    return (
                      (h.value = 6),
                      (a = e(e({ type: 2 }, t), {}, { traceId: C.value })),
                      (n.next = 4),
                      L(
                        "DEVICE_NETWORK_CONFIG_ATTEMPT",
                        JSON.stringify({
                          channel: t.channel,
                          rssi: t.rssi,
                          auth: t.unSetPsd ? 0 : 1,
                          bssid: t.bssid,
                          wifiName: t.name,
                        })
                      )
                    );
                  case 4:
                    $(a);
                  case 5:
                  case "end":
                    return n.stop();
                }
            }, n);
          })
        )).apply(this, arguments);
      }
      var K = r.ref(0);
      function U() {
        var e =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        console.log(e, "调用Wi-Fi列表索引");
        var n = {
          type: 1,
          startIndex: e,
          platform: r.index.getDeviceInfo().platform,
          ohosEnable: K.value,
        };
        $(n);
      }
      function $(e, n) {
        var t = JSON.stringify(e);
        n && (t = "{" + n + ":1"), console.log(t);
        var o = new ArrayBuffer(t.length),
          a = new DataView(o);
        console.log("wifi value", o);
        for (var c = 0; c < t.length; c++) a.setUint8(c, t.charCodeAt(c));
        var i = I.value;
        r.index.writeBLECharacteristicValue({
          deviceId: i.deviceId,
          serviceId: i.serviceId,
          characteristicId: i.characteristicId,
          value: o,
          success: function (n) {
            var t, o, a;
            console.log("Wi-Fi credentials sent successfully:", n),
              (t = i.deviceId),
              (o = i.serviceId),
              (a = i.characteristicId),
              (function (e, n, t) {
                r.index.readBLECharacteristicValue({
                  deviceId: e,
                  serviceId: n,
                  characteristicId: t,
                  success: function (e) {
                    console.log("readBLECharacteristicValue:", e);
                  },
                  fail: function (e) {
                    console.log("readBLECharacteristicValue failed:", e);
                  },
                });
              })(t, o, a),
              2 === e.type && "new" === z.value && ie();
          },
          fail: function (n) {
            console.log("Failed to send writeBLECharacteristicValue:", n),
              2 === e.type &&
                1 !== V.value &&
                ((V.value = 1), q(), r.index.hideLoading());
          },
        });
      }
      var J = r.ref(""),
        G = function (e) {
          7 !== h.value &&
            (r.index.showLoading({ title: "联网中", mask: !0 }),
            0 === x.value
              ? (!(function (e) {
                  W.apply(this, arguments);
                })(e),
                console.log("obj", e, "ssid", e.ssid),
                (J.value = e.ssid))
              : (function (e) {
                  E.apply(this, arguments);
                })(e));
        },
        Q = r.ref([]);
      var X = r.ref(!1);
      var Y = function () {
        console.log("goBack"),
          clearInterval(N),
          r.index.closeBluetoothAdapter({
            success: function (e) {
              console.log(e, "蓝牙关闭"),
                console.log("pageSource.value", g.value),
                r.index.switchTab({ url: "/pages/index/index" });
            },
            fail: function (e) {
              console.log(e, "蓝牙关闭失败"),
                r.index.switchTab({ url: "/pages/index/index" });
            },
          });
      };
      function Z() {
        clearInterval(N),
          r.index.closeBLEConnection({
            deviceId: I.value.deviceId,
            success: function (e) {
              console.log("Bluetooth connection closed:", e), (X.value = !1);
            },
            fail: function (e) {
              console.log("Failed to close Bluetooth connection:", e);
            },
          }),
          r.index.closeBluetoothAdapter({
            success: function (e) {
              console.log(e, "蓝牙关闭");
            },
            fail: function (e) {
              console.log(e, "蓝牙关闭失败");
            },
          });
      }
      r.onUnload(function () {
        (h.value = 0), Z(), (R.value = 10), clearInterval(N);
      }),
        r.onHide(function () {});
      var ee = r.ref(!1),
        ne = r.ref([]),
        te = (function () {
          var e = a(
            o().mark(function e() {
              return o().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return e.abrupt(
                        "return",
                        l
                          .userDeviceList()
                          .then(function (e) {
                            return (ne.value = e.data.data.list), ne.value;
                          })
                          .catch(function (e) {
                            console.log(e);
                          })
                      );
                    case 1:
                    case "end":
                      return e.stop();
                  }
              }, e);
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })();
      te();
      var oe = (function () {
          var e = a(
            o().mark(function e() {
              var n;
              return o().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.prev = 0),
                          console.log(
                            "列表是否有当前绑定设备～～～～～～～～",
                            ee.value
                          ),
                          (e.next = 4),
                          te()
                        );
                      case 4:
                        if (((e.t0 = e.sent), e.t0)) {
                          e.next = 7;
                          break;
                        }
                        e.t0 = [];
                      case 7:
                        (n = e.t0),
                          console.log(n, "deviceList========="),
                          n.forEach(function (e) {
                            ee.value
                              ? (console.log("重新绑定==============="),
                                e.sn == S.value &&
                                  1 == e.networkStatus &&
                                  (console.log(
                                    "重新绑定成功啦啦啦啦啦啦啦啦啦啦"
                                  ),
                                  clearInterval(D.value),
                                  (h.value = 8),
                                  r.index.hideLoading(),
                                  se()))
                              : (console.log("添加设备==============="),
                                e.sn == S.value &&
                                  1 == e.networkStatus &&
                                  (console.log("绑定成功啦啦啦啦啦啦啦啦啦啦"),
                                  clearInterval(D.value),
                                  (h.value = 8),
                                  r.index.hideLoading(),
                                  se()));
                          }),
                          (e.next = 15);
                        break;
                      case 12:
                        (e.prev = 12), (e.t1 = e.catch(0)), console.log(e.t1);
                      case 15:
                      case "end":
                        return e.stop();
                    }
                },
                e,
                null,
                [[0, 12]]
              );
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })(),
        ae = r.ref(!1),
        re = (function () {
          var e = a(
            o().mark(function e() {
              return o().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (
                        (ae.value = !0),
                        (Q.value = []),
                        (e.next = 4),
                        L("DEVICE_NETWORK_SCAN_START")
                      );
                    case 4:
                      U();
                    case 5:
                    case "end":
                      return e.stop();
                  }
              }, e);
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })();
      var ce = null;
      function ie() {
        return ue.apply(this, arguments);
      }
      function ue() {
        return (ue = a(
          o().mark(function e() {
            return o().wrap(function (e) {
              for (;;)
                switch ((e.prev = e.next)) {
                  case 0:
                    console.log(S.value, "snValue"),
                      console.log("开始获取绑定结果optionSn", p.value),
                      p.value,
                      (D.value = setInterval(function () {
                        if ((A.value--, A.value <= 0))
                          return (
                            clearInterval(D.value),
                            (h.value = 5),
                            r.index.hideLoading(),
                            void (A.value = 40)
                          );
                        oe();
                      }, 1e3));
                  case 4:
                  case "end":
                    return e.stop();
                }
            }, e);
          })
        )).apply(this, arguments);
      }
      var le = r.ref({}),
        se = (function () {
          var e = a(
            o().mark(function e() {
              return o().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return e.abrupt(
                        "return",
                        l
                          .deviceProduct({ sn: S.value })
                          .then(function (e) {
                            console.log("deviceProduct", e),
                              e.data.data &&
                                ((le.value = e.data.data),
                                console.log(
                                  le.value,
                                  "deviceProductInfo============="
                                ));
                          })
                          .catch(function (e) {
                            console.log(e);
                          })
                      );
                    case 1:
                    case "end":
                      return e.stop();
                  }
              }, e);
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })();
      return function (e, t) {
        var o, a;
        return r.e(
          { a: 8 === h.value },
          8 === h.value
            ? {
                b: c._imports_0$3,
                c: 2 * f.value.buttonMargin + "px",
                d: r.o(Y),
                e: f.value.navHeight + "px",
              }
            : { f: c._imports_0$4, g: f.value.navHeight + "px", h: r.o(Y) },
          { i: 0 === h.value },
          (h.value, {}),
          { j: 2 === h.value || 5 === h.value },
          2 === h.value || 5 === h.value
            ? {
                k: r.o(function (e) {
                  return M();
                }),
              }
            : {},
          { l: 1 === h.value },
          1 === h.value ? { m: r.o(y), n: r.p({ deviceInfo: le.value }) } : {},
          { o: 6 === h.value || 4 === h.value },
          6 === h.value || 4 === h.value
            ? {
                p: r.o(re),
                q: r.o(G),
                r: r.p({
                  wifiListState: w.value,
                  deviceInfo: le.value,
                  wifiList: Q.value,
                  connectFlag: x.value,
                }),
              }
            : {},
          { s: 8 === h.value },
          8 === h.value
            ? {
                t: r.o(Y),
                v: r.p(
                  n(
                    n({}, "wifi-name", J.value),
                    "success-text",
                    null == (a = null == (o = le.value) ? void 0 : o.ext)
                      ? void 0
                      : a.networkMsg
                  )
                ),
              }
            : {},
          { w: 5 === h.value },
          (h.value, {}),
          { x: 9 === h.value },
          9 === h.value ? { y: r.o(y) } : {},
          { z: f.value.statusBarHeight + "px" }
        );
      };
    },
  }),
  w = r._export_sfc(m, [["__scopeId", "data-v-b48e51dc"]]);
wx.createPage(w);
