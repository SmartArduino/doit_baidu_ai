var e = require("../../@babel/runtime/helpers/objectSpread2"),
  n = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  t = require("../../@babel/runtime/helpers/asyncToGenerator"),
  a = require("../../common/vendor.js"),
  r = require("../../common/assets.js"),
  u = require("../../store/deviceStore.js"),
  o = require("../../api/index.js"),
  i = a.defineComponent({
    __name: "index",
    setup: function (i) {
      var l = u.useDeviceStore(),
        c = a.ref([]),
        v = a.ref(""),
        s = a.ref(""),
        f = (function () {
          var e = t(
            n().mark(function e() {
              var t, a, r, u;
              return n().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.prev = 0),
                          (e.next = 3),
                          o.actionList({ sn: s.value })
                        );
                      case 3:
                        (a = e.sent),
                          (r = a.data),
                          console.log(r),
                          "A00000" == r.resultCode &&
                            ((c.value =
                              (null == (t = r.data) ? void 0 : t.list) || []),
                            (u = c.value.map(function (e) {
                              return {
                                name: e.actionName,
                                command: e.code,
                                img: e.img,
                              };
                            })),
                            l.setCommandList(u)),
                          (e.next = 12);
                        break;
                      case 9:
                        (e.prev = 9), (e.t0 = e.catch(0)), console.log(e.t0);
                      case 12:
                      case "end":
                        return e.stop();
                    }
                },
                e,
                null,
                [[0, 9]]
              );
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })(),
        d = a.ref([]),
        h = a.ref(!1),
        g = a.ref(null),
        p = a.ref({ x: 0, y: 0 }),
        x = a.ref(!1),
        m = a.ref(-1),
        b = null,
        y = { x: 0, y: 0 },
        w = a.ref(!1),
        S = a.ref(300),
        k = a.ref(300),
        T = a.ref(300),
        _ = a.ref(450),
        L = a.ref({}),
        B = a.ref(!1),
        I = a.ref(!1),
        W = a.ref([]),
        M = a.ref(0),
        X = (function () {
          var e = t(
            n().mark(function e() {
              var t, r, u, i;
              return n().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (e.next = 2), o.isBindDevice({ code: v.value });
                    case 2:
                      return (
                        (r = e.sent),
                        "A00000" == (u = r.data).resultCode &&
                          (console.log(u.data),
                          0 ===
                          (i =
                            (null == (t = u.data)
                              ? void 0
                              : t.deviceInfoList) || []).length
                            ? ((B.value = !0),
                              A(),
                              setTimeout(function () {
                                a.index.reLaunch({
                                  url: "/pages/device/device",
                                });
                              }, 200))
                            : i.length > 1
                            ? ((W.value = i), (M.value = 0), (I.value = !0))
                            : 1 === i.length && (s.value = i[0].sn)),
                        e.abrupt("return", u)
                      );
                    case 6:
                    case "end":
                      return e.stop();
                  }
              }, e);
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })(),
        q = (function () {
          var e = t(
            n().mark(function e() {
              var t, r;
              return n().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      if (
                        (console.log("checkTokenIsExpired"),
                        (t = a.index.getAccountInfoSync()),
                        (r = a.ref(t.miniProgram.envVersion)),
                        a.index.getStorageSync(r.value + "token"))
                      ) {
                        e.next = 7;
                        break;
                      }
                      return (
                        setTimeout(function () {
                          a.index.reLaunch({ url: "/pages/login/index" });
                        }, 400),
                        e.abrupt("return")
                      );
                    case 7:
                    case "end":
                      return e.stop();
                  }
              }, e);
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })();
      a.onLoad(
        (function () {
          var a = t(
            n().mark(function t(a) {
              var r;
              return n().wrap(function (n) {
                for (;;)
                  switch ((n.prev = n.next)) {
                    case 0:
                      console.log("页面加载参数：", a),
                        (L.value = e({}, a)),
                        a.source
                          ? a.code &&
                            (console.log("来源：", a.source),
                            (v.value = a.code))
                          : (s.value =
                              (null == (r = l.device) ? void 0 : r.sn) || ""),
                        q();
                    case 4:
                    case "end":
                      return n.stop();
                  }
              }, t);
            })
          );
          return function (e) {
            return a.apply(this, arguments);
          };
        })()
      ),
        a.onShow(
          t(
            n().mark(function e() {
              return n().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      if ((q(), !L.value.source)) {
                        e.next = 9;
                        break;
                      }
                      return (e.next = 4), X();
                    case 4:
                      if (I.value) {
                        e.next = 7;
                        break;
                      }
                      return (e.next = 7), f();
                    case 7:
                      e.next = 11;
                      break;
                    case 9:
                      return (e.next = 11), f();
                    case 11:
                    case "end":
                      return e.stop();
                  }
              }, e);
            })
          )
        ),
        a.onMounted(function () {
          try {
            a.index.setPageOrientation &&
              a.index.setPageOrientation({ orientation: "landscape" });
          } catch (e) {
            console.log("设置横屏失败", e);
          }
          setTimeout(function () {
            var e = a.index.getSystemInfoSync(),
              n = e.screenWidth,
              t = e.screenHeight,
              r = function (e) {
                return (e / 1624) * n;
              },
              u = function (e) {
                return (e / 750) * t;
              },
              o = u(88),
              i = t - o,
              l = r(600),
              c = 2 * r(80) + 1,
              v = r(80),
              s = n - v - l - c,
              f = r(120),
              d = r(100),
              h = r(100),
              g = u(40),
              p = u(32),
              x = s - f - h,
              m = s - d - h,
              b = i - f - g,
              y = b - d - p;
            (S.value = Math.max(0, x)),
              (k.value = Math.max(0, b)),
              (T.value = Math.max(0, m)),
              (_.value = Math.max(0, y)),
              console.log("悬浮按钮初始位置：", {
                screenWidth: n,
                screenHeight: t,
                headerHeight: o,
                movableAreaWidth: s,
                movableAreaHeight: i,
                executeBtnSize: f,
                clearBtnSize: d,
                marginRight: h,
                marginBottom: g,
                btnSpacing: p,
                leftPanelWidth: l,
                lineMargin: c,
                contentPaddingLeft: v,
                executeBtnX: S.value,
                executeBtnY: k.value,
                clearBtnX: T.value,
                clearBtnY: _.value,
              });
          }, 100),
            console.log("动作组合页面已加载");
        });
      var A = function () {
        try {
          a.index.setPageOrientation &&
            a.index.setPageOrientation({ orientation: "portrait" });
        } catch (e) {
          console.log("恢复竖屏失败", e);
        }
      };
      a.onUnmounted(function () {
        b && clearTimeout(b), A();
      }),
        a.onHide(function () {
          B.value && (A(), (B.value = !1));
        });
      var C = function () {
          (B.value = !0),
            A(),
            setTimeout(function () {
              a.index.reLaunch({ url: "/pages/index/index" });
            }, 200);
        },
        N = function (e) {
          var n = e.currentTarget.dataset.action;
          if (n) {
            var t = e.touches[0];
            (y = { x: t.pageX, y: t.pageY }),
              (b = setTimeout(function () {
                var t = JSON.parse(n);
                j(t, e), a.index.vibrateShort({ type: "heavy" });
              }, 500));
          }
        },
        P = function (e) {
          if (b && !h.value) {
            var n = e.touches[0],
              t = Math.abs(n.pageX - y.x),
              a = Math.abs(n.pageY - y.y);
            (t > 10 || a > 10) && (clearTimeout(b), (b = null));
          }
          if (h.value && e.touches && e.touches.length > 0) {
            var r = e.touches[0];
            (p.value = { x: r.pageX - 40, y: r.pageY - 40 }),
              H(r.pageX),
              z(r.pageX, r.pageY);
          }
        },
        O = function (e) {
          b && (clearTimeout(b), (b = null)), h.value && D(e);
        },
        Y = function (e) {
          var n = e.currentTarget.dataset.action;
          if (n && !h.value) {
            var t = JSON.parse(n);
            j(t, e), a.index.vibrateShort({ type: "heavy" });
          }
        },
        j = function (e, n) {
          if (d.value.length >= 20) R("可添加动作已满");
          else if (
            ((g.value = e), (h.value = !0), n.touches && n.touches.length > 0)
          ) {
            var t = n.touches[0];
            p.value = { x: t.pageX - 40, y: t.pageY - 40 };
          }
        },
        H = function (e) {
          var n = a.index.getWindowInfo().screenWidth;
          x.value = e > 0.4 * n;
        },
        z = function (e, n) {
          if (e <= 0.4 * a.index.getWindowInfo().screenWidth) m.value = -1;
          else if (0 !== d.value.length) {
            var t = a.index.createSelectorQuery();
            t.selectAll(".combined-item-wrapper").boundingClientRect(),
              t.exec(function (e) {
                var t;
                if (e && e[0] && 0 !== e[0].length) {
                  for (
                    var a = e[0], r = d.value.length, u = 0;
                    u < a.length;
                    u++
                  ) {
                    var o = a[u],
                      i = o.top + o.height / 2;
                    if (n < i) {
                      r = u;
                      break;
                    }
                  }
                  (m.value = r),
                    console.log("计算插入位置：", {
                      y: n,
                      targetIndex: r,
                      itemsLength: a.length,
                      lastItemBottom:
                        null == (t = a[a.length - 1]) ? void 0 : t.bottom,
                    });
                } else m.value = d.value.length;
              });
          } else m.value = 0;
        },
        D = function (n) {
          var t, r;
          h.value &&
            g.value &&
            (n.changedTouches[0].pageX >
              0.4 * a.index.getWindowInfo().screenWidth &&
              m.value >= 0 &&
              ((t = g.value),
              (r = m.value),
              d.value.length >= 20
                ? R("可添加动作已满")
                : (d.value.splice(r, 0, e({}, t)),
                  a.index.vibrateShort({ type: "medium" }),
                  0 === r ||
                    r === d.value.length - 1 ||
                    "第".concat(r + 1, "位"))),
            (h.value = !1),
            (g.value = null),
            (x.value = !1),
            (m.value = -1));
        },
        E = function () {
          a.index.showModal({
            title: "确认清空",
            content: "确定要清空所有动作吗？",
            success: function (e) {
              e.confirm && (d.value = []);
            },
          });
        },
        J = (function () {
          var e = t(
            n().mark(function e() {
              var t, a;
              return n().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        return (
                          (e.prev = 0),
                          (t = []),
                          d.value.forEach(function (e) {
                            t.push(Number(e.code));
                          }),
                          (e.next = 5),
                          o.actionCoding({ sn: s.value, codeList: t })
                        );
                      case 5:
                        (a = e.sent),
                          "A00000" == a.data.resultCode && R("发送动作成功"),
                          (e.next = 13);
                        break;
                      case 10:
                        (e.prev = 10), (e.t0 = e.catch(0)), console.log(e.t0);
                      case 13:
                      case "end":
                        return e.stop();
                    }
                },
                e,
                null,
                [[0, 10]]
              );
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })(),
        R = function (e) {
          a.index.showToast({ title: e, icon: "none", duration: 2e3 });
        },
        $ = (function () {
          var e = t(
            n().mark(function e() {
              var t;
              return n().wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (
                        (t = W.value[M.value]),
                        (s.value = t.sn),
                        (I.value = !1),
                        (e.next = 5),
                        f()
                      );
                    case 5:
                    case "end":
                      return e.stop();
                  }
              }, e);
            })
          );
          return function () {
            return e.apply(this, arguments);
          };
        })(),
        F = function () {
          (I.value = !1),
            (B.value = !0),
            A(),
            setTimeout(function () {
              a.index.reLaunch({ url: "/pages/index/index" });
            }, 200);
        };
      return function (e, n) {
        var t;
        return a.e(
          {
            a: r._imports_0$4,
            b: a.o(C),
            c: a.f(c.value, function (e, n, t) {
              return {
                a: a.t(e.actionName),
                b: e.img,
                c: e.code,
                d: JSON.stringify(e),
                e: a.o(Y, e.code),
                f: a.o(N, e.code),
                g: a.o(P, e.code),
                h: a.o(O, e.code),
              };
            }),
            d: a.t(d.value.length),
            e: 0 === d.value.length,
          },
          (d.value.length, {}),
          { f: h.value && d.value.length > 0 && 0 === m.value },
          (h.value && d.value.length > 0 && m.value, {}),
          {
            g: a.f(d.value, function (e, n, t) {
              return a.e(
                { a: h.value && m.value === n && n > 0 },
                (h.value && m.value, {}),
                {
                  b: a.t(e.actionName),
                  c: e.img,
                  d: a.o(function (e) {
                    return (function (e) {
                      d.value[e],
                        d.value.splice(e, 1),
                        a.index.vibrateShort({ type: "light" });
                    })(n);
                  }, n),
                  e: n,
                  f: 0 === n ? "2.4vh" : "0",
                  g: n,
                }
              );
            }),
            h: r._imports_1$5,
            i: h.value && d.value.length > 0 && m.value === d.value.length,
          },
          (h.value && d.value.length > 0 && (m.value, d.value.length), {}),
          { j: h.value },
          h.value ? { k: x.value ? 1 : "" } : {},
          { l: d.value.length > 0 },
          d.value.length > 0
            ? {
                m: r._imports_2$5,
                n: a.o(E),
                o: T.value,
                p: _.value,
                q: a.t(w.value ? "停止" : "执行"),
                r: w.value ? 1 : "",
                s: a.o(J),
                t: S.value,
                v: k.value,
              }
            : {},
          { w: h.value },
          h.value
            ? {
                x: null == (t = g.value) ? void 0 : t.img,
                y: p.value.x + "px",
                z: p.value.y + "px",
              }
            : {},
          { A: I.value },
          I.value
            ? {
                B: a.f(W.value, function (e, n, t) {
                  return a.e({ a: M.value === n }, (M.value, {}), {
                    b: a.t(e.productName),
                    c: a.t(e.sn),
                    d: e.sn,
                    e: M.value === n ? 1 : "",
                    f: a.o(function (e) {
                      return (function (e) {
                        M.value = e;
                      })(n);
                    }, e.sn),
                  });
                }),
                C: a.o(F),
                D: a.o($),
                E: a.o(function () {}),
                F: a.o(function () {}),
              }
            : {}
        );
      };
    },
  }),
  l = a._export_sfc(i, [["__scopeId", "data-v-244d8b4c"]]);
wx.createPage(l);
