Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
var n = require("./common/vendor.js");
Math;
var e = n.defineComponent({
  __name: "App",
  setup: function (e) {
    function o(e) {
      n.index.showLoading(),
        e.onUpdateReady(function () {
          n.index.hideLoading(), e.applyUpdate();
        }),
        e.onUpdateFailed(function () {
          n.index.showModal({
            title: "已经有新版本了哟~",
            content: "新版本已经上线啦~，请您删除当前小程序，重新搜索打开哟~",
          });
        });
    }
    return (
      n.onLaunch(function () {
        console.log("App Launch"),
          n.index.setInnerAudioOption({ mixWithOther: !1, obeyMuteSwitch: !1 }),
          (function () {
            if (n.index.canIUse("getUpdateManager")) {
              var e = n.index.getUpdateManager();
              e.onCheckForUpdate(function (t) {
                t.hasUpdate &&
                  n.index.showModal({
                    title: "更新提示",
                    content: "检测到新版本，是否下载新版本并重启小程序？",
                    success: function (t) {
                      t.confirm
                        ? o(e)
                        : t.cancel &&
                          n.index.showModal({
                            title: "温馨提示~",
                            content:
                              "本次版本更新涉及到新的功能添加，旧版本无法正常访问的哦~",
                            showCancel: !1,
                            confirmText: "确定更新",
                            success: function (n) {
                              n.confirm && o(e);
                            },
                          });
                    },
                  });
              });
            } else
              n.index.showModal({
                title: "提示",
                content:
                  "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。",
              });
          })();
      }),
      n.onShow(function () {
        console.log("App Show");
      }),
      n.onHide(function () {
        console.log("App Hide");
      }),
      n.onShareAppMessage(function () {
        return {};
      }),
      n.onShareTimeline(function () {
        return {};
      }),
      function () {}
    );
  },
});
function o() {
  var o = n.createSSRApp(e);
  return o.use(n.createPinia()), { app: o, Pinia: n.Pinia };
}
(e.__runtimeHooks = 6), o().app.mount("#app"), (exports.createApp = o);
